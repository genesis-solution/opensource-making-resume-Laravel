<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\UpdateController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\TaxRateController;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\SocialController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\FaqController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\ResumeController;
use App\Http\Controllers\CoverLetterController;
use App\Http\Controllers\TemplateController;
use App\Http\Controllers\SoftSkillController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\PricingController;
use App\Http\Controllers\WebhookController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Resume_builderController;
use App\Http\Controllers\frontend\Career_blogController;
use App\Http\Controllers\frontend\work_experienceController;
use App\Http\Controllers\frontend\uploadController;
use App\Http\Controllers\frontend\Contact_infoController;
use App\Http\Controllers\frontend\experienceController;
use App\Http\Controllers\frontend\Job_detailController;
use App\Http\Controllers\frontend\EducationController;
use App\Http\Controllers\frontend\Education_detailController;
use App\Http\Controllers\frontend\SkillController;
use App\Http\Controllers\frontend\Skill_DescriptionController;
use App\Http\Controllers\frontend\SummaryController;
use App\Http\Controllers\frontend\Summary_DetailsController;
use App\Http\Controllers\frontend\Resume_templateController;
use App\Http\Controllers\frontend\BuilderController;
use App\Http\Controllers\frontend\Resume_template\Resume_template1Controller;
use Illuminate\Support\Facades\App;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Landing page
Route::get('/', [FrontendController::class, 'index'])->name('landing');

// Install
Route::prefix('install')->group(function () {
    Route::middleware('install')->group(function () {
        Route::get('/', [InstallController::class, 'index'])->name('install');
        Route::get('/requirements', [InstallController::class, 'requirements'])->name('install.requirements');
        Route::get('/permissions', [InstallController::class, 'permissions'])->name('install.permissions');
        Route::get('/database', [InstallController::class, 'database'])->name('install.database');
        Route::get('/account', [InstallController::class, 'account'])->name('install.account');

        Route::post('/database',  [InstallController::class, 'saveDatabaseCredentials']);
        Route::post('/account',  [InstallController::class, 'migrateDatabase']);
    });

    Route::get('/complete', [InstallController::class, 'complete'])->name('install.complete');
});

// Social Login
Route::get('/login/{social}', [SocialController::class, 'socialLogin'])->where('social','twitter|facebook|linkedin|google|github|bitbucket');
Route::get('/login/{social}/callback', [SocialController::class, 'handleProviderCallback'])->where('social','twitter|facebook|linkedin|google|github|bitbucket');

// Contact
Route::get('/contact', [ContactController::class, 'index'])->name('contact');
Route::post('/contact', [ContactController::class, 'sendMessage'])->name('send');

// Pricing
Route::prefix('pricing')->name('pricing')->group(function () {
    Route::get('/', [PricingController::class, 'index']);
});

// Faqs
Route::prefix('faqs')->name('faqs')->group(function () {
    Route::get('/', [FaqController::class, 'frontendFaqs']);
});

// Pages
Route::prefix('pages')->name('pages')->group(function () {
    Route::get('/{slug}', [PageController::class, 'frontendPage']);
});

// Blog
Route::prefix('blog')->name('blog')->group(function () {
    Route::get('/', [PostController::class, 'blog']);
    Route::get('/{slug}', [PostController::class, 'blogPost']);
    Route::get('/category/{slug}', [PostController::class, 'blogPostByCategory']);
    Route::get('/author/{slug}', [PostController::class, 'blogPostByAuthor']);
    Route::get('/tag/{slug}', [PostController::class, 'blogPostByTag']);
});

// Search
Route::prefix('search')->name('search')->group(function () {
    Route::get('/', [PostController::class, 'blogPostSearch']);
});

// Share Profile
Route::prefix('p')->name('p')->group(function () {
    Route::get('/{profile_id}', [UserController::class, 'shareUserProfile']);
    Route::post('/{profile_id}/password', [UserController::class, 'validateProfilePassword']);
});

// Share Resume
Route::prefix('r')->name('r')->group(function () {
    Route::get('/{resume_id}', [ResumeController::class, 'shareUserResume']);
    Route::post('/{resume_id}/password', [ResumeController::class, 'validateResumePassword']);
});

// Share Cover Letter
Route::prefix('c')->name('c')->group(function () {
    Route::get('/{cover_letter_id}', [CoverLetterController::class, 'shareUserCoverLetter']);
    Route::post('/{cover_letter_id}/password', [CoverLetterController::class, 'validateCoverLetterPassword']);
});

// Webhook
Route::post('webhook/paypal', [WebhookController::class, 'paypal'])->name('webhook.paypal');
Route::post('webhook/stripe', [WebhookController::class, 'stripe'])->name('webhook.stripe');
Route::post('webhook/razorpay', [WebhookController::class, 'razorpay'])->name('webhook.razorpay');
Route::post('webhook/paystack', [WebhookController::class, 'paystack'])->name('webhook.paystack');
Route::post('webhook/coinbase', [WebhookController::class, 'coinbase'])->name('webhook.coinbase');
Route::post('webhook/crypto', [WebhookController::class, 'crypto'])->name('webhook.crypto');

// Sitemap
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap.index');

Route::prefix('dashboard')->middleware('auth', 'verified')->name('dashboard.')->group(function () {

    Route::get('/', [UserController::class, 'redirect'])->name('index');

    // User Area
    Route::prefix('user')->name('user.')->group(function () {
        Route::get('/', [UserController::class, 'index'])->name('index');
        
        Route::get('/activities', [UserController::class, 'activities'])->name('activities');
        
        Route::post('/coupon/check', [CouponController::class, 'checkCouponCode'])->name('check');

        Route::post('/avatar', [UserController::class, 'uploadUserAvatar'])->name('avatar');

        Route::post('/subscription/cancel', [UserController::class, 'userCancelSubscription'])->name('subscription.cancel');

        // User Profile Settings
        Route::prefix('settings')->name('settings.')->group(function () {
            Route::get('/', [UserController::class, 'userSettings'])->name('index');
           
            Route::get('/profile', [UserController::class, 'userProfileSettings'])->name('profile');
            Route::get('/profile/{id}/qrcode', [UserController::class, 'shareUserQrCodeProfile'])->name('qrcode');
            
            Route::get('/account', [UserController::class, 'userAccountSettings'])->name('account');
            Route::post('/account/delete', [UserController::class, 'userDeleteAccount'])->name('account.delete');
            
            Route::post('/generate', [UserController::class, 'generateAIUserProfileBio'])->name('generate');

            Route::post('/save', [UserController::class, 'userSettingsSave'])->name('save');

        });

        // User Checkout
        Route::prefix('checkout')->name('checkout.')->group(function () {
            Route::get('/cancelled', [CheckoutController::class, 'cancelled'])->name('cancelled');
            Route::get('/pending', [CheckoutController::class, 'pending'])->name('pending');
            Route::get('/complete', [CheckoutController::class, 'complete'])->name('complete');
            
            Route::get('/{id}', [CheckoutController::class, 'index'])->name('index');
            Route::post('/{id}', [CheckoutController::class, 'startCheckoutProcess']);
        });

        // User Payments
        Route::prefix('payments')->name('payments.')->group(function () {
            Route::get('/', [PaymentController::class, 'userPayments'])->name('index');
        });

        // User Resume Tailoring
        Route::prefix('resume')->name('resume.')->group(function () {
            Route::get('/tailor', [ResumeController::class, 'userResumeTailoring'])->name('tailor');
            Route::post('/action/tailor/generate', [ResumeController::class, 'generateAITailoredResume'])->name('tailor.generate');
        });

        // User Resumes
        Route::prefix('resumes')->name('resumes.')->group(function () {
            Route::get('/', [ResumeController::class, 'index'])->name('index');
            Route::get('/item/{id?}', [ResumeController::class, 'resumeCreateUpdate'])->name('item');

            Route::get('/action/delete/{id}', [ResumeController::class, 'resumeDelete'])->name('delete');
            Route::post('/action/save', [ResumeController::class, 'resumeCreateUpdateSave'])->name('save');
            Route::post('/action/color/reset', [ResumeController::class, 'resetResumeColorPalette'])->name('color.reset');
            Route::post('/action/template/reset', [ResumeController::class, 'resetResumeTemplateColors'])->name('template.reset');
            Route::post('/action/template/preview', [ResumeController::class, 'previewUserResumeTemplate'])->name('template.preview');
            Route::post('/action/summary/generate', [ResumeController::class, 'generateAIResumeProfessionalSummary'])->name('summary.generate');
            Route::post('/action/job/description/generate', [ResumeController::class, 'generateAIResumeJobDescription'])->name('job.description.generate');
            Route::post('/action/volunteer/description/generate', [ResumeController::class, 'generateAIResumeVolunteerDescription'])->name('volunteer.description.generate');

            Route::get('/item/{id}/export/json', [ResumeController::class, 'exportUserJsonResume'])->name('export.json');
            Route::get('/item/{id}/export/txt', [ResumeController::class, 'exportUserTxtResume'])->name('export.txt');
            Route::get('/item/{id}/clone', [ResumeController::class, 'resumeClone'])->name('clone');
            Route::get('/item/{id}/qrcode', [ResumeController::class, 'shareUserQrCodeResume'])->name('qrcode');
        });

        // User Cover Letter
        Route::prefix('cover-letters')->name('cover-letters.')->group(function () {
            Route::get('/', [CoverLetterController::class, 'index'])->name('index');
            Route::get('/item/{id?}', [CoverLetterController::class, 'coverLetterCreateUpdate'])->name('item');
            Route::get('/action/delete/{id}', [CoverLetterController::class, 'coverLetterDelete'])->name('delete');
            Route::post('/action/save', [CoverLetterController::class, 'coverLetterCreateUpdateSave'])->name('save');
            Route::post('/action/generate', [CoverLetterController::class, 'generateAICoverLetterContent'])->name('generate');
            Route::post('/action/color/reset', [CoverLetterController::class, 'resetCoverLetterColorPalette'])->name('color.reset');
            Route::post('/action/template/reset', [CoverLetterController::class, 'resetCoverLetterTemplateColors'])->name('template.reset');
            Route::post('/action/template/preview', [CoverLetterController::class, 'previewUserCoverLetterTemplate'])->name('template.preview');
            Route::post('/action/work-style/{style}', [CoverLetterController::class, 'generateWorkStyleBasedContent']);

            Route::get('/item/{id}/export/pdf', [CoverLetterController::class, 'exportUserPdfCoverLetter'])->name('export.pdf');
            Route::get('/item/{id}/export/txt', [CoverLetterController::class, 'exportUserTxtCoverLetter'])->name('export.txt');

            Route::get('/item/{id}/clone', [CoverLetterController::class, 'coverLetterClone'])->name('clone');
            Route::get('/item/{id}/qrcode', [CoverLetterController::class, 'shareUserQrCodeCoverLetter'])->name('qrcode');

        });

    });

    // Admin Area
    Route::prefix('admin')->middleware('admin', 'license')->name('admin.')->group(function () {
        Route::get('/', [AdminController::class, 'index'])->name('index');
        Route::get('/activities', [AdminController::class, 'activities'])->name('activities');

        // User Management
        Route::prefix('users')->name('users.')->group(function () {
            Route::get('/', [AdminController::class, 'users'])->name('index');
            Route::post('/', [AdminController::class, 'listUsers'])->name('list');
            Route::get('/edit/{id}', [AdminController::class, 'userEdit'])->name('edit');
            Route::get('/delete/{id}', [AdminController::class, 'userDelete'])->name('delete');
            Route::post('/save', [AdminController::class, 'userSave'])->name('save');

        });

        // Coupons Management
        Route::prefix('coupons')->name('coupons.')->group(function () {
            Route::get('/', [CouponController::class, 'index'])->name('index');
            Route::get('/item/{id?}', [CouponController::class, 'couponCreateUpdate'])->name('item');
            Route::get('/action/delete/{id}', [CouponController::class, 'couponDelete'])->name('delete');
            Route::post('/action/save', [CouponController::class, 'couponCreateUpdateSave'])->name('save');
        });

        // Settings
        Route::prefix('settings')->name('settings.')->group(function () {
            Route::get('/', [SettingController::class, 'index'])->name('index');
            Route::get('/general', [SettingController::class, 'general'])->name('general');
            Route::post('/general-save', [SettingController::class, 'saveGeneralSettings']);

            Route::get('/license', [SettingController::class, 'license'])->name('license');
            Route::post('/license', [SettingController::class, 'saveLicenseSettings']);
            Route::post('/license/reset', [SettingController::class, 'resetLicenseSettings'])->name('license.reset');

            Route::get('/openai', [SettingController::class, 'openai'])->name('openai');
            Route::post('/openai-save', [SettingController::class, 'saveOpenAISettings']);

            Route::get('/work-styles', [SettingController::class, 'workStyles'])->name('work-styles');
            Route::post('/work-style-save', [SettingController::class, 'saveWorkStyleSettings']);

            Route::get('/billing', [SettingController::class, 'billing'])->name('billing');
            Route::post('/billing-save', [SettingController::class, 'saveBillingSettings']);

            Route::get('/processor', [SettingController::class, 'processor'])->name('processor');
            Route::post('/processor-save', [SettingController::class, 'saveProcessorSettings']);

            Route::get('/social', [SettingController::class, 'social'])->name('social');
            Route::post('/social-save', [SettingController::class, 'saveSocialLoginSettings']);

            Route::get('/storage', [SettingController::class, 'storage'])->name('storage');
            Route::post('/storage-save', [SettingController::class, 'saveStorageSettings']);

            Route::get('/smtp', [SettingController::class, 'smtp'])->name('smtp');
            Route::post('/smtp-save', [SettingController::class, 'saveSmtpSettings']);
            Route::post('/smtp-test', [SettingController::class, 'smtpTest'])->name('smtp.test');

        });

        // Frontend
        Route::prefix('frontend')->name('frontend.')->group(function () {
            Route::get('/', [FrontendController::class, 'frontendSettings'])->name('index');
            Route::post('/save', [FrontendController::class, 'saveFrontendSettings'])->name('save');

            // Navs Section
            Route::prefix('navs')->name('navs.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendNavs'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendNavCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendNavDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendNavCreateUpdateSave'])->name('save');
            });

            // Stats Section
            Route::prefix('stats')->name('stats.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendStats'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendStatCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendStatDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendStatCreateUpdateSave'])->name('save');
            });

            // Features Section
            Route::prefix('features')->name('features.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendFeatures'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendFeatureCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendFeatureDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendFeatureCreateUpdateSave'])->name('save');
            });

            // Steps Section
            Route::prefix('steps')->name('steps.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendSteps'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendStepCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendStepDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendStepCreateUpdateSave'])->name('save');
            });

            // Resources Section
            Route::prefix('resources')->name('resources.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendResources'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendResourceCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendResourceDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendResourceCreateUpdateSave'])->name('save');
            });

            // Footer Section
            Route::prefix('footer')->name('footer.')->group(function () {
                Route::get('/', [FrontendController::class, 'frontendFooter'])->name('index');
                Route::get('/item/{id?}', [FrontendController::class, 'frontendFooterCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FrontendController::class, 'frontendFooterDelete'])->name('delete');
                Route::post('/action/save', [FrontendController::class, 'frontendFooterCreateUpdateSave'])->name('save');
            });

            // Categories Section
            Route::prefix('categories')->name('categories.')->group(function () {
                Route::get('/', [CategoryController::class, 'index'])->name('index');
                Route::get('/item/{id?}', [CategoryController::class, 'categoryCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [CategoryController::class, 'categoryDelete'])->name('delete');
                Route::post('/action/save', [CategoryController::class, 'categoryCreateUpdateSave'])->name('save');
            });

            // Authors Section
            Route::prefix('authors')->name('authors.')->group(function () {
                Route::get('/', [AuthorController::class, 'index'])->name('index');
                Route::get('/item/{id?}', [AuthorController::class, 'authorCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [AuthorController::class, 'authorDelete'])->name('delete');
                Route::post('/action/generate', [AuthorController::class, 'generateAIAuthorBio'])->name('generate');
                Route::post('/action/save', [AuthorController::class, 'authorCreateUpdateSave'])->name('save');
            });

            // Faqs Section
            Route::prefix('faqs')->name('faqs.')->group(function () {
                Route::get('/', [FaqController::class, 'index'])->name('index');
                Route::get('/item/{id?}', [FaqController::class, 'faqCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [FaqController::class, 'faqDelete'])->name('delete');
                Route::post('/action/save', [FaqController::class, 'faqCreateUpdateSave'])->name('save');
            });

            // Pages Section
            Route::prefix('pages')->name('pages.')->group(function () {
                Route::get('/', [PageController::class, 'index'])->name('index');
                Route::get('/item/{id?}', [PageController::class, 'pageCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [PageController::class, 'pageDelete'])->name('delete');
                Route::post('/action/save', [PageController::class, 'pageCreateUpdateSave'])->name('save');
            });

            // Posts Section
            Route::prefix('posts')->name('posts.')->group(function () {
                Route::get('/', [PostController::class, 'index'])->name('index');
                Route::post('/', [PostController::class, 'listPosts'])->name('list');
                Route::get('/item/{id?}', [PostController::class, 'postCreateUpdate'])->name('item');
                Route::get('/action/delete/{id}', [PostController::class, 'postDelete'])->name('delete');
                Route::post('/action/save', [PostController::class, 'postCreateUpdateSave'])->name('save');
            });
            
        });

        // Plans Management
        Route::prefix('plans')->name('plans.')->group(function () {
            Route::get('/', [PlanController::class, 'index'])->name('index');
            Route::get('/item/{id?}', [PlanController::class, 'planCreateUpdate'])->name('item');
            Route::get('/action/delete/{id}', [PlanController::class, 'planDelete'])->name('delete');
            Route::post('/action/save', [PlanController::class, 'planCreateUpdateSave'])->name('save');
        });

        // Payment Management
        Route::prefix('payments')->name('payments.')->group(function () {
            Route::get('/', [PaymentController::class, 'index'])->name('index');
            Route::post('/', [PaymentController::class, 'listPayments'])->name('list');
            Route::get('/edit/{id?}', [PaymentController::class, 'paymentEdit'])->name('edit');
            Route::get('/delete/{id}', [PaymentController::class, 'paymentDelete'])->name('delete');
            Route::post('/save', [PaymentController::class, 'paymentSave'])->name('save');
        });

        // Tax Rates Management
        Route::prefix('tax-rates')->name('tax-rates.')->group(function () {
            Route::get('/', [TaxRateController::class, 'index'])->name('index');
            Route::get('/item/{id?}', [TaxRateController::class, 'taxRateCreateUpdate'])->name('item');
            Route::get('/action/delete/{id}', [TaxRateController::class, 'taxRateDelete'])->name('delete');
            Route::post('/action/save', [TaxRateController::class, 'taxRateCreateUpdateSave'])->name('save');
        });

        // Template Management
        Route::prefix('templates')->name('templates.')->group(function () {
            Route::get('/', [TemplateController::class, 'index'])->name('index');
            Route::post('/', [TemplateController::class, 'listTemplates'])->name('list');
            Route::get('/edit/{id?}', [TemplateController::class, 'templateEdit'])->name('edit');
            Route::get('/delete/{id}', [TemplateController::class, 'templateDelete'])->name('delete');
            Route::post('/save', [TemplateController::class, 'templateSave'])->name('save');
        });

        // Soft Skills Management
        Route::prefix('soft-skills')->name('soft-skills.')->group(function () {
            Route::get('/', [SoftSkillController::class, 'index'])->name('index');
            Route::post('/', [SoftSkillController::class, 'listSoftSkills'])->name('list');
            Route::get('/item/{id?}', [SoftSkillController::class, 'softSkillCreateUpdate'])->name('item');
            Route::get('/action/delete/{id}', [SoftSkillController::class, 'softSkillDelete'])->name('delete');
            Route::post('/action/save', [SoftSkillController::class, 'softSkillCreateUpdateSave'])->name('save');
        });

        // Update
        Route::prefix('update')->name('update.')->group(function () {
            Route::get('/', [UpdateController::class, 'index'])->name('index');

            Route::get('/file', [UpdateController::class, 'viewFileStep'])->name('file');
            Route::post('/upload', [UpdateController::class, 'uploadFile'])->name('upload');
            Route::get('/percent', [UpdateController::class, 'downloadFilePercent'])->name('percent');
            Route::post('/download', [UpdateController::class, 'downloadFile'])->name('download');

            Route::get('/database', [UpdateController::class, 'viewDatabaseStep'])->name('database');
            Route::post('/database', [UpdateController::class, 'updateDatabase'])->name('update.database');
            
            Route::get('/complete', [UpdateController::class, 'complete'])->name('complete');

            Route::get('/one-click', [UpdateController::class, 'oneClickUpdate'])->name('one-click');
        });

        // Clear Cache
        Route::prefix('clear-cache')->name('clear-cache')->group(function () {
            Route::get('/', [AdminController::class, 'clearAppCache']);
        });

        // About Product
        Route::prefix('about')->name('about')->group(function () {
            Route::get('/', [AdminController::class, 'aboutProduct']);
        });

    });

    // Invoices
    Route::prefix('invoices')->name('invoices.')->group(function () {
        Route::get('/invoice/{id}', [PaymentController::class, 'invoice'])->name('invoice');
        Route::get('/invoice/{id}/view', [PaymentController::class, 'invoiceViewPDF'])->name('view');
        Route::get('/invoice/{id}/send', [PaymentController::class, 'invoiceSendPDF'])->name('send');
        Route::get('/invoice/{id}/download', [PaymentController::class, 'invoiceDownloadPDF'])->name('download');
    });

});
Route::get('/choose_template',[Resume_builderController::class, 'choose_template']);

Route::get('/resume_builder',[Resume_builderController::class, 'index']);
Route::get('/career_blog',[Career_blogController::class, 'index']);
Route::get('/ work_experience',[work_experienceController::class, 'index']);
Route::get('/upload',[uploadController::class, 'index']);
Route::get('/contact_info',[Contact_infoController::class, 'index']);
Route::get('/experience',[experienceController::class, 'index']);
Route::get('/job_detail',[Job_detailController::class, 'index']);
Route::get('/education',[EducationController::class, 'index']);
Route::get('/education_detail',[Education_detailController::class, 'index']);
Route::get('/skill',[SkillController::class, 'index']);
Route::get('/skill_description',[Skill_DescriptionController::class, 'index']);
Route::get('/summary',[SummaryController::class, 'index']);
Route::get('/summary_details',[Summary_DetailsController::class, 'index']);
Route::get('/resume_template',[Resume_templateController::class, 'index']);
Route::get('/1_resume_template',[Resume_template1Controller::class, 'index']);
Route::get('/3_resume_template',[Resume_templateController::class, 'Resume_template_3']);
Route::get('/4_resume_template',[Resume_templateController::class, 'Resume_template_4']);
Route::get('/5_resume_template',[Resume_templateController::class, 'Resume_template_5']);


Route::get('/contact_info1',[Resume_template1Controller::class, 'updateContactInfo']);
Route::get('/job_description',[BuilderController::class, 'job_description']);
Route::get('/job_review',[BuilderController::class, 'job_review']);
Route::get('/education_review',[BuilderController::class, 'education_review']);
Route::get('/how_its_work',[BuilderController::class, 'how_its_work']);
Route::get('/AI_module',[BuilderController::class, 'AI_module']);
Route::get('/languages',[BuilderController::class, 'languages']);
Route::get('/additional_sections',[BuilderController::class, 'additional_sections']);
Route::get('/other',[BuilderController::class, 'other']);
Route::get('/finalize',[BuilderController::class, 'finalize']);
Route::get('/upgrade',[BuilderController::class, 'upgrade']);
Route::get('/payout',[BuilderController::class, 'payout']);



Route::post('/generate', [BuilderController::class, 'generate'])->name('generate');