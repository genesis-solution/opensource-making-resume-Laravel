var environment = window.location.host.split('.')[0].replace('-builder', '').replace('-app', '');
var subdomain = "qa."
  , prefetchScriptName = "prefetchscript.js";
var prefetchRBJsUrl = "";
const getDeviceType = ()=>{
    const ua = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
        return "tablet";
    }
    if (/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
        return "mobile";
    }
    return "desktop";
}
;
switch (environment) {
case "loc":
    subdomain = "loc.";
    prefetchScriptName = "prefetchscript.js";
    break;
case "regression":
case "dev":
case "reg":
    subdomain = "reg.";
    prefetchScriptName = "prefetchscript.js";
    break;
case "pen":
    subdomain = "pen.";
    prefetchScriptName = "prefetchscript.js";
    break;
case "pseudo":
    subdomain = "pseudo.";
    prefetchScriptName = "prefetchscript.js";
    break;
case "staging":
case "stg":
    subdomain = "staging.";
    prefetchScriptName = "prefetchscript.js";
    break;
case "www":
case "app":
case "resumehelp":
    subdomain = "";
    prefetchScriptName = "prefetchscript.js";
    break;
case "aidecv":
    subdomain = "";
    prefetchScriptName = "intlprefetchscript.js";
    break;
}
var hostname = window.location.hostname;
if (hostname.includes('resumehelp.com')) {
    subdomain = subdomain + 'resumehelp.com';
} else if (hostname.includes('aidecv.fr')) {
    prefetchScriptName = "intlprefetchscript.js";
    subdomain = subdomain + 'aidecv.fr';
} else {
    subdomain = subdomain + 'resumehelp.io';
}
var deviceType = getDeviceType(navigator.userAgent);
if (deviceType == "desktop") {
    prefetchRBJsUrl = "https://" + subdomain + "/jresume/scripts/rhv2/" + prefetchScriptName;
} else {
    prefetchRBJsUrl = "https://" + subdomain + "/jresume/mobile/scripts/rhv2/" + prefetchScriptName;
}
function loadPrefetchJs(e, t) {
    var o = document.getElementsByTagName("script")[0]
      , n = document.createElement("script")
      , s = !1;
    n.async = !0,
    n.type = 'text/javascript',
    n.src = e,
    n.onload = n.onreadystatechange = function() {
        s || this.readyState && "complete" != this.readyState && "loaded" != this.readyState || (s = !0,
        typeof t == "function" && t());
    }
    ,
    o.parentNode.insertBefore(n, o);
}
loadPrefetchJs(prefetchRBJsUrl, function() {});
