<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'watermark_position_left', 'value' => '15'],
                ['name' => 'watermark_position_bottom', 'value' => '90'],
                ['name' => 'watermark_dimension_width', 'value' => '75'],
                ['name' => 'watermark_dimension_height', 'value' => '75'],
                ['name' => 'watermark_background_opacity', 'value' => '0.2'],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
