<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_resources', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('icon')->nullable();
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->string('link_title')->nullable();
            $table->string('link_url')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create features entries
        DB::table('frontend_resources')->insert([
            ['order' => '1', 'icon' => 'fa-regular fa-file', 'title' => 'Resources', 'description' => 'Looking for a job is the next stage in creating the career and life you desire. Wouldn\'t it be amazing to have someone helping you enhance your salary, find a better job, and achieve better results?', 'link_title' => 'Resources', 'link_url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'icon' => 'fa-regular fa-life-ring', 'title' => 'Support', 'description' => 'Not every job requirement listed is mandatory. In other words, a job description includes both necessary and preferred qualifications, giving you the opportunity to consider different possibilities.', 'link_title' => 'Support', 'link_url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_resources');
    }
};
