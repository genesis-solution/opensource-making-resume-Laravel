<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('faqs', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('icon')->nullable();
            $table->string('title')->nullable();
            $table->string('category')->nullable();
            $table->text('description')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create faqs entries
        DB::table('faqs')->insert([
            ['order' => '1', 'icon' => 'fa-solid fa-credit-card', 'title' => 'Accepted Payment Methods', 'category' => 'Pricing', 'description' => 'We accept PayPal, Credit card and Bank transfer as our supported payment methods.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'icon' => 'fa-solid fa-credit-card', 'title' => 'Can I change plans?', 'category' => 'Pricing', 'description' => 'You have the ability to change your plan as needed and upon doing so, your current subscription will be immediately cancelled.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'icon' => 'fa-solid fa-credit-card', 'title' => 'Can I cancel my subscription?', 'category' => 'Pricing', 'description' => 'It is possible to cancel your subscription whenever you desire. You\'ll still be able to use the features you paid for until the end of your billing period. After your subscription runs out, you won\'t have access to any of the subscription-based features.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '1', 'icon' => 'fa-solid fa-file-alt', 'title' => 'How many resumes can I create?', 'category' => 'Resumes', 'description' => 'The subscription plan you choose determines the basis for it. To understand the restrictions of each plan, please refer to the pricing section to gather more information.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '1', 'icon' => 'fa-solid fa-file-alt', 'title' => 'How many cover letters will I be able to create?', 'category' => 'Cover Letters', 'description' => 'You can locate the limitations for each plan in the pricing section. Your selection of subscription will determine what those restrictions are.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('faqs');
    }
};
