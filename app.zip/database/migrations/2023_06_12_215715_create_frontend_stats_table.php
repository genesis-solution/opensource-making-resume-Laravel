<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_stats', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create stats entries
        DB::table('frontend_stats')->insert([
            ['order' => '1', 'title' => '1500+', 'description' => 'Resumes', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'title' => '5000+', 'description' => 'Cover Letters', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'title' => '1000+', 'description' => 'Members', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()]
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_stats');
    }
};
