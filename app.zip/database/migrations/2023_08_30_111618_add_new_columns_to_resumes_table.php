<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            $table->text('publications')->after('awards_status')->nullable();
            $table->enum('publications_status', ['0','1'])->after('publications')->default('0');
            $table->text('references')->after('interests_status')->nullable();
            $table->enum('references_status', ['0','1'])->after('references')->default('0');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            //
        });
    }
};
