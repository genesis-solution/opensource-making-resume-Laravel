<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'cookie_consent', 'value' => '1'],
                ['name' => 'cookie_consent_modal_layout', 'value' => 'box'],
                ['name' => 'cookie_consent_modal_position', 'value' => 'bottom'],
                ['name' => 'cookie_consent_modal_orientation', 'value' => 'right'],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
