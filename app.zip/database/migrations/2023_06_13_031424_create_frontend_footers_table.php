<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_footers', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('header')->nullable();
            $table->string('title')->nullable();
            $table->string('url')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create features entries
        DB::table('frontend_footers')->insert([
            ['order' => '1', 'header' => 'Job Seekers', 'title' => 'Create a Resume', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'header' => 'Job Seekers', 'title' => 'Resume Examples', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'header' => 'Job Seekers', 'title' => 'Resume Templates', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'header' => 'Job Seekers', 'title' => 'Cover Letter Templates', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '5', 'header' => 'Job Seekers', 'title' => 'Job Search', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '1', 'header' => 'Career Resources', 'title' => 'Resume Help', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'header' => 'Career Resources', 'title' => 'Job Interview', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'header' => 'Career Resources', 'title' => 'Career', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'header' => 'Career Resources', 'title' => 'Cover Letter', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '5', 'header' => 'Career Resources', 'title' => 'Media Kit', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '1', 'header' => 'Our Company', 'title' => 'About Us', 'url' => '/pages/about', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'header' => 'Our Company', 'title' => 'Pricing', 'url' => '#', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'header' => 'Our Company', 'title' => 'Contact Us', 'url' => '/contact', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'header' => 'Our Company', 'title' => 'Privacy', 'url' => '/pages/privacy-policy', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '5', 'header' => 'Our Company', 'title' => 'Terms', 'url' => '/pages/terms', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_footers');
    }
};
