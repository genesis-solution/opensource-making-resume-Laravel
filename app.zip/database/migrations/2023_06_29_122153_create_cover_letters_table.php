<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cover_letters', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->index('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->string('cover_letter_id', 128)->index('cover_letter_id');
            $table->text('name')->nullable();
            $table->text('content')->nullable();
            $table->integer('template')->nullable();
            $table->string('tpl_topbgcolor', 7)->nullable()->default('#3d3e42');
            $table->string('tpl_toptxtcolor', 7)->nullable()->default('#ffffff');
            $table->text('employer')->nullable();
            $table->text('skills')->nullable();
            $table->enum('privacy', ['0','1','2'])->default('0');
            $table->text('password')->nullable();
            $table->enum('status', ['0','1'])->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cover_letters');
    }
};
