<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontends', function (Blueprint $table) {
            $table->id();
            $table->string('name', 128);
            $table->text('value')->nullable();
        });

        DB::table('frontends')->insert(
            [
                ['name' => 'frontend_hero', 'value' => '1'],
                ['name' => 'frontend_hero_byline', 'value' => 'Be the Perfect Candidate'],
                ['name' => 'frontend_hero_headline', 'value' => 'Create a professional resume and cover letter'],
                ['name' => 'frontend_hero_description', 'value' => 'Resumaine will give all the help you need to quickly generate high-quality, professional resume in minutes.'],
                ['name' => 'frontend_hero_image', 'value' => 'img/landing/hero.svg'],
                ['name' => 'frontend_hero_button', 'value' => 'Get Started'],
                ['name' => 'frontend_hero_button_url', 'value' => '#'],
                ['name' => 'frontend_stats', 'value' => '1'],
                ['name' => 'frontend_stats_headline', 'value' => 'get hired faster'],
                ['name' => 'frontend_stats_description', 'value' => 'our stats'],
                ['name' => 'frontend_stats_highlight_words', 'value' => 'our'],
                ['name' => 'frontend_features', 'value' => '1'],
                ['name' => 'frontend_features_headline', 'value' => 'Make your professional resume in minutes'],
                ['name' => 'frontend_features_description', 'value' => 'Our service features top-notch software for creating cover letters and resumes. If you\'re in a hurry to start working, our tools make it easy to generate personalized applications for multiple job openings efficiently.'],
                ['name' => 'frontend_features_highlight_words', 'value' => 'professional, in minutes'],
                ['name' => 'frontend_declare', 'value' => '1'],
                ['name' => 'frontend_declare_byline', 'value' => 'Your resume made easy'],
                ['name' => 'frontend_declare_headline', 'value' => 'Beautiful ready-to-use resume templates'],
                ['name' => 'frontend_declare_description', 'value' => 'Our Resume Builder offers a wide range of attractive templates. Every template in the Resume Builder is designed to automatically format your resume to ensure it maintains a professional appearance regardless of the content you add.'],
                ['name' => 'frontend_declare_highlight_words', 'value' => 'ready-to-use, templates'],
                ['name' => 'frontend_declare_image', 'value' => 'img/landing/declare.svg'],
                ['name' => 'frontend_declare_link_text', 'value' => 'Get Started'],
                ['name' => 'frontend_declare_link_url', 'value' => '#'],
                ['name' => 'frontend_pricing', 'value' => '1'],
                ['name' => 'frontend_pricing_headline', 'value' => 'Get your next job, faster!'],
                ['name' => 'frontend_pricing_description', 'value' => 'Our job-winning resume-writing service will help you show employers you’re the perfect fit.'],
                ['name' => 'frontend_pricing_highlight_words', 'value' => 'faster'],
                ['name' => 'frontend_appeal', 'value' => '1'],
                ['name' => 'frontend_appeal_byline', 'value' => 'Powerful Outcome'],
                ['name' => 'frontend_appeal_headline', 'value' => 'Want job offers from top companies?'],
                ['name' => 'frontend_appeal_description', 'value' => 'Build your resume and follow in the footsteps of countless job seekers today! Our job-winning resume-writing service helps users secure competitive positions at leading companies.'],
                ['name' => 'frontend_appeal_highlight_words', 'value' => 'job offers, top'],
                ['name' => 'frontend_appeal_image', 'value' => 'img/landing/appeal.svg'],
                ['name' => 'frontend_appeal_link_text', 'value' => 'The next step'],
                ['name' => 'frontend_appeal_link_url', 'value' => '#'],
                ['name' => 'frontend_tryout', 'value' => '1'],
                ['name' => 'frontend_tryout_headline', 'value' => 'Try our professional Resume builder now!'],
                ['name' => 'frontend_tryout_description', 'value' => 'Create a resume and cover letter with ease that will impress employers and help you land a job quickly. Say goodbye to writer\'s block and struggles with formatting. Quickly generate a flawless resume that employers will appreciate.'],
                ['name' => 'frontend_tryout_highlight_words', 'value' => 'professional, builder'],
                ['name' => 'frontend_tryout_button', 'value' => 'Create My Resume'],
                ['name' => 'frontend_tryout_button_url', 'value' => '#'],
                ['name' => 'frontend_steps', 'value' => '1'],
                ['name' => 'frontend_steps_headline', 'value' => 'Are you ready to level up your job hunt?'],
                ['name' => 'frontend_steps_description', 'value' => 'Increase your chance of securing interviews and receiving job offers by following these four tried-and-tested steps.'],
                ['name' => 'frontend_steps_highlight_words', 'value' => 'ready, job hunt'],
                ['name' => 'frontend_steps_image', 'value' => 'img/landing/steps.svg'],
                ['name' => 'frontend_carryout', 'value' => '1'],
                ['name' => 'frontend_carryout_headline', 'value' => 'Prove You’re the Perfect Candidate'],
                ['name' => 'frontend_carryout_description', 'value' => 'Once you’re done completing your resume, customize it using one of our professional templates for each job. Do not just settle for submitting it, stand out by having an exceptional resume.'],
                ['name' => 'frontend_carryout_highlight_words', 'value' => 'prove, perfect'],
                ['name' => 'frontend_carryout_button', 'value' => 'Build My Resume'],
                ['name' => 'frontend_carryout_button_url', 'value' => '#'],
                ['name' => 'frontend_faqs', 'value' => '1'],
                ['name' => 'frontend_faqs_headline', 'value' => 'Frequently Asked Questions'],
                ['name' => 'frontend_faqs_description', 'value' => 'Find answers to the typical questions or issues that users frequently encounter.'],
                ['name' => 'frontend_faqs_highlight_words', 'value' => 'questions'],
                ['name' => 'frontend_resources', 'value' => '1'],
                ['name' => 'frontend_footer', 'value' => '1'],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontends');
    }
};
