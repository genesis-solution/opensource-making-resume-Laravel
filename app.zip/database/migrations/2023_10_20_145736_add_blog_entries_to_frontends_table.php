<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });

        DB::table('frontends')->insert(
            [
                ['name' => 'frontend_blog', 'value' => '1'],
                ['name' => 'frontend_blog_headline', 'value' => 'Career Guidance and Professional Journey'],
                ['name' => 'frontend_blog_description', 'value' => 'Learn about the top recommendations for career guidance and acquire valuable knowledge that will assist you in initiating and enhancing your professional journey and search for employment.'],
                ['name' => 'frontend_blog_highlight_words', 'value' => 'guidance, professional'],
            ]

        );

        DB::table('frontend_navs')->insert([
            ['order' => '2', 'title' => 'Blog', 'url' => '/blog', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()]
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });
    }
};
