<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });

         DB::table('frontends')->insert(
            [
                ['name' => 'frontend_templates', 'value' => '1'],
                ['name' => 'frontend_templates_headline', 'value' => 'Proven resume and cover letter templates'],
                ['name' => 'frontend_templates_description', 'value' => 'The collection of classic templates in our library that have successfully helped numerous individuals secure employment opportunities.'],
                ['name' => 'frontend_templates_highlight_words', 'value' => 'resume, cover letter'],
                ['name' => 'frontend_contact', 'value' => '1'],
                ['name' => 'frontend_contact_headline', 'value' => 'Get in touch with us'],
                ['name' => 'frontend_contact_description', 'value' => 'Reach out, and let us turn your questions into solutions.'],
                ['name' => 'frontend_contact_highlight_words', 'value' => 'touch, us'],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });
    }
};
