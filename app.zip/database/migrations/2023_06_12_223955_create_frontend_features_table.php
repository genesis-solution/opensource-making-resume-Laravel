<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_features', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('icon')->nullable();
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create features entries
        DB::table('frontend_features')->insert([
            ['order' => '1', 'icon' => 'fa-solid fa-robot', 'title' => 'Powerful Builder Software', 'description' => 'Our cover letter and resume builder software, developed by professionals, has been refined to perfection. Utilizing our tools will ultimately result in hours of time and effort saved.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'icon' => 'fa-solid fa-user-tie', 'title' => 'Job-Winning Examples', 'description' => 'Looking for some inspiration before sending in your application? Browse through a wide range of resume, cover letter, and CV samples for various jobs and life circumstances.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'icon' => 'fa-solid fa-list', 'title' => 'Frequently Asked Questions', 'description' => 'If you are unable to find answers to your most important career-related questions, our FAQ library is a helpful resource to begin your search and find professional solutions.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'icon' => 'fa-solid fa-file-alt', 'title' => 'Resume and cover letter template', 'description' => 'There are various formats available for resume and cover letter templates. Once you finish creating your resume or cover letter, you can download the chosen template.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '5', 'icon' => 'fa-solid fa-map-signs', 'title' => 'Expert Writing Guides', 'description' => 'Crafting a resume and writing a cover letter can be made simple by utilizing our exceptional software tool that effortlessly guides you through each step.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '6', 'icon' => 'fa-regular fa-life-ring', 'title' => 'Additional Career Resources', 'description' => 'Templates for resumes and cover letters, suggestions for crafting thank you and recommendation letters, tips for acing interviews, and additional resources.', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_features');
    }
};
