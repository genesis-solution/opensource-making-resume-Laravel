<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('frontend_footers', function (Blueprint $table) {
            $table->unsignedBigInteger('category_id')->after('header')->index('category_id');
        });

        DB::statement("UPDATE `frontend_footers` SET `category_id` = '1'");

        DB::table('frontend_footers as f')
            ->rightjoin('categories as c', 'f.header', '=', 'c.title')
                ->update([ 'f.category_id' => DB::raw("`c`.`id`") ]);

        Schema::table('frontend_footers', function (Blueprint $table) {
            $table->foreign('category_id')->references('id')->on('categories');
            $table->dropColumn('header');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('frontend_footers', function (Blueprint $table) {
            //
        });
    }
};
