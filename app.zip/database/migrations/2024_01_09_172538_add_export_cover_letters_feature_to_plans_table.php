<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('plans', function (Blueprint $table) {
            //
        });

        foreach (DB::table('plans')->select('*')->cursor() as $row) {
            $features = json_decode($row->features);

            DB::statement("UPDATE `plans` SET `features` = :features WHERE `id` = :id", ['features' => json_encode(['resumes' => $features->resumes, 'cover_letters' => $features->cover_letters, 'ai_generated_content' => $features->ai_generated_content, 'white_label_resumes' => $features->white_label_resumes, 'white_label_cover_letters' => $features->white_label_cover_letters, 'resume_tailoring' => $features->resume_tailoring, 'export_resumes' => $features->export_resumes, 'export_cover_letters' => '0']), 'id' => $row->id]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('plans', function (Blueprint $table) {
            //
        });
    }
};
