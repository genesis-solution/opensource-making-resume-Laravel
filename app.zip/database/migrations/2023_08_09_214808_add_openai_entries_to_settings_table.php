<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'openai', 'value' => '0'],
                ['name' => 'openai_key', 'value' => NULL],
                ['name' => 'openai_completions_model', 'value' => 'gpt-3.5-turbo'],
                ['name' => 'openai_creativity', 'value' => '0.5'],
                ['name' => 'openai_variations', 'value' => '1'],
                ['name' => 'openai_request_timeout', 'value' => '5'],
                ['name' => 'openai_request_user_agent', 'value' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36'],
                ['name' => 'openai_user_bio_prompt', 'value' => 'Create a professional summary under 500 characters that showcases my skills, experiences relevant to a :occupation role, and includes my :yoe years of experience in this role.'],
                ['name' => 'openai_resume_summary_prompt', 'value' => 'Create a professional summary under 500 characters that showcases my skills, experiences relevant to a :ptitle role, and includes my :pyoe years of experience in this role.'],
                ['name' => 'openai_cover_letter_content_prompt', 'value' => 'Write only body and call to action without header, salutation, letter ending and signature part, for a cover letter for the :jtitle position at :company. I want to highlight my expertise in :ptitle and my :pyoe years of experience, my ability in :skills, and how it can help :company company stay ahead of the competition in regards to this position.  Keep it short and professional with no more than four paragraphs. The tone should be professional yet approachable.'],
            ]
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
