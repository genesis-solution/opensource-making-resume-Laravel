<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::update("UPDATE `settings` SET `value` = '<p>I was enthusiastic to come across the <strong>:tJobTitle</strong> position at <strong>:company</strong> while actively seeking out new creative activities. With my background in <strong>:skill1</strong> and my forward-thinking approach, I am confident in my ability to make worthwhile contributions to your team.</p><p>Finding innovative approaches and improved solutions to business challenges deeply inspire and motivate me. I believe that careful observation, seeking inspiration, and staying determined are the key foundations of achieving success. I strongly believe that by introducing fresh perspectives and adopting new techniques, businesses can adapt and thrive. Just like <strong>:company</strong>, I aim to remain at the forefront of advancements. In my previous role as <strong>:cJobTitle</strong>, I achieved success by utilizing crucial skills such as <strong>:skill2</strong> and <strong>:skill3</strong>. I have also honed my ability to delegate and have built a reputation as a valuable contributor through interpersonal skills and motivation. I am a team player who actively seeks opportunities to share insightful knowledge. With these attributes, I have the capacity to drive positive change and make a substantial impact.</p><p>To gain a better understanding of my experience and skills, kindly refer to my enclosed resume. I am enthusiastic about discussing this further with you and sincerely thank you for taking the time to consider me.</p>' WHERE `name` = 'cover_letter_work_style_artistic'");

        DB::update("UPDATE `settings` SET `value` = '<p>As a highly motivated individual with strong skills in delegation and significant experience in <strong>:tJobTitle</strong>, I was excited to discover the available position of <strong>:company</strong>. I am enthusiastic about expressing my interest as being considered for this opportunity with <strong>:company</strong> would be a significant milestone in my career. I firmly believe that my professional experience and determination align perfectly with the requirements of this role, making me an excellent candidate.</p><p>I excel when faced with demanding and rapid situations, always aiming for favorable outcomes by utilizing my abilities in <strong>:skill1</strong> and <strong>:skill2</strong>. Additionally, I have extensive knowledge in <strong>:skill3</strong> and possess the talent to enhance performance and motivate my colleagues. I can envision success and come up with innovative and successful approaches to attain it. I have successfully managed to prioritize both organizational objectives and constructive relationships, strategizing and suggesting methods to obtain and sustain a competitive advantage in business. My interpersonal skills and ability to inspire have played a crucial role in my professional development.</p><p>Please find attached my resume for your perusal. I anticipate reaching out to you in the coming week to further discuss the next phase of your hiring procedure. In conclusion, I sincerely appreciate the time and consideration you have given to my application.</p>' WHERE `name` = 'cover_letter_work_style_enterprising'");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
