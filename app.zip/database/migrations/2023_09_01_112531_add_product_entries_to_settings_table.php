<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'license_product_market_name', 'value' => NULL],
                ['name' => 'license_product_support_expiry', 'value' => NULL],
                ['name' => 'license_product_latest_version', 'value' => NULL],
                ['name' => 'license_product_release_date', 'value' => NULL],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
