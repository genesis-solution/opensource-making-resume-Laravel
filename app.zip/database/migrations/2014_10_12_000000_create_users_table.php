<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('firstname', 20);
            $table->string('lastname', 35);
            $table->string('email')->unique();
            $table->string('password');
            $table->timestamp('email_verified_at')->nullable();
            $table->enum('gender', array('Male','Female'))->default('Male');
            $table->enum('role', ['user','admin'])->default('user');
            $table->string('phone', 15)->nullable();
            $table->string('avatar')->nullable();
            $table->text('avatar_path')->nullable();
            $table->text('address')->nullable();
            $table->string('occupation', 60)->nullable();
            $table->text('bio')->nullable();
            $table->string('timezone', 64)->nullable();
            $table->unsignedInteger('plan_id')->default(1)->index('plan_id');
            $table->string('plan_amount', 32)->nullable();
            $table->string('plan_currency', 12)->nullable();
            $table->string('plan_interval', 16)->nullable();
            $table->string('plan_payment_processor', 32)->nullable();
            $table->string('plan_subscription_id', 128)->nullable();
            $table->string('plan_subscription_status', 32)->nullable();
            $table->timestamp('plan_created_at')->nullable();
            $table->timestamp('plan_recurring_at')->nullable();
            $table->timestamp('plan_trial_ends_at')->nullable();
            $table->timestamp('plan_ends_at')->nullable();
            $table->text('social')->nullable();
            $table->enum('status', ['0','1'])->default('1');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
