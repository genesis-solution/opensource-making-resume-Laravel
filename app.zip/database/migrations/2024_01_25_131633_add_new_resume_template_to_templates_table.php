<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            //
        });

        DB::table('templates')->insert([
            ['name' => 'Template 22','image' => 'img/template/resume-template-22.jpg','resource_id' => '22','order' => '22','type' => 'R','top_colors' => json_encode(['position' => 'top','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'No','subheader_background' => 'Yes','subheader_title' => 'Yes','subheader_byline' => 'No','subheader_description' => 'No']),'top_colors_status' => '1','sidebar_colors' => json_encode(['position' => 'left','background' => 'Yes','header_background' => 'No','header_title' => 'Yes','header_description' => 'No','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'sidebar_colors_status' => '1','content_colors' => json_encode(['position' => 'right','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'Yes','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'content_colors_status' => '1','status' => '1'],
        ]);

        DB::table('templates')->insert([
            ['name' => 'Template 23','image' => 'img/template/resume-template-23.jpg','resource_id' => '23','order' => '23','type' => 'R','top_colors' => json_encode(['position' => 'top','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'No','subheader_background' => 'Yes','subheader_title' => 'Yes','subheader_byline' => 'No','subheader_description' => 'No']),'top_colors_status' => '1','sidebar_colors' => json_encode(['position' => 'right','background' => 'Yes','header_background' => 'No','header_title' => 'Yes','header_description' => 'No','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'sidebar_colors_status' => '1','content_colors' => json_encode(['position' => 'left','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'Yes','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'content_colors_status' => '1','status' => '1'],
        ]);

        DB::table('templates')->where('resource_id', 22)->where('type', 'R')->update(['top_default_colors' => json_encode(['background' => '#f5f5f5','header_background' => '#ffffff', 'header_title' => '#191d21','header_description' => '#ffffff','subheader_background' => '#f5f5f5','subheader_title' => '#191d21','subheader_byline' => '#ffffff','subheader_description' => '#ffffff']),'sidebar_default_colors' => json_encode(['background' => '#ffffff','header_background' => '#ffffff','header_title' => '#191d21','header_description' => '#191d21','subheader_background' => '#ffffff','subheader_title' => '#191d21','subheader_byline' => '#191d21','subheader_description' => '#595c5e']),'content_default_colors' => json_encode(['background' => '#ffffff','header_background' => '#ffffff', 'header_title' => '#191d21','header_description' => '#191D21','subheader_background' => '#ffffff','subheader_title' => '#191D21','subheader_byline' => '#98a6ad','subheader_description' => '#3B3B3B'])]);

        DB::table('templates')->where('resource_id', 23)->where('type', 'R')->update(['top_default_colors' => json_encode(['background' => '#f5f5f5','header_background' => '#ffffff', 'header_title' => '#191d21','header_description' => '#ffffff','subheader_background' => '#f5f5f5','subheader_title' => '#191d21','subheader_byline' => '#ffffff','subheader_description' => '#ffffff']),'sidebar_default_colors' => json_encode(['background' => '#ffffff','header_background' => '#ffffff','header_title' => '#191d21','header_description' => '#191d21','subheader_background' => '#ffffff','subheader_title' => '#191d21','subheader_byline' => '#191d21','subheader_description' => '#595c5e']),'content_default_colors' => json_encode(['background' => '#ffffff','header_background' => '#ffffff', 'header_title' => '#191d21','header_description' => '#191D21','subheader_background' => '#ffffff','subheader_title' => '#191D21','subheader_byline' => '#98a6ad','subheader_description' => '#3B3B3B'])]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            //
        });
    }
};
