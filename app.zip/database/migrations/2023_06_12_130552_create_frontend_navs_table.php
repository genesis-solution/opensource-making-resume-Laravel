<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_navs', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('title')->nullable();
            $table->string('url')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create navigation menu entries
        DB::table('frontend_navs')->insert([
            ['order' => '1', 'title' => 'Home', 'url' => '/', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'title' => 'Pricing', 'url' => '/pricing', 'status' => '0', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'title' => 'Faqs', 'url' => '/faqs', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'title' => 'Contact', 'url' => '/contact', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()]
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_navs');
    }
};
