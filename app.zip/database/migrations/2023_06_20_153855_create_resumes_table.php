<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;


return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resumes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->index('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->string('resume_id', 128)->index('resume_id');
            $table->text('name')->nullable();
            $table->integer('template')->nullable();
            $table->string('tpl_topbgcolor', 7)->nullable()->default('#3d3e42');
            $table->string('tpl_toptxtcolor', 7)->nullable()->default('#ffffff');
            $table->string('tpl_sidebgcolor', 7)->nullable()->default('#f5f5f5');
            $table->string('tpl_sidetxtcolor', 7)->nullable()->default('#191d21');
            $table->text('employments')->nullable();
            $table->text('education')->nullable();
            $table->text('languages')->nullable();
            $table->text('skills')->nullable();
            $table->enum('privacy', ['0','1','2'])->default('0');
            $table->text('password')->nullable();
            $table->enum('status', ['0','1'])->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resumes');
    }
};
