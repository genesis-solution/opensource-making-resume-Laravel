<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'openai_resume_tailoring_prompt', 'value' => 'I want you to act as a resume reviewer. I will provide you with my resume, and the job description I am applying for. :breakline My resume is: :resumeTxtContent :breakline The job description i am applying for is: :targetJobDescription :breakline You\'ll go over it and provide feedback in :lang language of how tailored my resume is for the job. Then, at the end you will provide the revision of my resume and make it sound better. I want the resume to have a formal, professional tone, as I will be applying to a corporation. The language should be :lang.'],
                ['name' => 'openai_resume_tailoring_with_cover_letter_prompt', 'value' => 'I want you to act as a resume reviewer. I will provide you with my resume, and the job description I am applying for. :breakline My resume is: :resumeTxtContent :breakline The job description i am applying for is: :targetJobDescription :breakline You\'ll go over it and provide feedback in :lang language of how tailored my resume is for the job. Then, at the end you will provide the revision of my resume and make it sound better; and a concise cover letter body to compliment the revised resume. I want the resume and cover letter to have a formal, professional tone, as I will be applying to a corporation. The language should be :lang.'],
            ]
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
