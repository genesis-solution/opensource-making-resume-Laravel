<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->string('slug')->nullable();
            $table->text('description')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        DB::table('pages')->insert([
            ['title' => 'Terms of Use', 'slug' => 'terms', 'description' => '<h2>Terms of Use</h2>', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['title' => 'Privacy Policy', 'slug' => 'privacy-policy', 'description' => '<h2>Privacy Policy</h2>', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['title' => 'About Us', 'slug' => 'about', 'description' => '<h2>About Us</h2>', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pages');
    }
};
