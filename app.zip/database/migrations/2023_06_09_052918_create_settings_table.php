<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('name', 128);
            $table->text('value')->nullable();
        });

        DB::table('settings')->insert(
            [
                ['name' => 'site_name', 'value' => 'Resumaine'],
                ['name' => 'site_url', 'value' => NULL],
                ['name' => 'site_email', 'value' => NULL],
                ['name' => 'site_meta_title', 'value' => 'Resumaine'],
                ['name' => 'site_meta_description', 'value' => 'Resumaine helps you leave a lasting impression with an exceptional resume. Crafting a resume is a skill, and we are experts in this field. Don\'t settle for simply applying, distinguish yourself with an outstanding resume.'],
                ['name' => 'site_meta_keywords', 'value' => 'resumaine, resume, cover letters, templates, job, work, candidate, employer, employee'],
                ['name' => 'site_logo', 'value' => ''],
                ['name' => 'site_favicon', 'value' => ''],
                ['name' => 'site_facebook', 'value' => NULL],
                ['name' => 'site_twitter', 'value' => NULL],
                ['name' => 'site_linkedin', 'value' => NULL],
                ['name' => 'site_pinterest', 'value' => NULL],
                ['name' => 'site_youtube', 'value' => NULL],
                ['name' => 'site_github', 'value' => NULL],
                ['name' => 'site_behance', 'value' => NULL],
                ['name' => 'site_instagram', 'value' => NULL],
                ['name' => 'site_tiktok', 'value' => NULL],
                ['name' => 'site_theme_color', 'value' => '#6777ef'],
                ['name' => 'site_bg_primary_color', 'value' => '#697ded'],
                ['name' => 'site_bg_secondary_color', 'value' => '#5e30c1'],
                ['name' => 'site_button_color', 'value' => '#6777ef'],
                ['name' => 'site_button_hover_color', 'value' => '#394eea'],
                ['name' => 'site_custom_css', 'value' => NULL],
                ['name' => 'site_custom_js', 'value' => NULL],
                ['name' => 'registration', 'value' => '1'],
                ['name' => 'subscription', 'value' => '0'],
                ['name' => 'license_product_id', 'value' => NULL],
                ['name' => 'license_user', 'value' => NULL],
                ['name' => 'license_key', 'value' => NULL],
                ['name' => 'license_type', 'value' => NULL],
                ['name' => 'legal_cookie_url', 'value' => '/pages/privacy-policy#cookies'],
                ['name' => 'legal_privacy_url', 'value' => '/pages/privacy-policy'],
                ['name' => 'legal_terms_url', 'value' => '/pages/terms'],
                ['name' => 'billing_vendor', 'value' => NULL],
                ['name' => 'billing_website', 'value' => NULL],
                ['name' => 'billing_phone', 'value' => NULL],
                ['name' => 'billing_street', 'value' => NULL],
                ['name' => 'billing_city', 'value' => NULL],
                ['name' => 'billing_state', 'value' => NULL],
                ['name' => 'billing_postal', 'value' => NULL],
                ['name' => 'billing_country', 'value' => NULL],
                ['name' => 'billing_invoice_prefix', 'value' => 'INV'],
                ['name' => 'billing_vat_number', 'value' => NULL],
                ['name' => 'currency', 'value' => 'USD'],
                ['name' => 'timezone', 'value' => 'UTC'],
                ['name' => 'stripe', 'value' => '0'],
                ['name' => 'stripe_publishable_key', 'value' => NULL],
                ['name' => 'stripe_secret_key', 'value' => NULL],
                ['name' => 'stripe_webhook_signing_secret', 'value' => NULL],
                ['name' => 'paypal', 'value' => '0'],
                ['name' => 'paypal_mode', 'value' => NULL],
                ['name' => 'paypal_client_id', 'value' => NULL],
                ['name' => 'paypal_client_secret', 'value' => NULL],
                ['name' => 'paypal_email', 'value' => NULL],
                ['name' => 'paypal_webhook_id', 'value' => NULL],
                ['name' => 'bank', 'value' => '0'],
                ['name' => 'bank_account_owner', 'value' => NULL],
                ['name' => 'bank_name', 'value' => NULL],
                ['name' => 'bank_routing_number', 'value' => NULL],
                ['name' => 'bank_account_number', 'value' => NULL],
                ['name' => 'bank_bic_swift', 'value' => NULL],
                ['name' => 'bank_iban', 'value' => NULL],
                ['name' => 'google_analytics', 'value' => '0'],
                ['name' => 'google_analytics_code', 'value' => NULL],
                ['name' => 'google_adsense', 'value' => '0'],
                ['name' => 'google_adsense_code', 'value' => NULL],
                ['name' => 'google_recaptcha', 'value' => '0'],
                ['name' => 'google_recaptcha_site_key', 'value' => NULL],
                ['name' => 'google_recaptcha_secret_key', 'value' => NULL],
                ['name' => 'facebook', 'value' => '0'],
                ['name' => 'facebook_app_id', 'value' => NULL],
                ['name' => 'facebook_app_secret', 'value' => NULL],
                ['name' => 'facebook_redirect_url', 'value' => NULL],
                ['name' => 'twitter', 'value' => '0'],
                ['name' => 'twitter_consumer_key', 'value' => NULL],
                ['name' => 'twitter_consumer_secret', 'value' => NULL],
                ['name' => 'twitter_redirect_url', 'value' => NULL],
                ['name' => 'linkedin', 'value' => '0'],
                ['name' => 'linkedin_app_id', 'value' => NULL],
                ['name' => 'linkedin_app_secret', 'value' => NULL],
                ['name' => 'linkedin_redirect_url', 'value' => NULL],
                ['name' => 'google', 'value' => '0'],
                ['name' => 'google_app_id', 'value' => NULL],
                ['name' => 'google_app_secret', 'value' => NULL],
                ['name' => 'google_redirect_url', 'value' => NULL],
                ['name' => 'github', 'value' => '0'],
                ['name' => 'github_app_id', 'value' => NULL],
                ['name' => 'github_app_secret', 'value' => NULL],
                ['name' => 'github_redirect_url', 'value' => NULL],
                ['name' => 'storage_method', 'value' => 'local'],
                ['name' => 'storage_aws_s3_key', 'value' => NULL],
                ['name' => 'storage_aws_s3_secret', 'value' => NULL],
                ['name' => 'storage_aws_s3_region', 'value' => NULL],
                ['name' => 'storage_aws_s3_bucket', 'value' => NULL],
                ['name' => 'storage_aws_s3_endpoint', 'value' => NULL],
                ['name' => 'smtp', 'value' => '0'],
                ['name' => 'smtp_host', 'value' => NULL],
                ['name' => 'smtp_port', 'value' => NULL],
                ['name' => 'smtp_username', 'value' => NULL],
                ['name' => 'smtp_password', 'value' => NULL],
                ['name' => 'smtp_sender_email', 'value' => NULL],
                ['name' => 'smtp_encryption', 'value' => 'TLS'],
            ]
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
