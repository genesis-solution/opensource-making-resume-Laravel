<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('frontend_steps', function (Blueprint $table) {
            $table->id();
            $table->integer('order')->default(0);
            $table->string('icon')->nullable();
            $table->string('title')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        // Create features entries
        DB::table('frontend_steps')->insert([
            ['order' => '1', 'icon' => 'fa-solid fa-user-tie', 'title' => 'Make a compelling resume', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '2', 'icon' => 'fa-solid fa-file-alt', 'title' => 'Write a complementary cover letter', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '3', 'icon' => 'fa-solid fa-stopwatch', 'title' => 'Get ready for the interview', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['order' => '4', 'icon' => 'fa-solid fa-envelope', 'title' => 'Send a thank-you email', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('frontend_steps');
    }
};
