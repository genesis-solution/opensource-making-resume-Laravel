<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::update("UPDATE `settings` SET `name` = 'site_custom_head_js' WHERE `name` = 'site_custom_js'");

        DB::table('settings')->insert([
            ['name' => 'site_custom_body_js', 'value' => NULL],
            ['name' => 'maintenance', 'value' => '0'],
            ['name' => 'maintenance_description', 'value' => 'Maintenance Mode']
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
