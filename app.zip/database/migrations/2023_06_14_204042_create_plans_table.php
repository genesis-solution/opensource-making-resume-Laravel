<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
            $table->text('description');
            $table->text('tax_rates')->nullable();
            $table->integer('trial_days')->nullable()->default(0);
            $table->string('amount_month', 32)->nullable()->default('0');
            $table->string('amount_year', 32)->nullable()->default('0');
            $table->unsignedInteger('order')->default(0);
            $table->enum('highlight', ['0','1'])->default('0');
            $table->text('features')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        DB::table('plans')->insert([
            'name' => 'Free',
            'description' => 'Free Plan',
            'trial_days' => 0,
            'amount_month' => 0,
            'amount_year' => 0,
            'order' => 0,
            'highlight' => '0',
            'features' => json_encode([
                'resumes' => '1', 
                'cover_letters' => '1',
                'ai_generated_content' => '0',
                'white_label_resumes' => '0', 
                'white_label_cover_letters' => '0',
                'export_resumes' => '0',
            ]),
            'status' => '1',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('plans');
    }
};
