<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            $table->enum('employments_status', ['0','1'])->after('employments')->default('0');
            $table->text('volunteer')->after('employments_status')->nullable();
            $table->enum('volunteer_status', ['0','1'])->after('volunteer')->default('0');
            $table->text('projects')->after('volunteer_status')->nullable();
            $table->enum('projects_status', ['0','1'])->after('projects')->default('0');
            $table->enum('education_status', ['0','1'])->after('education')->default('0');
            $table->text('certificates')->after('education_status')->nullable();
            $table->enum('certificates_status', ['0','1'])->after('certificates')->default('0');
            $table->text('awards')->after('certificates_status')->nullable();
            $table->enum('awards_status', ['0','1'])->after('awards')->default('0');
            $table->enum('languages_status', ['0','1'])->after('languages')->default('0');
            $table->enum('skills_status', ['0','1'])->after('skills')->default('0');
            $table->text('interests')->after('skills_status')->nullable();
            $table->enum('interests_status', ['0','1'])->after('interests')->default('0');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            //
        });
    }
};
