<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('soft_skills', function (Blueprint $table) {
            $table->id();
            $table->string('keyword')->unique();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        DB::table('soft_skills')->insert([
            ['keyword' => 'Active listening', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Adaptability and flexibility', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Adaptability', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Artistic Sense', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Assertiveness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Attention to detail', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Body Language', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Business Ethics', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Business Etiquette', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Business Trend Awareness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Calendar management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Clarity', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Coaching', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Collaborating', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Collaboration', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Compassion', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Competitiveness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Confidence', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Conflict Resolution', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Counseling', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Creative Thinking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Creativity', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Crisis Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Critical Thinking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Cross-cultural communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Customer Service', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Dealing with Difficult People', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Decision Making', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Delegation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Dependability', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Design Sense', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Diplomacy', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Disability Awareness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Dispute Resolution', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Diversity Awareness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Effective communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Email management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Emotion Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Emotional Intelligence', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Empathy', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Enthusiasm', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Entrepreneurial Thinking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Ethical', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Event coordination', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Facilitation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Feedback', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Friendliness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Giving Feedback', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Good Attitude ', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Honesty', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Humor', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Innovation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Inspiring', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Integrity', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Intercultural Competence', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Interpersonal Relationships', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Interpersonal', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Interviewing', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Judgement', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Knowledge Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Language Learning', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Leadership', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Listening', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Manager Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Managing Difficult Conversations', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Managing Remote Teams', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Managing Virtual Teams', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Managing', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Mediation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Meeting Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Mentoring', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Motivating', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Motivation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Negotiating', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Negotiation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Networking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Nonverbal communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Observation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Office Coordination', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Office Politics', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Open-mindedness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Organization', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Performance Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Personal Branding', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Persuasion', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Phone Calls', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Physical Communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Planning', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Presentation', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Problem Sensitivity', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Problem-Solving', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Process Improvement', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Public Speaking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Punctuality', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Quick-wittedness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Relationship Building', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Reliability and dependability', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Reliable', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Research', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Resilience', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Scheduling', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Self-Assessment', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Self-Awareness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Self-Confidence', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Self-Leadership', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Selling', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Storytelling', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Strategic Planning', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Strategic Thinking', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Stress Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Summarizing', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Supervising', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Taking Criticism', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Talent Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Teaching', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Team Building', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Team Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Team Oriented', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Team Player', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Teamwork', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Technology Savvy', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Technology Trend Awareness', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Time Management', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Tolerance of Change and Uncertainty', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Train the Trainer', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Training', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Troubleshooting', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Verbal Communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Video Conferencing', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Visual Communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Work Ethic', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Work-Life Balance', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Writing Reports and Proposals', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Writing', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()],
            ['keyword' => 'Written Communication', 'status' => '1', 'created_at' => Carbon::now (), 'updated_at' => Carbon::now ()]
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('soft_skills');
    }
};
