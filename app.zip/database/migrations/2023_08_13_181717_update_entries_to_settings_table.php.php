<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::update("UPDATE `settings` SET `value` = 'Create a professional summary under 500 characters that showcases my skills, experiences relevant to a :ptitle role, and includes my :pyoe years of experience in this role.' WHERE `name` = 'openai_resume_summary_prompt'");

        DB::update("UPDATE `settings` SET `value` = 'Write only body and call to action without header, salutation, letter ending and signature part, for a cover letter for the :jtitle position at :company. I want to highlight my expertise in :ptitle and my :pyoe years of experience, my ability in :skills, and how it can help :company company stay ahead of the competition in regards to this position.  Keep it short and professional with no more than four paragraphs. The tone should be professional yet approachable.' WHERE `name` = 'openai_cover_letter_content_prompt'");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
