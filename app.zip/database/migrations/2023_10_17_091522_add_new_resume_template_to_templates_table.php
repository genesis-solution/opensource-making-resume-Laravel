<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            //
        });

        DB::table('templates')->insert([
            ['name' => 'Template 15','image' => 'img/template/resume-template-15.jpg','resource_id' => '15','order' => '15','type' => 'R','top_colors' => json_encode(['position' => 'top','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'No','subheader_background' => 'Yes','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'No']),'top_colors_status' => '1','sidebar_colors' => json_encode(['position' => 'right','background' => 'No','header_background' => 'No','header_title' => 'No','header_description' => 'No','subheader_background' => 'No','subheader_title' => 'No','subheader_byline' => 'No','subheader_description' => 'No']),'sidebar_colors_status' => '0','content_colors' => json_encode(['position' => 'left','background' => 'Yes','header_background' => 'Yes', 'header_title' => 'Yes','header_description' => 'Yes','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'content_colors_status' => '1','status' => '1'],
            ['name' => 'Template 16','image' => 'img/template/resume-template-16.jpg','resource_id' => '16','order' => '16','type' => 'R','top_colors' => json_encode(['position' => 'top','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'No','subheader_background' => 'Yes','subheader_title' => 'No','subheader_byline' => 'Yes','subheader_description' => 'No']),'top_colors_status' => '1','sidebar_colors' => json_encode(['position' => 'left','background' => 'Yes','header_background' => 'No','header_title' => 'Yes','header_description' => 'No','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'sidebar_colors_status' => '1','content_colors' => json_encode(['position' => 'right','background' => 'Yes','header_background' => 'No', 'header_title' => 'Yes','header_description' => 'Yes','subheader_background' => 'No','subheader_title' => 'Yes','subheader_byline' => 'Yes','subheader_description' => 'Yes']),'content_colors_status' => '1','status' => '1']
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            //
        });
    }
};
