<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });

        DB::table('settings')->insert(
            [
                ['name' => 'openai_resume_job_description_prompt', 'value' => 'Create a compelling work experience based on :jtitle position at :jemployer, from :jstarted till :jended, with 3-5 bullet points that include achievements with metrics, keep it shorter than 500 characters, show only the bullet points, and make it sound more actionable. The language should be :lang.'],
            ]
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            //
        });
    }
};
