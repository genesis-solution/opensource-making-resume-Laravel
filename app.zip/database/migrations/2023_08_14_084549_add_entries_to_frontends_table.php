<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });

        DB::table('frontends')->insert(
            [
                ['name' => 'frontend_footer_title', 'value' => 'Resumaine'],
                ['name' => 'frontend_footer_description', 'value' => 'Resumaine helps you leave a lasting impression with an exceptional resume. Crafting a resume is a skill, and we are experts in this field. Don\'t settle for simply applying, distinguish yourself with an outstanding resume.'],
                ['name' => 'frontend_footer_copyright', 'value' => '© 2023 Resumaine'],
            ]

        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('frontends', function (Blueprint $table) {
            //
        });
    }
};
