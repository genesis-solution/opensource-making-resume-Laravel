<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;


return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('authors', function (Blueprint $table) {
            $table->id();
            $table->string('name', 70);
            $table->string('slug')->nullable();
            $table->string('image')->nullable();
            $table->text('image_path')->nullable();
            $table->string('occupation', 60)->nullable();
            $table->integer('yoe')->default(0);
            $table->text('bio')->nullable();
            $table->string('website')->nullable();
            $table->enum('privacy', ['0','1'])->default('0');
            $table->text('social')->nullable();
            $table->enum('status', ['0','1'])->default('0');
            $table->timestamps();
        });

        DB::table('authors')->insert([
            'name' => 'Admin',
            'slug' => 'admin',
            'occupation' => 'Resume Reviewer',
            'yoe' => '3',
            'bio' => 'As a seasoned resume writer and reviewer, my commitment is to elevate your professional narrative. Meticulously crafting resumes that resonate with employers, I specialize in accentuating your strengths and achievements. With a keen eye for detail and industry-specific insights, I ensure your resume not only meets but exceeds expectations. Your success is my priority.',
            'privacy' => '1',
            'status' => '1',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('authors');
    }
};
