<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('profile_id', 128)->after('plan_ends_at')->index('profile_id')->nullable();
            $table->text('profile_password')->after('profile_id')->nullable();
            $table->integer('resume')->after('profile_password')->nullable();
            $table->text('sections')->after('resume')->nullable();
            $table->text('availability')->after('sections')->nullable();
            $table->enum('availability_status', ['0','1'])->after('availability')->default('0');
            $table->text('preferences')->after('availability_status')->nullable();
            $table->enum('preferences_status', ['0','1'])->after('preferences')->default('0');
            $table->enum('privacy', ['0','1','2'])->after('preferences_status')->default('0');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
        });
    }
};
