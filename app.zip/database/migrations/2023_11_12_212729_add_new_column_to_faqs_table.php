<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('faqs', function (Blueprint $table) {
            $table->unsignedBigInteger('category_id')->after('category')->index('category_id');
        });

        DB::statement("UPDATE `faqs` SET `category_id` = '1'");

        DB::table('faqs as f')
            ->rightjoin('categories as c', 'f.category', '=', 'c.title')
                ->update([ 'f.category_id' => DB::raw("`c`.`id`") ]);

        Schema::table('faqs', function (Blueprint $table) {
            $table->foreign('category_id')->references('id')->on('categories');
            $table->dropColumn('category');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('faqs', function (Blueprint $table) {
            //
        });
    }
};
