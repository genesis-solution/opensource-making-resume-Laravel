<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            $table->string('tpl_contbgcolor', 7)->after('tpl_sidetxtcolor')->nullable()->default('#ffffff');
            $table->string('tpl_conttltxtcolor', 7)->after('tpl_contbgcolor')->nullable()->default('#191d21');
            $table->string('tpl_contsubtltxtcolor', 7)->after('tpl_conttltxtcolor')->nullable()->default('#98a6ad');
            $table->string('tpl_contdesctxtcolor', 7)->after('tpl_contsubtltxtcolor')->nullable()->default('#3b3b3b');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('resumes', function (Blueprint $table) {
            //
        });
    }
};
