<?php

return [

    /**
     * Server Requirements
     *
     */
    'php_version' => '8.1',

    'extensions' => [
        'php' => [
            'BCMath',
            'Ctype',
            'Fileinfo',
            'JSON',
            'Mbstring',
            'OpenSSL',
            'PDO',
            'Tokenizer',
            'XML',
            'Zip',
            'GD',
            'cURL'
        ],
        'apache' => [
            'mod_rewrite',
        ],
    ],

    /**
     * File permissions
     *
     */
    'permissions' => [
        'Files' => [
            '.env',
        ],
        'Folders' =>
            [
                'bootstrap/cache',
                'public/uploads',
                'storage',
                'storage/fonts',
                'storage/framework',
                'storage/framework/cache',
                'storage/framework/cache/data',
                'storage/framework/sessions',
                'storage/framework/views',
                'storage/logs',
            ],
    ],

    /**
     * Installation Steps
     *
     */
    'steps' => [
        [
            'icon' => 'fa-solid fa-home',
            'route' => 'install'
        ],
        [
            'icon' => 'fa-solid fa-tasks',
            'route' => 'install.requirements'
        ],
        [
            'icon' => 'fa-solid fa-folder-open',
            'route' => 'install.permissions'
        ],
        [
            'icon' => 'fa-solid fa-database',
            'route' => 'install.database'
        ],
        [
            'icon' => 'fa-solid fa-user-circle',
            'route' => 'install.account'
        ],
        [
            'icon' => 'fa-solid fa-check',
            'route' => 'install.complete'
        ]
    ],

    /**
     * Update Steps
     *
     */
    'upsteps' => [
        [
            'icon' => 'fa-solid fa-home',
            'route' => 'dashboard.admin.update.index'
        ],
        [
            'icon' => 'fa-regular fa-file-zipper',
            'route' => 'dashboard.admin.update.file'
        ],
        [
            'icon' => 'fa-solid fa-database',
            'route' => 'dashboard.admin.update.database'
        ],
        [
            'icon' => 'fa-solid fa-check',
            'route' => 'dashboard.admin.update.complete'
        ]
    ],
];
