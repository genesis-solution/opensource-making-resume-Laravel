<?php

return [

    'software' => [
        'name'      => 'Resumaine',
        'author'    => 'Carcani',
        'url'       => 'https://carcani.com',
        'api'      => [
            'internal' => 'B6099B15D5C3DFA06ACB',
            'external' => '40A0C7A51CE336BD8E54'
        ],
        'version'   => '8.0.0'
    ]

];
