 <div class="login-brand">
     <a href="/"><img src="{{ config('app.logo') }}"
         alt="{{ config('app.name') }}"
         id="logo"
         width="100"
         class="shadow-light rounded-circle"></a>
 </div>
