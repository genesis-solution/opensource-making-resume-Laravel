<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
	<div class="container justify-content-center">
        <a class="navbar-brand smooth" href="/">
        	<img src="{{ config('app.logo') }}"
		        alt="{{ config('app.name') }}"
		        id="logo"
		        width="50"
		        class="shadow-light rounded-circle">
        </a>
    </div>
 </nav>
