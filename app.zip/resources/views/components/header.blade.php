<nav class="navbar navbar-reverse navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand smooth" href="/"><img src="{{ config('app.logo') }}" alt="logo" width="50" class="shadow-light rounded-circle"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto ml-lg-3 align-items-lg-center">
                    @foreach($navs as $nav)
                        @if($nav->status == 1) 
                        <li class="nav-item"><a href="{{$nav->url}}" class="nav-link">{{$nav->title}}</a></li>
                        @endif
                    @endforeach
                    @if (!Auth::guest())
                    <li class="nav-item d-lg-none d-md-block">
                      <a href="{{ route('dashboard.index') }}" class="nav-link smooth">{{ __('Dashboard') }}</a>
                    </li>
                    @else
                    <li class="nav-item d-lg-none d-md-block">
                      <a href="{{ route('login') }}" class="nav-link smooth">{{ __('Login') }}</a>
                    </li> 
                    @endif
                </ul>
                <ul class="navbar-nav ml-auto align-items-lg-center d-none d-lg-block">
                     @if (!Auth::guest())
                    <li class="ml-lg-3 nav-item">
                        <a href="{{ route('dashboard.index') }}" class="btn btn-round smooth btn-icon icon-left">
                            <i class="fa-solid fa-fire"></i> {{ __('Dashboard') }}
                        </a>
                    </li>
                    @else
                    <li class="ml-lg-3 nav-item">
                        <a href="{{ route('login') }}" class="btn btn-round smooth btn-icon icon-left">
                            <i class="fa-solid fa-sign-in-alt"></i> {{ __('Login') }}
                        </a>
                    </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>