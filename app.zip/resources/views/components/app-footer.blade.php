<footer class="main-footer">
    <div class="footer-left">
        @if( config('frontends.frontend_footer_copyright') )
        <p>{{ config('frontends.frontend_footer_copyright') }}</p>
        @endif
    </div>
    @if(Auth::user()->role == 'admin')
    <div class="footer-right">
        v{{ config('info.software.version') }}
    </div>
    @endif
</footer>
