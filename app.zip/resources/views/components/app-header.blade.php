<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li>
                <a href="#"
                    data-toggle="sidebar"
                    class="nav-link nav-link-lg"><i class="fa-solid fa-bars"></i></a>
            </li>
        </ul>
    </form>
    <ul class="navbar-nav navbar-right">
        @if( config('settings.maintenance') == '1' )
        <li>
            <a href="{{ route('landing') }}" class="badge badge-pill text-white badge-danger">
                <i class="fa-solid fa-circle-exclamation"></i> {{ config('settings.maintenance_description') }}
            </a>
        </li>
        @endif
        @if( config('settings.maintenance') == '0' && config('settings.subscription') && Auth::user()->role == 'user' && Request::user()->planIsDefault() )
        <li>
            <a href="{{ route('pricing') }}" class="badge badge-pill text-white badge-warning">
                <i class="fa-solid fa-crown"></i> {{ __('Upgrade Now') }}
            </a>
        </li>
        @endif
        @if(Auth::user()->role == 'admin')
            @if(version_compare(config('settings.license_product_latest_version'), config('info.software.version'), '>') == true)
            <li class="dropdown dropdown-list-toggle">
                <a href="#" data-toggle="dropdown" 
                    class="nav-link notification-toggle nav-link-lg beep">
                    <i class="far fa-bell"></i>
                </a>
                <div class="dropdown-menu dropdown-list dropdown-menu-right">
                    <div class="dropdown-header">{{ __('Notification') }}</div>
                    <div class="dropdown-list-icons">
                        <a href="{{ url('dashboard/admin/about') }}" class="dropdown-item dropdown-item-unread">
                            <div class="dropdown-item-icon bg-primary text-white">
                                <i class="fa-solid fa-code"></i>
                            </div>
                            <div class="dropdown-item-desc">
                                {{ __('Application :version is available.', ['version' => 'v'. config('settings.license_product_latest_version')]) }}
                                <div class="time text-primary">{{ config('settings.license_product_release_date')!=null && Carbon\Carbon::parse(config('settings.license_product_release_date'))->isFuture() ? Carbon\Carbon::parse(config('settings.license_product_release_date'))->diffForHumans() : __('now') }}</div>
                            </div>
                        </a>
                    </div>
                </div>
            </li>
            @endif
        @endif
        <li class="dropdown">
            <a href="#"
                data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <img alt="image"
                    src="{{ ( Request::user()->avatar_path !=null ? Request::user()->avatar_path : ( Request::user()->avatar !=null ? asset(Request::user()->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                    class="rounded-circle mr-1">
                <div class="d-sm-none d-lg-inline-block">{{ __('Hi') }}, {{ Request::user()->firstname .' '.  Request::user()->lastname }}</div>
            </a>
            <div class="dropdown-menu medium dropdown-menu-right">
                <a href="{{ route('dashboard.user.index') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-tachometer-alt"></i> {{ __('Dashboard') }}
                </a>
                <div class="dropdown-divider"></div>
                <a href="{{ route('dashboard.user.settings.profile') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-user"></i> {{ __('Profile') }}
                </a>
                <a href="{{ route('dashboard.user.settings.account') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-address-book"></i> {{ __('Account') }}
                </a>
                @if( config('settings.subscription') )
                <a href="{{ route('pricing') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-gift"></i> {{ __('Plans') }}
                </a>
                <a href="{{ route('dashboard.user.payments.index') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-shopping-cart"></i> {{ __('Payments') }}
                </a>
                @endif
                <a href="{{ route('dashboard.user.resumes.index') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-file-alt"></i> {{ __('Resumes') }}
                </a>
                <a href="{{ route('dashboard.user.cover-letters.index') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-file"></i> {{ __('Cover Letters') }}
                </a>
                @if(config('settings.openai') && Auth::user()->canUserResumeTailoring() == '1')
                <a href="{{ route('dashboard.user.resume.tailor') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-bullseye"></i> {{ __('Resume Tailoring') }}
                </a>
                @endif
                <a href="{{ route('dashboard.user.settings.index') }}"
                    class="dropdown-item has-icon">
                    <i class="fa-solid fa-cogs"></i> {{ __('Settings') }}
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item has-icon text-danger" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    <i class="fa-solid fa-sign-out-alt"></i> {{ __('Logout') }}
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </div>
        </li>
    </ul>
</nav>
