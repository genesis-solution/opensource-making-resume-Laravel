<div class="text-center mb-3 mt-5 pb-3">
      <div class="btn-group btn-group-toggle" data-toggle="buttons">
          <label class="btn btn-outline-primary active" id="plan-month">
              <input type="radio" name="options" id="plan-month" autocomplete="off" checked>{{ __('Monthly') }}
          </label>
          <label class="btn btn-outline-primary" id="plan-year">
              <input type="radio" name="options" id="plan-year" autocomplete="off">{{ __('Yearly') }}
          </label>
      </div>
  </div>
  <div class="row">
    @foreach($plans->sortBy('order') as $plan)
       @if($plan->status == 1)
       <div class="col-12 col-sm-12 col-md-6 col-lg-4">
          <div class="pricing @if($plan->highlight == 1) pricing-highlight @endif">
              <div class="pricing-title">
                  {{ $plan->name }}
              </div>
              <div class="pricing-padding">
                @if(!$plan->isDefault())
                  <div class="plan-preload plan-month pricing-price d-block">
                      <div>{{ formatMoney($plan->amount_month, config('settings.currency')) }} 
                        <span class="h5 font-weight-bold text-muted">
                            {{ config('settings.currency') }}
                        </span>
                      </div>
                      <div class="text-muted text-lowercase">{{ __('per') }} {{ __('Month') }}</div>

                  </div>
                  <div class="plan-year pricing-price d-none" style="display:none;">
                    <div>{{ formatMoney($plan->amount_year, config('settings.currency')) }} 
                        <span class="h5 font-weight-bold text-muted">
                            {{ config('settings.currency') }}
                        </span>
                      </div>
                      <div class="text-muted text-lowercase">{{ __('per') }} {{ __('Year') }}
                        @if(($plan->amount_month * 12) > $plan->amount_year)
                            <span class="badge badge-success">
                                {{ __(':value% off', ['value' => number_format(((($plan->amount_month*12) - $plan->amount_year)/($plan->amount_month * 12) * 100), 0)]) }}
                            </span>
                        @endif
                      </div>
                  </div>
                  @else
                  <div class="plan-preload plan-month pricing-price d-none d-block">
                      <div>{{ __('Free') }}</div>
                      <div class="text-muted text-lowercase">{{ __('per') }} {{ __('Month') }}</div>
                  </div>

                  <div class="plan-year pricing-price d-none">
                      <div>{{ __('Free') }}</div>
                      <div class="text-muted text-lowercase">{{ __('per') }} {{ __('Year') }}</div>
                  </div>
                  @endif
                  <div class="pricing-details">
                    @if(isset($plan->features->resumes))
                    <div class="pricing-item">
                      @if($plan->features->resumes != 0)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->resumes == 0 ? 'text-muted' : '') }}">
                          @if($plan->features->resumes < 0)
                              {{ __('Unlimited resumes') }}
                          @else($plan->features->resumes)
                              {{ __(($plan->features->resumes == 1 ? ':number Resume' : ':number Resumes'), ['number' => number_format($plan->features->resumes, 0, __('.'), __(','))]) }} <span class="text-muted">/ {{ ucfirst(__('Month')) }}</span>
                          @endif
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->features->cover_letters))
                    <div class="pricing-item">
                      @if($plan->features->cover_letters != 0)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->cover_letters == 0 ? 'text-muted' : '') }}">
                          @if($plan->features->cover_letters < 0)
                              {{ __('Unlimited Cover Letters') }}
                          @else($plan->features->cover_letters)
                              {{ __(($plan->features->cover_letters == 1 ? ':number Cover Letter' : ':number Cover Letters'), ['number' => number_format($plan->features->cover_letters, 0, __('.'), __(','))]) }} <span class="text-muted">/ {{ ucfirst(__('Month')) }}</span>
                          @endif
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->features->ai_generated_content))
                    <div class="pricing-item">
                      @if($plan->features->ai_generated_content != 0)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->ai_generated_content == 0 ? 'text-muted' : '') }}">
                          @if($plan->features->ai_generated_content < 0)
                              {{ __('Unlimited AI-Generated Content') }}
                          @elseif($plan->features->ai_generated_content == 0)
                              {{ __('No AI-Generated Content') }}
                          @else($plan->features->ai_generated_content)
                              {{ __(($plan->features->ai_generated_content == 1 ? ':number AI-Generated Content' : ':number AI-Generated Content'), ['number' => number_format($plan->features->ai_generated_content, 0, __('.'), __(','))]) }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('The amount of requests made to OpenAI for producing AI-Generated Content.') }}"><i class="fa-solid fa-info-circle"></i></span> <span class="text-muted">/ {{ ucfirst(__('Month')) }}</span>
                          @endif
                      </div>
                    </div>
                    @endif

                    @if(config('settings.watermark') == '1' && isset($plan->features->white_label_resumes))
                    <div class="pricing-item">
                      @if($plan->features->white_label_resumes)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->white_label_resumes == 0 ? 'text-muted' : '') }}">
                        {{ __('White Label Resumes') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('White label, without watermark, resumes when printing or saving as PDF.') }}"><i class="fa-solid fa-info-circle"></i></span>
                      </div>
                    </div>
                    @endif

                    @if(config('settings.watermark') == '1' && isset($plan->features->white_label_cover_letters))
                    <div class="pricing-item">
                      @if($plan->features->white_label_cover_letters)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->white_label_cover_letters == 0 ? 'text-muted' : '') }}">
                        {{ __('White Label Cover Letters') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('White label, without watermark, cover letters when printing or saving as PDF.') }}"><i class="fa-solid fa-info-circle"></i></span>
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->features->resume_tailoring))
                    <div class="pricing-item">
                      @if($plan->features->resume_tailoring)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->resume_tailoring == 0 ? 'text-muted' : '') }}">
                        {{ __('Resume Tailoring') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Resume tailoring is the process of adapting your resume to a specific job opening or industry.') }}"><i class="fa-solid fa-info-circle"></i></span>
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->features->export_resumes))
                    <div class="pricing-item">
                      @if($plan->features->export_resumes)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->export_resumes == 0 ? 'text-muted' : '') }}">
                        {{ __('Export Resume Data') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Export Resume Data in JSON or TXT format.') }}"><i class="fa-solid fa-info-circle"></i></span>
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->features->export_cover_letters))
                    <div class="pricing-item">
                      @if($plan->features->export_cover_letters)
                        <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                      @else
                        <div class="pricing-item-icon bg-danger text-white"><i class="fa-solid fa-times"></i></div>
                      @endif

                      <div class="pricing-item-label {{ ($plan->features->export_cover_letters == 0 ? 'text-muted' : '') }}">
                        {{ __('Export Cover Letter Data') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Export Cover Letter Data in TXT format.') }}"><i class="fa-solid fa-info-circle"></i></span>
                      </div>
                    </div>
                    @endif

                    @if(isset($plan->offerings) && $plan->offerings!=null)
                        @foreach (explode(',', $plan->offerings) as $offering)
                        <div class="pricing-item">
                            <div class="pricing-item-icon"><i class="fa-solid fa-check"></i></div>
                            <div class="pricing-item-label">{{ $offering }}</div>
                        </div>
                        @endforeach
                    @endif

                  </div>
              </div>
              <div class="pricing-cta">
                  @auth
                      @if(!$plan->isDefault())
                          @if(Auth::user()->plan_id == $plan->id)
                              <a href="#" class="disabled">{{ __('Active') }}</a>
                          @else
                              <div class="plan-no-animation plan-month d-none d-block">
                                  <a href="{{ route('dashboard.user.checkout.index', ['id' => $plan->id, 'interval' => 'month']) }}">
                                      @if($plan->trial_days > 0 && ! Auth::user()->plan_trial_ends_at)
                                          {{ __('Free trial') }} <i class="fa-solid fa-arrow-right"></i>
                                      @else
                                          {{ __('Subscribe') }} <i class="fa-solid fa-arrow-right"></i>
                                      @endif
                                  </a>
                              </div>
                              <div class="plan-no-animation plan-year d-none">
                                  <a href="{{ route('dashboard.user.checkout.index', ['id' => $plan->id, 'interval' => 'year']) }}">
                                      @if($plan->trial_days > 0 && ! Auth::user()->plan_trial_ends_at)
                                          {{ __('Free trial') }} <i class="fa-solid fa-arrow-right"></i>
                                      @else
                                          {{ __('Subscribe') }} <i class="fa-solid fa-arrow-right"></i>
                                      @endif
                                  </a>
                              </div>
                          @endif
                      @else
                          <div class="btn btn-primary btn-block text-uppercase py-2 disabled">{{ __('Free') }}</div>
                      @endif
                  @else
                      @if( config('settings.registration') == '1')
                          <div class="plan-no-animation plan-month d-none d-block">
                              <a href="{{ route('register', ['plan' => $plan->id, 'interval' => 'month']) }}">{{ __('Register') }} <i class="fa-solid fa-arrow-right"></i></a>
                          </div>
                          <div class="plan-no-animation plan-year d-none">
                              <a href="{{ route('register', ['plan' => $plan->id, 'interval' => 'year']) }}">{{ __('Register') }} <i class="fa-solid fa-arrow-right"></i></a>
                          </div>
                      @else
                          <div class="plan-no-animation plan-month d-none d-block">
                              <a href="{{ route('login', ['plan' => $plan->id, 'interval' => 'month']) }}">{{ __('Login') }} <i class="fa-solid fa-arrow-right"></i></a>
                          </div>
                          <div class="plan-no-animation plan-year d-none">
                              <a href="{{ route('login', ['plan' => $plan->id, 'interval' => 'year']) }}">{{ __('Login') }} <i class="fa-solid fa-arrow-right"></i></a>
                          </div>
                      @endif
                  @endauth
              </div>
          </div>
      </div>
      @endif
    @endforeach
  </div>