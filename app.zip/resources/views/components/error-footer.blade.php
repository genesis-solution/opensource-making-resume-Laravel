<div class="simple-footer mt-5">
    @if( config('frontends.frontend_footer_copyright') )
    <p>{{ config('frontends.frontend_footer_copyright') }}</p>
    @endif
</div>
