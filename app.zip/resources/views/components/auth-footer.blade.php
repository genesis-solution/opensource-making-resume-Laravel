  <div class="simple-footer">
    @if( config('frontends.frontend_footer_copyright') )
    <p>{{ config('frontends.frontend_footer_copyright') }}</p>
    @endif
  </div>
