<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
             <a href="/"><img src="{{ config('app.logo') }}"
                 alt="{{ config('app.name') }}"
                 id="logo"
                 width="50"
                 class="shadow-light rounded-circle"></a>
         </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="/">{{ substr(config('app.name'), 0, 2) }}</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">{{ __('Dashboard') }}</li>
            <li class="nav-item dropdown">
                <a href="{{ url('dashboard') }}"
                    class="nav-link"><i class="fa-solid fa-tachometer-alt"></i><span>{{ __('Dashboard') }}</span></a>
            </li>
            @if(Auth::user()->role == 'user')
            @if( config('settings.subscription') )
            <li class="menu-header">{{ __('Subscription Area') }}</li>
            <li class="{{ ( Request::is('*/pricing') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('pricing') }}"><i class="fa-solid fa-gift"></i> <span>{{ __('Plans') }}</span></a>
            </li>
            <li class="{{ ( Request::is('*/payments') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.user.payments.index') }}"><i class="fa-solid fa-shopping-cart"></i> <span>{{ __('Payments') }}</span></a>
            </li>
            @endif
            <li class="menu-header">{{ __('Resume Area') }}</li>
            <li class="{{ ( Request::is('*/resumes') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.user.resumes.index') }}"><i class="fa-solid fa-file-alt"></i> <span>{{ __('Resumes') }}</span></a>
            </li>
            @if(config('settings.openai') && Auth::user()->canUserResumeTailoring() == '1')
            <li class="{{ ( Request::is('*/tailor') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.user.resume.tailor') }}"><i class="fa-solid fa-bullseye"></i> <span>{{ __('Resume Tailoring') }}</span></a>
            </li>
            @endif
            <li class="menu-header">{{ __('Cover Letter Area') }}</li>
            <li class="{{ ( Request::is('*/cover-letters') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.user.cover-letters.index') }}"><i class="fa-solid fa-file"></i> <span>{{ __('Cover Letters') }}</span></a>
            </li>
            <li class="menu-header">{{ __('Settings Area') }}</li>
            <li class="nav-item dropdown">
                <a href="#"
                    class="nav-link has-dropdown"><i class="fa-solid fa-cogs"></i> <span>{{ __('Settings') }}</span></a>
                <ul class="dropdown-menu">
                    <li class="{{ ( Request::is('*/profile') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.user.settings.profile') }}"><i class="fa-solid fa-user"></i> <span>{{ __('Profile') }}</span></a>
                    </li>
                    <li class="{{ ( Request::is('*/account') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.user.settings.account') }}"><i class="fa-solid fa-address-book"></i> <span>{{ __('Account') }}</span></a>
                    </li>
                </ul>
            </li>
            @endif
            @if(Auth::user()->role == 'admin')
            <li class="menu-header">{{ __('Frontend Area') }}</li>
            <li class="{{ Request::is('*/frontend') ? 'active' : '' }}">
                <a class="nav-link"
                    href="{{ route('dashboard.admin.frontend.index') }}"><i class="fa-solid fa-flag">
                    </i> <span>{{ __('Frontend') }}</span>
                </a>
            </li>
            <li class="menu-header">{{ __('Users Area') }}</li>
            <li class="{{ ( Request::is('*/users*') ? 'active' : '' ) }}">
                <a class="nav-link"
                        href="{{ route('dashboard.admin.users.index') }}"><i class="fa-solid fa-users"></i> <span>{{ __('Users') }}</span></a></li>
            @if( config('settings.subscription') )
            <li class="menu-header">{{ __('Subscription Area') }}</li>
            <li class="{{ ( Request::is('*/plans*') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.admin.plans.index') }}"><i class="fa-solid fa-gift"></i> <span>{{ __('Plans') }}</span></a></li>
            <li class="{{ ( Request::is('*/coupons*') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.admin.coupons.index') }}"><i class="fa-solid fa-tags"></i> <span>{{ __('Coupons') }}</span></a></li>
            <li class="{{ ( Request::is('*/payments*') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.admin.payments.index') }}"><i class="fa-solid fa-shopping-cart"></i> <span>{{ __('Payments') }}</span></a></li>
            <li class="{{ ( Request::is('*/tax-rates*') ? 'active' : '' ) }}">
                <a class="nav-link"
                    href="{{ route('dashboard.admin.tax-rates.index') }}"><i class="fa-solid fa-percentage"></i> <span>{{ __('Tax Rates') }}</span></a></li>
            @endif
            <li class="menu-header">{{ __('Settings Area') }}</li>
            <li class="nav-item dropdown">
                <a href="{{ route('dashboard.admin.settings.index') }}"
                    class="nav-link has-dropdown"><i class="fa-solid fa-cogs"></i> <span>{{ __('Settings') }}</span></a>
                <ul class="dropdown-menu">
                    <li class="{{ ( Request::is('*/general') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.general') }}"><i class="fa-solid fa-cog"></i> <span>{{ __('General') }}</span></a></li>
                    @if( config('settings.subscription') )
                    <li class="{{ ( Request::is('*/billing') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.billing') }}"><i class="fa-solid fa-file-invoice-dollar"></i> <span>{{ __('Billing') }}</span></a></li>
                    <li class="{{ ( Request::is('*/processor') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.processor') }}"><i class="fa-solid fa-credit-card"></i> <span>{{ __('Processors') }}</span></a></li>
                    @endif
                    <li class="{{ ( Request::is('*/social') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.social') }}"><i class="fa-solid fa-fire"></i> <span>{{ __('Social Logins') }}</span></a></li>
                    <li class="{{ ( Request::is('*/storage') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.storage') }}"><i class="fa-solid fa-hdd"></i> <span>{{ __('Storage') }}</span></a></li>
                    <li class="{{ ( Request::is('*/smtp') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.smtp') }}"><i class="fa-solid fa-envelope"></i> <span>{{ __('SMTP') }}</span></a></li>
                    <li class="{{ ( Request::is('*/work-styles') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.work-styles') }}"><i class="fa-solid fa-briefcase"></i> <span>{{ __('Work Styles') }}</span></a></li>
                    <li class="{{ ( Request::is('*/templates') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.templates.index') }}"><i class="fa-solid fa-palette"></i> <span>{{ __('Templates') }}</span></a></li>
                    <li class="{{ ( Request::is('*/soft-skills') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.soft-skills.index') }}"><i class="fa-solid fa-bolt"></i> <span>{{ __('Soft Skills') }}</span></a></li>
                    <li class="{{ ( Request::is('*/openai') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.openai') }}"><i class="fa-solid fa-robot"></i> <span>{{ __('OpenAI') }}</span></a></li> 
                    <li class="{{ ( Request::is('*/license') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ route('dashboard.admin.settings.license') }}"><i class="fa-solid fa-key"></i> <span>{{ __('License') }}</span></a></li>        
                </ul>
            </li>
            <li class="menu-header">{{ __('Update Area') }}</li>
            <li class="nav-item dropdown">
                <a href="{{ url('dashboard/admin/update') }}"
                    class="nav-link has-dropdown"><i class="fa-solid fa-sync"></i> <span>{{ __('Update') }}</span></a>
                <ul class="dropdown-menu">
                    <li class="{{ ( Request::is('*/update') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ url('dashboard/admin/update') }}"><i class="fa-solid fa-list-check"></i> <span>{{ __('Multi-Step') }}</span></a></li>
                    <li class="{{ ( Request::is('*/update/one-click') ? 'active' : '' ) }}">
                        <a class="nav-link"
                            href="{{ url('dashboard/admin/update/one-click') }}"><i class="fa-solid fa-hand-pointer"></i> <span>{{ __('One-Click') }}</span></a></li>
                </ul>
            </li>
            <li class="menu-header">{{ __('Cache Area') }}</li>
            <li class="{{ Request::is('*/clear-cache') ? 'active' : '' }}">
                <a class="nav-link"
                    href="{{ url('dashboard/admin/clear-cache') }}" onclick="return confirm('{{__('Are you sure?')}}');"><i class="fa-solid fa-trash">
                    </i> <span>{{ __('Clear Cache') }}</span>
                </a>
            </li>
            <li class="menu-header">{{ __('About Area') }}</li>
            <li class="{{ Request::is('*/about') ? 'active' : '' }}">
                <a class="nav-link"
                    href="{{ url('dashboard/admin/about') }}"><i class="fa-solid fa-info-circle">
                    </i> <span>{{ __('About') }}</span>
                </a>
            </li>
            @endif
        </ul>
    </aside>
</div>
