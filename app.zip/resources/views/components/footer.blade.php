<div class="container">
            <div class="row">
                <div class="col-md-5">
                    @if( config('frontends.frontend_footer_title') )
                    <h3 class="text-capitalize">{{ config('frontends.frontend_footer_title') }}</h3>
                    @endif
                    <div class="pr-lg-5">
                        @if( config('frontends.frontend_footer_description') )
                        <p>{{ config('frontends.frontend_footer_description') }}</p>
                        @endif
                        @if( config('frontends.frontend_footer_copyright') )
                        <p>{{ config('frontends.frontend_footer_copyright') }}</p>
                        @endif
                        @if(config('settings.site_facebook') != null || config('settings.site_twitter') != null || config('settings.site_linkedin') != null || config('settings.site_pinterest') != null || config('settings.site_youtube') != null || config('settings.site_github') != null || config('settings.site_behance') != null || config('settings.site_instagram') != null || config('settings.site_tiktok') != null)
                        <div class="mt-4 social-links">
                            @if ( config('settings.site_facebook') != null )
                            <a href="https://facebook.com/{{ config('settings.site_facebook') }}" target="_blank">
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_twitter') != null )
                            <a href="https://twitter.com/{{ config('settings.site_twitter') }}" target="_blank">
                                <i class="fa-brands fa-x-twitter"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_linkedin') != null )
                            <a href="https://www.linkedin.com/company/{{ config('settings.site_linkedin') }}/" target="_blank">
                                <i class="fa-brands fa-linkedin"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_pinterest') != null )
                            <a href="https://www.pinterest.com/{{ config('settings.site_pinterest') }}/" target="_blank">
                                <i class="fa-brands fa-pinterest"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_youtube') != null )
                            <a href="https://www.youtube.com/{{ config('settings.site_youtube') }}" target="_blank">
                                <i class="fa-brands fa-youtube"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_github') != null )
                            <a href="https://github.com/{{ config('settings.site_github') }}" target="_blank">
                                <i class="fa-brands fa-github"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_behance') != null )
                            <a href="https://www.behance.net/{{ config('settings.site_behance') }}" target="_blank">
                                <i class="fa-brands fa-behance"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_instagram') != null )
                            <a href="https://www.instagram.com/{{ config('settings.site_instagram') }}/" target="_blank">
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                            @endif
                            @if ( config('settings.site_tiktok') != null )
                            <a href="https://www.tiktok.com/{{ config('settings.site_tiktok') }}" target="_blank">
                                <i class="fa-brands fa-tiktok"></i>
                            </a>
                            @endif
                        </div>
                        @endif
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="row">
                        @foreach( collect($footer)->groupBy('category_id') as $items )
                        <div class="col-md-4">
                            <h4>{{ $items[0]->c_title }}</h4>
                            <ul>
                                @foreach( collect($items)->sortBy('f_order') as $item )
                                @if($item->f_status == 1) 
                                <li><a href="{{ $item->f_url }}">{{ $item->f_title }}</a></li>
                                @endif
                                @endforeach
                           </ul>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>