  <div class="simple-footer footer-share">
    @if( config('frontends.frontend_footer_copyright') )
    <p>{{ config('frontends.frontend_footer_copyright') }}</p>
    @endif
  </div>