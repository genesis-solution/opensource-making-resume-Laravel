@extends('layouts.frontend')

@section('title', __('Faqs'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    @if( config('frontends.frontend_faqs') == 1 ) 
    <section id="faqs" class="section section-faqs-inside">
        <div class="container">
            <div class="row mb-5 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h1>{!! $frontend::highlightWords(config('frontends.frontend_faqs_headline'), $frontend::stringtoArray(config('frontends.frontend_faqs_highlight_words'))) !!}</h1>
                    <p class="lead">{{ config('frontends.frontend_faqs_description') }}</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    @foreach( collect($faqs)->groupBy('category_id') as $items )
                            <div class="section-title"><h2>{{ $items[0]->c_title }}</h2></div>
                            <div class="section-faqs">
                            @foreach( collect($items)->sortBy('f_order') as $faq )
                                @if($faq->f_status == '1') 
                                <div class="faq">
                                    <div class="faq-icon">
                                        <i class="{{ $faq->f_icon }}"></i>
                                    </div>
                                    <h3>{{ $faq->f_title }}</h3>
                                    <p>{{ $faq->f_description }}</p>
                                </div>
                                @endif
                            @endforeach
                            </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
    @endif
    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [ @foreach( collect($faqs)->groupBy('category_id') as $items ) @foreach( collect($items)->sortBy('f_order') as $faq ) 
            {
                "@type": "Question",
                "name": "{{ $faq->f_title }}",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "{{ $faq->f_description }}"
                }
                
            }@if (!$loop->last),@endif @endforeach @if (!$loop->last),@endif @endforeach
            
        ]
    }
    </script>
@endpush