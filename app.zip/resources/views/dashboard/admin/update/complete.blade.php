@extends('layouts.app')

@section('title', __('Update Completed'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Complete') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item"><a href="#">{{ __('Update') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Complete') }}</div>
                </div>
            </div>
            <div class="section-body">
                <h2 class="section-title">{{ __('Complete') }}</h2>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                @include('dashboard.admin.update.steps')
                            </div>
                            <div class="card-body">
                                <div class="d-block text-center mb-4 mt-2">
                                    <h5>{{ __('Updated') }}</h5>
                                </div>
                                <div>
                                    <p class="text-center text-muted mb-0">{!! __(':name has been updated.', ['name' => '<span class="font-weight-bold">'.config('info.software.name').'</span>']) !!}</p>
                                </div>
                            </div>
                            <div class="card-footer text-center">
                                <a href="{{ route('landing') }}"
                                    class="btn btn-primary">
                                    {{ __('Finish') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
