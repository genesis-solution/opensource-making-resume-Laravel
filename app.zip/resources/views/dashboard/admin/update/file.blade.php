@extends('layouts.app')

@section('title', __('Update File'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('File') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item"><a href="#">{{ __('Update') }}</a></div>
                    <div class="breadcrumb-item">{{ __('File') }}</div>
                </div>
            </div>
            <div class="section-body">
                <h2 class="section-title">{{ __('File') }}</h2>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                @include('dashboard.admin.update.steps')
                            </div>
                            <div class="card-body">
                                <div class="d-block text-center mb-4 mt-2">
                                    <h5>{{ __('File Update') }}</h5>
                                </div>
                                @if(version_compare(config('settings.license_product_latest_version'), config('info.software.version'), '>') == true)
                                <form id="form-file-upload" onsubmit="uploadFileUpdate(); return false;" 
                                    enctype="multipart/form-data"
                                    class="needs-validation"
                                        novalidate="">
                                    @csrf

                                    <div id="file-upload-area">
                                        <div class="d-block text-center mb-4 mt-2">
                                            <h6>
                                                <small class="text-success">{{ __('Application :version is available.', ['version' => 'v'. config('settings.license_product_latest_version')]) }}</small>
                                            </h6>
                                        </div>
                                        <div id="file-upload" class="row align-items-center">
                                            <div class="form-group col-lg-6 offset-lg-3">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text py-1 px-2"><img src="{{ config('app.logo') }}" style="max-height: 1.625rem" /></span>
                                                    </div>
                                                    <div class="custom-file">
                                                        <input type="file" name="zip_file" id="zip_file" class="custom-file-input" accept="zip">
                                                        <label id="fileLabel" class="custom-file-label" for="zip_file" data-browse="Browse">{{ __('Choose Zip file') }}</label>
                                                    </div>
                                                </div>
                                                <div class="form-text text-muted">{{ __('Upload the latest version of the application in zip format. The file name is software.zip and it can be located inside the main zip file.') }}</div>

                                                @error('zip_file')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="form-group col-lg-6 offset-lg-3">
                                                <div class="progress" style="display:none;">
                                                    <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:0%">0%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="file-upload-btn-area" class="card-footer text-center mt-8">
                                        <button type="submit"
                                            id="file-upload-btn"
                                            class="btn btn-primary">
                                            <i class="fa-solid fa-upload"></i> {{ __('Upload') }}
                                        </button>
                                    </div>
                                </form>
                                @else
                                <div>
                                    <div class="card-icon text-primary row mx-auto justify-content-center">
                                        <i class="fa-solid fa-check" style="font-size: 100px;"></i>
                                    </div>
                                    <div>
                                        <p class="text-center text-muted mb-0">{{ __('You have the latest version.') }}</p>
                                    </div>
                                </div>
                                <div class="card-footer text-center mt-8">
                                    <a href="{{ route('dashboard.admin.update.database') }}"
                                        class="btn btn-primary">
                                        {{ __('Next') }}
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var fileUploadConfirmMsg = "{{ __('Are you sure?') }}";
        var fileUploadNoRecoveryMsg = "{{ __('Before updating the software, you must make a complete backup of your website files and database. Please be aware that if you have made any changes to the files of the software, those modifications will be lost.') }}";

        var fileUploadExtErrorMsg = "{{ __('The file extension must be zip.') }}";
        var fileUploadBtnUploadingMsg = "{{ __('Uploading...') }}";
        var fileUploadBtnExtractingMsg = "{{ __('Validating and Extracting...') }}";
        var fileUpdateSuccess = "{{ __('File Updated Successfully.') }}";

        // Change Image Input Label
        $('#zip_file').change(function() {
            var fileName = $(this)[0].files[0].name != undefined ? $(this)[0].files[0].name : '';
            $(this).parent().find('label').html(fileName);
        });
    </script>
    <script src="{{ asset('js/page/admin-file-upload.min.js?v='. config('info.software.version')) }}"></script>
@endpush
