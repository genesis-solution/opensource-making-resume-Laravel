@extends('layouts.app')

@section('title', __('Update'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Update') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Update') }}</div>
                </div>
            </div>
            <div class="section-body">
                <h2 class="section-title">{{ __('Update') }}</h2>
                
                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="nav flex-column mx-auto">
                                    <ul class="nav nav-pills d-flex justify-content-center">
                                        <li class="nav-item mx-1">
                                            <a href="{{ route('dashboard.index') }}" class="btn btn-primary btn-lg d-flex text-center">
                                                <span><i class="fa-solid fa-home"></i></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="d-block text-center mb-4 mt-2">
                                    <h5>{{ __('Update') }}</h5>
                                </div>
                                @if( config('settings.license_product_support_expiry')!=null && Carbon\Carbon::parse(config('settings.license_product_support_expiry'))->isFuture() )
                                    @if(version_compare(config('settings.license_product_latest_version'), config('info.software.version'), '>') == true)
                                    <div id="form-file-download">
                                        @csrf

                                        <div id="file-download-area">
                                            <div class="d-block text-center mb-4 mt-2">
                                                <h6>
                                                    <small class="text-success">{{ __('Application :version is available.', ['version' => 'v'. config('settings.license_product_latest_version')]) }}</small>
                                                </h6>
                                            </div>
                                            <div class="form-group col-lg-6 offset-lg-3">
                                                <div id="file-download-progress" class="progress" style="display:none;">
                                                    <div class="progress-bar progress-bar-success progress-bar-striped active" id="percent-complete" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:0%">0%</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer text-center mt-8">
                                            <div class="form-group text-center col-lg-6 offset-lg-3">
                                                <button type="submit"
                                                    id="file-download-btn"
                                                    class="btn btn-primary">
                                                    <i class="fa-solid fa-hand-pointer"></i> {{ __('One-Click Update') }}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <div>
                                        <div class="card-icon text-primary row mx-auto justify-content-center">
                                            <i class="fa-solid fa-check" style="font-size: 100px;"></i>
                                        </div>
                                        <div>
                                            <p class="text-center text-muted mb-0">{{ __('You have the latest version.') }}</p>
                                        </div>
                                    </div>
                                    @endif
                                @else
                                    <div class="card-icon text-danger row mx-auto justify-content-center">
                                        <i class="fa-solid fa-times" style="font-size: 100px;"></i>
                                    </div>
                                    <div class="col-lg-6 offset-lg-3">
                                        <p class="text-center text-muted mb-0"><i class="fa-solid fa-info-circle"></i> {!! __('You can no longer use the one-click update feature because your support date has expired. You need to either :renew your support or use the manual update.', ['renew' => '<a href="https://help.carcani.com" target="_blank">'. __('renew') .'</a>']) !!}</p>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var fileDownloadConfirmMsg = "{{ __('Are you sure?') }}";
        var fileDownloadNoRecoveryMsg = "{{ __('Before updating the software, you must make a complete backup of your website files and database. Please be aware that if you have made any changes to the files of the software, those modifications will be lost.') }}";

        var fileDownloadExtErrorMsg = "{{ __('The file extension must be zip.') }}";
        var fileDownloadBtnDownloadingMsg = "{{ __('Downloading...') }}";
        var fileDownloadBtnExtractingMsg = "{{ __('Validating, Extracting and Updating...') }}";
        var fileDownloadBtnUpdatedMsg = "{{ __('Application Updated.') }}";
        var fileDownloadUpdatedSuccess = "{{ __('Application Updated Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-file-download.min.js?v='. config('info.software.version')) }}"></script>
@endpush
