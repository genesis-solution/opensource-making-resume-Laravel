    @extends('layouts.app')

@section('title', __('Social Logins'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Social Logins') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Social Logins') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Social Logins') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all social login settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/social-save') }}"
                            enctype="multipart/form-data"
                            id="social-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="facebook-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Social Logins') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Social Login settings such as, integrate login with social media.') }}</p>
                                    <div class="form-group row">
                                        <label for="facebook" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Facebook') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="facebook"
                                                    class="custom-switch-input"
                                                    @if( config('settings.facebook') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="facebook_app_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Facebook App Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="facebook_app_id"
                                                class="form-control @error('facebook_app_id') is-invalid @enderror"
                                                id="facebook_app_id"
                                                value="{{ old('facebook_app_id') ?? config('settings.facebook_app_id') }}">

                                            @error('facebook_app_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="facebook_app_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Facebook App Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="facebook_app_secret"
                                                class="form-control @error('facebook_app_secret') is-invalid @enderror"
                                                id="facebook_app_secret"
                                                value="{{ old('facebook_app_secret') ?? config('settings.facebook_app_secret') }}">

                                            @error('facebook_app_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="facebook_redirect_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Facebook Redirect Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="facebook_redirect_url"
                                                class="form-control @error('facebook_redirect_url') is-invalid @enderror"
                                                id="facebook_redirect_url"
                                                value="{{ old('facebook_redirect_url') ?? config('settings.facebook_redirect_url') }}">

                                             <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/login/<span class="text-primary">facebook</span>/callback</p>

                                            @error('facebook_redirect_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
         
                                    <div class="form-group row">
                                        <label for="twitter" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Twitter') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="twitter"
                                                    class="custom-switch-input"
                                                    @if( config('settings.twitter') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="twitter_consumer_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Twitter Consumer Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="twitter_consumer_key"
                                                class="form-control @error('twitter_consumer_key') is-invalid @enderror"
                                                id="twitter_consumer_key"
                                                value="{{ old('twitter_consumer_key') ?? config('settings.twitter_consumer_key') }}">

                                            @error('twitter_consumer_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="twitter_consumer_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Twitter Consumer Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="twitter_consumer_secret"
                                                class="form-control @error('twitter_consumer_secret') is-invalid @enderror"
                                                id="twitter_consumer_secret"
                                                value="{{ old('twitter_consumer_secret') ?? config('settings.twitter_consumer_secret') }}">

                                            @error('twitter_consumer_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="twitter_redirect_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Twitter Redirect Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="twitter_redirect_url"
                                                class="form-control @error('twitter_redirect_url') is-invalid @enderror"
                                                id="twitter_redirect_url"
                                                value="{{ old('twitter_redirect_url') ?? config('settings.twitter_redirect_url') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/login/<span class="text-primary">twitter</span>/callback</p>

                                            @error('twitter_redirect_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="google" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Google') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="google"
                                                    class="custom-switch-input"
                                                    @if( config('settings.google') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="google_app_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google App Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_app_id"
                                                class="form-control @error('google_app_id') is-invalid @enderror"
                                                id="google_app_id"
                                                value="{{ old('google_app_id') ?? config('settings.google_app_id') }}">

                                            @error('google_app_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="google_app_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google App Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_app_secret"
                                                class="form-control @error('google_app_secret') is-invalid @enderror"
                                                id="google_app_secret"
                                                value="{{ old('google_app_secret') ?? config('settings.google_app_secret') }}">

                                            @error('google_app_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="google_redirect_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google Redirect Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_redirect_url"
                                                class="form-control @error('google_redirect_url') is-invalid @enderror"
                                                id="google_redirect_url"
                                                value="{{ old('google_redirect_url') ?? config('settings.google_redirect_url') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/login/<span class="text-primary">google</span>/callback</p>

                                            @error('google_redirect_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="linkedin" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('LinkedIn') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="linkedin"
                                                    class="custom-switch-input"
                                                    @if( config('settings.linkedin') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="linkedin_app_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('LinkedIn App Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="linkedin_app_id"
                                                class="form-control @error('linkedin_app_id') is-invalid @enderror"
                                                id="linkedin_app_id"
                                                value="{{ old('linkedin_app_id') ?? config('settings.linkedin_app_id') }}">

                                            @error('linkedin_app_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="linkedin_app_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('LinkedIn App Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="linkedin_app_secret"
                                                class="form-control @error('linkedin_app_secret') is-invalid @enderror"
                                                id="linkedin_app_secret"
                                                value="{{ old('linkedin_app_secret') ?? config('settings.linkedin_app_secret') }}">

                                            @error('linkedin_app_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="linkedin_redirect_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('LinkedIn Redirect Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="linkedin_redirect_url"
                                                class="form-control @error('linkedin_redirect_url') is-invalid @enderror"
                                                id="linkedin_redirect_url"
                                                value="{{ old('linkedin_redirect_url') ?? config('settings.linkedin_redirect_url') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/login/<span class="text-primary">linkedin</span>/callback</p>

                                            @error('linkedin_redirect_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="github" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('GitHub') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="github"
                                                    class="custom-switch-input"
                                                    @if( config('settings.github') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="github_app_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('GitHub App Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="github_app_id"
                                                class="form-control @error('github_app_id') is-invalid @enderror"
                                                id="github_app_id"
                                                value="{{ old('github_app_id') ?? config('settings.github_app_id') }}">

                                            @error('github_app_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="github_app_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('GitHub App Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="github_app_secret"
                                                class="form-control @error('github_app_secret') is-invalid @enderror"
                                                id="github_app_secret"
                                                value="{{ old('github_app_secret') ?? config('settings.github_app_secret') }}">

                                            @error('github_app_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="github_redirect_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('GitHub Redirect Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="github_redirect_url"
                                                class="form-control @error('github_redirect_url') is-invalid @enderror"
                                                id="github_redirect_url"
                                                value="{{ old('github_redirect_url') ?? config('settings.github_redirect_url') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/login/<span class="text-primary">github</span>/callback</p>

                                            @error('github_redirect_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
