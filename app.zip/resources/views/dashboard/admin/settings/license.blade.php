@extends('layouts.app')

@section('title', __('License Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('License') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('License') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About License') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all License settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/license') }}"
                            enctype="multipart/form-data"
                            id="license-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="license-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('License') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="license_product_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Product Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="license_product_id"
                                                class="form-control @error('license_product_id') is-invalid @enderror"
                                                id="license_product_id"
                                                value="{{ old('license_product_id') ?? config('settings.license_product_id') }}"
                                                required>

                                            @error('license_product_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="license_user"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Username') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="license_user"
                                                class="form-control @error('license_user') is-invalid @enderror"
                                                id="license_user"
                                                value="{{ old('license_user') ?? config('settings.license_user') }}"
                                                required>

                                            @error('license_user')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="license_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('License Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="license_key"
                                                class="form-control @error('license_key') is-invalid @enderror"
                                                id="license_key"
                                                placeholder="xxxxxxxxx or xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                                                value="{{ old('license_key') ?? config('settings.license_key') }}"
                                                required>

                                            @error('license_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @if( config('settings.license_key') !=null )
                                    <div class="form-group row align-items-center">
                                        <label for="license_type"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('License Type') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="license_type"
                                                class="form-control @error('license_type') is-invalid @enderror"
                                                id="license_type"
                                                value="{{ old('license_type') ?? (config('settings.license_type') ? 'Extended' : 'Regular' ) }}"
                                                readonly>

                                            @error('license_type')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @else
                                    <div class="form-group row align-items-center">
                                        <label for="license_type"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('License Type') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Regular') }}">
                                                    <input type="radio"
                                                        id="type-regular"
                                                        name="license_type"
                                                        class="selectgroup-input"
                                                        value="0" @if( config('settings.license_type') == '0' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Regular') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Extended') }}">
                                                    <input type="radio"
                                                        id="type-extended"
                                                        name="license_type"
                                                        class="selectgroup-input"
                                                        value="1" @if( config('settings.license_type') == '1' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Extended') }}</span>
                                                </label>
                                            </div>

                                            @error('license_type')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke">
                                    @if(config('settings.license_key') != null)
                                    <div class="float-lg-left mb-lg-0 mb-3">
                                        <button class="btn btn-danger" 
                                            id="reset-license-btn" 
                                            onclick="resetLicenseSettings(); return false;">
                                            <i class="fa-solid fa-key"></i> {{ __('Change License') }}
                                        </button>
                                    </div>
                                    @endif
                                    <div class="float-lg-right mb-lg-0 mb-3">
                                        <button class="btn btn-primary"
                                            id="save-btn">{{ __('Save Changes') }}</button>
                                        <button class="btn btn-secondary"
                                            type="reset">{{ __('Reset') }}</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var resetLicenseSettingsSuccess = "{{ __('License Settings Reset Successfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-license-reset.min.js?v='. config('info.software.version')) }}"></script>
@endpush
