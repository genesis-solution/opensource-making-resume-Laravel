@extends('layouts.app')

@section('title', __('General Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/codemirror/lib/codemirror.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/codemirror/theme/duotone-dark.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('General Settings') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('General') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About General Settings') }}</h2>
                <p class="section-lead">
                    {{ __('You can adjust all general settings here') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/general-save') }}"
                            enctype="multipart/form-data"
                            id="general-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="general-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('General') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('General settings such as, site name, site description, address and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="site_name"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Site Name') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="site_name"
                                                class="form-control @error('site_name') is-invalid @enderror"
                                                id="site_name"
                                                value="{{ old('site_name') ?? config('settings.site_name') }}">

                                            @error('site_name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Site Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="site_url"
                                                class="form-control @error('site_url') is-invalid @enderror"
                                                placeholder="e.g.: https://domain.com"
                                                id="site_url"
                                                value="{{ old('site_url') ?? config('settings.site_url') }}">

                                            @error('site_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_email"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Site Email') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="site_email"
                                                class="form-control @error('site_email') is-invalid @enderror"
                                                placeholder="e.g.: support@domain.com"
                                                id="site_email"
                                                value="{{ old('site_email') ?? config('settings.site_email') }}">

                                            @error('site_email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row align-items-center">
                                        <label for="site_meta_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Site Meta Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="site_meta_title"
                                                class="form-control @error('site_meta_title') is-invalid @enderror"
                                                id="site_meta_title"
                                                value="{{ old('site_meta_title') ?? config('settings.site_meta_title') }}">

                                            @error('site_meta_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_meta_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Meta Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('site_meta_description') is-invalid @enderror"
                                                name="site_meta_description"
                                                id="site_meta_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('site_meta_description') ?? config('settings.site_meta_description') }}</textarea>

                                            @error('site_meta_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_meta_keywords"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Site Meta Keywords') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="site_meta_keywords"
                                                class="form-control inputtags @error('site_meta_keywords') is-invalid @enderror"
                                                id="site_meta_keywords"
                                                value="{{ old('site_meta_keywords') ?? config('settings.site_meta_keywords') }}">

                                            @error('site_meta_keywords')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Site Logo') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('app.logo') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="site_logo" id="site_logo" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="site_logo" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 100 pixels in height and 1MB in size.') }}</div>

                                            @error('site_logo')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Site Favicon') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('app.favicon') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="site_favicon" id="site_favicon" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="site_favicon" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 1MB in size.') }}</div>

                                            @error('site_favicon')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="timezone"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Default Timezone') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="timezone" 
                                                name="timezone" 
                                                class="form-control select2 @error('timezone') is-invalid @enderror"
                                            >
                                                @foreach(timezone_identifiers_list() as $value)
                                                    <option value="{{ $value }}" @if ($value == config('settings.timezone')) selected @endif>{{ $value }}</option>
                                                @endforeach
                                            </select>

                                            @error('timezone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="country"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Default Country') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="country" 
                                                name="country" 
                                                class="form-control select2 @error('country') is-invalid @enderror"
                                            >
                                                @include('dashboard.admin.settings.countries', ['provided_country' => config('settings.country')])
                                            </select>

                                            @error('country')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="date_format"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Default Date Format') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="date_format" 
                                                name="date_format" 
                                                class="form-control select2 @error('date_format') is-invalid @enderror"
                                            >
                                                @foreach(listOfDateFormats() as $name => $value)
                                                <option value="{{ $value }}" @if ( (old('date_format') !== null && old('date_format') == $value) || (config('settings.date_format') == $value && old('date_format') == null) ) selected @endif>{{ $name }}</option>
                                                @endforeach
                                            </select>

                                            @error('date_format')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="language"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Default Language') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="language" 
                                                name="language" 
                                                class="form-control select2 @error('language') is-invalid @enderror"
                                            >
                                                @foreach(config('app.languages') as $code => $language)
                                                <option value="{{ $code }}" @if ((old('language') !== null && old('language') == $code) || (config('settings.language') == $code && old('language') == null)) selected @endif>{{ $language['name'] }}</option>
                                                @endforeach
                                            </select>

                                            @error('language')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="registration" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{__('Registration') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Enable or disable the registration.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                             <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="registration"
                                                    class="custom-switch-input"
                                                    @if( config('settings.registration') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="subscription" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{__('Subscription') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Enable or disable the subscription. Extended license is required.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                             <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="subscription"
                                                    class="custom-switch-input"
                                                    @if( config('settings.subscription') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="blog" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{__('Blog') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Enable or disable the blog.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                             <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="blog"
                                                    class="custom-switch-input"
                                                    @if( config('settings.blog') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="legal-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Legal') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="legal_terms_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Terms Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="legal_terms_url"
                                                class="form-control @error('legal_terms_url') is-invalid @enderror"
                                                id="legal_terms_url"
                                                value="{{ old('legal_terms_url') ?? config('settings.legal_terms_url') }}">

                                            @error('legal_terms_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="legal_privacy_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Privacy Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="legal_privacy_url"
                                                class="form-control @error('legal_privacy_url') is-invalid @enderror"
                                                id="legal_privacy_url"
                                                value="{{ old('legal_privacy_url') ?? config('settings.legal_privacy_url') }}">

                                            @error('legal_privacy_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="legal_cookie_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Cookies Url') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="legal_cookie_url"
                                                class="form-control @error('legal_cookie_url') is-invalid @enderror"
                                                id="legal_cookie_url"
                                                value="{{ old('legal_cookie_url') ?? config('settings.legal_cookie_url') }}">

                                            @error('legal_cookie_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="watermark-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Watermark') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="watermark" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{__('Watermark') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Apply a watermark on your resume and cover letter when downloading, exporting, printing or saving as PDF.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="watermark"
                                                    class="custom-switch-input"
                                                    @if( config('settings.watermark') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="watermark_position_left" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Watermark Left Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="watermark_position_left"
                                                class="form-control @error('watermark_position_left') is-invalid @enderror"
                                                id="watermark_position_left"
                                                min="0"
                                                step="any"
                                                value="{{ old('watermark_position_left') ?? config('settings.watermark_position_left') }}">

                                            @error('watermark_position_left')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="watermark_position_bottom" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Watermark Bottom Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="watermark_position_bottom"
                                                class="form-control @error('watermark_position_bottom') is-invalid @enderror"
                                                id="watermark_position_bottom"
                                                min="0"
                                                step="any"
                                                value="{{ old('watermark_position_bottom') ?? config('settings.watermark_position_bottom') }}">

                                            @error('watermark_position_bottom')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="watermark_dimension_width" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Watermark Width Dimension') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="watermark_dimension_width"
                                                class="form-control @error('watermark_dimension_width') is-invalid @enderror"
                                                id="watermark_dimension_width"
                                                min="0"
                                                step="any"
                                                value="{{ old('watermark_dimension_width') ?? config('settings.watermark_dimension_width') }}">

                                            @error('watermark_dimension_width')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="watermark_dimension_height" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Watermark Height Dimension') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="watermark_dimension_height"
                                                class="form-control @error('watermark_dimension_height') is-invalid @enderror"
                                                id="watermark_dimension_height"
                                                min="0"
                                                min="100"
                                                step="any"
                                                value="{{ old('watermark_dimension_height') ?? config('settings.watermark_dimension_height') }}">

                                            @error('watermark_dimension_height')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="watermark_background_opacity" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Watermark Background Opacity') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="watermark_background_opacity"
                                                class="form-control @error('watermark_background_opacity') is-invalid @enderror"
                                                id="watermark_background_opacity"
                                                min="0"
                                                min="1"
                                                step="any"
                                                value="{{ old('watermark_background_opacity') ?? config('settings.watermark_background_opacity') }}">

                                            @error('watermark_background_opacity')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="text-muted text-small mt-3"><i class="fa-solid fa-info-circle"></i> {{ __('The bottom position is only used when downloading. When printing or exporting, the watermark is adjusted to align with the left position by changing its bottom position.') }}</div>
                                </div>
                            </div>
                            <div class="card"
                                id="google-adsense-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Google AdSense') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="google_adsense" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Google AdSense') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="google_adsense"
                                                    class="custom-switch-input"
                                                    @if( config('settings.google_adsense') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="google_adsense_code" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google AdSense Code') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_adsense_code"
                                                class="form-control @error('google_adsense_code') is-invalid @enderror"
                                                id="google_adsense_code"
                                                data-mask="ca-pub-xxxxxxxxxxxxxxxx" 
                                                data-mask-visible="true" 
                                                placeholder="ca-pub-xxxxxxxxxxxxxxxx"
                                                value="{{ old('google_adsense_code') ?? config('settings.google_adsense_code') }}">

                                            @error('google_adsense_code')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="google-analytics-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Google Analytics') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="google_analytics" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Google Analytics') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="google_analytics"
                                                    class="custom-switch-input"
                                                    @if( config('settings.google_analytics') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="google_analytics_code" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google Analytics Code') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_analytics_code"
                                                class="form-control @error('google_analytics_code') is-invalid @enderror"
                                                id="google_analytics_code"
                                                data-mask="G-XXXXXXXXXX" 
                                                data-mask-visible="true" 
                                                placeholder="G-XXXXXXXXXX"
                                                value="{{ old('google_analytics_code') ?? config('settings.google_analytics_code') }}">

                                            @error('google_analytics_code')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="google-recaptcha-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Google ReCaptcha') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="google_recaptcha" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Google ReCaptcha') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="google_recaptcha"
                                                    class="custom-switch-input"
                                                    @if( config('settings.google_recaptcha') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="google_recaptcha_site_key" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google ReCaptcha Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="google_recaptcha_site_key"
                                                class="form-control @error('google_recaptcha_site_key') is-invalid @enderror"
                                                id="google_recaptcha_site_key"
                                                value="{{ old('google_recaptcha_site_key') ?? config('settings.google_recaptcha_site_key') }}">

                                            @error('google_recaptcha_site_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="google_recaptcha_secret_key" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Google ReCaptcha Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="password"
                                                name="google_recaptcha_secret_key"
                                                class="form-control @error('google_recaptcha_secret_key') is-invalid @enderror"
                                                id="google_recaptcha_secret_key"
                                                value="{{ old('google_recaptcha_secret_key') ?? config('settings.google_recaptcha_secret_key') }}">

                                            @error('google_recaptcha_secret_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="cookie-consent-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Cookie Consent') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="cookie_consent" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Cookie Consent') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="cookie_consent"
                                                    class="custom-switch-input"
                                                    @if( config('settings.cookie_consent') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div id="cookie-consent-layout-block" class="form-group row">
                                        <label for="cookie_consent_modal_layout" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Cookie Consent Layout') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    id="cookie-consent-layout-box-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Box') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-layout-box"
                                                        name="cookie_consent_modal_layout"
                                                        class="selectgroup-input"
                                                        value="box" @if( config('settings.cookie_consent_modal_layout') == 'box' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Box') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-layout-cloud-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Cloud') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-layout-cloud"
                                                        name="cookie_consent_modal_layout"
                                                        class="selectgroup-input"
                                                        value="cloud" @if( config('settings.cookie_consent_modal_layout') == 'cloud' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Cloud') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-layout-bar-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Bar') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-layout-bar"
                                                        name="cookie_consent_modal_layout"
                                                        class="selectgroup-input"
                                                        value="bar" @if( config('settings.cookie_consent_modal_layout') == 'bar' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Bar') }}</span>
                                                </label>
                                            </div>

                                            @error('cookie_consent_modal_layout')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div id="cookie-consent-position-block" class="form-group row">
                                        <label for="cookie_consent_modal_position" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Cookie Consent Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    id="cookie-consent-position-top-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Top') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-position-top"
                                                        name="cookie_consent_modal_position"
                                                        class="selectgroup-input"
                                                        value="top" @if( config('settings.cookie_consent_modal_position') == 'top' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Top') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-position-middle-block"
                                                    class="selectgroup-item @if( config('settings.cookie_consent_modal_layout') !=null && config('settings.cookie_consent_modal_layout') == 'bar' ) d-none @endif" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Middle') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-position-middle"
                                                        name="cookie_consent_modal_position"
                                                        class="selectgroup-input"
                                                        value="middle" @if( config('settings.cookie_consent_modal_position') == 'middle' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Middle') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-position-bottom-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Bottom') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-position-bottom"
                                                        name="cookie_consent_modal_position"
                                                        class="selectgroup-input"
                                                        value="bottom" @if( config('settings.cookie_consent_modal_position') == 'bottom' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Bottom') }}</span>
                                                </label>
                                            </div>

                                            @error('cookie_consent_modal_position')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div id="cookie-consent-orientation-block" class="form-group row @if( config('settings.cookie_consent_modal_layout') !=null && config('settings.cookie_consent_modal_layout') == 'bar' ) d-none @endif">
                                        <label for="cookie_consent_modal_orientation" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Cookie Consent Orientation') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    id="cookie-consent-orientation-left-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Left') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-orientation-left"
                                                        name="cookie_consent_modal_orientation"
                                                        class="selectgroup-input"
                                                        value="left" @if( config('settings.cookie_consent_modal_orientation') == 'left' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Left') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-orientation-center-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Center') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-orientation-center"
                                                        name="cookie_consent_modal_orientation"
                                                        class="selectgroup-input"
                                                        value="center" @if( config('settings.cookie_consent_modal_orientation') == 'center' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Center') }}</span>
                                                </label>
                                                <label 
                                                    id="cookie-consent-orientation-right-block"
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Right') }}">
                                                    <input type="radio"
                                                        id="cookie-consent-modal-orientation-right"
                                                        name="cookie_consent_modal_orientation"
                                                        class="selectgroup-input"
                                                        value="right" @if( config('settings.cookie_consent_modal_orientation') == 'right' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Right') }}</span>
                                                </label>
                                            </div>

                                            @error('cookie_consent_modal_orientation')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="tawk-chat-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Live Chat') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="tawk" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Tawk') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Tawk.to is a live chat software that allows you to communicate with your website visitors and app users.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="tawk"
                                                    class="custom-switch-input"
                                                    @if( config('settings.tawk') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tawk_property_id" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tawk Property Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="tawk_property_id"
                                                class="form-control @error('tawk_property_id') is-invalid @enderror"
                                                id="tawk_property_id"
                                                value="{{ old('tawk_property_id') ?? config('settings.tawk_property_id') }}">

                                            @error('tawk_property_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tawk_chat_widget_id" 
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tawk Chat Widget Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="tawk_chat_widget_id"
                                                class="form-control @error('tawk_chat_widget_id') is-invalid @enderror"
                                                id="tawk_chat_widget_id"
                                                value="{{ old('tawk_chat_widget_id') ?? config('settings.tawk_chat_widget_id') }}">

                                            @error('tawk_chat_widget_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="site-theme-card">
                                <div class="card-header">
                                    <h4>{{__('Site Theme Color')}}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="site_theme_color"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Theme Color')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <input type="color"
                                                    name="site_theme_color"
                                                    id="site_theme_color"
                                                    class="form-control"
                                                    value="{{ old('site_theme_color') ?? config('settings.site_theme_color') }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('site_theme_color')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_bg_primary_color"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Background Primary Color')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <input type="color"
                                                    name="site_bg_primary_color"
                                                    id="site_bg_primary_color"
                                                    class="form-control"
                                                    value="{{ old('site_bg_primary_color') ?? config('settings.site_bg_primary_color') }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('site_bg_primary_color')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_bg_secondary_color"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Background Secondary Color')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <input type="color"
                                                    name="site_bg_secondary_color"
                                                    id="site_bg_secondary_color"
                                                    class="form-control"
                                                    value="{{ old('site_bg_secondary_color') ?? config('settings.site_bg_secondary_color') }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('site_bg_secondary_color')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_button_color"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Button Color')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <input type="color"
                                                    name="site_button_color"
                                                    id="site_button_color"
                                                    class="form-control"
                                                    value="{{ old('site_button_color') ?? config('settings.site_button_color') }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('site_button_color')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_button_hover_color"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Site Button Hover Color')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <input type="color"
                                                    name="site_button_hover_color"
                                                    id="site_button_hover_color"
                                                    class="form-control"
                                                    value="{{ old('site_button_hover_color') ?? config('settings.site_button_hover_color') }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('site_button_hover_color')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="css-js-card">
                                <div class="card-header">
                                    <h4>{{__('Custom CSS/JS')}}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="site_custom_css"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Custom CSS')}} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Custom CSS style loaded before the end of header section.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control codeeditor @error('site_custom_css') is-invalid @enderror"
                                                name="site_custom_css"
                                                id="site_custom_css"
                                                data-height="100">{{ old('site_custom_css') ?? config('settings.site_custom_css') }}</textarea>

                                            @error('site_custom_css')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_custom_head_js"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Custom HEAD JS')}} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Custom JS loaded before the end of header section.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control codeeditor @error('site_custom_head_js') is-invalid @enderror"
                                                name="site_custom_head_js"
                                                id="site_custom_head_js"
                                                data-height="100">{{ old('site_custom_head_js') ?? config('settings.site_custom_head_js') }}</textarea>

                                            @error('site_custom_head_js')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="site_custom_body_js"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Custom BODY JS')}} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Custom JS loaded before the end of body section.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control codeeditor @error('site_custom_body_js') is-invalid @enderror"
                                                name="site_custom_body_js"
                                                id="site_custom_body_js"
                                                data-height="100">{{ old('site_custom_body_js') ?? config('settings.site_custom_body_js') }}</textarea>

                                            @error('site_custom_body_js')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card" id="maintenance-card">
                                <div class="card-header">
                                    <h4>{{ __('Blacklist') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="domain_blacklist"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Domain Blacklist') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Users will not be able to register or log in using email addresses from specified domains.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="domain_blacklist"
                                                class="form-control inputtags @error('domain_blacklist') is-invalid @enderror"
                                                id="domain_blacklist"
                                                placeholder="e.g.: domain.com" 
                                                value="{{ old('domain_blacklist') ?? config('settings.domain_blacklist') }}">

                                            @error('domain_blacklist')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="ip_blacklist"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('IP Blacklist') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Users from these IP addresses will be restricted.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="ip_blacklist"
                                                class="form-control inputtags @error('ip_blacklist') is-invalid @enderror"
                                                id="ip_blacklist"
                                                placeholder="e.g.: 192.168.0.0" 
                                                value="{{ old('ip_blacklist') ?? config('settings.ip_blacklist') }}">

                                            @error('ip_blacklist')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card" id="maintenance-card">
                                <div class="card-header">
                                    <h4>{{ __('Whitelist') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="ip_whitelist"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('IP Whitelist') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Users from these IP addresses will be allowed.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="ip_whitelist"
                                                class="form-control inputtags @error('ip_whitelist') is-invalid @enderror"
                                                id="ip_whitelist"
                                                placeholder="e.g.: 192.168.0.0" 
                                                value="{{ old('ip_whitelist') ?? config('settings.ip_whitelist') }}">

                                            @error('ip_whitelist')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card" id="maintenance-card">
                                <div class="card-header">
                                    <h4>{{ __('Maintenance') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="maintenance" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Maintenance') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Add a maintenance notification badge next to the user icon in the upper right corner.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="maintenance"
                                                    class="custom-switch-input"
                                                    @if( config('settings.maintenance') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="maintenance_description" 
                                            class="form-control-label col-sm-3 mt-2 text-md-right">{{ __('Maintenance Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="maintenance_description"
                                                class="form-control @error('maintenance_description') is-invalid @enderror"
                                                id="maintenance_description"
                                                value="{{ old('maintenance_description') ?? config('settings.maintenance_description') }}">

                                            @error('maintenance_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="social-card">
                                <div class="card-header">
                                    <h4>{{ __('Social Media') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_facebook">{{ __('Facebook') }}</label>
                                            <input id="site_facebook"
                                                type="text"
                                                class="form-control @error('site_facebook') is-invalid @enderror"
                                                name="site_facebook"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_facebook') ?? config('settings.site_facebook') }}"
                                                autocomplete="facebook"
                                            >
                                            <p class="text-muted"><small>https://facebook.com/<span class="text-primary">username</span></small></p>

                                            @error('site_facebook')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_twitter">{{ __('Twitter') }}</label>
                                            <input id="site_twitter"
                                                type="text"
                                                class="form-control @error('site_twitter') is-invalid @enderror"
                                                name="site_twitter"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_twitter') ?? config('settings.site_twitter') }}"
                                                autocomplete="twitter"
                                            >
                                            <p class="text-muted"><small>https://twitter.com/<span class="text-primary">username</span></small></p>

                                            @error('site_twitter')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    
                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_linkedin">{{ __('LinkedIn') }}</label>
                                            <input id="site_linkedin"
                                                type="text"
                                                class="form-control @error('site_linkedin') is-invalid @enderror"
                                                name="site_linkedin"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_linkedin') ?? config('settings.site_linkedin') }}"
                                                autocomplete="linkedin"
                                            >
                                            <p class="text-muted"><small>https://www.linkedin.com/company/<span class="text-primary">username</span>/</small></p>

                                            @error('site_linkedin')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_pinterest">{{ __('Pinterest') }}</label>
                                            <input id="site_pinterest"
                                                type="text"
                                                class="form-control @error('site_pinterest') is-invalid @enderror"
                                                name="site_pinterest"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_pinterest') ?? config('settings.site_pinterest') }}"
                                                autocomplete="pinterest"
                                            >
                                            <p class="text-muted"><small>https://www.pinterest.com/<span class="text-primary">username</span>/</small></p>

                                            @error('site_pinterest')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_youtube">{{ __('YouTube') }}</label>
                                            <input id="site_youtube"
                                                type="text"
                                                class="form-control @error('site_youtube') is-invalid @enderror"
                                                name="site_youtube"
                                                data-mask="@handle" 
                                                data-mask-visible="true" 
                                                placeholder="@handle"
                                                value="{{ old('site_youtube') ?? config('settings.site_youtube') }}"
                                                autocomplete="youtube"
                                            >
                                            <p class="text-muted"><small>https://www.youtube.com/<span class="text-primary">@handle</span></small></p>

                                            @error('site_youtube')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_github">{{ __('GitHub') }}</label>
                                            <input id="site_github"
                                                type="text"
                                                class="form-control @error('site_github') is-invalid @enderror"
                                                name="site_github"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_github') ?? config('settings.site_github') }}"
                                                autocomplete="github"
                                            >
                                            <p class="text-muted"><small>https://github.com/<span class="text-primary">username</span></small></p>

                                            @error('site_github')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_behance">{{ __('Behance') }}</label>
                                            <input id="site_behance"
                                                type="text"
                                                class="form-control @error('site_behance') is-invalid @enderror"
                                                name="site_behance"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_behance') ?? config('settings.site_behance') }}"
                                                autocomplete="behance"
                                            >
                                            <p class="text-muted"><small>https://www.behance.net/<span class="text-primary">username</span></small></p>

                                            @error('site_behance')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_instagram">{{ __('Instagram') }}</label>
                                            <input id="site_instagram"
                                                type="text"
                                                class="form-control @error('site_instagram') is-invalid @enderror"
                                                name="site_instagram"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ old('site_instagram') ?? config('settings.site_instagram') }}"
                                                autocomplete="instagram"
                                            >
                                            <p class="text-muted"><small>https://www.instagram.com/<span class="text-primary">username</span>/</small></p>

                                            @error('site_instagram')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="site_tiktok">{{ __('TikTok') }}</label>
                                            <input id="site_tiktok"
                                                type="text"
                                                class="form-control @error('site_tiktok') is-invalid @enderror"
                                                name="site_tiktok"
                                                data-mask="@handle" 
                                                data-mask-visible="true" 
                                                placeholder="@handle"
                                                value="{{ old('site_tiktok') ?? config('settings.site_tiktok') }}"
                                                autocomplete="tiktok"
                                            >
                                            <p class="text-muted"><small>https://www.tiktok.com/<span class="text-primary">@handle</span></small></p>

                                            @error('site_tiktok')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }} </button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') }}"></script>
    <script src="{{ asset('vendor/codemirror/lib/codemirror.js') }}"></script>
    <script src="{{ asset('vendor/jquery-charactercounter/jquery.charactercounter.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        $(function () {
            // jQuery Character Counts
            $('#site_meta_description').characterCounter();

            // Call Bootstrap InputTags
            $(".inputtags").tagsinput('items');

            // Change Image Input Label
            $('#site_logo, #site_favicon').change(function() {
                var fileName = $(this)[0].files[0].name != undefined ? $(this)[0].files[0].name : '';
                $(this).parent().find('label').html(fileName);
            });

            $('#cookie-consent-modal-layout-box, #cookie-consent-modal-layout-cloud').click(function() {
                $('#cookie-consent-position-middle-block').removeClass('d-none').addClass('d-block-inline');
                $('#cookie-consent-orientation-block').removeClass('d-none').addClass('d-block-inline');
            });

            $('#cookie-consent-modal-layout-bar').click(function() {
                $('#cookie-consent-position-middle-block').removeClass('d-block-inline').addClass('d-none');
                $('#cookie-consent-orientation-block').removeClass('d-block-inline').addClass('d-none');
            });
        });
    </script>
@endpush
