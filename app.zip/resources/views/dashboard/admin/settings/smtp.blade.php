@extends('layouts.app')

@section('title', __('SMTP Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('SMTP') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('SMTP') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About SMTP') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all SMTP settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/smtp-save') }}"
                            enctype="multipart/form-data"
                            id="smtp-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="smtp-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('SMTP') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('SMTP such as, host, port, username, password, sender and so on.') }}</p>
                                    <div class="form-group row">
                                        <label for="smtp" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('SMTP') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="smtp"
                                                    class="custom-switch-input"
                                                    @if( config('settings.smtp') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_host"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Host') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="smtp_host"
                                                class="form-control @error('smtp_host') is-invalid @enderror"
                                                id="smtp_host"
                                                value="{{ old('smtp_host') ?? config('settings.smtp_host') }}">

                                            @error('smtp_host')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_port"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Port') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="smtp_port"
                                                class="form-control @error('smtp_port') is-invalid @enderror"
                                                id="smtp_port"
                                                value="{{ old('smtp_port') ?? config('settings.smtp_port') }}">

                                            @error('smtp_port')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_username"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Username') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="smtp_username"
                                                class="form-control @error('smtp_username') is-invalid @enderror"
                                                id="smtp_username"
                                                value="{{ old('smtp_username') ?? config('settings.smtp_username') }}">

                                            @error('smtp_username')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_password"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Password') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="password"
                                                name="smtp_password"
                                                class="form-control @error('smtp_password') is-invalid @enderror"
                                                id="smtp_password"
                                                value="{{ old('smtp_password') ?? config('settings.smtp_password') }}">

                                            @error('smtp_password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_sender_email"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Sender Email') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="email"
                                                name="smtp_sender_email"
                                                class="form-control @error('smtp_sender_email') is-invalid @enderror"
                                                id="smtp_sender_email"
                                                value="{{ old('smtp_sender_email') ?? config('settings.smtp_sender_email') }}">

                                            @error('smtp_sender_email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="smtp_encryption"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('SMTP Encryption') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('SSL') }}">
                                                    <input type="radio"
                                                        id="type-ssl"
                                                        name="smtp_encryption"
                                                        class="selectgroup-input"
                                                        value="SSL" @if( config('settings.smtp_encryption') == 'SSL' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('SSL') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('TLS') }}">
                                                    <input type="radio"
                                                        id="type-tls"
                                                        name="smtp_encryption"
                                                        class="selectgroup-input"
                                                        value="TLS" @if( config('settings.smtp_encryption') == 'TLS' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('TLS') }}</span>
                                                </label>
                                            </div>

                                            @error('smtp_encryption')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/smtp-test') }}"
                            id="smtp-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="smtp-test-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('SMTP Test') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('SMTP test connection details.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="test_email"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Test Email') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="email"
                                                name="test_email"
                                                class="form-control @error('test_email') is-invalid @enderror"
                                                id="test_email"
                                                required 
                                                value="{{ old('test_email') ?? config('settings.test_email') }}">

                                            @error('test_email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-smtp-test-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="send-btn">{{ __('Send Email') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
