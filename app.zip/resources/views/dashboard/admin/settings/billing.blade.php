@extends('layouts.app')

@section('title', __('Billing Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Billing') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Billing') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Billing') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all billing settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/billing-save') }}"
                            enctype="multipart/form-data"
                            id="billing-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="billing-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Payment') }}</h4>
                                </div>
                                <div class="card-body">
                                    
                                    <div class="form-group row align-items-center">
                                        <label for="currency"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Default Currency') }}</label>
                                                <div class="col-sm-9 col-md-9">
                                                    <select name="currency"
                                                        class="form-control select2 @error('currency') is-invalid @enderror" 
                                                        id="currency" >
                                                        @include('dashboard.admin.settings.currencies', ['default_currency' => config('settings.currency')])
                                                    </select>

                                            @error('currency')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="billing-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Billing') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Billing settings such as, billing vendor, website, address, phone, VAT number and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_vendor"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Vendor') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_vendor"
                                                class="form-control @error('billing_vendor') is-invalid @enderror"
                                                id="billing_vendor"
                                                value="{{ old('billing_vendor') ?? config('settings.billing_vendor') }}">

                                            @error('billing_vendor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_website"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Website') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_website"
                                                class="form-control @error('billing_website') is-invalid @enderror"
                                                id="billing_website"
                                                value="{{ old('billing_website') ?? config('settings.billing_website') }}">

                                            @error('billing_website')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                     <div class="form-group row align-items-center">
                                        <label for="billing_phone"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Phone') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input id="billing_phone"
                                                type="tel"
                                                class="form-control @error('billing_phone') is-invalid @enderror"
                                                name="billing_phone"
                                                value="{{ old('billing_phone') ?? config('settings.billing_phone') }}"
                                                autocomplete="tel">

                                            <span id="billing_phone_output"></span>

                                            @error('billing_phone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_street"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Street') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_street"
                                                class="form-control @error('billing_street') is-invalid @enderror"
                                                id="billing_street"
                                                value="{{ old('billing_street') ?? config('settings.billing_street') }}">

                                            @error('billing_street')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_city"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing City') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_city"
                                                class="form-control @error('billing_city') is-invalid @enderror"
                                                id="billing_city"
                                                value="{{ old('billing_city') ?? config('settings.billing_city') }}">

                                            @error('billing_city')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_state"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing State') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_state"
                                                class="form-control @error('billing_state') is-invalid @enderror"
                                                id="billing_state"
                                                value="{{ old('billing_state') ?? config('settings.billing_state') }}">

                                            @error('billing_state')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_postal"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Postal') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_postal"
                                                class="form-control @error('billing_postal') is-invalid @enderror"
                                                id="billing_postal"
                                                maxlength="10"
                                                value="{{ old('billing_postal') ?? config('settings.billing_postal') }}">

                                            @error('billing_postal')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_country"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Country') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="billing_country" 
                                                name="billing_country" 
                                                class="form-control select2 @error('billing_country') is-invalid @enderror"
                                            >
                                                @include('dashboard.admin.settings.countries', ['provided_country' => ( config('settings.billing_country') ?? config('settings.country') )])
                                            </select>

                                            @error('billing_country')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_invoice_prefix"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing Invoice Prefix') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_invoice_prefix"
                                                class="form-control @error('billing_invoice_prefix') is-invalid @enderror"
                                                id="billing_invoice_prefix"
                                                data-mask="INV" 
                                                data-mask-visible="true" 
                                                placeholder="INV"
                                                value="{{ old('billing_invoice_prefix') ?? config('settings.billing_invoice_prefix') }}">

                                            @error('billing_invoice_prefix')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="billing_vat_number"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Billing VAT Number') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="billing_vat_number"
                                                class="form-control @error('billing_vat_number') is-invalid @enderror"
                                                id="billing_vat_number"
                                                value="{{ old('billing_vat_number') ?? config('settings.billing_vat_number') }}">

                                            @error('billing_vat_number')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        // International Phone Input
        var intlTelUtilInputSelector = '#billing_phone';
        var intlTelUtilOutputSelector = '#billing_phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}";

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";
    </script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>
@endpush
