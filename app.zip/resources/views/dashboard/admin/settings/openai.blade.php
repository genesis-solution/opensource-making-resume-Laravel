@extends('layouts.app')

@section('title', __('OpenAI Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('OpenAI') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('OpenAI') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About OpenAI') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all OpenAI settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/openai-save') }}"
                            enctype="multipart/form-data"
                            id="openai-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="openai-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('OpenAI') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('OpenAI settings such as, api key, completions, creativity, prompts and so on.') }}</p>
                                    <div class="form-group row">
                                        <label for="openai" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('OpenAI') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="openai"
                                                    class="custom-switch-input"
                                                    @if( config('settings.openai') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('API Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_key"
                                                class="form-control @error('openai_key') is-invalid @enderror"
                                                id="openai_key"
                                                value="{{ old('openai_key') ?? config('settings.openai_key') }}"
                                                required>

                                            @error('openai_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_completions_model"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Completions Model') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_completions_model"
                                                class="form-control @error('openai_completions_model') is-invalid @enderror"
                                                id="openai_completions_model"
                                                value="{{ old('openai_completions_model') ?? config('settings.openai_completions_model') }}"
                                                required>

                                            @error('openai_completions_model')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_creativity"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Creativity') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_creativity"
                                                class="form-control @error('openai_creativity') is-invalid @enderror"
                                                id="openai_creativity"
                                                value="{{ old('openai_creativity') ?? config('settings.openai_creativity') }}"
                                                required>

                                            @error('openai_creativity')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_variations"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Variations') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_variations"
                                                class="form-control @error('openai_variations') is-invalid @enderror"
                                                id="openai_variations"
                                                value="{{ old('openai_variations') ?? config('settings.openai_variations') }}"
                                                required>

                                            @error('openai_variations')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_request_timeout"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Request Timemout') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_request_timeout"
                                                class="form-control @error('openai_request_timeout') is-invalid @enderror"
                                                id="openai_request_timeout"
                                                value="{{ old('openai_request_timeout') ?? config('settings.openai_request_timeout') }}"
                                                required>

                                            @error('openai_request_timeout')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_request_user_agent"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Request User Agent') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="openai_request_user_agent"
                                                class="form-control @error('openai_request_user_agent') is-invalid @enderror"
                                                id="openai_request_user_agent"
                                                value="{{ old('openai_request_user_agent') ?? config('settings.openai_request_user_agent') }}"
                                                required>

                                            @error('openai_request_user_agent')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_user_bio_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('User Bio Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_user_bio_prompt') is-invalid @enderror"
                                                name="openai_user_bio_prompt"
                                                id="openai_user_bio_prompt"
                                                data-height="120">{{ old('openai_user_bio_prompt') ?? config('settings.openai_user_bio_prompt') }}</textarea>

                                            @error('openai_user_bio_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_resume_summary_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Professional Summary Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_resume_summary_prompt') is-invalid @enderror"
                                                name="openai_resume_summary_prompt"
                                                id="openai_resume_summary_prompt"
                                                data-height="120">{{ old('openai_resume_summary_prompt') ?? config('settings.openai_resume_summary_prompt') }}</textarea>

                                            @error('openai_resume_summary_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_resume_job_description_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Job Description Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_resume_job_description_prompt') is-invalid @enderror"
                                                name="openai_resume_job_description_prompt"
                                                id="openai_resume_job_description_prompt"
                                                data-height="120">{{ old('openai_resume_job_description_prompt') ?? config('settings.openai_resume_job_description_prompt') }}</textarea>

                                            @error('openai_resume_job_description_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_resume_volunteer_description_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Volunteer Description Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_resume_volunteer_description_prompt') is-invalid @enderror"
                                                name="openai_resume_volunteer_description_prompt"
                                                id="openai_resume_volunteer_description_prompt"
                                                data-height="120">{{ old('openai_resume_volunteer_description_prompt') ?? config('settings.openai_resume_volunteer_description_prompt') }}</textarea>

                                            @error('openai_resume_volunteer_description_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_cover_letter_content_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Cover Letter Content Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_cover_letter_content_prompt') is-invalid @enderror"
                                                name="openai_cover_letter_content_prompt"
                                                id="openai_cover_letter_content_prompt"
                                                data-height="120">{{ old('openai_cover_letter_content_prompt') ?? config('settings.openai_cover_letter_content_prompt') }}</textarea>

                                            @error('openai_cover_letter_content_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_resume_tailoring_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Resume Tailoring Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_resume_tailoring_prompt') is-invalid @enderror"
                                                name="openai_resume_tailoring_prompt"
                                                id="openai_resume_tailoring_prompt"
                                                data-height="120">{{ old('openai_resume_tailoring_prompt') ?? config('settings.openai_resume_tailoring_prompt') }}</textarea>

                                            @error('openai_resume_tailoring_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="openai_resume_tailoring_with_cover_letter_prompt"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Resume Tailoring with Cover Letter Prompt') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('openai_resume_tailoring_with_cover_letter_prompt') is-invalid @enderror"
                                                name="openai_resume_tailoring_with_cover_letter_prompt"
                                                id="openai_resume_tailoring_with_cover_letter_prompt"
                                                data-height="120">{{ old('openai_resume_tailoring_with_cover_letter_prompt') ?? config('settings.openai_resume_tailoring_with_cover_letter_prompt') }}</textarea>

                                            @error('openai_resume_tailoring_with_cover_letter_prompt')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
