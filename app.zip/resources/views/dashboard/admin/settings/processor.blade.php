@extends('layouts.app')

@section('title', __('Processors Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Processors') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Processors') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Processors') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all processors settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/processor-save') }}"
                            enctype="multipart/form-data"
                            id="processor-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="processor-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Processors') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Payment processors settings such as, methods to permit your users paying with them.') }}</p>
                                </div>
                            </div>
                            <div class="card"
                                id="stripe-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Stripe') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="stripe" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Stripe') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="stripe"
                                                    class="custom-switch-input"
                                                    @if( config('settings.stripe') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="stripe_publishable_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stripe Publishable Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="stripe_publishable_key"
                                                class="form-control @error('stripe_publishable_key') is-invalid @enderror"
                                                id="stripe_publishable_key"
                                                value="{{ old('stripe_publishable_key') ?? config('settings.stripe_publishable_key') }}">

                                            @error('stripe_publishable_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="stripe_secret_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stripe Secret Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="stripe_secret_key"
                                                class="form-control @error('stripe_secret_key') is-invalid @enderror"
                                                id="stripe_secret_key"
                                                value="{{ old('stripe_secret_key') ?? config('settings.stripe_secret_key') }}">

                                            @error('stripe_secret_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="stripe_webhook_signing_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stripe Webhook Signing Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="stripe_webhook_signing_secret"
                                                class="form-control @error('stripe_webhook_signing_secret') is-invalid @enderror"
                                                id="stripe_webhook_signing_secret"
                                                value="{{ old('stripe_webhook_signing_secret') ?? config('settings.stripe_webhook_signing_secret') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">stripe</span></p>

                                            @error('stripe_webhook_signing_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="paypal-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('PayPal') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="paypal" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('PayPal') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="paypal"
                                                    class="custom-switch-input"
                                                    @if( config('settings.paypal') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paypal_mode"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('PayPal Mode') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Sandbox') }}">
                                                    <input type="radio"
                                                        id="type-sandbox"
                                                        name="paypal_mode"
                                                        class="selectgroup-input"
                                                        value="sandbox" @if( config('settings.paypal_mode') == 'sandbox' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Sandbox') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Live') }}">
                                                    <input type="radio"
                                                        id="type-live"
                                                        name="paypal_mode"
                                                        class="selectgroup-input"
                                                        value="live" @if( config('settings.paypal_mode') == 'live' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Live') }}</span>
                                                </label>
                                            </div>

                                            @error('paypal_mode')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paypal_client_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('PayPal Client Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paypal_client_id"
                                                class="form-control @error('paypal_client_id') is-invalid @enderror"
                                                id="paypal_client_id"
                                                value="{{ old('paypal_client_id') ?? config('settings.paypal_client_id') }}">

                                            @error('paypal_client_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paypal_client_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('PayPal Client Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paypal_client_secret"
                                                class="form-control @error('paypal_client_secret') is-invalid @enderror"
                                                id="paypal_client_secret"
                                                value="{{ old('paypal_client_secret') ?? config('settings.paypal_client_secret') }}">

                                            @error('paypal_client_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paypal_email"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('PayPal Email') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paypal_email"
                                                class="form-control @error('paypal_email') is-invalid @enderror"
                                                id="paypal_email"
                                                value="{{ old('paypal_email') ?? config('settings.paypal_email') }}">

                                            @error('paypal_email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paypal_webhook_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('PayPal Webhook Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paypal_webhook_id"
                                                class="form-control @error('paypal_webhook_id') is-invalid @enderror"
                                                id="paypal_webhook_id"
                                                value="{{ old('paypal_webhook_id') ?? config('settings.paypal_webhook_id') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">paypal</span></p>

                                            @error('paypal_webhook_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="razorpay-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Razorpay') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="razorpay" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Razorpay') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="razorpay"
                                                    class="custom-switch-input"
                                                    @if( config('settings.razorpay') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="razorpay_key_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Razorpay Key Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="razorpay_key_id"
                                                class="form-control @error('razorpay_key_id') is-invalid @enderror"
                                                id="razorpay_key_id"
                                                value="{{ old('razorpay_key_id') ?? config('settings.razorpay_key_id') }}">

                                            @error('razorpay_key_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="razorpay_key_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Razorpay Key Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="razorpay_key_secret"
                                                class="form-control @error('razorpay_key_secret') is-invalid @enderror"
                                                id="razorpay_key_secret"
                                                value="{{ old('razorpay_key_secret') ?? config('settings.razorpay_key_secret') }}">

                                            @error('razorpay_key_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="razorpay_webhook_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Razorpay Webhook Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="razorpay_webhook_secret"
                                                class="form-control @error('razorpay_webhook_secret') is-invalid @enderror"
                                                id="razorpay_webhook_secret"
                                                value="{{ old('razorpay_webhook_secret') ?? config('settings.razorpay_webhook_secret') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">razorpay</span></p>

                                            @error('razorpay_webhook_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="paystack-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Paystack') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="paystack" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Paystack') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="paystack"
                                                    class="custom-switch-input"
                                                    @if( config('settings.paystack') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paystack_public_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Paystack Public Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paystack_public_key"
                                                class="form-control @error('paystack_public_key') is-invalid @enderror"
                                                id="paystack_public_key"
                                                value="{{ old('paystack_public_key') ?? config('settings.paystack_public_key') }}">

                                            @error('paystack_public_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="paystack_secret_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Paystack Secret Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="paystack_secret_key"
                                                class="form-control @error('paystack_secret_key') is-invalid @enderror"
                                                id="paystack_secret_key"
                                                value="{{ old('paystack_secret_key') ?? config('settings.paystack_secret_key') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">paystack</span></p>

                                            @error('paystack_secret_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="coinbase-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Coinbase') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="coinbase" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Coinbase') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="coinbase"
                                                    class="custom-switch-input"
                                                    @if( config('settings.coinbase') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="coinbase_api_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Coinbase API Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="coinbase_api_key"
                                                class="form-control @error('coinbase_api_key') is-invalid @enderror"
                                                id="coinbase_api_key"
                                                value="{{ old('coinbase_api_key') ?? config('settings.coinbase_api_key') }}">

                                            @error('coinbase_api_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="coinbase_webhook_shared_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Coinbase Webhook Shared Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="coinbase_webhook_shared_secret"
                                                class="form-control @error('coinbase_webhook_shared_secret') is-invalid @enderror"
                                                id="coinbase_webhook_shared_secret"
                                                value="{{ old('coinbase_webhook_shared_secret') ?? config('settings.coinbase_webhook_shared_secret') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">coinbase</span></p>

                                            @error('coinbase_webhook_shared_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="crypto-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Crypto') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="crypto" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Crypto') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="crypto"
                                                    class="custom-switch-input"
                                                    @if( config('settings.crypto') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="crypto_publishable_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Crypto Publishable Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="crypto_publishable_key"
                                                class="form-control @error('crypto_publishable_key') is-invalid @enderror"
                                                id="crypto_publishable_key"
                                                value="{{ old('crypto_publishable_key') ?? config('settings.crypto_publishable_key') }}">

                                            @error('crypto_publishable_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="crypto_secret_key"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Crypto Secret Key') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="crypto_secret_key"
                                                class="form-control @error('crypto_secret_key') is-invalid @enderror"
                                                id="crypto_secret_key"
                                                value="{{ old('crypto_secret_key') ?? config('settings.crypto_secret_key') }}">

                                            @error('crypto_secret_key')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="crypto_webhook_signature_secret"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Crypto Webhook Signature Secret') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="crypto_webhook_signature_secret"
                                                class="form-control @error('crypto_webhook_signature_secret') is-invalid @enderror"
                                                id="crypto_webhook_signature_secret"
                                                value="{{ old('crypto_webhook_signature_secret') ?? config('settings.crypto_webhook_signature_secret') }}">

                                            <p class="text-muted text-small">{{ config('settings.site_url') ?? 'https://domain.com' }}/webhook/<span class="text-primary">crypto</span></p>

                                            @error('crypto_webhook_signature_secret')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="bank-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Bank') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="bank" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Bank') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="bank"
                                                    class="custom-switch-input"
                                                    @if( config('settings.bank') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_account_owner"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Owner') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_account_owner"
                                                class="form-control @error('bank_account_owner') is-invalid @enderror"
                                                id="bank_account_owner"
                                                value="{{ old('bank_account_owner') ?? config('settings.bank_account_owner') }}">

                                            @error('bank_account_owner')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_name"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Name') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_name"
                                                class="form-control @error('bank_name') is-invalid @enderror"
                                                id="bank_name"
                                                value="{{ old('bank_name') ?? config('settings.bank_name') }}">

                                            @error('bank_name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_routing_number"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Routing number') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_routing_number"
                                                class="form-control @error('bank_routing_number') is-invalid @enderror"
                                                id="bank_routing_number"
                                                value="{{ old('bank_routing_number') ?? config('settings.bank_routing_number') }}">

                                            @error('bank_routing_number')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_account_number"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Accounting Number') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_account_number"
                                                class="form-control @error('bank_account_number') is-invalid @enderror"
                                                id="bank_account_number"
                                                value="{{ old('bank_account_number') ?? config('settings.bank_account_number') }}">

                                            @error('bank_account_number')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_bic_swift"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Swift Code') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_bic_swift"
                                                class="form-control @error('bank_bic_swift') is-invalid @enderror"
                                                id="bank_bic_swift"
                                                value="{{ old('bank_bic_swift') ?? config('settings.bank_bic_swift') }}">

                                            @error('bank_bic_swift')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="bank_iban"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Bank Iban') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="bank_iban"
                                                class="form-control @error('bank_iban') is-invalid @enderror"
                                                id="bank_iban"
                                                value="{{ old('bank_iban') ?? config('settings.bank_iban') }}">

                                            @error('bank_iban')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }} </button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
