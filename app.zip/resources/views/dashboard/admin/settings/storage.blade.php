@extends('layouts.app')

@section('title', __('Storage Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Storage') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Storage') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Storage') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all storage settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/storage-save') }}"
                            id="storage-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="storage-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Storage') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Storage Settings such as, method used to upload the public files.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="storage_method"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Storage Method') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Local') }}">
                                                    <input type="radio"
                                                        id="type-local"
                                                        name="storage_method"
                                                        class="selectgroup-input"
                                                        value="local" @if( config('settings.storage_method') == 'local' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Local') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('AWS S3 Storage') }}">
                                                    <input type="radio"
                                                        id="type-s3"
                                                        name="storage_method"
                                                        class="selectgroup-input"
                                                        value="s3" @if( config('settings.storage_method') == 's3' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('AWS S3 Storage') }}</span>
                                                </label>
                                            </div>

                                            @error('storage_method')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div id="storage-type-s3" class="@if( config('settings.storage_method') == 's3' ) d-block @else d-none @endif">
                                        <div class="form-group row align-items-center">
                                            <label for="storage_aws_s3_key"
                                                class="form-control-label col-sm-3 text-md-right">{{ __('Amazon S3 Key') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <input type="text"
                                                    name="storage_aws_s3_key"
                                                    class="form-control @error('storage_aws_s3_key') is-invalid @enderror"
                                                    id="storage_aws_s3_key"
                                                    value="{{ old('storage_aws_s3_key') ?? config('settings.storage_aws_s3_key') }}">

                                                @error('storage_aws_s3_key')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="form-group row align-items-center">
                                            <label for="storage_aws_s3_secret"
                                                class="form-control-label col-sm-3 text-md-right">{{ __('Amazon S3 Secret') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <input type="text"
                                                    name="storage_aws_s3_secret"
                                                    class="form-control @error('storage_aws_s3_secret') is-invalid @enderror"
                                                    id="storage_aws_s3_secret"
                                                    value="{{ old('storage_aws_s3_secret') ?? config('settings.storage_aws_s3_secret') }}">

                                                @error('storage_aws_s3_secret')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="form-group row align-items-center">
                                            <label for="storage_aws_s3_region"
                                                class="form-control-label col-sm-3 text-md-right">{{ __('Amazon S3 Region') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <input type="text"
                                                    name="storage_aws_s3_region"
                                                    class="form-control @error('storage_aws_s3_region') is-invalid @enderror"
                                                    id="storage_aws_s3_region"
                                                    placeholder="e.g.: us-east-1"
                                                    value="{{ old('storage_aws_s3_region') ?? config('settings.storage_aws_s3_region') }}">

                                                @error('storage_aws_s3_region')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="form-group row align-items-center">
                                            <label for="storage_aws_s3_bucket"
                                                class="form-control-label col-sm-3 text-md-right">{{ __('Amazon S3 Bucket') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <input type="text"
                                                    name="storage_aws_s3_bucket"
                                                    class="form-control @error('storage_aws_s3_bucket') is-invalid @enderror"
                                                    id="storage_aws_s3_bucket"
                                                    value="{{ old('storage_aws_s3_bucket') ?? config('settings.storage_aws_s3_bucket') }}">

                                                @error('storage_aws_s3_bucket')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="form-group row align-items-center">
                                            <label for="storage_aws_s3_endpoint"
                                                class="form-control-label col-sm-3 text-md-right">{{ __('Amazon S3 Endpoint') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <input type="text"
                                                    name="storage_aws_s3_endpoint"
                                                    class="form-control @error('storage_aws_s3_endpoint') is-invalid @enderror"
                                                    id="storage_aws_s3_endpoint"
                                                    placeholder="e.g.: https://s3.amazonaws.com"
                                                    value="{{ old('storage_aws_s3_endpoint') ?? config('settings.storage_aws_s3_endpoint') }}">

                                                @error('storage_aws_s3_endpoint')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script src="{{ asset('js/page/admin-storage.min.js?v='. config('info.software.version')) }}"></script>
@endpush
