@foreach(\App\Models\Country::all() as $country)
<option value="{{$country->code}}"{{$provided_country == $country->code ? 'selected' : ''}}>{{$country->name.'-'.$country->code}}</option>
@endforeach
