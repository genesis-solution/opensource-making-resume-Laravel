@extends('layouts.app')

@section('title', __('Settings'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Settings') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Settings') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('Overview') }}</h2>
                <p class="section-lead">
                    {{ __('The organized list of all settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-home"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Frontend') }}</h4>
                                <p>{{ __('The list of all frontend settings.') }}</p>
                                <a href="{{ route('dashboard.admin.frontend.index') }}"
                                    class="card-cta">{{ __('Change Frontend Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-cog"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('General') }}</h4>
                                <p>{{ __('The list of all general settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.general') }}"
                                    class="card-cta">{{ __('Change General Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-shopping-cart"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Plans') }}</h4>
                                <p>{{ __('The list of all plan settings.') }}</p>
                                <a href="{{ route('dashboard.admin.plans.index') }}"
                                    class="card-cta">{{ __('Change Plan Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-tags"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Coupons') }}</h4>
                                <p>{{ __('The list of all coupon settings.') }}</p>
                                <a href="{{ route('dashboard.admin.coupons.index') }}"
                                    class="card-cta">{{ __('Change Coupon Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-shopping-cart"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Payments') }}</h4>
                                <p>{{ __('The list of all payment settings.') }}</p>
                                <a href="{{ route('dashboard.admin.payments.index') }}"
                                    class="card-cta">{{ __('Change Payment Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-percentage"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Tax Rates') }}</h4>
                                <p>{{ __('The list of all tax rate settings.') }}</p>
                                <a href="{{ route('dashboard.admin.tax-rates.index') }}"
                                    class="card-cta">{{ __('Change Tax Rate Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-file-invoice-dollar"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Billing') }}</h4>
                                <p>{{ __('The list of all billing settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.billing') }}"
                                    class="card-cta">{{ __('Change Billing Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-credit-card"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Processors') }}</h4>
                                <p>{{ __('The list of all processor settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.processor') }}"
                                    class="card-cta">{{ __('Change Processor Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-fire"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Social Logins') }}</h4>
                                <p>{{ __('The list of all social login settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.social') }}"
                                    class="card-cta">{{ __('Change Social Login Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-hdd"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Storage') }}</h4>
                                <p>{{ __('The list of all storage settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.storage') }}"
                                    class="card-cta text-primary">{{ __('Change Storage Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('SMTP') }}</h4>
                                <p>{{ __('The list of all SMTP settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.smtp') }}"
                                    class="card-cta text-primary">{{ __('Change SMTP Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-briefcase"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Work Styles') }}</h4>
                                <p>{{ __('The list of all work style settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.work-styles') }}"
                                    class="card-cta text-primary">{{ __('Change Work Style Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-palette"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Templates') }}</h4>
                                <p>{{ __('The list of all template settings.') }}</p>
                                <a href="{{ route('dashboard.admin.templates.index') }}"
                                    class="card-cta text-primary">{{ __('Change Template Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-bolt"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Soft Skills') }}</h4>
                                <p>{{ __('The list of all soft skill settings.') }}</p>
                                <a href="{{ route('dashboard.admin.soft-skills.index') }}"
                                    class="card-cta text-primary">{{ __('Change Soft Skill Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-robot"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('OpenAI') }}</h4>
                                <p>{{ __('The list of all OpenAI settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.openai') }}"
                                    class="card-cta text-primary">{{ __('Change OpenAI Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-key"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('License') }}</h4>
                                <p>{{ __('The list of all License settings.') }}</p>
                                <a href="{{ route('dashboard.admin.settings.license') }}"
                                    class="card-cta text-primary">{{ __('Change License Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
