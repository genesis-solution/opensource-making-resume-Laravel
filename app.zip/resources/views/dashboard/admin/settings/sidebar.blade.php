<ul class="nav nav-pills flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.settings.general') }}"
                                            class="nav-link {{ (Request::is('*/general') ? 'active' : '') }}"><i class="fa-solid fa-cog"></i> <span>{{ __('General') }}</span></a></li>
                                    @if( config('settings.subscription') )
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.settings.billing') }}"
                                            class="nav-link {{ (Request::is('*/billing') ? 'active' : '') }}"><i class="fa-solid fa-file-invoice-dollar"></i> <span>{{ __('Billing') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.settings.processor') }}"
                                            class="nav-link {{ (Request::is('*/processor') ? 'active' : '') }}"><i class="fa-solid fa-credit-card"></i> <span>{{ __('Processors') }}</span></a></li>
                                    @endif
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.settings.social') }}"
                                            class="nav-link {{ (Request::is('*/social') ? 'active' : '') }}"><i class="fa-solid fa-fire"></i> <span>{{ __('Social Logins') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.settings.storage') }}"
                                            class="nav-link {{ (Request::is('*/storage') ? 'active' : '') }}"><i class="fa-solid fa-hdd"></i> <span>{{ __('Storage') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.settings.smtp') }}"
                                            class="nav-link {{ (Request::is('*/smtp') ? 'active' : '') }}"><i class="fa-solid fa-envelope"></i> <span>{{ __('SMTP') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.settings.work-styles') }}"
                                            class="nav-link {{ (Request::is('*/work-styles') ? 'active' : '') }}"><i class="fa-solid fa-briefcase"></i> <span>{{ __('Work Styles') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.templates.index') }}"
                                            class="nav-link {{ (Request::is('*/templates') ? 'active' : '') }}"><i class="fa-solid fa-palette"></i> <span>{{ __('Templates') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.soft-skills.index') }}"
                                            class="nav-link {{ (Request::is('*/soft-skills') ? 'active' : '') }}"><i class="fa-solid fa-bolt"></i> <span>{{ __('Soft Skills') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.settings.openai') }}"
                                            class="nav-link {{ (Request::is('*/openai') ? 'active' : '') }}"><i class="fa-solid fa-robot"></i> <span>{{ __('OpenAI') }}</span></a></li>
                                    <li class="nav-item"><a href="{{ route('dashboard.admin.settings.license') }}"
                                            class="nav-link {{ (Request::is('*/license') ? 'active' : '') }}"><i class="fa-solid fa-key"></i> <span>{{ __('License') }}</span></a></li>
                                </ul>