@foreach(\App\Models\SoftSkill::all() as $softSkill)
<option value="{{$softSkill->keyword}}"{{$provided_soft_skill == $softSkill->keyword ? 'selected' : ''}}>{{$softSkill->keyword}}</option>
@endforeach
