@extends('layouts.app')

@section('title', __('Work Styles Settings'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Work Styles') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Work Styles') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Work Styles') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all work styles settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/settings/work-style-save') }}"
                            enctype="multipart/form-data"
                            id="work-style-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="work-style-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Work Styles') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Work Style settings such as, artistic, enterprising, investigative, organized, practical and so on.') }}</p>
                                    <div class="form-group row">
                                        <label for="cover_letter_work_style" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Work Styles') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="cover_letter_work_style"
                                                    class="custom-switch-input"
                                                    @if( config('settings.cover_letter_work_style') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_artistic"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Artistic Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_artistic') is-invalid @enderror"
                                                name="cover_letter_work_style_artistic"
                                                id="cover_letter_work_style_artistic"
                                                data-height="150">{{ old('cover_letter_work_style_artistic') ?? config('settings.cover_letter_work_style_artistic') }}</textarea>

                                            @error('cover_letter_work_style_artistic')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_enterprising"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Enterprising Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_enterprising') is-invalid @enderror"
                                                name="cover_letter_work_style_enterprising"
                                                id="cover_letter_work_style_enterprising"
                                                data-height="120">{{ old('cover_letter_work_style_enterprising') ?? config('settings.cover_letter_work_style_enterprising') }}</textarea>

                                            @error('cover_letter_work_style_enterprising')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_investigative"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Investigative Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_investigative') is-invalid @enderror"
                                                name="cover_letter_work_style_investigative"
                                                id="cover_letter_work_style_investigative"
                                                data-height="120">{{ old('cover_letter_work_style_investigative') ?? config('settings.cover_letter_work_style_investigative') }}</textarea>

                                            @error('cover_letter_work_style_investigative')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_organized"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Organized Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_organized') is-invalid @enderror"
                                                name="cover_letter_work_style_organized"
                                                id="cover_letter_work_style_organized"
                                                data-height="120">{{ old('cover_letter_work_style_organized') ?? config('settings.cover_letter_work_style_organized') }}</textarea>

                                            @error('cover_letter_work_style_organized')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_practical"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Practical Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_practical') is-invalid @enderror"
                                                name="cover_letter_work_style_practical"
                                                id="cover_letter_work_style_practical"
                                                data-height="120">{{ old('cover_letter_work_style_practical') ?? config('settings.cover_letter_work_style_practical') }}</textarea>

                                            @error('cover_letter_work_style_practical')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="cover_letter_work_style_service_oriented"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Service-Oriented Work Style') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control summernote-simple @error('cover_letter_work_style_service_oriented') is-invalid @enderror"
                                                name="cover_letter_work_style_service_oriented"
                                                id="cover_letter_work_style_service_oriented"
                                                data-height="120">{{ old('cover_letter_work_style_service_oriented') ?? config('settings.cover_letter_work_style_service_oriented') }}</textarea>

                                            @error('cover_letter_work_style_service_oriented')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
