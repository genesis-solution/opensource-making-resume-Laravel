@foreach(\App\Models\Currency::all() as $currency)
<option value="{{$currency->code}}"{{$default_currency == $currency->code ? 'selected' : ''}}>{{$currency->country.'-'.$currency->code.'-'.$currency->symbol}}</option>
@endforeach
