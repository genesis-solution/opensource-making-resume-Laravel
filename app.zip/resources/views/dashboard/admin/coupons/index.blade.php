@extends('layouts.app')

@section('title', __('Coupons'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.coupons.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Coupons') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Coupons') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Coupons') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all available coupons') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.plans.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Coupons') }}</h4>
                                <div class="card-header-form">
                                    <a class="btn btn-primary text-md-right" href="{{route('dashboard.admin.coupons.item')}}">{{ __('Add New') }}</a>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table-striped table-md table">
                                        <tr>
                                            <th>{{__('#')}}</th>
                                            <th>{{__('Name')}}</th>
                                            <th>{{__('Type')}}</th>
                                            <th>{{__('Percentage')}}</th>
                                            <th>{{__('Quantity')}}</th>
                                            <th>{{__('Redeemed')}}</th>
                                            <th>{{__('Status')}}</th>
                                            <th>{{__('Actions')}}</th>
                                        </tr>
                                        @foreach($items as $entry)
                                        <tr>
                                            <td>{{$entry->id}}</td>
                                            <td>{{$entry->name}}</td>
                                            <td>
                                                <div @if( $entry->type == '1') class="badge badge-success" @else class="badge badge-primary" @endif>@if( $entry->type == '1') {{__('Redeemable')}} @else {{__('Discount')}} @endif</div>
                                            </td>
                                            <td>{{$entry->percentage}}%</td>
                                            <td><div class="badge badge-light mr-2" data-toggle="tooltip" data-original-title="{{__('Quantity')}}"><i class="fa-solid fa-tags"></i> {{ ( $entry->quantity!=null && $entry->quantity == '-1' ? __('Unlimited') : $entry->quantity ) }}</div></td>
                                            <td>
                                                <div class="badge badge-light mr-2" data-toggle="tooltip" data-original-title="{{__('Redeemed codes')}}"><i class="fa-solid fa-tags"></i> {{ $entry->redeems }}</div>
                                            </td>
                                            <td>
                                                <div @if( $entry->status == '1') class="badge badge-success" @else class="badge badge-danger" @endif>@if( $entry->status == '1') {{__('Active')}} @else {{__('Inactive')}} @endif</div>
                                            </td>
                                            <td class="text-nowrap">
                                                <a href="{{route('dashboard.admin.coupons.item', $entry->id)}}" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                                <a type="button" class="btn btn-danger delete-confirm-item" data-item-id="{{ $entry->id }}"><i class="fa-solid fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                            <div class="pull-right">
                                <div class="card-footer text-right">
                                    {!! $items->links() !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var couponConfirmDeleteMsg = "{{__('Are you sure?')}}";
        var couponDeleteNoRecoveryMsg = "{{__('You will not be able to recover the deleted item!')}}";
        var couponDeletedSuccess = "{{ __('Coupon Deleted Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-coupons.min.js?v='. config('info.software.version')) }}"></script>
@endpush
