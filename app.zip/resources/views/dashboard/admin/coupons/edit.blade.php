@extends('layouts.app')

@section('title', __('Coupon'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.coupons.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Coupon') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.coupons.index') }}"> {{ __('Coupons') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Coupon') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Coupon') }}</h2>
                <p class="section-lead">
                    {{ __('The details of the coupon') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.plans.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="coupon-item" 
                            onsubmit="couponCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="coupon-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Coupon') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Coupon settings such as, name, code, type, percentage and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="name"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Name') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-signature"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="name"
                                                    class="form-control @error('name') is-invalid @enderror"
                                                    id="name"
                                                    value="{{ $item!=null ? $item->name : null }}"
                                                    required>
                                            </div>

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="code"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Code') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-tags"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="code"
                                                    class="form-control @error('code') is-invalid @enderror"
                                                    id="code"
                                                    value="{{ $item!=null ? $item->code : null }}"
                                                    required>
                                            </div>

                                            @error('code')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="type"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Type') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Discount') }}">
                                                    <input type="radio"
                                                        id="type-discount"
                                                        name="type"
                                                        class="selectgroup-input"
                                                        value="0" @if( $item==null || ( $item!=null && $item->type == '0' ) )checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Discount') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Redeemable') }}">
                                                    <input type="radio"
                                                        id="type-redeemable"
                                                        name="type"
                                                        class="selectgroup-input"
                                                        value="1" @if( $item!=null && $item->type == '1') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Redeemable') }}</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    @if( $item!=null && $item->type == 1 )
                                    <div class="form-group discount-percentage d-none row align-items-center">
                                    @else 
                                    <div class="form-group discount-percentage d-block row align-items-center">
                                    @endif
                                        <label for="percentage"
                                            class="form-control-label col-sm-3 mt-3 text-md-right">{{ __('Percentage') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Choose a discount between 1% and 99%.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 float-right col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-percentage"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="percentage"
                                                    class="form-control @error('percentage') is-invalid @enderror"
                                                    id="percentage"
                                                    data-mask="0.00" 
                                                    data-mask-visible="true" 
                                                    placeholder="0.00"
                                                    min="1"
                                                    max="99.99"
                                                    value="{{ $item!=null ? $item->percentage : null }}">
                                            </div>
                                        
                                            @error('percentage')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="quantity"
                                            class="form-control-label col-sm-3 mb-4 text-md-right">{{ __('Quantity') }} </label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="quantity"
                                                class="form-control @error('quantity') is-invalid @enderror"
                                                id="quantity"
                                                min="-1"
                                                value="{{ $item!=null ? $item->quantity : null }}"
                                                required>

                                            @error('quantity')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-small text-muted mt-2">{!! __(':value for unlimited.', ['value' => '<code class="badge badge-light">-1</code>']) !!} {!! __(':value for none.', ['value' => '<code class="badge badge-light">0</code>']) !!} {!! __(':value for number.', ['value' => '<code class="badge badge-light">N</code>']) !!}</div>
                                        </div>
                                    </div>
                                    @if( $item==null || ( $item!=null && $item->type == 0 ) )
                                    <div class="form-group redeemable-days d-none row align-items-center"> 
                                    @else 
                                    <div class="form-group redeemable-days row align-items-center"> 
                                    @endif
                                        <label for="days"
                                            class="form-control-label col-sm-3 mt-3 text-md-right">{{ __('Days') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('How many days will the plan be available.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 float-right col-md-9">
                                            <input type="number"
                                                name="days"
                                                class="form-control @error('days') is-invalid @enderror"
                                                id="days"
                                                min="0"
                                                value="{{ $item!=null ? $item->days : null }}">

                                            @error('days')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var couponBtnSaveMsg = "{{ __('Save') }}";
        var couponBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var couponSavedSuccess = "{{ __('Coupon Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-coupons.min.js?v='. config('info.software.version')) }}"></script>
@endpush
