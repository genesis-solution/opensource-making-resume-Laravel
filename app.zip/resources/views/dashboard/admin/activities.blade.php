@extends('layouts.app')

@section('title', __('Activities'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Activities') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Activities') }}</div>
                </div>
            </div>
            <div class="section-body">
                <h2 class="section-title">{{ __('Activities') }}</h2>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="activities">
                             @if( isset( $activities ) )
                                @if(count($activities) == 0)
                                <div class="text media-item">{{__('No activity logged yet.')}}</div>
                                @else
                                    @foreach($activities as $activity)
                                    <div class="activity">
                                        <div class="activity-icon bg-primary shadow-primary text-white">
                                            <img class="rounded-circle mr-3"
                                            width="50"
                                            src="{{ ( $activity->avatar_path !=null ? $activity->avatar_path : ( $activity->avatar !=null ? asset($activity->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                                            alt="avatar">
                                        </div>
                                        <div class="activity-detail">
                                            <div class="mb-2">
                                                <span class="text-job text-primary">{{ $activity->updated_at->diffForHumans() }}</span>
                                                <span class="bullet"></span>
                                                <span class="text-job">{{ $activity->activity_type }}</span>
                                                @if($activity->activity_url != null)
                                                <div class="dropdown float-right">
                                                    <a href="#"
                                                        data-toggle="dropdown"><i class="fa-solid fa-ellipsis-h"></i></a>
                                                    <div class="dropdown-menu">
                                                        <div class="dropdown-title">{{ __('Options') }}</div>
                                                        <a href="{{ $activity->activity_url }}"
                                                            class="dropdown-item has-icon"><i class="fa-solid fa-eye"></i> {{ __('View') }}</a>
                                                    </div>
                                                </div>
                                                @endif
                                            </div>
                                            <p>{{ $activity->firstname .' '.$activity->lastname }} {{ __('has') }} <strong>{{ Str::lower($activity->activity_type) }}</strong> {{ Str::lower($activity->activity_title) }}.</p>
                                        </div>
                                    </div>
                                    @endforeach
                                @endif
                            @endif
                        </div>
                        <div class="row pull-right">  
                            <div class="col-lg-12">
                            {!! $activities->links() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush
