@extends('layouts.app')

@section('title', __('Template'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.templates.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Template') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.templates.index') }}"> {{ __('Templates') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Template') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Template') }}</h2>
                <p class="section-lead">
                    {{ __('The details of the template') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/templates/save') }}"
                            enctype="multipart/form-data"
                            id="general-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="template-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Template') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Template information such as, name, image, type, status and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="name"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Name') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-signature"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="name"
                                                    class="form-control @error('name') is-invalid @enderror"
                                                    id="name"
                                                    value="{{ $template->name ?? null }}"
                                                    required>
                                            </div>

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ $template->image!=null ? asset($template->image) : asset('img/template/'. ( $template->type == 'R' ? 'resume' : 'cover-letter' ) .'-template-'. $template->resource_id .'.jpg' ) }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="image" id="image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should be at least 300x450 pixels with a 2/3 aspect ratio, and not exceed 1MB in size.') }}</div>

                                            @error('image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="order"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Order') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="order"
                                                min="0"
                                                class="form-control @error('order') is-invalid @enderror"
                                                id="order"
                                                value="{{ $template!=null ? $template->order : null }}"
                                                required>

                                            @error('order')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="type"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Type') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Resume') }}">
                                                    <input type="radio"
                                                        id="type-resume"
                                                        name="type"
                                                        class="selectgroup-input"
                                                        value="R" @if( $template->type == 'R' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Resume') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Cover Letter') }}">
                                                    <input type="radio"
                                                        id="type-cover-letter"
                                                        name="type"
                                                        class="selectgroup-input"
                                                        value="C" @if( $template->type == 'C' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Cover Letter') }}</span>
                                                </label>
                                            </div>

                                            @error('type')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="status"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $template!=null && $template->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>

                                            @error('status')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <input type="hidden" name="template_id" id="template_id" value="{{ $template->id }}" />
                                </div>
                            </div>
                            @if($template!=null && $template->top_colors!=null)
                            <div class="card"
                                id="top-colors-card">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseTopColors" aria-expanded="true" aria-controls="collapseTopColors" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Top Position Colors') }}</h4>
                                    <div class="card-header-form">
                                        <label class="custom-switch p-1 text-md-right">
                                            <input type="checkbox"
                                                name="top_colors_status"
                                                id="top_colors_status"
                                                class="custom-switch-input"
                                                @if( $template!=null && $template->top_colors!=null && $template->top_colors_status == '1') checked="checked" @endif>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="card-body collapse" id="collapseTopColors">
                                    <div class="form-group row align-items-center">
                                        <label for="top_position"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Top') }}">
                                                    <input type="radio"
                                                        id="top-position-top"
                                                        name="top_position"
                                                        class="selectgroup-input"
                                                        value="top" @if( $template->top_colors->position == 'top' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Top') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Left') }}">
                                                    <input type="radio"
                                                        id="top-position-left"
                                                        name="top_position"
                                                        class="selectgroup-input"
                                                        value="left" @if( $template->top_colors->position == 'left' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Left') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Right') }}">
                                                    <input type="radio"
                                                        id="top-position-right"
                                                        name="top_position"
                                                        class="selectgroup-input"
                                                        value="right" @if( $template->top_colors->position == 'right' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Right') }}</span>
                                                </label>
                                            </div>

                                            @error('top_position')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-bakground-yes"
                                                        name="top_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-bakground-no"
                                                        name="top_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_header_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Header Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-header-bakground-yes"
                                                        name="top_header_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->header_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-header-bakground-no"
                                                        name="top_header_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->header_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_header_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_header_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Header Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-header-title-yes"
                                                        name="top_header_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->header_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-header-title-no"
                                                        name="top_header_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->header_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_header_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_header_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Header Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-header-description-yes"
                                                        name="top_header_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->header_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-header-description-no"
                                                        name="top_header_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->header_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_header_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_subheader_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Subheader Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-subheader-background-yes"
                                                        name="top_subheader_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->subheader_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-subheader-background-no"
                                                        name="top_subheader_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->subheader_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_subheader_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_subheader_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Subheader Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-subheader-title-yes"
                                                        name="top_subheader_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->subheader_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-subheader-title-no"
                                                        name="top_subheader_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->subheader_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_subheader_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_subheader_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Subheader ByLine') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-subheader-byline-yes"
                                                        name="top_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->subheader_byline == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-subheader-byline-no"
                                                        name="top_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->subheader_byline == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_subheader_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="top_subheader_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Top Subheader Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="top-subheader-description-yes"
                                                        name="top_subheader_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->top_colors->subheader_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="top-subheader-description-no"
                                                        name="top_subheader_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->top_colors->subheader_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('top_subheader_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                            </div>
                            @endif
                            @if($template!=null && $template->top_default_colors!=null && $template->top_colors_status == '1')
                            <div id="template-top-color" class="card @if( $template->top_colors_status == '1' ) @else d-none @endif">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseTemplateTopColor" aria-expanded="true" aria-controls="collapseTemplateTopColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Top Default Colors') }}</h4>
                                </div>
                                <div class="card-body collapse" id="collapseTemplateTopColor">
                                    <div class="row">
                                        <div id="template-top-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_topbgcolor"
                                                    id="tpl_topbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->background : '#3d3e42' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_topbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-header-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Header Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_tophdbgcolor"
                                                    id="tpl_tophdbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->header_background : '#3d3e42' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_tophdbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-header-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Header Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_tophdtltxtcolor"
                                                    id="tpl_tophdtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->header_title : '#a19191' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_tophdtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-header-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Header Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_tophddesctxtcolor"
                                                    id="tpl_tophddesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->header_description : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_tophddesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Subheader Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_topsubbgcolor"
                                                    id="tpl_topsubbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_background : '#3d3e42' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_topsubbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Subheader Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_topsubtltxtcolor"
                                                    id="tpl_topsubtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_title : '#b4b7c5' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_topsubtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Subheader Byline Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_topsubbltxtcolor"
                                                    id="tpl_topsubbltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_byline : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_topsubbltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-top-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Top Subheader Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_topsubdesctxtcolor"
                                                    id="tpl_topsubdesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_description : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_topsubdesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if($template!=null && $template->sidebar_colors!=null)
                            <div class="card"
                                id="sidebar-colors-card">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseSidebarColors" aria-expanded="true" aria-controls="collapseSidebarColors" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Sidebar Position Colors') }}</h4>
                                    <div class="card-header-form">
                                        <label class="custom-switch p-1 text-md-right">
                                            <input type="checkbox"
                                                name="sidebar_colors_status"
                                                id="sidebar_colors_status"
                                                class="custom-switch-input"
                                                @if( $template!=null && $template->sidebar_colors!=null && $template->sidebar_colors_status == '1') checked="checked" @endif>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="card-body collapse" id="collapseSidebarColors">
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_position"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Top') }}">
                                                    <input type="radio"
                                                        id="sidebar-position-top"
                                                        name="sidebar_position"
                                                        class="selectgroup-input"
                                                        value="top" @if( $template->sidebar_colors->position == 'top' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Top') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Left') }}">
                                                    <input type="radio"
                                                        id="sidebar-position-left"
                                                        name="sidebar_position"
                                                        class="selectgroup-input"
                                                        value="left" @if( $template->sidebar_colors->position == 'left' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Left') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Right') }}">
                                                    <input type="radio"
                                                        id="sidebar-position-right"
                                                        name="sidebar_position"
                                                        class="selectgroup-input"
                                                        value="right" @if( $template->sidebar_colors->position == 'right' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Right') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_position')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-bakground-yes"
                                                        name="sidebar_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-bakground-no"
                                                        name="sidebar_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_header_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Header Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-bakground-yes"
                                                        name="sidebar_header_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->header_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-bakground-no"
                                                        name="sidebar_header_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->header_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_header_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_header_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Header Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-title-yes"
                                                        name="sidebar_header_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->header_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-title-no"
                                                        name="sidebar_header_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->header_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_header_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_header_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Header Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-description-yes"
                                                        name="sidebar_header_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->header_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-header-description-no"
                                                        name="sidebar_header_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->header_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_header_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_subheader_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Subheader Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-background-yes"
                                                        name="sidebar_subheader_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->subheader_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-background-no"
                                                        name="sidebar_subheader_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->subheader_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_subheader_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_subheader_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Subheader Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-title-yes"
                                                        name="sidebar_subheader_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->subheader_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-title-no"
                                                        name="sidebar_subheader_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->subheader_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_subheader_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_subheader_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Subheader ByLine') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-byline-yes"
                                                        name="sidebar_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->subheader_byline == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-byline-no"
                                                        name="sidebar_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->subheader_byline == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_subheader_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="sidebar_subheader_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Sidebar Subheader Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-description-yes"
                                                        name="sidebar_subheader_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->sidebar_colors->subheader_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="sidebar-subheader-description-no"
                                                        name="sidebar_subheader_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->sidebar_colors->subheader_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('sidebar_subheader_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                            </div>
                            @endif
                            @if($template!=null && $template->sidebar_default_colors!=null && $template->sidebar_colors_status == '1')
                            <div id="template-sidebar-color" class="card @if( $template->sidebar_colors_status == '1' ) @else d-none @endif">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseTemplateSidebarColor" aria-expanded="true" aria-controls="collapseTemplateSidebarColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Sidebar Default Colors') }}</h4>
                                </div>
                                <div class="card-body collapse" id="collapseTemplateSidebarColor">
                                    <div class="row">
                                        <div id="template-sidebar-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidebgcolor"
                                                    id="tpl_sidebgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->background : '#f5f5f5' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidebgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-header-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Header Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidehdbgcolor"
                                                    id="tpl_sidehdbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_background : '#f5f5f5' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidehdbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-header-title-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Header Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidehdtltxtcolor"
                                                    id="tpl_sidehdtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_title : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidehdtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-header-description-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Header Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidehddesctxtcolor"
                                                    id="tpl_sidehddesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_description : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidehddesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Subheader Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidesubbgcolor"
                                                    id="tpl_sidesubbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_background : '#f5f5f5' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidesubbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Subheader Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidesubtltxtcolor"
                                                    id="tpl_sidesubtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_title : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidesubtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Subheader Byline Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidesubbltxtcolor"
                                                    id="tpl_sidesubbltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_byline : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidesubbltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-sidebar-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Sidebar Subheader Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_sidesubdesctxtcolor"
                                                    id="tpl_sidesubdesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_description : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_sidesubdesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if($template!=null && $template->content_colors!=null)
                            <div class="card"
                                id="content-colors-card">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseContentColors" aria-expanded="true" aria-controls="collapseContentColors" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Content Position Colors') }}</h4>
                                    <div class="card-header-form">
                                        <label class="custom-switch p-1 text-md-right">
                                            <input type="checkbox"
                                                name="content_colors_status"
                                                id="content_colors_status"
                                                class="custom-switch-input"
                                                @if( $template!=null && $template->content_colors!=null && $template->content_colors_status == '1') checked="checked" @endif>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="card-body collapse" id="collapseContentColors">
                                    <div class="form-group row align-items-center">
                                        <label for="content_position"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Position') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Top') }}">
                                                    <input type="radio"
                                                        id="content-position-top"
                                                        name="content_position"
                                                        class="selectgroup-input"
                                                        value="top" @if( $template->content_colors->position == 'top' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Top') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Left') }}">
                                                    <input type="radio"
                                                        id="content-position-left"
                                                        name="content_position"
                                                        class="selectgroup-input"
                                                        value="left" @if( $template->content_colors->position == 'left' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Left') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Right') }}">
                                                    <input type="radio"
                                                        id="content-position-right"
                                                        name="content_position"
                                                        class="selectgroup-input"
                                                        value="right" @if( $template->content_colors->position == 'right' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Right') }}</span>
                                                </label>
                                            </div>

                                            @error('content_position')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-bakground-yes"
                                                        name="content_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-bakground-no"
                                                        name="content_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_header_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Header Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-header-bakground-yes"
                                                        name="content_header_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->header_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-header-bakground-no"
                                                        name="content_header_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->header_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_header_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_header_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Header Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-header-title-yes"
                                                        name="content_header_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->header_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-header-title-no"
                                                        name="content_header_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->header_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_header_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_header_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Header Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-header-description-yes"
                                                        name="content_header_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->header_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-header-description-no"
                                                        name="content_header_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->header_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_header_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_subheader_background"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Subheader Background') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-subheader-background-yes"
                                                        name="content_subheader_background"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->subheader_background == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-subheader-background-no"
                                                        name="content_subheader_background"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->subheader_background == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_subheader_background')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_subheader_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Subheader Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-subheader-title-yes"
                                                        name="content_subheader_title"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->subheader_title == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-subheader-title-no"
                                                        name="content_subheader_title"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->subheader_title == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_subheader_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_subheader_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Subheader ByLine') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-subheader-byline-yes"
                                                        name="content_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->subheader_byline == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-subheader-byline-no"
                                                        name="content_subheader_byline"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->subheader_byline == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_subheader_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content_subheader_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content Subheader Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="content-subheader-description-yes"
                                                        name="content_subheader_description"
                                                        class="selectgroup-input"
                                                        value="Yes" @if( $template->content_colors->subheader_description == 'Yes' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Yes') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="content-subheader-description-no"
                                                        name="content_subheader_description"
                                                        class="selectgroup-input"
                                                        value="No" @if( $template->content_colors->subheader_description == 'No' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('No') }}</span>
                                                </label>
                                            </div>

                                            @error('content_subheader_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                            </div>
                            @endif
                            @if($template!=null && $template->content_default_colors!=null && $template->content_colors_status == '1')
                            <div id="template-content-color" class="card @if( $template->content_colors_status == '1' ) @else d-none @endif">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseTemplateContentColor" aria-expanded="true" aria-controls="collapseTemplateContentColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Content Default Colors') }}</h4>
                                </div>
                                <div class="card-body collapse" id="collapseTemplateContentColor">
                                    <div class="row">
                                        <div id="template-content-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_contbgcolor"
                                                    id="tpl_contbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->background : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_contbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-header-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Header Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_conthdbgcolor"
                                                    id="tpl_conthdbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->header_background : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_conthdbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-header-title-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Header Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_conthdtltxtcolor"
                                                    id="tpl_conthdtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->header_title : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_conthdtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-header-description-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Header Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_conthddesctxtcolor"
                                                    id="tpl_conthddesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->header_description : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_conthddesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_background == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Subheader Background Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_contsubbgcolor"
                                                    id="tpl_contsubbgcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_background : '#ffffff' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_contsubbgcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_title == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Subheader Title Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_contsubtltxtcolor"
                                                    id="tpl_contsubtltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_title : '#191d21' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_contsubtltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Subheader Byline Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_contsubbltxtcolor"
                                                    id="tpl_contsubbltxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_byline : '#98a6ad' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_contsubbltxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div id="template-content-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_description == 'Yes' ) @else d-none @endif">
                                            <label>{{ __('Content Subheader Description Color') }}</label>
                                            <div class="input-group">
                                                <input type="color"
                                                    name="tpl_contsubdesctxtcolor"
                                                    id="tpl_contsubdesctxtcolor"
                                                    class="form-control"
                                                    value="{{ ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_description : '#3b3b3b' ) }}">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-fill-drip"></i>
                                                    </div>
                                                </div>
                                            </div>

                                            @error('tpl_contsubdesctxtcolor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }} </button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
