@extends('layouts.app')

@section('title', __('About Product'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('About Product') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('About Product') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Product') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all information about product.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Credits') }}</h4>
                            </div>
                            <div class="card-body">
                                <p>
                                    {{ __('We would like to express our gratitude to the creators of the main framework and the template that we utilize, as they deserve special recognition.') }}
                                </p>
                                <div class="list-unstyled list-unstyled-border mt-2">
                                    <div class="media">
                                        <div class="media-icon"><i class="fa-regular fa-circle"></i></div>
                                        <div class="media-body">
                                            <p><strong>Laravel</strong> <span class="text-muted text-small">{{ __('by') }} Taylor Otwell</span></p>
                                        </div>
                                    </div>
                                    <div class="media">
                                        <div class="media-icon"><i class="fa-regular fa-circle"></i></div>
                                        <div class="media-body">
                                            <p><strong>Stisla Template</strong> <span class="text-muted text-small">{{ __('by') }} Nauval Azhar</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('About Product') }}</h4>
                                <div class="card-header-form">
                                    <div class="dropdown d-inline dropleft text-right">
                                        <button class="btn btn-primary dropdown-toggle"
                                            type="button"
                                            id="work-styles-btn"
                                            data-toggle="dropdown"
                                            aria-haspopup="true"
                                            aria-expanded="false">
                                            <i class="fa-solid fa-headset"></i> {{ __('Support') }}
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item has-icon"
                                                type="button" id="support"
                                                href="https://help.carcani.com"
                                                target="_blank">
                                                <i class="fa-solid fa-life-ring"></i> <span>{{ __('Support') }}</span>
                                            </a>
                                            <a class="dropdown-item has-icon"
                                                type="button" id="documentation"
                                                href="https://carcani.com/product/resumaine-documentation.html"
                                                target="_blank">
                                                <i class="fa-solid fa-rocket"></i> <span>{{ __('Documentation') }}</span>
                                            </a>
                                            <a class="dropdown-item has-icon"
                                                type="button" id="changelog"
                                                href="https://carcani.com/product/resumaine-changelog.html"
                                                target="_blank">
                                                <i class="fa-solid fa-clipboard-list"></i> <span>{{ __('Changelog') }}</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="summary">
                                    <div class="summary-info">
                                        <h4>{{ config('info.software.name') }}</h4>
                                        <div class="text-muted text-small">{{ __('by') }} <a href="{{ config('info.software.url') }}">{{ config('info.software.author') }}</a>
                                            <div class="bullet"></div> v{{ config('info.software.version') }}
                                        </div>
                                    </div>
                                    <div class="summary-item">
                                        <h6><span class="text-muted">{{ __('Additional Information') }}</span></h6>
                                        <ul class="list-unstyled list-unstyled-border">
                                            @if(config('settings.license_product_market_name'))
                                            <li class="media">
                                                <div class="card-product bg-primary">
                                                    <i class="fa-solid fa-key card-icon"></i>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-right"><span class="badge badge-info">{{ config('settings.license_type') ? 'Extended' : 'Regular' }}</span></div>
                                                    <div class="media-title">{{ __('License Type') }}</div>
                                                    <div class="text-muted text-small">{{ __('from') }} <a href="{{ 'https://'. Str::lower(trim(config('settings.license_product_market_name'))) .'.com' }}" target="_blank"><span id="product-marketplace">{{ config('settings.license_product_market_name') }}</span></a>
                                                        <div class="bullet"></div> {{ __('Marketplace') }}
                                                    </div>
                                                </div>
                                            </li>
                                            @endif
                                            @if(config('settings.license_product_support_expiry'))
                                            <li class="media">
                                                <div class="card-product bg-primary">
                                                    <i class="fa-solid fa-life-ring card-icon"></i>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-right"><span class="badge @if(Carbon\Carbon::parse(config('settings.license_product_support_expiry'))->isFuture()) badge-success @else badge-danger @endif">{{ Carbon\Carbon::parse(config('settings.license_product_support_expiry'))->isFuture() ? __('Active') : __('Expired') }}</span></div>
                                                    <div class="media-title">{{ __('Support Till') }}</div>
                                                    <div class="text-muted text-small">{{ __('by') }} <a href="https://help.carcani.com" target="_blank">{{ config('info.software.author') }}</a>
                                                        <div class="bullet"></div> <span id="product-support-date">{{ date('Y-m-d', strtotime(config('settings.license_product_support_expiry'))) }}</span>
                                                    </div>
                                                </div>
                                            </li>
                                            @endif
                                            @if(config('settings.license_product_latest_version') || config('settings.license_product_release_date'))
                                            <li class="media">
                                                <div class="card-product bg-primary">
                                                    <i class="fa-solid fa-code card-icon"></i>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-right"><span class="badge @if(version_compare(config('settings.license_product_latest_version'), config('info.software.version'), '>') == true) badge-warning @else badge-success @endif">{!! ( version_compare(config('settings.license_product_latest_version'), config('info.software.version'), '>') == true ) ? __(':product_update', ['product_update' => '<a href="https://'. Str::lower(trim(config('settings.license_product_market_name'))) .'.com" class="text-decoration-none" target="_blank"><span class="text-white">'. __('New Update') .'</span></a>']) : __('Latest') !!}</span></div>
                                                    <div class="media-title">{{ __('Latest Version') }}</div>
                                                    <div class="text-muted text-small">{{ __('by') }} <a href="https://carcani.com/product/resumaine-changelog.html" target="_blank">{{ config('info.software.author') }}</a>
                                                        @if(config('settings.license_product_latest_version'))
                                                        <div class="bullet"></div> <span id="product-latest-version">v{{ config('settings.license_product_latest_version') }}</span>
                                                        @endif
                                                        @if(config('settings.license_product_release_date'))
                                                        <div class="bullet"></div> <span id="product-latest-release">{{ config('settings.license_product_release_date') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </li>
                                            @endif
                                            <li class="media">
                                                <div class="card-product bg-primary">
                                                    <i class="fa-brands fa-laravel card-icon"></i>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-right"><span class="badge badge-info">Laravel</span></div>
                                                    <div class="media-title">{{ __('Web Framework') }}</div>
                                                    <div class="text-muted text-small">{{ __('by') }} <a href="https://laravel.com" target="_blank">Taylor Otwell</a>
                                                        <div class="bullet"></div> v{{ app()->version() }}
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush
