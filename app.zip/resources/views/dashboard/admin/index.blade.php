@extends('layouts.app')

@section('title', __('Dashboard'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/flag-icon-css/css/flag-icon.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Dashboard') }}</h1>
            </div>

            <div id="output-status">
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if(session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                @endif
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-primary">
                            <i class="fa-regular fa-user"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Total Users') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('total_users') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-danger">
                            <i class="fa-regular fa-newspaper"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Resumes') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('resume_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-warning">
                            <i class="fa-regular fa-file"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Cover Letters') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('cover_letter_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                @if( config('settings.subscription') )
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-secondary">
                            <i class="fa-solid fa-gift"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Subscriptions') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('subscription_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-info">
                            <i class="fa-solid fa-shopping-cart"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Payments') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('payment_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-success">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Total Paid') }}</h4>
                            </div>
                            <div class="card-body">
                                @if(cache('payment_total_paid') != null)
                                {{ formatMoney(cache('payment_total_paid'), config('settings.currency')) }} <span class="text-small text-muted">{{ config('settings.currency') }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-12 col-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Statistics') }}</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="myChart"
                                height="162"></canvas>
                            <div class="statistic-details mt-sm-4">
                                <div class="statistic-details-item">
                                    <span class="text-muted">{!! percentageChange(cache('users_previous_day'), cache('users_this_day')) !!}</span>
                                    <div class="detail-value">{{cache('users_this_day')}}</div>
                                    <div class="detail-name">{{__('Today`s Users')}}</div>
                                </div>
                                <div class="statistic-details-item">
                                    <span class="text-muted">{!! percentageChange(cache('users_previous_week'), cache('users_this_week')) !!}</span>
                                    <div class="detail-value">{{cache('users_this_week')}}</div>
                                    <div class="detail-name">{{__('This Week`s Users')}}</div>
                                </div>
                                <div class="statistic-details-item">
                                    <span class="text-muted">{!! percentageChange(cache('users_previous_month'), cache('users_this_month')) !!}</span>
                                    <div class="detail-value">{{cache('users_this_month')}}</div>
                                    <div class="detail-name">{{__('This Month`s Users')}}</div>
                                </div>
                                <div class="statistic-details-item">
                                    <span class="text-muted">{!! percentageChange(cache('users_previous_year'), cache('users_this_year')) !!}</span>
                                    <div class="detail-value">{{cache('users_this_year')}}</div>
                                    <div class="detail-name">{{__('This Year`s Users')}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if( $resumes != null )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Resume Progress')}}</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                                @if(cache('resume_counts') == 0)
                                <li class="media">
                                    <div class="media-body">
                                        {{ __('No resume has been created yet.')}}
                                    </div>
                                </li>
                                @endif
                                @foreach( $resumes as $resume )
                                <li class="media">
                                    <img alt="image"
                                        class="rounded-circle mr-3"
                                        width="50"
                                        src="{{ ( $resume->avatar_path !=null ? $resume->avatar_path : ( $resume->avatar !=null ? asset($resume->avatar) : null ) ) ?? asset('img/avatar/avatar-'. mt_rand(1,5) .'.png') }}">
                                    <div class="media-body">
                                        <div class="media-title">{{ $resume->firstname }} {{ $resume->lastname }}</div>
                                        <div class="text-job text-muted">{{ $resume->professional_title }}</div>
                                    </div>
                                    <div class="media-body">
                                        <div class="media-title">{{ $resume->name }}</div>
                                        <div class="text-job text-muted">resume</div>
                                    </div>
                                    <div class="media-progressbar">
                                        <div class="progress-text">{{ calculateResumePercentageCompleted($resume->r_id, $resume->user_id) }}%</div>
                                        <div class="progress"
                                            data-height="15">
                                            <div class="progress-bar"
                                                data-width="{{ calculateResumePercentageCompleted($resume->r_id, $resume->user_id) }}%"></div>
                                        </div>
                                    </div>
                                    <div class="media-cta mt-2">
                                        <a href="{{ url('r/'. $resume->resume_id) }}"
                                            target="_blank"
                                            class="btn btn-outline-{{ displayBgColorProgress(calculateResumePercentageCompleted($resume->r_id, $resume->user_id)) }}">{{ __('Detail') }}</a>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    @endif
                    @if( $coverLetters != null )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Cover Letter Progress')}}</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                                @if(cache('cover_letter_counts') == 0)
                                <li class="media">
                                    <div class="media-body">
                                        {{ __('No cover letter has been created yet.')}}
                                    </div>
                                </li>
                                @endif
                                @foreach( $coverLetters as $coverLetter )
                                <li class="media">
                                    <img alt="image"
                                        class="rounded-circle mr-3"
                                        width="50"
                                        src="{{ ( $coverLetter->avatar_path !=null ? $coverLetter->avatar_path : ( $coverLetter->avatar !=null ? asset($coverLetter->avatar) : null ) ) ?? asset('img/avatar/avatar-'. mt_rand(1,5) .'.png') }}">
                                    <div class="media-body">
                                        <div class="media-title">{{ $coverLetter->firstname }} {{ $coverLetter->lastname }}</div>
                                        <div class="text-job text-muted">{{ $coverLetter->professional_title }}</div>
                                    </div>
                                    <div class="media-body">
                                        <div class="media-title">{{ $coverLetter->name }}</div>
                                        <div class="text-job text-muted">cover letter</div>
                                    </div>
                                    <div class="media-progressbar">
                                        <div class="progress-text">{{ calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id) }}%</div>
                                        <div class="progress"
                                            data-height="15">
                                            <div class="progress-bar"
                                                data-width="{{ calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id) }}%"></div>
                                        </div>
                                    </div>
                                    <div class="media-cta mt-2">
                                        <a href="{{ url('c/'. $coverLetter->cover_letter_id) }}"
                                            class="btn btn-outline-{{ displayBgColorProgress(calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id)) }}">{{ __('Detail') }}</a>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    @endif
                    @if( config('settings.subscription') )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Invoices') }}</h4>
                            <div class="card-header-action">
                                <a href="{{ route('dashboard.admin.payments.index') }}"
                                    class="btn btn-outline-danger">{{ __('View More') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive table-invoice">
                                <table class="table-striped table">
                                    <tr>
                                        <th>{{__('Invoice')}}</th>
                                        <th>{{__('User')}}</th>
                                        <th>{{__('Amount')}}</th>
                                        <th>{{__('Date')}}</th>
                                        <th>{{__('Status')}}</th>
                                        <th>{{__('Action')}}</th>
                                    </tr>
                                    
                                    @foreach($payments as $entry)
                                    <tr>
                                        <td>
                                            <a href="{{ url('dashboard/invoices/invoice') }}/{{$entry->invoice_id}}" class="badge badge-light text-truncate">{{ ( config('settings.billing_invoice_prefix') ?? 'INV') }}-{{$entry->p_id}}</a>
                                        </td>
                                        <td>{{$entry->firstname}} {{$entry->lastname}}</td>
                                        <td>{{$entry->amount}} {{$entry->currency}}</td>
                                        <td data-date="{{strtotime($entry->created_at)}}">
                                            <p class="m-0">{{date(config('settings.date_format'), strtotime($entry->p_created_at))}}</p>
                                        </td>
                                        <td>
                                            <div @if( $entry->payment_status == 'completed') class="badge badge-success" @else class="badge badge-warning" @endif>@if( $entry->payment_status == 'completed') {{__('Paid')}} @else {{__('Unpaid')}} @endif</div>
                                        </td>
                                        <td>
                                            <a href="{{ url('dashboard/invoices/invoice') }}/{{$entry->invoice_id}}"
                                                class="btn btn-outline-primary">{{ __('Detail') }}</a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                <div class="col-lg-4 col-md-12 col-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Recent Activities') }}</h4>
                        </div>
                        <div class="card-body">
                            @if( isset( $activity ) )
                                @if(count($activity) == 0)
                                <div class="text media-item">{{__('No activity logged yet.')}}</div>
                                @else
                                <ul class="list-unstyled list-unstyled-border">
                                    @foreach($activity as $entry)
                                    <li class="media">
                                        <img class="rounded-circle mr-3"
                                            width="50"
                                            src="{{ ( $entry->avatar_path !=null ? $entry->avatar_path : ( $entry->avatar !=null ? asset($entry->avatar) : null ) ) ?? asset('img/avatar/avatar-'. mt_rand(1,5) .'.png') }}"
                                            alt="avatar">
                                        <div class="media-body">
                                            <div class="text-primary float-right">{{ $entry->a_updated_at->diffForHumans() }}</div>
                                            <div class="media-title text-truncate">{{ $entry->firstname .' '.$entry->lastname }}</div>
                                            <span class="text-small text-muted"><strong>{{ $entry->activity_type }}</strong> {{ $entry->activity_title }}</span>
                                        </div>
                                    </li>
                                    @endforeach
                                </ul>
                                <div class="pt-1 pb-1 text-center">
                                    <a href="{{ route('dashboard.admin.activities') }}"
                                        class="btn btn-outline-primary btn-lg btn-round">
                                        {{ __('View All') }}
                                    </a>
                                </div>
                                @endif
                            @endif
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('User Details') }}</h4>
                        </div>
                        <div class="card-body">
                            @if( isset( $users ) )
                                @if(count($users) == 0)
                                <div class="text media-item">{{__('No user registered yet.')}}</div>
                                @else
                                <ul class="list-unstyled user-details list-unstyled-border list-unstyled-noborder">
                                    @foreach( $users as $user)
                                    <li class="media">
                                        <img alt="image"
                                            class="rounded-circle mr-3"
                                            width="50"
                                            src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar/avatar-'. mt_rand(1,5) .'.png') }}">
                                        <div class="media-body">
                                            <div class="media-title">{{ $user->firstname }} {{ $user->lastname }}</div>
                                            <div class="text-job text-muted">{{ $user->occupation }}</div>
                                        </div>
                                        <div class="media-items">
                                            <div class="media-item">
                                                <div class="media-value">{{ $user->resumeCounts() }}</div>
                                                <div class="media-label">{{ __('Resumes') }}</div>
                                            </div>
                                            <div class="media-item">
                                                <div class="media-value">{{ $user->coverLetterCounts() }}</div>
                                                <div class="media-label">{{ __('Covers') }}</div>
                                            </div>
                                        </div>
                                    </li>
                                    @endforeach
                                </ul>
                                <div class="pt-1 pb-1 text-center">
                                    <a href="{{ route('dashboard.admin.users.index') }}"
                                        class="btn btn-outline-primary btn-lg btn-round">
                                        {{ __('View All') }}
                                    </a>
                                </div>
                                @endif
                            @endif
                        </div>
                    </div>
                    @if( count(json_decode(cache('top_10_first_countries'))) > 0 )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Top Countries') }}</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <ul class="list-unstyled list-unstyled-border list-unstyled-noborder mb-0">
                                        @foreach(json_decode(cache('top_10_first_countries')) as $top_countries)
                                        <li class="media">
                                            <span class='flag-icon flag-icon-{{ Str::lower($top_countries->code) }}'></span>
                                            <div class="media-body ml-3">
                                                <div class="media-title">{{ $top_countries->name }}</div>
                                                <div class="text-small text-muted">{{ $top_countries->total }}</div>
                                            </div>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                                <div class="col-sm-6 mt-sm-0 mt-4">
                                    <ul class="list-unstyled list-unstyled-border list-unstyled-noborder mb-0">
                                        @foreach(json_decode(cache('top_10_second_countries')) as $top_countries)
                                        <li class="media">
                                            <span class='flag-icon flag-icon-{{ Str::lower($top_countries->code) }}'></span>
                                            <div class="media-body ml-3">
                                                <div class="media-title">{{ $top_countries->name }}</div>
                                                <div class="text-small text-muted">{{ $top_countries->total }}</div>
                                            </div>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraies -->
    <script src="{{ asset('vendor/chart.js/dist/Chart.min.js') }}"></script>
    <script src="{{ asset('vendor/chocolat/dist/js/jquery.chocolat.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script src="{{ asset('js/page/dashboard.min.js?v='. config('info.software.version')) }}"></script>
    <script>
        "use strict";

        var chartBorderColor = "{{ config('settings.site_theme_color') }}";

        var statistics_chart = document.getElementById("myChart").getContext('2d');

        var myChart = new Chart(statistics_chart, {
          type: 'line',
          data: {
            labels: [@foreach(json_decode(cache('last_week_dates')) as $date => $count) "{{ Carbon\Carbon::parse($date)->dayName}}", @endforeach],
            datasets: [{
              label: 'Users',
              data: [@foreach(json_decode(cache('last_week_dates')) as $date => $count) "{{$count}}", @endforeach],
              borderWidth: 5,
              borderColor: chartBorderColor,
              backgroundColor: 'transparent',
              pointBackgroundColor: '#fff',
              pointBorderColor: chartBorderColor,
              pointRadius: 4
            }]
          },
          options: {
            legend: {
              display: false
            },
            scales: {
              yAxes: [{
                gridLines: {
                  display: false,
                  drawBorder: false,
                },
                ticks: {
                  stepSize: 150
                }
              }],
              xAxes: [{
                gridLines: {
                  color: '#fbfbfb',
                  lineWidth: 2
                }
              }]
            },
          }
        });
    </script>
@endpush
