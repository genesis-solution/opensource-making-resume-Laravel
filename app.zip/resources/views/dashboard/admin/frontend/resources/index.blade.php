@extends('layouts.app')

@section('title', __('Frontend Resources'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.frontend.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Resources') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.frontend.index') }}">{{ __('Frontend') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Resources') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Resources') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all resources') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.frontend.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">

                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Resources') }}</h4>
                                <div class="card-header-form">
                                    <a class="btn btn-primary text-md-right" href="{{route('dashboard.admin.frontend.resources.item')}}">{{ __('Add New') }}</a>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table-striped table-md table">
                                        <tr>
                                            <th>{{__('Order')}}</th>
                                            <th>{{__('Icon')}}</th>
                                            <th>{{__('Title')}}</th>
                                            <th>{{__('Description')}}</th>
                                            <th>{{__('Date')}}</th>
                                            <th>{{__('Status')}}</th>
                                            <th>{{__('Actions')}}</th>
                                        </tr>
                                        @foreach($items as $entry)
                                        <tr>
                                            <td>{{$entry->order}}</td>
                                            <td><i class="{{$entry->icon}}"></i></td>
                                            <td>{{$entry->title}}</td>
                                            <td>{{$entry->description}}</td>
                                            <td data-date="{{strtotime($entry->created_at)}}">
                                                <p class="m-0">{{date(config('settings.date_format'), strtotime($entry->created_at))}}</p>
                                            </td>
                                            <td>
                                                <div @if( $entry->status == '1') class="badge badge-success" @else class="badge badge-danger" @endif>@if( $entry->status == '1') {{__('Active')}} @else {{__('Inactive')}} @endif</div>
                                            </td>
                                            <td class="text-nowrap">
                                                <a href="{{route('dashboard.admin.frontend.resources.item', $entry->id)}}" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                                <a type="button" class="btn btn-danger delete-confirm-item" data-section-id="resources" data-item-id="{{ $entry->id }}"><i class="fa-solid fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                            <div class="pull-right">
                                <div class="card-footer text-right">
                                    {!! $items->links() !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var frontendItemConfirmDeleteMsg = "{{__('Are you sure?')}}";
        var frontendItemDeleteNoRecoveryMsg = "{{__('You will not be able to recover the deleted item!')}}";
        var frontendItemDeletedSuccess = "{{ __('Item Deleted Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/frontend-setting-list.min.js?v='. config('info.software.version')) }}"></script>
@endpush
