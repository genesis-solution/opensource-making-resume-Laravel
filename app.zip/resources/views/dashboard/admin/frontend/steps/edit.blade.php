@extends('layouts.app')

@section('title', __('Frontend Steps'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.frontend.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Steps') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.frontend.index') }}">{{ __('Frontend') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Steps') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Steps') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all steps settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.frontend.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="step-item" 
                            onsubmit="stepCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="frontend-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Steps') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Steps item such as, item order, icon, title and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="order"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Order') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="order"
                                                class="form-control @error('order') is-invalid @enderror"
                                                id="order"
                                                min="1"
                                                value="{{ $item!=null ? $item->order : null }}"
                                                required>

                                            @error('order')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="icon"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Icon') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="icon"
                                                class="form-control @error('icon') is-invalid @enderror"
                                                id="icon"
                                                value="{{ $item!=null ? $item->icon : null }}"
                                                required>

                                            @error('icon')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="title"
                                                class="form-control @error('title') is-invalid @enderror"
                                                id="title"
                                                value="{{ $item!=null ? $item->title : null }}"
                                                required>

                                            @error('title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        $(function(){
            // Call Bootstrap Input Spinner
            $("input[type='number']").inputSpinner();
        });

        var itemBtnSaveMsg = "{{ __('Save') }}";
        var itemBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var itemSavedSuccess = "{{ __('Step Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/frontend-settings.min.js?v='. config('info.software.version')) }}"></script>
@endpush
