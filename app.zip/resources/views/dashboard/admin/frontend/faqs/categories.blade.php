@foreach(\App\Models\Category::all() as $category)
<option value="{{$category->id}}"{{$default_category == $category->id ? 'selected' : ''}}>{{$category->title}}</option>
@endforeach
