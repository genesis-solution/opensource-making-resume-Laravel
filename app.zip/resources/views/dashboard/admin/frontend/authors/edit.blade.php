@extends('layouts.app')

@section('title', __('Author'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.frontend.authors.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Author') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.frontend.authors.index') }}">{{ __('Authors') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Author') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Author') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all author settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.frontend.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="author-item" 
                            onsubmit="authorCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="author-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Author') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Author item such as, name, slug and so on.') }}</p>
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="name">{{ __('Name') }}</label>
                                            <input type="text"
                                                name="name"
                                                class="form-control @error('name') is-invalid @enderror"
                                                id="name"
                                                value="{{ $item!=null ? $item->name : null }}"
                                                required>

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="slug">{{ __('Slug') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Slug for SEO, such as cover-letters.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                            <input type="text"
                                                name="slug"
                                                class="form-control @error('slug') is-invalid @enderror"
                                                id="slug"
                                                value="{{ $item!=null ? $item->slug : null }}"
                                                required>

                                            @error('slug')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="image">{{ __('Image') }}</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ ( $item!=null && $item->image_path!=null ? $item->image_path : asset('img/author/author-'. rand(1,5) .'.png') ) }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="image" id="image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The file extension must be jpg, jpeg, png, gif, webp or svg.') }}</div>

                                            @error('image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="website">{{ __('Website') }}</label>
                                            <input type="url"
                                                name="website"
                                                class="form-control @error('website') is-invalid @enderror"
                                                id="website"
                                                placeholder="e.g.: https://domain.com" 
                                                value="{{ $item!=null ? $item->website : null }}">

                                            @error('website')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="occupation-card">
                                <div class="card-header">
                                    <h4>{{ __('Occupation') }}</h4>
                                </div>
                                <div class="card-body"> 
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="occupation">{{ __('Occupation') }}</label>
                                            <input id="occupation"
                                                type="text"
                                                class="form-control @error('occupation') is-invalid @enderror"
                                                name="occupation"
                                                value="{{ $item!=null ? $item->occupation : null }}"
                                                autocomplete="occupation">

                                            @error('occupation')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="yoe">{{ __('Years of Experience') }}</label>
                                            <input id="yoe"
                                                type="number"
                                                class="form-control @error('yoe') is-invalid @enderror"
                                                name="yoe"
                                                min="0"
                                                value="{{ $item!=null ? $item->yoe : null }}"
                                                autocomplete="yoe">

                                            @error('yoe')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="bio-card">
                                <div class="card-header">
                                    <h4>{{ __('Bio') }}</h4>
                                    <div class="card-header-form">
                                        @if( config('settings.openai') )
                                            <button type="button" id="generate-bio-btn" onclick="generateAIAuthorBio(); return false;" class="btn btn-warning btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ $aiGeneratedContentDescription }}">
                                                <i class="fa-solid fa-magic"></i> {{ __('Generate with AI') }} @if($aiGeneratedContentLeft >= 0)<span class="badge badge-transparent">{{ $aiGeneratedContentLeft }}</span>@endif
                                            </button>
                                        @endif
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="bio">{{ __('Bio') }}</label>
                                            <textarea id="bio" 
                                                name="bio"
                                                class="form-control summernote-simple"
                                                style="height:150px;"
                                            >{{ $item!=null ? $item->bio : null }}</textarea>

                                            @error('bio')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="privacy-card">
                                <div class="card-header">
                                    <h4>{{ __('Privacy') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label class="form-label" for="privacy">{{ __('Privacy') }}</label>
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Public') }}">
                                                    <input type="radio"
                                                        id="privacy-public"
                                                        name="privacy"
                                                        class="selectgroup-input"
                                                        value="0" @if( $item==null || ($item!=null && $item->privacy == '0') ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-globe"></i> {{ __('Public') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Private') }}">
                                                    <input type="radio"
                                                        id="privacy-private"
                                                        name="privacy"
                                                        class="selectgroup-input"
                                                        value="1" @if( $item!=null && $item->privacy == '1') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-lock"></i> {{ __('Private') }}</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="social-card">
                                <div class="card-header">
                                    <h4 data-toggle="collapse" href="#collapseSocialMedia" aria-expanded="true" aria-controls="collapseSocialMedia" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Social Media') }}</h4>
                                </div>
                                <div class="card-body collapse" id="collapseSocialMedia">
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="facebook">{{ __('Facebook') }}</label>
                                            <input id="facebook"
                                                type="text"
                                                class="form-control @error('facebook') is-invalid @enderror"
                                                name="facebook"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->facebook ?? null }}"
                                                autocomplete="facebook"
                                            >

                                            <p class="text-muted"><small>https://facebook.com/<span class="text-primary">username</span></small></p>

                                            @error('facebook')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="twitter">{{ __('Twitter') }}</label>
                                            <input id="twitter"
                                                type="text"
                                                class="form-control @error('twitter') is-invalid @enderror"
                                                name="twitter"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->twitter ?? null }}"
                                                autocomplete="twitter"
                                            >
                                            <p class="text-muted"><small>https://twitter.com/<span class="text-primary">username</span></small></p>

                                            @error('twitter')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    
                                        <div class="form-group col-md-4 col-12">
                                            <label for="linkedin">{{ __('LinkedIn') }}</label>
                                            <input id="linkedin"
                                                type="text"
                                                class="form-control @error('linkedin') is-invalid @enderror"
                                                name="linkedin"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->linkedin ?? null }}"
                                                autocomplete="linkedin"
                                            >
                                            <p class="text-muted"><small>https://www.linkedin.com/in/<span class="text-primary">username</span>/</small></p>

                                            @error('linkedin')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="pinterest">{{ __('Pinterest') }}</label>
                                            <input id="pinterest"
                                                type="text"
                                                class="form-control @error('pinterest') is-invalid @enderror"
                                                name="pinterest"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->pinterest ?? null }}"
                                                autocomplete="pinterest"
                                            >
                                            <p class="text-muted"><small>https://www.pinterest.com/<span class="text-primary">username</span>/</small></p>

                                            @error('pinterest')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="youtube">{{ __('YouTube') }}</label>
                                            <input id="youtube"
                                                type="text"
                                                class="form-control @error('youtube') is-invalid @enderror"
                                                name="youtube"
                                                data-mask="@handle" 
                                                data-mask-visible="true" 
                                                placeholder="@handle"
                                                value="{{ $item->social->youtube ?? null }}"
                                                autocomplete="youtube"
                                            >
                                            <p class="text-muted"><small>https://www.youtube.com/<span class="text-primary">@handle</span></small></p>

                                            @error('youtube')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="github">{{ __('GitHub') }}</label>
                                            <input id="github"
                                                type="text"
                                                class="form-control @error('github') is-invalid @enderror"
                                                name="github"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->github ?? null }}"
                                                autocomplete="github"
                                            >
                                            <p class="text-muted"><small>https://github.com/<span class="text-primary">username</span></small></p>

                                            @error('github')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="behance">{{ __('Behance') }}</label>
                                            <input id="behance"
                                                type="text"
                                                class="form-control @error('behance') is-invalid @enderror"
                                                name="behance"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->behance ?? null }}"
                                                autocomplete="behance"
                                            >
                                            <p class="text-muted"><small>https://www.behance.net/<span class="text-primary">username</span></small></p>

                                            @error('behance')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="instagram">{{ __('Instagram') }}</label>
                                            <input id="instagram"
                                                type="text"
                                                class="form-control @error('instagram') is-invalid @enderror"
                                                name="instagram"
                                                data-mask="username" 
                                                data-mask-visible="true" 
                                                placeholder="username"
                                                value="{{ $item->social->instagram ?? null }}"
                                                autocomplete="instagram"
                                            >
                                            <p class="text-muted"><small>https://www.instagram.com/<span class="text-primary">username</span>/</small></p>

                                            @error('instagram')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="tiktok">{{ __('TikTok') }}</label>
                                            <input id="tiktok"
                                                type="text"
                                                class="form-control @error('tiktok') is-invalid @enderror"
                                                name="tiktok"
                                                data-mask="@handle" 
                                                data-mask-visible="true" 
                                                placeholder="@handle"
                                                value="{{ $item->social->tiktok ?? null }}"
                                                autocomplete="tiktok"
                                            >
                                            <p class="text-muted"><small>https://www.tiktok.com/<span class="text-primary">@handle</span></small></p>

                                            @error('tiktok')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="status-card">
                                <div class="card-header">
                                    <h4>{{ __('Status') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="status">{{ __('Status') }}</label>
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/slugit-jquery/jquery.slugit.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var authorBtnSaveMsg = "{{ __('Save') }}";
        var authorBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var authorSavedSuccess = "{{ __('Author Saved Succesfully.') }}";
        var authorBioGeneratedSuccess = "{{ __('Author Bio Generated Succesfully.') }}";

        // Change Image Input Label
        $('#image').change(function() {
            var fileName = $(this)[0].files[0].name != undefined ? $(this)[0].files[0].name : '';
            $(this).parent().find('label').html(fileName);
        });
    </script>
    <script src="{{ asset('js/page/admin-authors.min.js?v='. config('info.software.version')) }}"></script>
@endpush
