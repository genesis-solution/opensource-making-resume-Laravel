<ul class="nav nav-pills flex-column">
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.index') }}"
                                            class="nav-link {{ (Request::is('*/frontend') ? 'active' : '') }}"><i class="fa-solid fa-flag"></i> <span>{{ __('Frontend') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.navs.index') }}"
                                            class="nav-link {{ (Request::is('*/navs*') ? 'active' : '') }}"><i class="fa-solid fa-bars"></i> <span>{{ __('Navigation') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.stats.index') }}"
                                            class="nav-link {{ (Request::is('*/stats*') ? 'active' : '') }}"><i class="fa-solid fa-chart-bar"></i> <span>{{ __('Stats') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.features.index') }}"
                                            class="nav-link {{ (Request::is('*/features*') ? 'active' : '') }}"><i class="fa-solid fa-puzzle-piece"></i> <span>{{ __('Features') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.steps.index') }}"
                                            class="nav-link {{ (Request::is('*/steps*') ? 'active' : '') }}"><i class="fa-solid fa-sort-numeric-up"></i> <span>{{ __('Steps') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.resources.index') }}"
                                            class="nav-link {{ (Request::is('*/resources*') ? 'active' : '') }}"><i class="fa-solid fa-life-ring"></i> <span>{{ __('Resources') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.categories.index') }}"
                                            class="nav-link {{ (Request::is('*/categories*') ? 'active' : '') }}"><i class="fa-solid fa-list"></i> <span>{{ __('Categories') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.faqs.index') }}"
                                            class="nav-link {{ (Request::is('*/faqs*') ? 'active' : '') }}"><i class="fa-solid fa-question"></i> <span>{{ __('Faqs') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.pages.index') }}"
                                            class="nav-link {{ (Request::is('*/pages*') ? 'active' : '') }}"><i class="fa-solid fa-file-alt"></i> <span>{{ __('Pages') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.authors.index') }}"
                                            class="nav-link {{ (Request::is('*/authors*') ? 'active' : '') }}"><i class="fa-solid fa-users"></i> <span>{{ __('Authors') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.posts.index') }}"
                                            class="nav-link {{ (Request::is('*/posts*') ? 'active' : '') }}"><i class="fa-solid fa-blog"></i> <span>{{ __('Posts') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.frontend.footer.index') }}"
                                            class="nav-link {{ (Request::is('*/footer*') ? 'active' : '') }}"><i class="fa-solid fa-bars"></i> <span>{{ __('Footer') }}</span></a></li>
                                </ul>