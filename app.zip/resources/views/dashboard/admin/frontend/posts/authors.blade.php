@foreach(\App\Models\Author::all() as $author)
<option value="{{$author->id}}"{{$default_author == $author->id ? 'selected' : ''}}>{{$author->name}}</option>
@endforeach
