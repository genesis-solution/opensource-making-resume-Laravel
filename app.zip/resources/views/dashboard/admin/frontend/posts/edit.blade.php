@extends('layouts.app')

@section('title', __('Post'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.frontend.posts.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Post') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.frontend.posts.index') }}">{{ __('Posts') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Post') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Post') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all post settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.frontend.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="post-item" 
                            onsubmit="postCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="post-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Post') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Post item such as, title, slug, description and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Title') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="title"
                                                class="form-control @error('title') is-invalid @enderror"
                                                id="title"
                                                value="{{ $item!=null ? $item->title : null }}"
                                                required>

                                            @error('title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="slug"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Slug') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Slug for SEO, such as cover-letters.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="slug"
                                                class="form-control @error('slug') is-invalid @enderror"
                                                id="slug"
                                                value="{{ $item!=null ? $item->slug : null }}"
                                                required>

                                            @error('slug')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="category_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Category') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <select name="category_id"
                                                    class="form-control select2 @error('category_id') is-invalid @enderror" 
                                                    id="category_id">
                                                    @include('dashboard.admin.frontend.posts.categories', ['default_category' => ( $item!=null && $item->category_id ? $item->category_id : null) ])
                                                </select>

                                            @error('category_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="author_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Author') }}</label>
                                            <div class="col-sm-9 col-md-9">
                                                <select name="author_id"
                                                    class="form-control select2 @error('author_id') is-invalid @enderror" 
                                                    id="author_id">
                                                    @include('dashboard.admin.frontend.posts.authors', ['default_author' => ( $item!=null && $item->author_id ? $item->author_id : null) ])
                                                </select>

                                            @error('author_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea id="description" 
                                                name="description"
                                                class="form-control"
                                                data-max-chars="500"
                                                data-height="100"
                                            >{{ $item!=null ? $item->description : null }}</textarea>

                                            @error('description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="keywords"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Keywords') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="keywords"
                                                class="form-control inputtags @error('keywords') is-invalid @enderror"
                                                id="keywords"
                                                value="{{ $item!=null ? $item->keywords : null }}"
                                                required>

                                            @error('keywords')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ ( $item!=null && $item->image_path!=null ? $item->image_path : asset('img/blog/blog-'. rand(1,5) .'.jpg') ) }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="image" id="image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should be at least 650x425 pixels and not exceed 1MB in size.') }}</div>

                                            @error('image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="content"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Content') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea id="content" 
                                                name="content"
                                                class="form-control summernote"
                                                style="height:75px;"
                                            >{{ $item!=null ? $item->content : null }}</textarea>

                                            @error('content')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="tags"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tags') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="tags"
                                                class="form-control inputtags @error('tags') is-invalid @enderror"
                                                id="tags"
                                                value="{{ $item!=null ? $item->tags : null }}">

                                            @error('tags')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/jquery-charactercounter/jquery.charactercounter.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/slugit-jquery/jquery.slugit.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var itemBtnSaveMsg = "{{ __('Save') }}";
        var itemBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var itemFileExtErrorMsg = "{{ __('The file extension must be jpg, jpeg, png, gif, webp or svg.') }}";
        var itemSavedSuccess = "{{ __('Post Saved Succesfully.') }}";
    </script>
    <script>
        $(function () {
            // Summernote
            $('.summernote').summernote({
                styleWithSpan: false,
                toolbar: [
                    ['style', ['bold', 'italic', 'underline', 'clear']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color', 'undo', 'redo']],
                    ['para', ['style', 'ul', 'ol', 'paragraph', 'height', 'hr']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture', 'video']],
                    ['view', ['codeview']]
                ]
            });

            // jQuery Character Counts
            $('#description').characterCounter();
            
            // Call Bootstrap InputTags
            $(".inputtags").tagsinput('items');

            // Call Bootstrap Input Spinner
            $("input[type='number']").inputSpinner();

            // Call Slugit jQuery
            $('#title').slugIt();
        });
    </script> 
    <script src="{{ asset('js/page/frontend-settings.min.js?v='. config('info.software.version')) }}"></script>
@endpush
