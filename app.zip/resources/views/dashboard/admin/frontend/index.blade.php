@extends('layouts.app')

@section('title', __('Frontend'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.frontend.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Frontend') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Frontend') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Frontend') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all frontend settings.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.frontend.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form method="POST"
                            action="{{ url('/dashboard/admin/frontend/save') }}"
                            enctype="multipart/form-data"
                            id="general-settings-form"
                            class="needs-validation"
                            novalidate="">
                            @csrf

                            <div class="card"
                                id="hero-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Hero') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_hero" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Hero') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_hero"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_hero') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_hero_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Hero Byline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_hero_byline"
                                                class="form-control @error('frontend_hero_byline') is-invalid @enderror"
                                                id="frontend_hero_byline"
                                                value="{{ old('frontend_hero_byline') ?? config('frontends.frontend_hero_byline') }}">

                                            @error('frontend_hero_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_hero_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Hero Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_hero_headline"
                                                class="form-control @error('frontend_hero_headline') is-invalid @enderror"
                                                id="frontend_hero_headline"
                                                value="{{ old('frontend_hero_headline') ?? config('frontends.frontend_hero_headline') }}">

                                            @error('frontend_hero_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_hero_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Hero Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_hero_description') is-invalid @enderror"
                                                name="frontend_hero_description"
                                                id="frontend_hero_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_hero_description') ?? config('frontends.frontend_hero_description') }}</textarea>

                                            @error('frontend_hero_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Hero Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('frontends.frontend_hero_image') ? asset(config('frontends.frontend_hero_image')) : asset('img/logo.png') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="frontend_hero_image" id="frontend_hero_image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="frontend_hero_image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 1MB in size.') }}</div>

                                            @error('frontend_hero_image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_hero_button"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Hero Button') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_hero_button"
                                                class="form-control @error('frontend_hero_button') is-invalid @enderror"
                                                id="frontend_hero_button"
                                                value="{{ old('frontend_hero_button') ?? config('frontends.frontend_hero_button') }}">

                                            @error('frontend_hero_button')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_hero_button_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Hero Button Url') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_hero_button_url"
                                                class="form-control @error('frontend_hero_button_url') is-invalid @enderror"
                                                id="frontend_hero_button_url"
                                                value="{{ old('frontend_hero_button_url') ?? config('frontends.frontend_hero_button_url') }}">

                                            @error('frontend_hero_button_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="stats-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Stats') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_stats" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Stats') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_stats"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_stats') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_stats_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stats Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_stats_headline"
                                                class="form-control @error('frontend_stats_headline') is-invalid @enderror"
                                                id="frontend_stats_headline"
                                                value="{{ old('frontend_stats_headline') ?? config('frontends.frontend_stats_headline') }}">

                                            @error('frontend_stats_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_stats_description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stats Description') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_stats_description"
                                                class="form-control @error('frontend_stats_description') is-invalid @enderror"
                                                id="frontend_stats_description"
                                                value="{{ old('frontend_stats_description') ?? config('frontends.frontend_stats_description') }}">

                                            @error('frontend_stats_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_stats_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Stats Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_stats_highlight_words"
                                                class="form-control inputtags @error('frontend_stats_highlight_words') is-invalid @enderror"
                                                id="frontend_stats_highlight_words"
                                                value="{{ old('frontend_stats_highlight_words') ?? config('frontends.frontend_stats_highlight_words') }}">

                                            @error('frontend_stats_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="features-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Features') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_features" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Features') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_features"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_features') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_features_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Features Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_features_headline"
                                                class="form-control @error('frontend_features_headline') is-invalid @enderror"
                                                id="frontend_features_headline"
                                                value="{{ old('frontend_features_headline') ?? config('frontends.frontend_features_headline') }}">

                                            @error('frontend_features_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_features_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Features Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_features_description') is-invalid @enderror"
                                                name="frontend_features_description"
                                                id="frontend_features_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_features_description') ?? config('frontends.frontend_features_description') }}</textarea>

                                            @error('frontend_features_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_features_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Features Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_features_highlight_words"
                                                class="form-control inputtags @error('frontend_features_highlight_words') is-invalid @enderror"
                                                id="frontend_features_highlight_words"
                                                value="{{ old('frontend_features_highlight_words') ?? config('frontends.frontend_features_highlight_words') }}">

                                            @error('frontend_features_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="declare-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Declare') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_declare" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Declare') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_declare"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_declare') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Declare Byline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_declare_byline"
                                                class="form-control @error('frontend_declare_byline') is-invalid @enderror"
                                                id="frontend_declare_byline"
                                                value="{{ old('frontend_declare_byline') ?? config('frontends.frontend_declare_byline') }}">

                                            @error('frontend_declare_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Declare Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_declare_headline"
                                                class="form-control @error('frontend_declare_headline') is-invalid @enderror"
                                                id="frontend_declare_headline"
                                                value="{{ old('frontend_declare_headline') ?? config('frontends.frontend_declare_headline') }}">

                                            @error('frontend_declare_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Declare Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_declare_description') is-invalid @enderror"
                                                name="frontend_declare_description"
                                                id="frontend_declare_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_declare_description') ?? config('frontends.frontend_declare_description') }}</textarea>

                                            @error('frontend_declare_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Declare Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_declare_highlight_words"
                                                class="form-control inputtags @error('frontend_declare_highlight_words') is-invalid @enderror"
                                                id="frontend_declare_highlight_words"
                                                value="{{ old('frontend_declare_highlight_words') ?? config('frontends.frontend_declare_highlight_words') }}">

                                            @error('frontend_declare_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Declare Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('frontends.frontend_declare_image') ? asset(config('frontends.frontend_declare_image')) : asset('img/logo.png') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="frontend_declare_image" id="frontend_declare_image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="frontend_declare_image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 1MB in size.') }}</div>

                                            @error('frontend_declare_image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_link_text"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Declare Link') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_declare_link_text"
                                                class="form-control @error('frontend_declare_link_text') is-invalid @enderror"
                                                id="frontend_declare_link_text"
                                                value="{{ old('frontend_declare_link_text') ?? config('frontends.frontend_declare_link_text') }}">

                                            @error('frontend_declare_link_text')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_declare_link_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Declare Link Url') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_declare_link_url"
                                                class="form-control @error('frontend_declare_link_url') is-invalid @enderror"
                                                id="frontend_declare_link_url"
                                                value="{{ old('frontend_declare_link_url') ?? config('frontends.frontend_declare_link_url') }}">

                                            @error('frontend_declare_link_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="pricing-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Pricing') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_pricing" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Pricing') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_pricing"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_pricing') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_pricing_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Pricing Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_pricing_headline"
                                                class="form-control @error('frontend_pricing_headline') is-invalid @enderror"
                                                id="frontend_pricing_headline"
                                                value="{{ old('frontend_pricing_headline') ?? config('frontends.frontend_pricing_headline') }}">

                                            @error('frontend_pricing_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_pricing_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Pricing Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_pricing_description') is-invalid @enderror"
                                                name="frontend_pricing_description"
                                                id="frontend_pricing_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_pricing_description') ?? config('frontends.frontend_pricing_description') }}</textarea>

                                            @error('frontend_pricing_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_pricing_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Pricing Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_pricing_highlight_words"
                                                class="form-control inputtags @error('frontend_pricing_highlight_words') is-invalid @enderror"
                                                id="frontend_pricing_highlight_words"
                                                value="{{ old('frontend_pricing_highlight_words') ?? config('frontends.frontend_pricing_highlight_words') }}">

                                            @error('frontend_pricing_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="appeal-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Appeal') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_appeal" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Appeal') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_appeal"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_appeal') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_byline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Byline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_appeal_byline"
                                                class="form-control @error('frontend_appeal_byline') is-invalid @enderror"
                                                id="frontend_appeal_byline"
                                                value="{{ old('frontend_appeal_byline') ?? config('frontends.frontend_appeal_byline') }}">

                                            @error('frontend_appeal_byline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_appeal_headline"
                                                class="form-control @error('frontend_appeal_headline') is-invalid @enderror"
                                                id="frontend_appeal_headline"
                                                value="{{ old('frontend_appeal_headline') ?? config('frontends.frontend_appeal_headline') }}">

                                            @error('frontend_appeal_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Appeal Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_appeal_description') is-invalid @enderror"
                                                name="frontend_appeal_description"
                                                id="frontend_appeal_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_appeal_description') ?? config('frontends.frontend_appeal_description') }}</textarea>

                                            @error('frontend_appeal_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_appeal_highlight_words"
                                                class="form-control inputtags @error('frontend_appeal_highlight_words') is-invalid @enderror"
                                                id="frontend_appeal_highlight_words"
                                                value="{{ old('frontend_appeal_highlight_words') ?? config('frontends.frontend_appeal_highlight_words') }}">

                                            @error('frontend_appeal_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('frontends.frontend_appeal_image') ? asset(config('frontends.frontend_appeal_image')) : asset('img/logo.png') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="frontend_appeal_image" id="frontend_appeal_image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="frontend_appeal_image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 1MB in size.') }}</div>

                                            @error('frontend_appeal_image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_link_text"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Link') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_appeal_link_text"
                                                class="form-control @error('frontend_appeal_link_text') is-invalid @enderror"
                                                id="frontend_appeal_link_text"
                                                value="{{ old('frontend_appeal_link_text') ?? config('frontends.frontend_appeal_link_text') }}">

                                            @error('frontend_appeal_link_text')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_appeal_link_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Appeal Link Url') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_appeal_link_url"
                                                class="form-control @error('frontend_appeal_link_url') is-invalid @enderror"
                                                id="frontend_appeal_link_url"
                                                value="{{ old('frontend_appeal_link_url') ?? config('frontends.frontend_appeal_link_url') }}">

                                            @error('frontend_appeal_link_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="tryout-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Tryout') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_tryout" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Tryout') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_tryout"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_tryout') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_tryout_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tryout Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_tryout_headline"
                                                class="form-control @error('frontend_tryout_headline') is-invalid @enderror"
                                                id="frontend_tryout_headline"
                                                value="{{ old('frontend_tryout_headline') ?? config('frontends.frontend_tryout_headline') }}">

                                            @error('frontend_tryout_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_tryout_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Tryout Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_tryout_description') is-invalid @enderror"
                                                name="frontend_tryout_description"
                                                id="frontend_tryout_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_tryout_description') ?? config('frontends.frontend_tryout_description') }}</textarea>

                                            @error('frontend_tryout_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_tryout_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tryout Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_tryout_highlight_words"
                                                class="form-control inputtags @error('frontend_tryout_highlight_words') is-invalid @enderror"
                                                id="frontend_tryout_highlight_words"
                                                value="{{ old('frontend_tryout_highlight_words') ?? config('frontends.frontend_tryout_highlight_words') }}">

                                            @error('frontend_tryout_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_tryout_button"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tryout Button') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_tryout_button"
                                                class="form-control @error('frontend_tryout_button') is-invalid @enderror"
                                                id="frontend_tryout_button"
                                                value="{{ old('frontend_tryout_button') ?? config('frontends.frontend_tryout_button') }}">

                                            @error('frontend_tryout_button')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_tryout_button_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tryout Button Url') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_tryout_button_url"
                                                class="form-control @error('frontend_tryout_button_url') is-invalid @enderror"
                                                id="frontend_tryout_button_url"
                                                value="{{ old('frontend_tryout_button_url') ?? config('frontends.frontend_tryout_button_url') }}">

                                            @error('frontend_tryout_button_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="steps-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Steps') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_steps" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Steps') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_steps"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_steps') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_steps_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Steps Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_steps_headline"
                                                class="form-control @error('frontend_steps_headline') is-invalid @enderror"
                                                id="frontend_steps_headline"
                                                value="{{ old('frontend_steps_headline') ?? config('frontends.frontend_steps_headline') }}">

                                            @error('frontend_steps_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_steps_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Steps Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_steps_description') is-invalid @enderror"
                                                name="frontend_steps_description"
                                                id="frontend_steps_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_steps_description') ?? config('frontends.frontend_steps_description') }}</textarea>

                                            @error('frontend_steps_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_steps_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Steps HIghlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_steps_highlight_words"
                                                class="form-control inputtags @error('frontend_steps_highlight_words') is-invalid @enderror"
                                                id="frontend_steps_highlight_words"
                                                value="{{ old('frontend_steps_highlight_words') ?? config('frontends.frontend_steps_highlight_words') }}">

                                            @error('frontend_steps_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label class="form-control-label col-sm-3 text-md-right">{{ __('Steps Image') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text py-1 px-2"><img src="{{ config('frontends.frontend_steps_image') ? asset(config('frontends.frontend_steps_image')) : asset('img/logo.png') }}" style="max-height: 1.625rem" /></span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" name="frontend_steps_image" id="frontend_steps_image" class="custom-file-input" accept="jpg,jpeg,png,gif,webp,svg">
                                                    <label class="custom-file-label" for="frontend_steps_image" data-browse="Browse">{{ __('Choose file') }}</label>
                                                </div>
                                            </div>
                                            <div class="form-text text-muted">{{ __('The image should not exceed 1MB in size.') }}</div>

                                            @error('frontend_steps_image')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="templates-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Templates') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_templates" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Templates') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_templates"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_templates') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_templates_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Templates Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_templates_headline"
                                                class="form-control @error('frontend_templates_headline') is-invalid @enderror"
                                                id="frontend_templates_headline"
                                                value="{{ old('frontend_templates_headline') ?? config('frontends.frontend_templates_headline') }}">

                                            @error('frontend_templates_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_templates_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Templates Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_templates_description') is-invalid @enderror"
                                                name="frontend_templates_description"
                                                id="frontend_templates_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_templates_description') ?? config('frontends.frontend_templates_description') }}</textarea>

                                            @error('frontend_templates_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_templates_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Templates Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_templates_highlight_words"
                                                class="form-control inputtags @error('frontend_templates_highlight_words') is-invalid @enderror"
                                                id="frontend_templates_highlight_words"
                                                value="{{ old('frontend_templates_highlight_words') ?? config('frontends.frontend_templates_highlight_words') }}">

                                            @error('frontend_templates_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="carryout-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Carryout') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_carryout" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Carryout') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_carryout"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_carryout') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_carryout_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Carryout Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_carryout_headline"
                                                class="form-control @error('frontend_carryout_headline') is-invalid @enderror"
                                                id="frontend_carryout_headline"
                                                value="{{ old('frontend_carryout_headline') ?? config('frontends.frontend_carryout_headline') }}">

                                            @error('frontend_carryout_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_carryout_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Carryout Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_carryout_description') is-invalid @enderror"
                                                name="frontend_carryout_description"
                                                id="frontend_carryout_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_carryout_description') ?? config('frontends.frontend_carryout_description') }}</textarea>

                                            @error('frontend_carryout_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_carryout_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Carryout Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_carryout_highlight_words"
                                                class="form-control inputtags @error('frontend_carryout_highlight_words') is-invalid @enderror"
                                                id="frontend_carryout_highlight_words"
                                                value="{{ old('frontend_carryout_highlight_words') ?? config('frontends.frontend_carryout_highlight_words') }}">

                                            @error('frontend_carryout_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_carryout_button"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Carryout Button') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_carryout_button"
                                                class="form-control @error('frontend_carryout_button') is-invalid @enderror"
                                                id="frontend_carryout_button"
                                                value="{{ old('frontend_carryout_button') ?? config('frontends.frontend_carryout_button') }}">

                                            @error('frontend_carryout_button')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_carryout_button_url"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Carryout Button Url') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_carryout_button_url"
                                                class="form-control @error('frontend_carryout_button_url') is-invalid @enderror"
                                                id="frontend_carryout_button_url"
                                                value="{{ old('frontend_carryout_button_url') ?? config('frontends.frontend_carryout_button_url') }}">

                                            @error('frontend_carryout_button_url')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="resources-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Resources') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_resources" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Resources') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_resources"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_resources') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="faqs-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Faqs') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_faqs" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Faqs') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_faqs"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_faqs') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_faqs_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Faqs Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_faqs_headline"
                                                class="form-control @error('frontend_faqs_headline') is-invalid @enderror"
                                                id="frontend_faqs_headline"
                                                value="{{ old('frontend_faqs_headline') ?? config('frontends.frontend_faqs_headline') }}">

                                            @error('frontend_faqs_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_faqs_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Faqs Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_faqs_description') is-invalid @enderror"
                                                name="frontend_faqs_description"
                                                id="frontend_faqs_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_faqs_description') ?? config('frontends.frontend_faqs_description') }}</textarea>

                                            @error('frontend_faqs_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_faqs_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Faqs Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_faqs_highlight_words"
                                                class="form-control inputtags @error('frontend_faqs_highlight_words') is-invalid @enderror"
                                                id="frontend_faqs_highlight_words"
                                                value="{{ old('frontend_faqs_highlight_words') ?? config('frontends.frontend_faqs_highlight_words') }}">

                                            @error('frontend_faqs_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="blog-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Blog') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_blog" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Blog') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_blog"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_blog') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_blog_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Blog Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_blog_headline"
                                                class="form-control @error('frontend_blog_headline') is-invalid @enderror"
                                                id="frontend_blog_headline"
                                                value="{{ old('frontend_blog_headline') ?? config('frontends.frontend_blog_headline') }}">

                                            @error('frontend_blog_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_blog_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Blog Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_blog_description') is-invalid @enderror"
                                                name="frontend_blog_description"
                                                id="frontend_blog_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_blog_description') ?? config('frontends.frontend_blog_description') }}</textarea>

                                            @error('frontend_blog_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_blog_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Blog Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_blog_highlight_words"
                                                class="form-control inputtags @error('frontend_blog_highlight_words') is-invalid @enderror"
                                                id="frontend_blog_highlight_words"
                                                value="{{ old('frontend_blog_highlight_words') ?? config('frontends.frontend_blog_highlight_words') }}">

                                            @error('frontend_blog_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="contact-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Contact') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_contact" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Contact') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_contact"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_contact') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_contact_headline"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Contact Headline') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_contact_headline"
                                                class="form-control @error('frontend_contact_headline') is-invalid @enderror"
                                                id="frontend_contact_headline"
                                                value="{{ old('frontend_contact_headline') ?? config('frontends.frontend_contact_headline') }}">

                                            @error('frontend_contact_headline')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_contact_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Contact Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_contact_description') is-invalid @enderror"
                                                name="frontend_contact_description"
                                                id="frontend_contact_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_contact_description') ?? config('frontends.frontend_contact_description') }}</textarea>

                                            @error('frontend_contact_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_contact_highlight_words"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Contact Highlight Words') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_contact_highlight_words"
                                                class="form-control inputtags @error('frontend_contact_highlight_words') is-invalid @enderror"
                                                id="frontend_contact_highlight_words"
                                                value="{{ old('frontend_contact_highlight_words') ?? config('frontends.frontend_contact_highlight_words') }}">

                                            @error('frontend_contact_highlight_words')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="footer-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Footer') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="frontend_footer" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Footer') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="frontend_footer"
                                                    class="custom-switch-input"
                                                    @if( config('frontends.frontend_footer') == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_footer_title"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Footer Title') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_footer_title"
                                                class="form-control @error('frontend_footer_title') is-invalid @enderror"
                                                id="frontend_footer_title"
                                                value="{{ old('frontend_footer_title') ?? config('frontends.frontend_footer_title') }}">

                                            @error('frontend_footer_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_footer_description"
                                            class="form-control-label col-sm-3 text-md-right">{{__('Footer Description')}}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <textarea class="form-control @error('frontend_footer_description') is-invalid @enderror"
                                                name="frontend_footer_description"
                                                id="frontend_footer_description"
                                                data-max-chars="255"
                                                data-height="100">{{ old('frontend_footer_description') ?? config('frontends.frontend_footer_description') }}</textarea>

                                            @error('frontend_footer_description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="frontend_footer_copyright"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Footer Copyright') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <input type="text"
                                                name="frontend_footer_copyright"
                                                class="form-control @error('frontend_footer_copyright') is-invalid @enderror"
                                                id="frontend_footer_copyright"
                                                value="{{ old('frontend_footer_copyright') ?? config('frontends.frontend_footer_copyright') }}">

                                            @error('frontend_footer_copyright')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
    <script src="{{ asset('vendor/jquery-charactercounter/jquery.charactercounter.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        $(function(){
            // jQuery Character Counts
            $('textarea').characterCounter();

            // Call Bootstrap InputTags
            $(".inputtags").tagsinput('items');

            // Change Image Input Label
            $('#frontend_hero_image, #frontend_declare_image, #frontend_appeal_image, #frontend_steps_image').change(function() {
                var fileName = $(this)[0].files[0].name != undefined ? $(this)[0].files[0].name : '';
                $(this).parent().find('label').html(fileName);
            });
        });
    </script>
@endpush
