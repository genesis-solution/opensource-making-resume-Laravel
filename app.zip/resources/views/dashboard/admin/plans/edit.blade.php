@extends('layouts.app')

@section('title', __('Plan'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.plans.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Plan') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.plans.index') }}"> {{ __('Plans') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Plan') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Plan') }}</h2>
                <p class="section-lead">
                    {{ __('The details of the plan') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.plans.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="nav-item" 
                            onsubmit="planCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="plan-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Plan') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Plan settings such as, name, description, order, status and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="name"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Name') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="name"
                                                class="form-control @error('name') is-invalid @enderror"
                                                id="name"
                                                value="{{ $item!=null ? $item->name : null }}"
                                                required>

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="description"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Description') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="description"
                                                class="form-control @error('description') is-invalid @enderror"
                                                id="description"
                                                value="{{ $item!=null ? $item->description : null }}"
                                                required>

                                            @error('description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="trial_days"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Trial Days') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="trial_days"
                                                min="0"
                                                class="form-control @error('trial_days') is-invalid @enderror"
                                                id="trial_days"
                                                value="{{ $item!=null ? $item->trial_days : null }}"
                                                required>

                                            @error('trial_days')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="tax_rates"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Tax Rates') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select name="tax_rates[]" 
                                                id="tax_rates" 
                                                class="custom-select select2 @error('tax_rates') is-invalid @enderror" 
                                                multiple>
                                                @foreach($taxRates as $taxRate)
                                                    <option value="{{ $taxRate->id }}" @if( $item!=null && ( $item->tax_rates !== null && in_array($taxRate->id, $item->tax_rates) ) ) selected @endif>{{ $taxRate->name }} ({{ number_format($taxRate->percentage, 2, __('.'), __(',')) }}% {{ ($taxRate->type ? __('Exclusive') : __('Inclusive')) }})</option>
                                                @endforeach
                                            </select>

                                            @error('tax_rates')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="amount_month"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Monthly') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="amount_month"
                                                class="form-control @error('amount_month') is-invalid @enderror"
                                                id="amount_month"
                                                value="{{ $item!=null ? $item->amount_month : null }}"
                                                required>

                                            @error('amount_month')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="amount_year"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Yearly') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="amount_year"
                                                class="form-control @error('amount_year') is-invalid @enderror"
                                                id="amount_year"
                                                value="{{ $item!=null ? $item->amount_year : null }}"
                                                required>

                                            @error('amount_year')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="order"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Order') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="order"
                                                min="0"
                                                class="form-control @error('order') is-invalid @enderror"
                                                id="order"
                                                value="{{ $item!=null ? $item->order : null }}"
                                                required>

                                            @error('order')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="highlight" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Highlight') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="highlight"
                                                    class="custom-switch-input"
                                                    id="highlight"
                                                    @if( $item!=null && $item->highlight == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="features-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Features') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="resumes"
                                            class="form-control-label col-sm-3 mb-4 text-md-right">{{ __('Resumes') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="resumes"
                                                class="form-control @error('resumes') is-invalid @enderror"
                                                id="resumes"
                                                min="-1"
                                                value="{{ $item->features->resumes ?? null }}"
                                                required>

                                            @error('resumes')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-small text-muted mt-2">{!! __(':value for unlimited.', ['value' => '<code class="badge badge-secondary">-1</code>']) !!} {!! __(':value for none.', ['value' => '<code class="badge badge-secondary">0</code>']) !!} {!! __(':value for number.', ['value' => '<code class="badge badge-secondary">N</code>']) !!}</div>
                                        </div>
                                    </div>

                                    <div class="form-group row align-items-center">
                                        <label for="cover_letters"
                                            class="form-control-label col-sm-3 mb-4 text-md-right">{{ __('Cover Letters') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="cover_letters"
                                                class="form-control @error('cover_letters') is-invalid @enderror"
                                                id="cover_letters"
                                                min="-1"
                                                value="{{ $item->features->cover_letters ?? null }}"
                                                required>

                                            @error('cover_letters')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-small text-muted mt-2">{!! __(':value for unlimited.', ['value' => '<code class="badge badge-secondary">-1</code>']) !!} {!! __(':value for none.', ['value' => '<code class="badge badge-secondary">0</code>']) !!} {!! __(':value for number.', ['value' => '<code class="badge badge-secondary">N</code>']) !!}</div>
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="ai_generated_content"
                                            class="form-control-label col-sm-3 mb-4 text-md-right">{{ __('AI-Generated Content') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('The amount of requests made to OpenAI for producing AI-Generated Content.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="number"
                                                name="ai_generated_content"
                                                class="form-control @error('ai_generated_content') is-invalid @enderror"
                                                id="ai_generated_content"
                                                min="-1"
                                                value="{{ $item->features->ai_generated_content ?? null }}"
                                                required>

                                            @error('ai_generated_content')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-small text-muted mt-2">{!! __(':value for unlimited.', ['value' => '<code class="badge badge-secondary">-1</code>']) !!} {!! __(':value for none.', ['value' => '<code class="badge badge-secondary">0</code>']) !!} {!! __(':value for number.', ['value' => '<code class="badge badge-secondary">N</code>']) !!}</div>
                                        </div>
                                    </div>
                                    @if(config('settings.watermark') == '1')
                                    <div class="form-group row">
                                        <label for="white_label_resumes" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('White Label Resumes') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('White label, without watermark, resumes when printing or saving as PDF.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="white_label_resumes"
                                                    class="custom-switch-input"
                                                    id="white_label_resumes"
                                                    @if( isset($item->features->white_label_resumes) && $item->features->white_label_resumes == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="white_label_cover_letters" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('White Label Cover Letters') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('White label, without watermark, cover letters when printing or saving as PDF.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="white_label_cover_letters"
                                                    class="custom-switch-input"
                                                    id="white_label_cover_letters"
                                                    @if( isset($item->features->white_label_cover_letters) && $item->features->white_label_cover_letters == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    @endif
                                    <div class="form-group row">
                                        <label for="resume_tailoring" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Resume Tailoring') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Resume tailoring is the process of adapting your resume to a specific job opening or industry.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="resume_tailoring"
                                                    class="custom-switch-input"
                                                    id="resume_tailoring"
                                                    @if( isset($item->features->resume_tailoring) && $item->features->resume_tailoring == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="export_resumes" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Export Resume Data') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Export Resume Data in JSON or TXT format.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="export_resumes"
                                                    class="custom-switch-input"
                                                    id="export_resumes"
                                                    @if( isset($item->features->export_resumes) && $item->features->export_resumes == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="export_cover_letters" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Export Cover Letter Data') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Export Cover Letter Data in TXT format.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="export_cover_letters"
                                                    class="custom-switch-input"
                                                    id="export_cover_letters"
                                                    @if( isset($item->features->export_cover_letters) && $item->features->export_cover_letters == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="offerings-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Offerings') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row align-items-center">
                                        <label for="offerings"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Offerings') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Extra features provided in addition to the main features.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-9 col-md-9">
                                            <input type="text"
                                                name="offerings"
                                                class="form-control inputtags @error('offerings') is-invalid @enderror"
                                                id="offerings"
                                                value="{{ $item!=null ? $item->offerings : null }}">

                                            @error('offerings')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var planBtnSaveMsg = "{{ __('Save') }}";
        var planBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var planSavedSuccess = "{{ __('Plan Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-plans.min.js?v='. config('info.software.version')) }}"></script>
@endpush
