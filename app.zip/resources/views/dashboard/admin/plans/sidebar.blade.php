<ul class="nav nav-pills flex-column">
                                    @if( config('settings.subscription') )
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.plans.index') }}"
                                            class="nav-link {{ (Request::is('*/plans*') ? 'active' : '') }}"><i class="fa-solid fa-gift"></i> <span>{{ __('Plans') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.coupons.index') }}"
                                            class="nav-link {{ (Request::is('*/coupons*') ? 'active' : '') }}"><i class="fa-solid fa-tags"></i> <span>{{ __('Coupons') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.payments.index') }}"
                                            class="nav-link {{ (Request::is('*/payments*') ? 'active' : '') }}"><i class="fa-solid fa-shopping-cart"></i> <span>{{ __('Payments') }}</span></a></li>
                                    <li class="nav-item">
                                        <a href="{{ route('dashboard.admin.tax-rates.index') }}"
                                            class="nav-link {{ (Request::is('*/tax-rates*') ? 'active' : '') }}"><i class="fa-solid fa-percentage"></i> <span>{{ __('Tax Rates') }}</span></a></li>
                                    @endif
                                </ul>