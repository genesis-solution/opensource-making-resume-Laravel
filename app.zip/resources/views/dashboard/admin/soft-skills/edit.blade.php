@extends('layouts.app')

@section('title', __('Soft Skill'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.soft-skills.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Soft Skill') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.soft-skills.index') }}"> {{ __('Soft Skills') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Soft Skill') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Soft Skill') }}</h2>
                <p class="section-lead">
                    {{ __('The details of the soft skill') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="soft-skill-item" 
                            onsubmit="softSkillCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="soft-skill-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Soft Skill') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Soft Skill settings such as, keyword, status and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="keyword"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Keyword') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-signature"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="keyword"
                                                    class="form-control @error('keyword') is-invalid @enderror"
                                                    id="keyword"
                                                    value="{{ $item!=null ? $item->keyword : null }}"
                                                    required>
                                            </div>

                                            @error('keyword')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label col-sm-3 mt-1 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    class="custom-switch-input"
                                                    id="status"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var softSkillBtnSaveMsg = "{{ __('Save') }}";
        var softSkillBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var softSkillSavedSuccess = "{{ __('Soft Skill Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-soft-skills.min.js?v='. config('info.software.version')) }}"></script>
@endpush
