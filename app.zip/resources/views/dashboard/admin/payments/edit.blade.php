@extends('layouts.app')

@section('title', __('Payment'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.payments.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Payment') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.payments.index') }}"> {{ __('Payments') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Payment') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Payment') }}</h2>
                <p class="section-lead">
                    {{ __('The details of the payment') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.plans.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="payment-item" 
                            onsubmit="paymentSave({{ $payment->p_id }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="payment-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Payment') }}</h4>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted">{{ __('Payment information such as, invoice, amount, plan, user and so on.') }}</p>
                                    <div class="form-group row align-items-center">
                                        <label for="user_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('User') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="user_id" 
                                                name="user_id" 
                                                class="form-control select2 @error('user_id') is-invalid @enderror"
                                            >
                                                <option value="{{ $payment->u_id ?? null }}" {{ $payment->u_id == $payment->user_id ? 'selected' : '' }}>{{ $payment->firstname .' '. $payment->lastname }}</option>
                                            </select>

                                            @error('user_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="plan_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Plan') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="plan_id" 
                                                name="plan_id" 
                                                class="form-control select2 @error('plan_id') is-invalid @enderror"
                                            >
                                                <option value="{{ $payment->pl_id ?? null }}" {{ $payment->pl_id == $payment->plan_id ? 'selected' : '' }}>{{ $payment->name }}</option>
                                            </select>

                                            @error('plan_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row align-items-center">
                                        <label for="payment_id"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Payment Id') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-shopping-cart"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="payment_id"
                                                    class="form-control @error('payment_id') is-invalid @enderror"
                                                    id="payment_id"
                                                    value="{{ $payment->payment_id ?? Str::random(16) }}"
                                                    required>
                                            </div>

                                            @error('payment_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="processor"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Processor') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select name="processor"
                                                class="form-control select2 @error('processor') is-invalid @enderror" 
                                                id="processor" >
                                                <option value="{{ $payment->processor ?? null }}" selected>{{ $payment->processor!=null ? mb_ucfirst($payment->processor) : __('Select Processor') }}</option>
                                                <option value="paypal">PayPal</option>
                                                <option value="stripe">Stripe</option>
                                                <option value="bank">Bank</option>
                                            </select>

                                            @error('processor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="amount"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Amount') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fa-solid fa-hand-holding-usd"></i>
                                                    </div>
                                                </div>
                                                <input type="text"
                                                    name="amount"
                                                    class="form-control @error('amount') is-invalid @enderror"
                                                    id="amount"
                                                    value="{{ $payment->amount ?? null }}"
                                                    required>
                                            </div>

                                            @error('amount')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="currency"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Currency') }}</label>
                                                <div class="col-sm-9 col-md-9">
                                                    <select name="currency"
                                                        class="form-control select2 @error('currency') is-invalid @enderror" 
                                                        id="currency" >
                                                        @include('dashboard.admin.settings.currencies', ['default_currency' => config('settings.currency')])
                                                    </select>

                                            @error('currency')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row align-items-center">
                                        <label for="interval"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Interval') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Month') }}">
                                                    <input type="radio"
                                                        id="interval-month"
                                                        name="interval"
                                                        class="selectgroup-input"
                                                        value="month" @if( $payment->interval == 'month') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-calendar-day"></i></span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Year') }}">
                                                    <input type="radio"
                                                        id="interval-year"
                                                        name="interval"
                                                        class="selectgroup-input"
                                                        value="year" @if( $payment->interval == 'year') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-calendar"></i></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row align-items-center">
                                        <label for="payment_status"
                                            class="form-control-label col-sm-3 text-md-right">{{ __('Status') }}</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select name="payment_status"
                                                class="form-control select2 @error('payment_status') is-invalid @enderror" 
                                                id="payment_status" >
                                                <option value="{{ $payment->payment_status ?? null }}" selected>{{ $payment->payment_status!=null ? mb_ucfirst($payment->payment_status) : __('Select Status') }}</option>
                                                <option value="completed">{{ __('Completed') }}</option>
                                                <option value="pending">{{ __('Pending') }}</option>
                                                <option value="cancelled">{{ __('Cancelled') }}</option>
                                            </select>

                                            @error('payment_status')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var paymentBtnSaveMsg = "{{ __('Save') }}";
        var paymentBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var paymentSavedSuccess = "{{ __('Payment Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-payments.min.js?v='. config('info.software.version')) }}"></script>
@endpush
