@extends('layouts.app')

@section('title', __('Payment'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.payments.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Payments') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Payments') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Payments') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all payments') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.admin.plans.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Payments') }}</h4>
                                <div class="card-header-form">
                                    <form>
                                        <div class="input-group">
                                            <div class="input-group-btn">
                                                <span id="paymentExportButtons"></span>
                                            </div>
                                            <input type="text"
                                                id="paymentSearch"
                                                class="form-control"
                                                placeholder="{{ __('Search') }}">
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="payments" class="table table-striped responsive display wrap" border="0" style="width:100%">
                                        <thead>
                                            <th>{{__('#')}}</th>
                                            <th class="no-sort">{{__('Avatar')}}</th>
                                            <th>{{__('First Name')}}</th>
                                            <th>{{__('Last Name')}}</th>
                                            <th>{{__('Plan')}}</th>
                                            <th class="no-sort">{{__('Invoice')}}</th>
                                            <th>{{__('Processor')}}</th>
                                            <th>{{__('Amount')}}</th>
                                            <th>{{__('Interval')}}</th>
                                            <th>{{__('Date')}}</th>
                                            <th>{{__('Status')}}</th>
                                            <th class="no-sort">{{__('Actions')}}</th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables/media/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>  
    <script src="{{ asset('vendor/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>  
    <script src="{{ asset('vendor/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables.net-buttons/js/buttons.colVis.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var paymentListTableUrl = "{{ url('dashboard/admin/payments') }}";
        var paymentConfirmDeleteMsg = "{{__('Are you sure?')}}";
        var paymentDeleteNoRecoveryMsg = "{{__('You will not be able to recover the deleted payment!')}}";
        var paymentDeletedSuccess = "{{ __('Payment Deleted Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/admin-payment-list.min.js?v='. config('info.software.version')) }}"></script>
@endpush
