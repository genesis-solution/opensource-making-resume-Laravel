@extends('layouts.app')

@section('title', __('User'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-social/bootstrap-social.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.users.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('User') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.users.index') }}">{{ __('Users') }}</a></div>
                    <div class="breadcrumb-item">{{ __('User') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About User') }}</h2>
                <p class="section-lead">
                    {{ __('The profile details of the user') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row mt-sm-4">
                    <div class="col-12 col-md-12 col-lg-5">
                        <div class="card profile-widget">
                            <div class="profile-widget-header">
                                <img alt="image"
                                    src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                                    class="rounded-circle profile-widget-picture">
                                <div class="profile-widget-items">
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label">{{ __('Resumes') }}</div>
                                        <div class="profile-widget-item-value">{{ $resume_counts }}</div>
                                    </div>
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label">{{ __('Cover Letters') }}</div>
                                        <div class="profile-widget-item-value">{{ $cover_letter_counts }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-widget-description">
                                <div class="profile-widget-name">{{ $user->firstname .' '.  $user->lastname }} <div
                                        class="text-muted d-inline font-weight-normal">
                                        <div class="slash"></div> {{ $user->occupation }}
                                    </div>
                                </div>
                                {!! preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', $user->bio) !!}
                            </div>
                            <div class="card-footer text-center">
                                @if ( isset($user->social->facebook) && $user->social->facebook != '' )
                                <a href="https://facebook.com/{{ $user->social->facebook }}"
                                    class="btn btn-social-icon btn-facebook mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->twitter) && $user->social->twitter != '' )
                                <a href="https://twitter.com/{{ $user->social->twitter }}"
                                    class="btn btn-social-icon btn-x-twitter mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-x-twitter"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->linkedin) && $user->social->linkedin != '' )
                                <a href="https://www.linkedin.com/in/{{ $user->social->linkedin }}/"
                                    class="btn btn-social-icon btn-linkedin mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-linkedin"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->pinterest) && $user->social->pinterest != '' )
                                <a href="https://www.pinterest.com/{{ $user->social->pinterest }}/"
                                    class="btn btn-social-icon btn-pinterest mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-pinterest"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->youtube) && $user->social->youtube != '' )
                                <a href="https://www.youtube.com/{{ $user->social->youtube }}"
                                    class="btn btn-social-icon btn-youtube mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-youtube"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->github) && $user->social->github != '' )
                                <a href="https://github.com/{{ $user->social->github }}"
                                    class="btn btn-social-icon btn-github mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-github"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->behance) && $user->social->behance != '' )
                                <a href="https://www.behance.net/{{ $user->social->behance }}"
                                    class="btn btn-social-icon btn-behance mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-behance"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->instagram) && $user->social->instagram != '' )
                                <a href="https://www.instagram.com/{{ $user->social->instagram }}/"
                                    class="btn btn-social-icon btn-instagram"
                                    target="_blank">
                                    <i class="fa-brands fa-instagram"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->tiktok) && $user->social->tiktok != '' )
                                <a href="https://www.tiktok.com/{{ $user->social->tiktok }}"
                                    class="btn btn-social-icon btn-tiktok"
                                    target="_blank">
                                    <i class="fa-brands fa-tiktok"></i>
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-12 col-lg-7">
                        <form id="users-user" 
                            onsubmit="userSave({{ $user->id }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card" id="user-card">
                                <div class="card-header">
                                    <h4>{{ __('Edit User') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="firstname">{{ __('First Name') }}</label>
                                            <input id="firstname"
                                                type="text"
                                                class="form-control @error('firstname') is-invalid @enderror"
                                                tabindex="1"
                                                name="firstname"
                                                required 
                                                value="{{ old('firstname') ?? $user->firstname }}"
                                                autocomplete="firstname"
                                                autofocus
                                            >

                                            @error('firstname')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-6 col-12">
                                            <label for="lastname">{{ __('Last Name') }}</label>
                                            <input id="lastname"
                                                type="text"
                                                class="form-control @error('lastname') is-invalid @enderror"
                                                tabindex="2"
                                                name="lastname"
                                                required 
                                                value="{{ old('lastname') ?? $user->lastname }}"
                                                autocomplete="lastname"
                                            >

                                            @error('lastname')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="email">{{ __('Email Address') }}</label>
                                            <input id="email"
                                                type="email"
                                                class="form-control @error('email') is-invalid @enderror"
                                                name="email"
                                                tabindex="3"
                                                value="{{ old('email') ?? $user->email }}"
                                                required
                                                autocomplete="email"
                                            >

                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-6 col-12">
                                            <label for="phone">{{ __('Phone') }}</label>
                                            <input id="phone"
                                                type="tel"
                                                class="form-control @error('phone') is-invalid @enderror"
                                                name="phone"
                                                tabindex="4"
                                                value="{{ old('phone') ?? $user->phone }}"
                                                autocomplete="tel">

                                            <span id="phone_output"></span>

                                            @error('phone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="timezone">{{ __('Timezone') }}</label>
                                            <select id="timezone" 
                                                name="timezone" 
                                                class="form-control select2"
                                            >
                                                @foreach(timezone_identifiers_list() as $value)
                                                    <option value="{{ $value }}" @if ($value == $user->timezone) selected @endif>{{ $value }}</option>
                                                @endforeach
                                            </select>

                                            @error('timezone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="occupation-card">
                                <div class="card-header">
                                    <h4>{{ __('Occupation') }}</h4>
                                </div>
                                <div class="card-body"> 
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="occupation">{{ __('Occupation') }}</label>
                                            <input id="occupation"
                                                type="text"
                                                class="form-control @error('occupation') is-invalid @enderror"
                                                name="occupation"
                                                tabindex="5"
                                                value="{{ old('occupation') ?? $user->occupation }}"
                                                autocomplete="occupation"
                                            >

                                            @error('occupation')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="yoe">{{ __('Years of Experience') }}</label>
                                            <input id="yoe"
                                                type="text"
                                                class="form-control @error('yoe') is-invalid @enderror"
                                                name="yoe"
                                                min="0"
                                                tabindex="6"
                                                value="{{ old('yoe') ?? $user->yoe }}"
                                                autocomplete="yoe"
                                            >

                                            @error('yoe')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="address-card">
                                <div class="card-header">
                                    <h4>{{ __('Address') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="street">{{ __('Street') }}</label>
                                            <input id="street"
                                                type="text"
                                                class="form-control @error('street') is-invalid @enderror"
                                                name="street"
                                                tabindex="6"
                                                value="{{ $user->address->street ?? null }}"
                                                autocomplete="street"
                                            >

                                            @error('street')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="city">{{ __('City') }}</label>
                                            <input id="city"
                                                type="text"
                                                class="form-control @error('city') is-invalid @enderror"
                                                name="city"
                                                tabindex="7"
                                                value="{{ $user->address->city ?? null }}"
                                                autocomplete="city"
                                            >

                                            @error('city')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="state">{{ __('State') }}</label>
                                            <input id="state"
                                                type="text"
                                                class="form-control @error('state') is-invalid @enderror"
                                                name="state"
                                                tabindex="8"
                                                value="{{ $user->address->state ?? null }}"
                                                autocomplete="state"
                                            >

                                            @error('state')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-4 col-12">
                                            <label for="postal">{{ __('Postal') }}</label>
                                            <input id="postal"
                                                type="text"
                                                class="form-control @error('postal') is-invalid @enderror"
                                                name="postal"
                                                tabindex="9"
                                                value="{{ $user->address->postal ?? null }}"
                                                maxlength="10"
                                                autocomplete="postal"
                                            >

                                            @error('postal')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="country">{{ __('Country') }}</label>
                                            <select id="country" 
                                                name="country" 
                                                class="form-control select2"
                                            >
                                                @include('dashboard.admin.settings.countries', [ 'provided_country' => ( $user->address->country ?? config('settings.country') ) ])
                                            </select>

                                            @error('country')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="bio-card">
                                <div class="card-header">
                                    <h4>{{ __('Bio') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="bio">{{ __('Bio') }}</label>
                                            <textarea id="bio" 
                                                name="bio"
                                                class="form-control summernote-simple"
                                            >{{ old('bio') ?? $user->bio }}</textarea>

                                            @error('bio')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card" id="plan-card">
                                <div class="card-header">
                                    <h4>{{ __('Plan') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="plan_ends_at">{{ __('Plan Name') }}</label>
                                            <select name="plan_id"
                                                class="form-control select2 @error('plan_id') is-invalid @enderror" 
                                                id="plan_id">
                                                @include('dashboard.admin.users.plans', ['default_plan' => $user->plan_id])
                                            </select>

                                            @error('plan_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <label for="plan_ends_at">{{ __('Plan End Date') }}</label>
                                            <input id="plan_ends_at"
                                                type="date"
                                                class="form-control @error('plan_ends_at') is-invalid @enderror"
                                                name="plan_ends_at"
                                                value="{{ $user->plan_ends_at!=null ? $user->plan_ends_at->format('Y-m-d') : null }}"
                                                autocomplete="plan_ends_at"
                                            >

                                            @error('plan_ends_at')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <label for="plan_payment_processor">{{ __('Payment Processor') }}</label>
                                            <input id="plan_payment_processor"
                                                type="text"
                                                class="form-control @error('plan_payment_processor') is-invalid @enderror"
                                                name="plan_payment_processor"
                                                tabindex="13"
                                                value="{{ $user->plan_payment_processor ?? 'None' }}"
                                                autocomplete="plan_payment_processor"
                                            readonly>

                                            @error('plan_payment_processor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="role-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Role') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="role">{{ __('Role') }}</label>
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('User') }}">
                                                    <input type="radio"
                                                        id="type-user"
                                                        name="role"
                                                        class="selectgroup-input"
                                                        value="user" @if( $user->role == 'user' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('User') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Admin') }}">
                                                    <input type="radio"
                                                        id="type-admin"
                                                        name="role"
                                                        class="selectgroup-input"
                                                        value="admin" @if( $user->role == 'admin' ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon">{{ __('Admin') }}</span>
                                                </label>
                                            </div>

                                            @error('role')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="status-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Status') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label mt-1 ml-3 text-md-left">{{ __('Status') }}</label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    id="status"
                                                    class="custom-switch-input"
                                                    @if( $user->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-settings-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save Changes') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')

    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        // International Phone Input
        var intlTelUtilInputSelector = '#phone';
        var intlTelUtilOutputSelector = '#phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}";

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";

        var userBtnSaveMsg = "{{ __('Save') }}";
        var userBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var userSavedSuccess = "{{ __('User Saved Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/page/admin-users.min.js?v='. config('info.software.version')) }}"></script>
    
@endpush
