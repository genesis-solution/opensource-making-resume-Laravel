@foreach(\App\Models\Plan::all() as $plan)
<option value="{{$plan->id}}"{{$default_plan == $plan->id ? 'selected' : ''}}>{{$plan->name}}</option>
@endforeach
