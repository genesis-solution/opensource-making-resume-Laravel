@extends('layouts.app')

@section('title', __('Invoice'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Invoice') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Invoice') }}</div>
                </div>
            </div>

            <div class="section-body">
                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div id="invoice" class="invoice">
                    <div class="invoice-print">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="invoice-title">
                                    <h2>{{ __('Invoice') }}</h2>
                                    <h5><span class="badge badge-light text-truncate">{{ config('settings.billing_invoice_prefix') ?? 'INV' }}-{{$payment->p_id}}</span></h5>
                                    <div class="invoice-number">
                                        <h3><span @if( $payment->payment_status == 'completed') class="badge badge-success px-4 text-white" @else class="badge badge-danger px-4 text-white" @endif>@if( $payment->payment_status == 'completed') {{__('Paid')}} @else {{__('Unpaid')}} @endif</span></h3>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <address>
                                            {!! config('settings.billing_vendor') ? '<strong>'. config('settings.billing_vendor') .'</strong><br>' : null !!}
                                            {!! config('settings.billing_street') ? config('settings.billing_street') .'<br>' : null !!}
                                            {!! config('settings.billing_city') ? config('settings.billing_city') .',' : null !!} {{ config('settings.billing_state') ?? null }} {!! config('settings.billing_postal') ? config('settings.billing_postal') .'<br>' : null !!}
                                            {{ getCountryName(config('settings.billing_country')) ?? null }}
                                        </address>
                                    </div>
                                    <div class="col-md-6 text-md-right">
                                        @if($payment->address != null)
                                        <address>
                                            <strong>{{ $payment->firstname }} {{ $payment->lastname }}</strong><br>
                                            {!! json_decode($payment->address)->street ? json_decode($payment->address)->street .'<br>' : null !!}
                                            {!! json_decode($payment->address)->city ? json_decode($payment->address)->city .',' : null !!} {{ json_decode($payment->address)->state ?? null }} {!! json_decode($payment->address)->postal ? json_decode($payment->address)->postal .'<br>' : null !!}
                                            {{ getCountryName(json_decode($payment->address)->country) ?? null }}
                                        </address>
                                        @endif
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                    </div>
                                    <div class="col-md-6 text-md-right">
                                        <address>
                                            <strong>{{ __('Invoice Date:') }}</strong><br>
                                            {{ mb_ucwords(Carbon\Carbon::parse($payment->p_created_at)->locale(config('settings.language'))->translatedFormat('F j, Y')) }}<br><br>
                                        </address>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="section-title">{{ __('Invoice Summary') }}</div>
                                <p class="section-lead">{{ __('All items here cannot be deleted.') }}</p>
                                <div class="table-responsive">
                                    <table class="table-striped table-hover table-md table">
                                        <tr>
                                            <th data-width="40">#</th>
                                            <th>{{ __('Description') }}</th>
                                            <th class="text-center">{{ __('Interval') }}</th>
                                            <th class="text-center">{{ __('Date') }}</th>
                                            <th class="text-right">{{ __('Amount') }}</th>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>{{ $payment->product->name }} {{ __('Plan') }}</td>
                                            <td class="text-center">{{ __(ucfirst($payment->interval)) }}</td>
                                            <td class="text-center">{{date(config('settings.date_format'), strtotime($payment->p_created_at))}}</td>
                                            <td class="text-right">@if($payment->interval == 'month') {{ $payment->product->amount_month }} @else {{ $payment->product->amount_year }} @endif <small class="text-muted">{{ $payment->currency }}</small></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-lg-8">
                                        @if($payment->processor != null)
                                        <div class="section-title">{{ __('Payment Method') }}</div>
                                        <p class="section-lead">{{ __('The payment method used to pay for the plan.') }}</p>
                                        <div class="images">
                                            <img src="{{ asset('img/payment') }}/{{ $payment->processor }}.png"
                                                class="rounded-circle mr-1" width="35" alt="{{ $payment->processor }}"> {{ ucfirst($payment->processor) }}
                                        </div>
                                        @endif
                                    </div>
                                    <div class="col-lg-4 text-right">
                                        @if ($payment->coupon || $payment->tax_rates)
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Subtotal') }}</div>
                                            <div class="invoice-detail-value invoice-detail-value-lg">@if($payment->interval == 'month') {{ $payment->product->amount_month }} @else {{ $payment->product->amount_year }} @endif <small class="text-muted">{{ $payment->currency }}</small></div>
                                        </div>
                                        @endif
                                        @if($payment->coupon !=null)
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Discount') }} ({{ $payment->coupon->percentage }}%)</div>
                                            @if($payment->interval == 'month')
                                            <div class="invoice-detail-value">-{{ formatMoney(calculateDiscount($payment->product->amount_month, $payment->coupon->percentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                            @else
                                            <div class="invoice-detail-value">-{{ formatMoney(calculateDiscount($payment->product->amount_year, $payment->coupon->percentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                            @endif
                                        </div>
                                        @endif
                                        @if($payment->p_tax_rates!=null)
                                            @foreach(collect($payment->p_tax_rates) as $taxRate)
                                            <div class="invoice-detail-item">
                                                <div class="invoice-detail-name">{{ $taxRate->name }} ({{ $taxRate->percentage }}% {{ $taxRate->type ? __('excl.') : __('incl.') }})</div>
                                                @if($taxRate->type)
                                                <div class="invoice-detail-value">{{ formatMoney(checkoutExclusiveTaxRate(($payment->interval == 'month' ? $payment->product->amount_month : $payment->product->amount_year), $payment->coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                                @else
                                                <div class="invoice-detail-value">  {{ formatMoney(calculateInclusiveTaxRate(($payment->interval == 'month' ? $payment->product->amount_month : $payment->product->amount_year), $payment->coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                                @endif
                                            </div>
                                            @endforeach
                                        @endif
                                        <hr class="mt-2 mb-2">
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Total') }}</div>
                                            <div class="invoice-detail-value invoice-detail-value-lg">{{ formatMoney($payment->amount, $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-no-print">
                        <hr>
                        <div class="text-md-right">
                            <div class="float-lg-left mb-lg-0 mb-3">
                                <div class="btn-group dropup">
                                    <button type="button"
                                        class="btn btn-danger dropdown-toggle"
                                        data-toggle="dropdown"
                                        aria-haspopup="true"
                                        aria-expanded="false">
                                        {{ __('Actions') }}
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item"
                                            target="_blank"
                                            href="{{ URL::to('/dashboard/invoices/invoice/'. $payment->invoice_id .'/view') }}"><i class="fa-solid fa-eye"></i> {{ __('View') }}</a>
                                        @if(Auth::user()->role == 'admin')
                                        <a class="dropdown-item"
                                            href="{{ URL::to('/dashboard/invoices/invoice/'. $payment->invoice_id .'/send') }}"><i class="fa-solid fa-envelope"></i> {{ __('Send') }}</a>
                                        @endif
                                        <a class="dropdown-item"
                                            href="{{ URL::to('/dashboard/invoices/invoice/'. $payment->invoice_id .'/download') }}"><i class="fa-solid fa-download"></i> {{ __('Download') }}</a>
                                    </div>
                                </div>
                            </div>
                            <button onclick="printInvoice('invoice'); return false;" class="btn btn-warning btn-icon icon-left"><i class="fa-solid fa-print"></i> {{ __('Print') }}</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
    <script src="{{ asset('js/page/user-invoice.min.js?v='. config('info.software.version')) }}"></script>
@endpush
