<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ __('Invoice') }} #{{ $payment->p_id }}</title>
    <link rel="shortcut icon" href="{{ asset('/img/favicon.png') }}">
    <style>
        @media print {
          body {
            -webkit-print-color-adjust: exact !important; /* Chrome, Safari */
            color-adjust: exact !important; /*Firefox*/
            transform: scale(var(--scale-factor));
                transform-origin: 0 0;
          }
        }
        @page {
          size: A4 Portrait;
          margin-left: 15px;
          margin-right: 15px;
          margin-top: 0px;
          margin-bottom: 0px;
          margin: 0;
          -webkit-print-color-adjust: exact !important; /* Chrome, Safari */
          color-adjust: exact !important; /*Firefox*/
        }
        body {
            background-color: #fff;
            font-size: 14px;
            font-weight: 400;
            font-family: "Nunito", "Segoe UI", arial;
            color: #6c757d;
        }
        body, html {
            min-height: 100%;
        }
        .navbar .navbar-brand {
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 3px;
            font-weight: 700;
        }
        .navbar-brand {
            display: inline-block;
            padding-top: .3125rem;
            padding-bottom: .3125rem;
            margin-right: 1rem;
            font-size: 1.25rem;
            line-height: inherit;
            white-space: nowrap;
        }
        #logo {
            border-style: none;
            max-width: 100%;
            height: 50px;
            vertical-align: middle;
        }
        .rounded-circle {
            border-radius: 50%!important;
        }
        img {
            vertical-align: middle;
            border-style: none;
        }
        .shadow-light {
            box-shadow: 0 2px 6px #e6ecf1;
        }
        .images {
            vertical-align: middle;
        }
        .section {
            position: relative;
            z-index: 1;
        }
        article, aside, figcaption, figure, footer, header, hgroup, main, nav, section {
            display: block;
        }
        .invoice {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.03);
            background-color: #fff;
            border-radius: 3px;
            border: none;
            position: relative;
            margin-bottom: 30px;
            padding: 40px;
        }
        .row {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;
        }
        .invoice .invoice-title .invoice-number {
            font-size: 20px;
            font-weight: 700;
        }
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
        }
        .h3, h3 {
            font-size: 1.75rem;
        }
        .h5, h5 {
            font-size: 1.25rem;
        }
        .label.label-success {
            border: 1px solid #47c363;
            background-color: #fff;
        }
        .label.label-danger {
            border: 1px solid #fc544b;
            background-color: #fff;
        }
        h3 .label {
            font-size: 16px;
            padding: 10px 20px;
        }
        h3 .label.label-success {
            color: #47c363 !important;
        }
        h3 .label.label-danger {
            color: #fc544b !important;
        }
        .label {
            vertical-align: middle;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        .text-white, .text-white-all *, .text-white-all *:before, .text-white-all *:after {
            color: #ffffff !important;
        }
        .invoice hr {
            display: block;
            height: 1px;
            border: 0;
            border-top: 1px solid #ccc;
            margin: 1em 0;
            padding: 0;
        }
        .invoice .invoice-detail-item {
            margin-bottom: 15px;
        }
        .invoice .invoice-detail-item .invoice-detail-name {
            letter-spacing: 0.3px;
            color: #98a6ad;
            margin-bottom: 4px;
        }
        .invoice .invoice-detail-item .invoice-detail-value.invoice-detail-value-lg {
            font-size: 18px;
        }
        .invoice .invoice-detail-item .invoice-detail-value {
            color: #34395e;
            font-weight: 700;
        }
        .text-left {
            text-align: left!important;
        }
        .text-right {
            text-align: right!important;
        }
        .text-center {
            text-align: center!important;
        }
        .text-muted {
            color: #98a6ad !important;
        }
        address {
            margin-bottom: 1rem;
            font-style: normal;
            font-size: 15px;
            line-height: inherit;
        }
        b, strong {
            font-weight: bolder;
        }
        .mt-4, .my-4 {
            margin-top: 1.5rem!important;
        }
        .small, small {
            font-size: .875em;
            font-weight: 400;
        }
        .mb-2, .my-2 {
            margin-bottom: .5rem!important;
        }
        .mt-2, .my-2 {
            margin-top: .5rem!important;
        }
        .mr-1, .mx-1 {
            margin-right: .25rem!important;
        }
        .section .section-title:before {
            content: " ";
            border-radius: 5px;
            height: 8px;
            width: 30px;
            background-color: #191d21;
            display: inline-block;
            float: left;
            margin-top: 8px;
            margin-right: 15px;
        }
        .section .section-title {
            font-size: 18px;
            color: #191d21;
            font-weight: 600;
            position: relative;
            margin: 30px 0 25px 0;
        }
        .section .section-title + .section-lead {
            margin-top: -20px;
            color: #98a6ad !important;
        }
        .section .section-lead {
            margin-left: 45px;
            color: #98a6ad !important;
        }
        p, ul:not(.list-unstyled), ol {
            line-height: 28px;
        }
        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .table-header {
            width: 100%;
        }
        .table {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }
        .table-header th, .table-header td {
            border-top: none;
            vertical-align: middle;
        }
        .table th, .table td {
            padding: 10px 15px;
        }
        .table td, .table:not(.table-bordered) th {
            border-top: none;
            vertical-align: top;
        }
    </style>

    @if( config('settings.site_theme_color') || config('settings.site_bg_primary_color') || config('settings.site_bg_secondary_color') || config('settings.site_button_color') || config('settings.site_button_hover_color') )
    <style>
        @include('theme')
    </style>
    @endif
</head>

<body>
    <div class="main-wrapper">
        <section class="section">
            <div id="invoice" class="invoice">
                <div class="row">
                    <div class="">
                        <table class="table-header">
                            <tr>
                                <td class="text-left">
                                    <a class="navbar-brand smooth" href="{{ config('settings.site_url') }}">
                                        <img id="logo" src="{{ config('app.logo') }}" alt="{{ mb_ucwords(config('app.name')) }}" alt="logo" class="shadow-light rounded-circle">
                                    </a>
                                </td>
                                <td class="text-right">
                                    <div class="invoice-title">
                                        <div class="invoice-number">
                                             <h5>{{ config('settings.billing_invoice_prefix') ?? 'INV' }}-{{$payment->p_id}}</h5>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <td class="text-left">
                                        <address>
                                            {!! config('settings.billing_vendor') ? '<strong>'. config('settings.billing_vendor') .'</strong><br>' : null !!}
                                            {!! config('settings.billing_street') ? config('settings.billing_street') .'<br>' : null !!}
                                            {!! config('settings.billing_city') ? config('settings.billing_city') .',' : null !!} {{ config('settings.billing_state') ?? null }} {!! config('settings.billing_postal') ? config('settings.billing_postal') .'<br>' : null !!}
                                            {{ getCountryName(config('settings.billing_country')) ?? null }}
                                        </address>
                                    </td>
                                    <td class="text-right">
                                        @if($payment->address != null)
                                        <address>
                                            <strong>{{ $payment->firstname }} {{ $payment->lastname }}</strong><br>
                                            {!! json_decode($payment->address)->street ? json_decode($payment->address)->street .'<br>' : null !!}
                                            {!! json_decode($payment->address)->city ? json_decode($payment->address)->city .',' : null !!} {{ json_decode($payment->address)->state ?? null }} {!! json_decode($payment->address)->postal ? json_decode($payment->address)->postal .'<br>' : null !!}
                                            {{ getCountryName(json_decode($payment->address)->country) ?? null }}
                                        </address>
                                        @endif

                                        <address>
                                            <strong>{{ __('Invoice Date:') }}</strong><br>
                                            {{ mb_ucwords(Carbon\Carbon::parse($payment->p_created_at)->locale(config('settings.language'))->translatedFormat('F j, Y')) }}<br><br>
                                        </address>

                                        <h3><span @if( $payment->payment_status == 'completed') class="label label-success px-4" @else class="label label-danger px-4" @endif>@if( $payment->payment_status == 'completed') {{__('Paid')}} @else {{__('Unpaid')}} @endif</span></h3>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="section-title">{{ __('Invoice Summary') }}</div>
                    <p class="section-lead">{{ __('All listed items are billed.') }}</p>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <tr>
                                <th class="text-left">#</th>
                                <th class="text-left">{{ __('Description') }}</th>
                                <th class="text-center">{{ __('Interval') }}</th>
                                <th class="text-center">{{ __('Date') }}</th>
                                <th class="text-right">{{ __('Amount') }}</th>
                            </tr>
                            <tr>
                                <td class="text-left">1</td>
                                <td class="text-left">{{ $payment->product->name }} {{ __('Plan') }}</td>
                                <td class="text-center">{{ __(ucfirst($payment->interval)) }}</td>
                                <td class="text-center">{{date(config('settings.date_format'), strtotime($payment->p_created_at))}}</td>
                                <td class="text-right">@if($payment->interval == 'month') {{ $payment->product->amount_month }} @else {{ $payment->product->amount_year }} @endif <small class="text-muted">{{ $payment->currency }}</small></td>
                            </tr>
                        </table>
                    </div>
                    <div class="row mt-4">
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <td class="text-left">
                                        @if($payment->processor != null)
                                        <div class="section-title">{{ __('Payment Method') }}</div>
                                        <p class="section-lead">{{ __('The payment method used for the bill.') }}</p>
                                        <div class="images">
                                            <img src="{{ asset('img/payment/'. $payment->processor .'.png') }}"
                                                class="rounded-circle mr-1" style="width: 35px;" alt="{{ $payment->processor }}"> {{ mb_ucfirst($payment->processor) }}
                                        </div>
                                        @endif
                                    </td>
                                    <td class="text-right">
                                        @if ($payment->coupon || $payment->tax_rates)
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Subtotal') }}</div>
                                            <div class="invoice-detail-value invoice-detail-value-lg">@if($payment->interval == 'month') {{ $payment->product->amount_month }} @else {{ $payment->product->amount_year }} @endif <small class="text-muted">{{ $payment->currency }}</small></div>
                                        </div>
                                        @endif
                                        @if($payment->coupon !=null)
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Discount') }} ({{ $payment->coupon->percentage }}%)</div>
                                            @if($payment->interval == 'month')
                                            <div class="invoice-detail-value">-{{ formatMoney(calculateDiscount($payment->product->amount_month, $payment->coupon->percentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                            @else
                                            <div class="invoice-detail-value">-{{ formatMoney(calculateDiscount($payment->product->amount_year, $payment->coupon->percentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                            @endif
                                        </div>
                                        @endif
                                        @if($payment->p_tax_rates!=null)
                                            @foreach(collect($payment->p_tax_rates) as $taxRate)
                                            <div class="invoice-detail-item">
                                                <div class="invoice-detail-name">{{ $taxRate->name }} ({{ $taxRate->percentage }}% {{ $taxRate->type ? __('excl.') : __('incl.') }})</div>
                                                @if($taxRate->type)
                                                <div class="invoice-detail-value">{{ formatMoney(checkoutExclusiveTaxRate(($payment->interval == 'month' ? $payment->product->amount_month : $payment->product->amount_year), $payment->coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                                @else
                                                <div class="invoice-detail-value">  {{ formatMoney(calculateInclusiveTaxRate(($payment->interval == 'month' ? $payment->product->amount_month : $payment->product->amount_year), $payment->coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                                @endif
                                            </div>
                                            @endforeach
                                        @endif
                                        <hr class="mt-2 mb-2">
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name">{{ __('Total') }}</div>
                                            <div class="invoice-detail-value invoice-detail-value-lg">{{ formatMoney($payment->amount, $payment->currency) }} <small class="text-muted">{{ $payment->currency }}</small></div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>
</html>
