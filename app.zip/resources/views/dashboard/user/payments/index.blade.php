@extends('layouts.app')

@section('title', __('Payments'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.payments.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Payments') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Payments') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Payments') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all payments') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Payments') }}</h4>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table-striped table-md table">
                                        <tr>
                                            <th>{{__('Plan')}}</th>
                                            <th>{{__('Invoice')}}</th>
                                            <th>{{__('Processor')}}</th>
                                            <th>{{__('Amount')}}</th>
                                            <th>{{__('Interval')}}</th>
                                            <th>{{__('Date')}}</th>
                                            <th>{{__('Status')}}</th>
                                        </tr>
                                        @foreach($items as $entry)
                                            <td>
                                                <a href="{{ route('pricing') }}" class="badge badge-success text-truncate">{{ getUserPlan($entry->plan_id) }}</a>
                                            </td>
                                            <td>
                                                <a href="{{ url('dashboard/invoices/invoice') }}/{{$entry->invoice_id}}" class="badge badge-light text-truncate">{{ ( config('settings.billing_invoice_prefix') ?? 'INV') }}-{{$entry->p_id}}</a>
                                            </td>
                                            <td><img class="rounded-circle mr-3" width="35" src="{{ asset('img/payment/'. $entry->processor .'.png') }}" alt="{{ $entry->processor }}"></td>
                                            <td>{{$entry->amount}} {{$entry->currency}}</td>
                                            <td>
                                                <span class="badge badge-info text-truncate">{{ __($entry->interval) }}</span></td>
                                            <td data-date="{{strtotime($entry->p_created_at)}}">
                                                <p class="m-0">{{date(config('settings.date_format'), strtotime($entry->p_created_at))}}</p>
                                            </td>
                                            <td>
                                                <div @if( $entry->payment_status == 'completed') class="badge badge-success" @else class="badge badge-warning" @endif>{{ __($entry->payment_status) }}</div>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                            <div class="pull-right">
                                <div class="card-footer text-right">
                                    {!! $items->links() !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>

    <!-- Page Specific JS File -->
@endpush
