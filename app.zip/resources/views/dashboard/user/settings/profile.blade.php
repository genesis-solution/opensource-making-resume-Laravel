@extends('layouts.app')

@section('title', __('Profile'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-social/bootstrap-social.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-fileinput/css/fileinput.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Profile') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Profile') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('Hi') }}, {{ old('firstname') ?? $user->firstname }}!</h2>
                <p class="section-lead">
                    {{ __('Change information about yourself') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row mt-sm-4">
                    <div class="col-12 col-md-12 col-lg-5">
                        <div class="card profile-widget">
                            <div class="profile-widget-header">
                                <img alt="image"
                                    src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                                    class="rounded-circle profile-widget-picture">
                                <div class="profile-widget-items">
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label">{{ __('Resumes') }}</div>
                                        <div class="profile-widget-item-value">{{ $resume_counts }}</div>
                                    </div>
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label">{{ __('Cover Letter') }}</div>
                                        <div class="profile-widget-item-value">{{ $cover_letter_counts }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-widget-description">
                                <div class="profile-widget-name">{{ $user->firstname .' '.  $user->lastname }} <div
                                        class="text-muted d-inline font-weight-normal">
                                        <div class="slash"></div> {{ $user->occupation }}
                                    </div>
                                </div>
                                {!! preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', $user->bio) !!}
                            </div>
                            <div class="card-footer text-center">
                                @if ( isset($user->social->facebook) && $user->social->facebook != '' )
                                <a href="https://facebook.com/{{ $user->social->facebook }}"
                                    class="btn btn-social-icon btn-facebook mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->twitter) && $user->social->twitter != '' )
                                <a href="https://twitter.com/{{ $user->social->twitter }}"
                                    class="btn btn-social-icon btn-x-twitter mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-x-twitter"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->linkedin) && $user->social->linkedin != '' )
                                <a href="https://www.linkedin.com/in/{{ $user->social->linkedin }}/"
                                    class="btn btn-social-icon btn-linkedin mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-linkedin"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->pinterest) && $user->social->pinterest != '' )
                                <a href="https://www.pinterest.com/{{ $user->social->pinterest }}/"
                                    class="btn btn-social-icon btn-pinterest mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-pinterest"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->youtube) && $user->social->youtube != '' )
                                <a href="https://www.youtube.com/{{ $user->social->youtube }}"
                                    class="btn btn-social-icon btn-youtube mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-youtube"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->github) && $user->social->github != '' )
                                <a href="https://github.com/{{ $user->social->github }}"
                                    class="btn btn-social-icon btn-github mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-github"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->behance) && $user->social->behance != '' )
                                <a href="https://www.behance.net/{{ $user->social->behance }}"
                                    class="btn btn-social-icon btn-behance mr-1"
                                    target="_blank">
                                    <i class="fa-brands fa-behance"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->instagram) && $user->social->instagram != '' )
                                <a href="https://www.instagram.com/{{ $user->social->instagram }}/"
                                    class="btn btn-social-icon btn-instagram"
                                    target="_blank">
                                    <i class="fa-brands fa-instagram"></i>
                                </a>
                                @endif
                                @if ( isset($user->social->tiktok) && $user->social->tiktok != '' )
                                <a href="https://www.tiktok.com/{{ $user->social->tiktok }}"
                                    class="btn btn-social-icon btn-tiktok"
                                    target="_blank">
                                    <i class="fa-brands fa-tiktok"></i>
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-7">
                        <div id="user-profile-card">
                             @if (Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updateProfileInformation()))
                                @include('forms.update-profile-information-form')
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade"
            tabindex="-1"
            role="dialog"
            id="profileQrCodeModal">
            <div class="modal-dialog"
                role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title w-100 text-center">{{ __('QR Code') }}</h5>
                        <button type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"></div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-input-spinner/src/bootstrap-input-spinner.js') }}"></script>
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-fileinput/js/fileinput.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-fileinput/js/locales/'. ( config('settings.language') == 'en' ? 'LANG' : mb_strtolower(config('settings.language')) ) .'.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('vendor/bootstrap-fileinput/themes/fa6/theme.min.js') }}"></script>
    <script src="{{ asset('vendor/clipboard/dist/clipboard.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        // International Phone Input
        var intlTelUtilInputSelector = '#phone';
        var intlTelUtilOutputSelector = '#phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}";

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";

        var userProfileBioGeneratedSuccess = "{{ __('User Profile Bio Generated Succesfully.') }}";

        // File Inputs
        $("#image").fileinput({
            theme: 'fa6',
            language: "{{ ( config('settings.language') == 'en' ? 'LANG' : mb_strtolower(config('settings.language')) ) }}",
            uploadAsync: true,
            dropZoneEnabled: false,
            maxFileCount: 1,
            allowedFileTypes: ['image'],    // allow only images
            showCancel: false,
            showDrag: false,
            uploadUrl: '{{ route('dashboard.user.avatar') }}',
            uploadExtraData: {
                '_token': '{{ csrf_token() }}', 
            },
            slugCallback: function(filename) {
                return filename.replace('_', '-');
            },
            initialPreviewShowDelete: false,
            initialPreview: [
                '<img src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}" border="0" alt="Avatar" class="file-preview-image" style="max-width:165px;height:auto;" />'
            ],
        }).on('fileuploaded', function(event, data) {
            $('#image').fileinput('disable');
            setTimeout(function() {
                window.location.href = window.location.href;
            }, 2000);
        });

        // Call Bootstrap Input Spinner
        $("input[type='number']").inputSpinner();

        // Profile QR Code Modal
        $('#profileQrCodeModal').on('show.bs.modal', function (event) {
            var profileDesc = "{{ __('Profile') }}";
            var profileId = $(event.relatedTarget).data('pid');
            var profileName = $(event.relatedTarget).data('pname');
            var profileShareURL = "/dashboard/user/settings/profile/"+ profileId +"/qrcode";
            $(this).find(".modal-title").text(profileName);
            $(this).find(".modal-body").html('<div class="visible-print text-center"><img src="'+ profileShareURL +'" width="250" height="250" /><div class="text-job text-muted"><p>'+ profileDesc +'</p></div></div>');
        });
    </script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/page/user-profile.min.js?v='. config('info.software.version')) }}"></script>
@endpush
