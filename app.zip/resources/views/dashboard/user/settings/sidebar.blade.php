<ul class="nav nav-pills flex-column">
    <li class="nav-item">
        <a href="{{ route('dashboard.user.settings.profile') }}"
            class="nav-link {{ (Request::is('*/profile*') ? 'active' : '') }}"><i class="fa-solid fa-user"></i> <span>{{ __('Profile') }}</span></a></li>
    <li class="nav-item">
        <a href="{{ route('dashboard.user.settings.account') }}"
            class="nav-link {{ (Request::is('*/account*') ? 'active' : '') }}"><i class="fa-solid fa-address-book"></i> <span>{{ __('Account') }}</span></a></li>
    @if( config('settings.subscription') )
    <li class="nav-item">
        <a href="{{ route('pricing') }}"
            class="nav-link {{ (Request::is('*/pricing') ? 'active' : '') }}"><i class="fa-solid fa-gift"></i> <span>{{ __('Plans') }}</span></a></li>
    <li class="nav-item">
        <a href="{{ route('dashboard.user.payments.index') }}"
            class="nav-link {{ (Request::is('*/payments*') ? 'active' : '') }}"><i class="fa-solid fa-shopping-cart"></i> <span>{{ __('Payments') }}</span></a></li>
    @endif
    <li class="nav-item">
        <a href="{{ route('dashboard.user.resumes.index') }}"
            class="nav-link {{ (Request::is('*/resumes*') ? 'active' : '') }}"><i class="fa-solid fa-file-alt"></i> <span>{{ __('Resumes') }}</span></a></li>
    <li class="nav-item">
        <a href="{{ route('dashboard.user.cover-letters.index') }}"
            class="nav-link {{ (Request::is('*/cover-letters*') ? 'active' : '') }}"><i class="fa-solid fa-file"></i> <span>{{ __('Cover Letters') }}</span></a></li>
    @if(config('settings.openai') && Auth::user()->canUserResumeTailoring() == '1')
    <li class="nav-item">
        <a href="{{ route('dashboard.user.resume.tailor') }}"
            class="nav-link {{ (Request::is('*/tailor*') ? 'active' : '') }}"><i class="fa-solid fa-bullseye"></i> <span>{{ __('Resume Tailoring') }}</span></a></li>
    @endif
</ul>
