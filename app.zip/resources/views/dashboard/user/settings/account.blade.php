@extends('layouts.app')

@section('title', __('Account'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.settings.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Account') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Account') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('Account') }}</h2>
                <p class="section-lead">
                    {{ __('Password and two factor authentication') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4>{{ __('Change Password') }}</h4>
                                </div>
                                <div class="card-body">

                                    @if (Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updatePasswords()))
                                        @include('forms.update-user-password-form')
                                    @endif
                                </div>
                            </div>

                             <div class="card">
                                <div class="card-header">
                                    <h4>{{ __('Two Factor Authentication') }}</h4>
                                </div>
                                <div class="card-body">

                                    @if (Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::twoFactorAuthentication()))
                                        @include('forms.two-factor-authentication-form')
                                    @endif   
                                </div>
                            </div>

                            @if( Auth::user()->id != '1')
                            <div>
                                @include('forms.delete-user-account-form')  
                            </div>
                            @endif
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var userAccountConfirmDeleteMsg = "{{__('Are you sure?')}}";
        var userAccountDeleteNoRecoveryMsg = "{{__('You will not be able to reverse this action!')}}";
        var userAccountDeletedSuccess = "{{ __('User Account Deleted Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-delete-account.min.js?v='. config('info.software.version')) }}"></script>
@endpush
