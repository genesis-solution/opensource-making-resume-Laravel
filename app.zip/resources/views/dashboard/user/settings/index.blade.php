@extends('layouts.app')

@section('title', __('Settings'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Settings') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Settings') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('Overview') }}</h2>
                <p class="section-lead">
                    {{ __('The organized list of all settings') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Profile') }}</h4>
                                <p>{{ __('The list of all profile settings.') }}</p>
                                <a href="{{ route('dashboard.user.settings.profile') }}"
                                    class="card-cta">{{ __('Change Profile Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-large-icons">
                            <div class="card-icon bg-primary text-white">
                                <i class="fa-solid fa-address-book"></i>
                            </div>
                            <div class="card-body">
                                <h4>{{ __('Account') }}</h4>
                                <p>{{ __('The list of all account settings.') }}</p>
                                <a href="{{ route('dashboard.user.settings.account') }}"
                                    class="card-cta">{{ __('Change Account Settings') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
