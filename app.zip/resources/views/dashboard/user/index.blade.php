@extends('layouts.app')

@section('title', __('Dashboard'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/chart.js/dist/Chart.min.css') }}">
        <link rel="stylesheet"
        href="{{ asset('vendor/chocolat/dist/css/chocolat.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/flag-icon-css/css/flag-icon.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>{{ __('Dashboard') }}</h1>
            </div>
            <div id="output-status">
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if(session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                @endif
            </div>
            <div class="row">
                <div class="@if( config('settings.subscription') ) col-xl-3 @else col-xl-6 @endif col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-primary">
                            <i class="fa-regular fa-user"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Resumes') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('resume_user_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="@if( config('settings.subscription') ) col-xl-3 @else col-xl-6 @endif col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-danger">
                            <i class="fa-regular fa-newspaper"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Cover Letters') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('cover_letter_user_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                @if( config('settings.subscription') )
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-warning">
                            <i class="fa-regular fa-file"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Payments') }}</h4>
                            </div>
                            <div class="card-body">
                                {{ cache('payment_user_counts') }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-success">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>{{ __('Total Paid') }}</h4>
                            </div>
                            <div class="card-body">
                                @if(cache('payment_user_paid') != null)
                                {{ formatMoney(cache('payment_user_paid'), config('settings.currency')) }} <span class="text-small text-muted">{{ config('settings.currency') }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </div>
            
            <div class="row">
                <div class="col-lg-8 col-md-12 col-12 col-sm-12">
                    @if( $resumes != null )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Resume Progress')}}</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                                @if(cache('resume_user_counts') == 0)
                                <li class="media">
                                    <div class="media-body">
                                        {{ __('No resume has been created yet.')}}
                                    </div>
                                </li>
                                @endif
                                @foreach( $resumes as $resume )
                                <li class="media">
                                    <img alt="image"
                                        class="rounded-circle mr-3"
                                        width="50"
                                        src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}">
                                    <div class="media-body">
                                        <div class="media-title">{{ $resume->firstname }} {{ $resume->lastname }}</div>
                                        <div class="text-job text-muted">{{ $resume->professional_title }}</div>
                                    </div>
                                    <div class="media-body">
                                        <div class="media-title">{{ $resume->name }}</div>
                                        <div class="text-job text-muted">{{ __('resume') }}</div>
                                    </div>
                                    <div class="media-progressbar">
                                        <div class="progress-text">{{ calculateResumePercentageCompleted($resume->r_id, $resume->user_id) }}%</div>
                                        <div class="progress"
                                            data-height="15">
                                            <div class="progress-bar"
                                                data-width="{{ calculateResumePercentageCompleted($resume->r_id, $resume->user_id) }}%"></div>
                                        </div>
                                    </div>
                                    <div class="media-cta mt-2">
                                        <a href="{{ route('dashboard.user.resumes.item') }}/{{ $resume->r_id }}"
                                            class="btn btn-outline-{{ displayBgColorProgress(calculateResumePercentageCompleted($resume->r_id, $resume->user_id)) }}">{{ __('Detail') }}</a>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    @endif
                    @if( $coverLetters != null )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Cover Letter Progress')}}</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                                @if(cache('cover_letter_user_counts') == 0)
                                <li class="media">
                                    <div class="media-body">
                                        {{ __('No cover letter has been created yet.')}}
                                    </div>
                                </li>
                                @endif
                                @foreach( $coverLetters as $coverLetter )
                                <li class="media">
                                    <img alt="image"
                                        class="rounded-circle mr-3"
                                        width="50"
                                        src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}">
                                    <div class="media-body">
                                        <div class="media-title">{{ $coverLetter->firstname }} {{ $coverLetter->lastname }}</div>
                                        <div class="text-job text-muted">{{ $coverLetter->professional_title }}</div>
                                    </div>
                                    <div class="media-body">
                                        <div class="media-title">{{ $coverLetter->name }}</div>
                                        <div class="text-job text-muted">{{ __('cover letter') }}</div>
                                    </div>
                                    <div class="media-progressbar">
                                        <div class="progress-text">{{ calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id) }}%</div>
                                        <div class="progress"
                                            data-height="15">
                                            <div class="progress-bar"
                                                data-width="{{ calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id) }}%"></div>
                                        </div>
                                    </div>
                                    <div class="media-cta mt-2">
                                        <a href="{{ route('dashboard.user.cover-letters.item') }}/{{ $coverLetter->cl_id }}"
                                            class="btn btn-outline-{{ displayBgColorProgress(calculateCoverLetterPercentageCompleted($coverLetter->cl_id, $coverLetter->user_id)) }}">{{ __('Detail') }}</a>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    @endif
                    @if( config('settings.subscription') )
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Invoices') }}</h4>
                            <div class="card-header-action">
                                <a href="{{ route('dashboard.user.payments.index') }}"
                                    class="btn btn-outline-danger">{{ __('View More') }} <i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive table-invoice">
                                <table class="table-striped table">
                                    <tr>
                                        <th>{{__('Invoice')}}</th>
                                        <th>{{__('Amount')}}</th>
                                        <th>{{__('Date')}}</th>
                                        <th>{{__('Status')}}</th>
                                        <th>{{__('Action')}}</th>
                                    </tr>
                                    
                                    @foreach($payments as $entry)
                                    <tr>
                                        <td>
                                            <a href="{{ url('dashboard/invoices/invoice') }}/{{$entry->invoice_id}}" class="badge badge-light text-truncate">{{ ( config('settings.billing_invoice_prefix') ?? 'INV') }}-{{$entry->p_id}}</a>
                                        </td>
                                        <td>{{ $entry->amount }} <small class="text-muted">{{ $entry->currency }}</small></td>
                                        <td data-date="{{strtotime($entry->created_at)}}">
                                            <p class="m-0">{{date(config('settings.date_format'), strtotime($entry->p_created_at))}}</p>
                                        </td>
                                        <td>
                                            <div @if( $entry->payment_status == 'completed') class="badge badge-success" @else class="badge badge-warning" @endif>@if( $entry->payment_status == 'completed') {{__('Paid')}} @else {{__('Unpaid')}} @endif</div>
                                        </td>
                                        <td>
                                            <a href="{{ url('dashboard/invoices/invoice') }}/{{$entry->invoice_id}}"
                                                class="btn btn-outline-primary">{{ __('Detail') }}</a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                <div class="col-lg-4 col-md-12 col-12 col-sm-12">
                    @if( config('settings.subscription') )
                    <div class="card card-hero">
                        <div class="card-header">
                            <div class="card-icon">
                                <i class="fa-regular fa-question-circle"></i>
                            </div>
                            <h4>{{ getUserPlan($user->plan_id) }}</h4>
                            <div class="card-description">@if( $user->planOnTrial() == true && $user->plan_ends_at!=null ) {{ __('Plan ends :time', ['time' => $user->plan_ends_at->diffForHumans()]) }} @elseif( $user->planIsCancelled() == true && $user->plan_ends_at!=null && $user->plan_ends_at->isFuture() ) {{ __('Plan ends :time', ['time' => $user->plan_ends_at->diffForHumans()]) }} @elseif( $user->planIsCancelled() == true && $user->plan_ends_at!=null && $user->plan_ends_at->isPast() ) {{ __('Plan ended :time', ['time' => $user->plan_ends_at->diffForHumans()]) }} @else {{ __('You are on :plan Plan.', ['plan' => getUserPlan($user->plan_id)]) }} @endif</div>
                        </div>
                        <div class="card-body p-0">
                            <div class="tickets-list">
                                <div class="ticket-item">
                                    <div class="ticket-title">
                                        <p><a href="{{ route('contact') }}" class="text-dark font-weight-normal text-decoration-none"> {{ __('Need help? Do not hesitate to contact us.') }}</a></p>
                                    </div>
                                    @if($user->plan_payment_processor)
                                    @if($user->plan_recurring_at)
                                    <div class="ticket-title text-md-right">
                                        <p><a type="button" class="text-muted font-weight-normal text-decoration-none cancel-user-subscription" data-user-id="'. $user->id .'">{{ __('Cancel Subscription') }}</a></p>
                                    </div>
                                    @endif
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Recent Activities') }}</h4>
                        </div>
                        <div class="card-body">
                            @if( isset( $activity ) )
                                @if(count($activity) == 0)
                                <div class="text media-item">{{__('No activity logged yet.')}}</div>
                                @else
                                <ul class="list-unstyled list-unstyled-border">
                                    @foreach($activity as $entry)
                                    <li class="media">
                                        <img class="rounded-circle mr-3"
                                            width="50"
                                            src="{{ ( $entry->avatar_path !=null ? $entry->avatar_path : ( $entry->avatar !=null ? asset($entry->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                                            alt="avatar">
                                        <div class="media-body">
                                            <div class="text-primary float-right">{{ $entry->a_updated_at->diffForHumans() }}</div>
                                            <div class="media-title text-truncate">{{ $entry->firstname .' '.$entry->lastname }}</div>
                                            <span class="text-small text-muted"><strong>{{ $entry->activity_type }}</strong> {{ $entry->activity_title }}</span>
                                        </div>
                                    </li>
                                    @endforeach
                                </ul>
                                <div class="pt-1 pb-1 text-center">
                                    <a href="{{ route('dashboard.user.activities') }}"
                                        class="btn btn-outline-primary btn-lg btn-round">
                                        {{ __('View All') }}
                                    </a>
                                </div>
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraies -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/chart.js/dist/Chart.min.js') }}"></script>
    <script src="{{ asset('vendor/chocolat/dist/js/jquery.chocolat.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var userSubscriptionConfirmCancelMsg = "{{ __('Are you sure?') }}";
        var userSubscriptionCancelTermMsg = "{{__('You will continue to have access to the features you have paid for until the end of your billing cycle.')}}";
        var userSubscriptionCancelSuccess = "{{ __('User Subscription Cancelled Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-cancel-subscription.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/page/dashboard.min.js?v='. config('info.software.version')) }}"></script>
@endpush
