@extends('layouts.auth')

@section('title', __('Protected Profile'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">

@endpush

@section('main')
<div class="card card-primary">
  <div class="card-header">
      <h4>{{ __('Protected Profile') }}</h4>
  </div>

  <div class="card-body">
    @if (session('status'))
        <div class="p-2 mb-2 bg-success text-white">
            {{ session('status') }}
        </div>
    @endif
    <form onsubmit="return false;" class="needs-validation" novalidate="">
        @csrf

        <input type="hidden" id="profile_id" name="profile_id" value="{{ $user->profile_id }}">

        <div class="form-group">
            <label for="profile_password">{{ __('Password') }}</label>
            <input id="profile_password"
                type="password"
                class="form-control @error('profile_password') is-invalid @enderror"
                name="profile_password"
                required
                autocomplete="profile_password">

            @error('profile_password')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>
        <div id="password-error" class="mt-3"></div>

        <div class="form-group">
            <button type="button" 
                onclick="validateProfilePassword(); return false;"
                id="password-validate"
                class="btn btn-primary btn-lg btn-block">
                {{ __('Validate') }}
            </button>
        </div>
    </form>
  </div>
</div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var profilePassBtnValidateMsg = "{{ __('Validate') }}";
        var profilePassBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var profilePassValidatedSuccess = "{{ __('Password Validated Successfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-profile-password.min.js?v='. config('info.software.version')) }}"></script>
@endpush
