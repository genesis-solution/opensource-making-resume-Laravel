@extends('layouts.profile')

@section('title', $user->firstname .' '.  $user->lastname .' - '. __('Share Profile'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-social/bootstrap-social.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('css/page/user-profile-template.min.css?v='. config('info.software.version')) }}">
@endpush

@section('main')
  <div class="main-profile-content">
    <div class="row m-0 justify-content-center">
        <div class="col-12 col-md-10 col-lg-8 col-xl-6">
            <div class="card profile-widget">
                <div class="profile-widget-header">
                    <img alt="image"
                        src="{{ ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png') }}"
                        class="rounded-circle profile-widget-picture">
                    <div class="profile-widget-items">
                        @if($user->phone!=null)
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><a href="tel:{{ $user->phone }}"><i class="fa-solid fa-mobile-alt fa-2x text-muted"></i></a></div>
                            <div class="text-muted mt-2"><small>{{ $user->phone }}</small></div>
                        </div>
                        @endif
                        @if($user->address!=null && $user->address->city!=null && $user->address->state!=null)
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><i class="fa-solid fa-map-marker-alt fa-2x text-muted"></i></div>
                            <div class="text-muted mt-2"><small>{{ $user->address->city }}, {{ $user->address->state }} {{ $user->address->postal ?? null }}</small></div>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="profile-widget-description">
                    <div class="profile-widget-name">{{ $user->firstname .' '.  $user->lastname }} <div
                            class="text-muted d-inline font-weight-normal">
                            <div class="slash"></div> {{ $user->occupation }}
                        </div>
                    </div>
                    {!! preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', $user->bio) !!}
                </div>
                <div class="card-footer text-center">
                    @if ( isset($user->social->facebook) && $user->social->facebook != '' )
                    <a href="https://facebook.com/{{ $user->social->facebook }}"
                        class="btn btn-social-icon btn-facebook mr-1"
                        target="_blank">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->twitter) && $user->social->twitter != '' )
                    <a href="https://twitter.com/{{ $user->social->twitter }}"
                        class="btn btn-social-icon btn-x-twitter mr-1"
                        target="_blank">
                        <i class="fa-brands fa-x-twitter"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->linkedin) && $user->social->linkedin != '' )
                    <a href="https://www.linkedin.com/in/{{ $user->social->linkedin }}/"
                        class="btn btn-social-icon btn-linkedin mr-1"
                        target="_blank">
                        <i class="fa-brands fa-linkedin"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->pinterest) && $user->social->pinterest != '' )
                    <a href="https://www.pinterest.com/{{ $user->social->pinterest }}/"
                        class="btn btn-social-icon btn-pinterest mr-1"
                        target="_blank">
                        <i class="fa-brands fa-pinterest"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->youtube) && $user->social->youtube != '' )
                    <a href="https://www.youtube.com/{{ $user->social->youtube }}"
                        class="btn btn-social-icon btn-youtube mr-1"
                        target="_blank">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->github) && $user->social->github != '' )
                    <a href="https://github.com/{{ $user->social->github }}"
                        class="btn btn-social-icon btn-github mr-1"
                        target="_blank">
                        <i class="fa-brands fa-github"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->behance) && $user->social->behance != '' )
                    <a href="https://www.behance.net/{{ $user->social->behance }}"
                        class="btn btn-social-icon btn-behance mr-1"
                        target="_blank">
                        <i class="fa-brands fa-behance"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->instagram) && $user->social->instagram != '' )
                    <a href="https://www.instagram.com/{{ $user->social->instagram }}/"
                        class="btn btn-social-icon btn-instagram"
                        target="_blank">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                    @endif
                    @if ( isset($user->social->tiktok) && $user->social->tiktok != '' )
                    <a href="https://www.tiktok.com/{{ $user->social->tiktok }}"
                        class="btn btn-social-icon btn-tiktok"
                        target="_blank">
                        <i class="fa-brands fa-tiktok"></i>
                    </a>
                    @endif
                </div>
            </div>
            @if( $user!=null && $user->availability!=null && $user->availability_status == '1' )
            <div class="card">
                <div class="card-header">
                    <h4><i class="fa-regular fa-calendar-alt fa-1x"></i> {{ __('Work Availability') }}</h4>
                </div>
                <div class="card-body p-0">
                    <table class="table">
                        <thead>
                            <tr class="text-center">
                                <th scope="col"></th>
                                <th scope="col">{{ __('Morning') }}</th>
                                <th scope="col">{{ __('Afternoon') }}</th>
                                <th scope="col">{{ __('Evening') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Monday') }}</span><span class="d-md-none">{{ __('Mon') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->monday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->monday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->monday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Tuesday') }}</span><span class="d-md-none">{{ __('Tue') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->tuesday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->tuesday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->tuesday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Wednesday') }}</span><span class="d-md-none">{{ __('Wed') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->wednesday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->wednesday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                 <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->wednesday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Thursday') }}</span><span class="d-md-none">{{ __('Thu') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->thursday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->thursday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->thursday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Friday') }}</span><span class="d-md-none">{{ __('Fri') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->friday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->friday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->friday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Saturday') }}</span><span class="d-md-none">{{ __('Sat') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->saturday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->saturday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->saturday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="d-none d-md-block">{{ __('Sunday') }}</span><span class="d-md-none">{{ __('Sun') }}</span></th>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->sunday, __('Morning')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->sunday, __('Afternoon')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                                <td class="text-center">@if( $user!=null && $user->availability!=null && (strpos($user->availability->sunday, __('Evening')) !== false) ) <i class="fa-solid fa-check fa-1x text-success"></i> @else <i class="fa-solid fa-times fa-1x text-danger"></i> @endif</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            @endif

            @if( $user!=null && $user->preferences!=null && $user->preferences_status == '1' )
            <div class="card">
                <div class="card-header">
                    <h4><i class="fa-solid fa-laptop-house fa-1x"></i> {{ __('Work Preferences') }}</h4>
                </div>
                <div class="card-body">
                    @if( $user->preferences->work_type!=null )
                        <div class="section-title mt-0 mb-3">{{ __('Work Type') }}</div>
                        @foreach( collect(explode(', ', $user->preferences->work_type)) as $work_type)
                            <span class="badge badge-light m-1">{{ $work_type }}</span>
                        @endforeach
                    @endif
                    @if( $user->preferences->work_location!=null )
                        <div class="section-title mt-4 mb-3">{{ __('Work Location') }}</div>
                        @foreach( collect(explode(', ', $user->preferences->work_location)) as $work_location)
                            <span class="badge badge-light m-1">{{ $work_location }}</span>
                        @endforeach
                    @endif
                    @if( $user->preferences->work_benefits!=null )
                        <div class="section-title mt-4 mb-3">{{ __('Work Benefits') }}</div>
                        @foreach( collect(explode(', ', $user->preferences->work_benefits)) as $work_benefit)
                            <span class="badge badge-light m-1">{{ $work_benefit }}</span>
                        @endforeach
                    @endif
                </div>
            </div>
            @endif

            @if($user->resume!=null)
                @if( ( $user->sections!=null && $user->sections->skills == '1' ) && ( $resume->skills!=null && $resume->skills_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-bolt fa-1x"></i> {{ __('Skills') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->skills)->sortBy('skill_order') as $skill)
                            <span class="badge badge-light m-1">{{ $skill->skill_name }}</span>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->languages == '1' ) && ( $resume->languages!=null && $resume->languages_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-flag fa-1x"></i> {{ __('Languages') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->languages)->sortBy('language_order') as $language)
                            <span class="badge badge-light m-1">{{ $language->language_name }}</span>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->employments == '1' ) && ( $resume->employments!=null && $resume->employments_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-briefcase fa-1x"></i> {{ __('Work Experience') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->employments)->sortBy('job_order') as $employment)
                        <div class="section-subheader">
                            <h1>{{ $employment->job_title }}</h1>
                            <div class="section-lead"><span class="section-lead-left">{{ $employment->job_employer }} &bull; {{ $employment->job_location }}</span> <span class="section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($employment->job_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $employment->job_ended!=null ? mb_ucwords(Carbon\Carbon::parse($employment->job_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
                            <div class="section-subdescription">
                                <p>{!! $employment->job_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                  </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->volunteer == '1' ) && ( $resume->volunteer!=null && $resume->volunteer_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-hands-helping fa-1x"></i> {{ __('Volunteer Experience') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->volunteer)->sortBy('volunteer_order') as $volunteer)
                        <div class="section-subheader">
                            <h1>{{ $volunteer->volunteer_title }}</h1>
                            <div class="section-lead"><span class="section-lead-left">{{ $volunteer->volunteer_employer }} &bull; {{ $volunteer->volunteer_location }}</span> <span class="section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($volunteer->volunteer_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $volunteer->volunteer_ended!=null ? mb_ucwords(Carbon\Carbon::parse($volunteer->volunteer_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
                            <div class="section-subdescription">
                                <p>{!! $volunteer->volunteer_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->education == '1' ) && ( $resume->education!=null && $resume->education_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-university fa-1x"></i> {{ __('Education') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->education)->sortBy('school_order') as $education)
                        <div class="section-subheader">
                            <h1>{{ $education->school_degree }}</h1>
                            <div class="section-lead"><span class="section-lead-left">{{ $education->school_name }}</span> <span class="section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($education->school_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $education->school_ended!=null ? mb_ucwords(Carbon\Carbon::parse($education->school_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
                            <div class="section-subdescription">
                                <p>{!! $education->school_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->certificates == '1' ) && ( $resume->certificates!=null && $resume->certificates_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-certificate fa-1x"></i> {{ __('Certificates') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->certificates)->sortBy('certificate_order') as $certificate)
                        <div class="section-subheader">
                            <h1>{{ $certificate->certificate_title }} &bull; <span class="section-lead">{{ mb_ucwords(Carbon\Carbon::parse($certificate->certificate_started)->locale(config('settings.language'))->translatedFormat('M Y')) }}{{ $certificate->certificate_ended!=null ? ' - '. mb_ucwords(Carbon\Carbon::parse($certificate->certificate_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : '' }}</span></h1>
                            <div class="section-subdescription">
                                <p>{!! $certificate->certificate_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->awards == '1' ) && ( $resume->awards!=null && $resume->awards_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-award fa-1x"></i> {{ __('Awards') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->awards)->sortBy('award_order') as $award)
                        <div class="section-subheader">
                            <h1>{{ $award->award_title }}</h1>
                            <div class="section-lead"><span class="section-lead-left">{{ $award->award_institution }} &bull; {{ mb_ucwords(Carbon\Carbon::parse($award->award_started)->locale(config('settings.language'))->translatedFormat('M Y')) }}{{ $award->award_ended!=null ? ' - '. mb_ucwords(Carbon\Carbon::parse($award->award_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : '' }}</span></div>
                            <div class="section-subdescription">
                                <p>{!! $award->award_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                 @if( ( $user->sections!=null && $user->sections->publications == '1' ) && ( $resume->publications!=null && $resume->publications_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-book-reader fa-1x"></i> {{ __('Publications') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->publications)->sortBy('publication_order') as $publication)
                        <div class="section-subheader">
                            <h1>{{ $publication->publication_name }}</h1>
                            <div class="section-lead"><span class="section-lead-left">{{ $publication->publication_publisher }} &bull; {{ mb_ucwords(Carbon\Carbon::parse($publication->publication_date)->locale(config('settings.language'))->translatedFormat('M Y')) }}</span></div>
                            <div class="section-subdescription">
                                <p>{{ strip_tags($publication->publication_description) }}</p>
                            </div>
                        </div>
                        @endforeach
                  </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->projects == '1' ) && ( $resume->projects!=null && $resume->projects_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-umbrella fa-1x"></i> {{ __('Personal Projects') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->projects)->sortBy('project_order') as $project)
                        <div class="section-subheader">
                            <h1>{{ $project->project_title }} &bull; <span class="section-lead">{{ mb_ucwords(Carbon\Carbon::parse($project->project_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $project->project_ended!=null ? mb_ucwords(Carbon\Carbon::parse($project->project_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></h1>
                            <div class="section-subdescription">
                                <p>{!! $project->project_description !!}</p>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->interests == '1' ) && ( $resume->interests!=null && $resume->interests_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-icons fa-1x"></i> {{ __('Interests') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->interests)->sortBy('interest_order') as $interest)
                            <span class="badge badge-light m-1">{{ $interest->interest_name }}</span>
                        @endforeach
                    </div>
                </div>
                @endif

                @if( ( $user->sections!=null && $user->sections->references == '1' ) && ( $resume->references!=null && $resume->references_status == '1' ) )
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa-solid fa-project-diagram fa-1x"></i> {{ __('References') }}</h4>
                    </div>
                    <div class="card-body">
                        @foreach( collect($resume->references)->sortBy('reference_order') as $reference)
                        <div class="section-subheader">
                          <h1>{{ $reference->reference_referee }}</h1>
                          <div class="section-lead">{{ $reference->reference_referee_title }} &bull; {{ $reference->reference_referee_company }}</div>
                            <div class="references-items">
                              <ul>
                                @if($reference->reference_referee_phone!=null)
                                <li class="references-item">
                                  <span><i class="ion-ios-telephone"></i> {{ $reference->reference_referee_phone }}</span>
                                </li>
                                @endif
                                @if($reference->reference_referee_email!=null)
                                <li class="references-item">
                                  <span><i class="ion-ios-email"></i> {{ $reference->reference_referee_email }}</span>
                                </li>
                                @endif
                            </ul>
                          </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif
            @endif
        </div>
    </div>
  </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
@endpush
