@extends('layouts.share')

@section('title', ( $resume!=null ? ( $user->firstname. ' '. $user->lastname .' - '. $resume->name .' - '.  __('Resume') ) : __('Share Resume') ) )

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('css/page/user-resume-template-'. $resume->template .'.min.css?v='. config('info.software.version')) }}">
    <style>
        @include('dashboard.user.resumes.multicolor', [ 'resume' => $resume ])
    </style>
@endpush

@section('main')
  <div class="col-12">
    @include('dashboard.user.resumes.templates.template-'. $resume->template)
  </div>
  <div class="col-12">
    <div class="buttons-share text-md-center">
        <button id="download-pdf-page" class="btn btn-primary mr-1 download-pdf-page"><i class="fa-solid fa-cloud-download-alt"></i> {{ __('Download') }}</button>
        <button id="print-resume-page" class="btn btn-warning ml-2 print-resume-page"><i class="fa-solid fa-print"></i> {{ __('Print/PDF') }}</button>
    </div>
  </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/html2canvas/dist/html2canvas.min.js') }}"></script>
    <script src="{{ asset('vendor/jspdf/dist/jspdf.umd.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var resumeId = "{{ $resume->r_id }}";
        var templateId = "{{ $resume->template }}";
        var isLocalStorage = "{{ config('settings.storage_method') == 's3' ? '0' : '1' }}";
        var isWatermarked = "{{ $watermark!=null ? $watermark : '0' }}";

        var watermarkLeft = "{{ config('settings.watermark_position_left') }}";
        var watermarkBottom = "{{ config('settings.watermark_position_bottom') }}";
        var watermarkWidth = "{{ config('settings.watermark_dimension_width') }}";
        var watermarkHeight = "{{ config('settings.watermark_dimension_height') }}";
        var watermarkOpacity = "{{ config('settings.watermark_background_opacity') }}";

        var resumeDownloadFileName = "{{ ( $resume!=null ? Str::lower( $user->firstname .'_'. $user->lastname .'_'. preg_replace('/\s+/', '_', $resume->name) .'_'. now()->format('mdY') ) : null ) }}";
    </script>
    <script src="{{ asset('js/page/user-resume-template.min.js?v='. config('info.software.version')) }}"></script>
@endpush
