<div class="resume-wrapper">
  <div id="resume" class="resume-page">
    <div class="resume-top-container">
      <div class="top-box">
        <div class="top-box-header-borderless">
          <div class="top-box-header-init-wrapper">
            <span class="top-box-header-initials">{{ substr($user->firstname, 0, 1) }}{{ substr($user->lastname, 0, 1) }}</span>
          </div>
          <div class="top-box-header-title">
              <span>{{ $user->firstname }}</span>
              <span>{{ $user->lastname }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="resume-container">
      <div class="left-box">
        <div class="left-box-top-padding"></div>
        @if($user->phone!=null || $user->email!=null || $user->address!=null)
        <div class="left-box-section">
          <div class="left-box-section-content">
            <div class="left-box-section-title">{{ __('Contact') }}</div>
            <div class="left-box-contact-items">
              <ul>
                <li>
                  @if($user->phone!=null)
                  <div class="left-box-contact-item">
                    <span width="10" height="10" class="left-box-contact-icon"><i class="ion-ios-telephone"></i></span>
                    <span> {{ $user->phone }}</span>
                  </div>
                  @endif
                  @if($user->email!=null)
                  <div class="left-box-contact-item">
                    <span width="10" height="10" class="left-box-contact-icon"><i class="ion-ios-email"></i></span>
                    <span> <a href="mailto:{{ $user->email }}" class="text-reset text-decoration-none">{{ $user->email }}</a></span>
                  </div>
                  @endif
                  @if($user->address!=null && $user->address->city!=null && $user->address->state!=null)
                  <div class="left-box-contact-item">
                    <span width="10" height="10" class="left-box-contact-icon"><i class="ion-ios-location"></i></span>
                    <span> {{ $user->address->city }}, {{ $user->address->state }} {{ $user->address->postal ?? null }}</span>
                  </div>
                  @endif
                  @if(isset($user->social->linkedin) && $user->social->linkedin !=null)
                  <div class="left-box-contact-item">
                    <span width="10" height="10" class="left-box-contact-icon"><i class="ion-social-linkedin"></i></span>
                    <span> <a href="https://www.linkedin.com/in/{{ $user->social->linkedin }}/" class="text-reset text-decoration-none" target="_blank">in/{{ $user->social->linkedin }}</a></span>
                  </div>
                  @endif
                </li>
              </ul>
            </div>
          </div>
        </div>
        <hr>
        @endif
        @if($resume->languages!=null && $resume->languages_status == '1')
        <div class="left-box-section no-break-inside">
          <div class="left-box-section-content">
            <div class="left-box-section-title">{{ __('Languages') }}</div>
            <div class="left-box-languages-items">
              @foreach( collect($resume->languages)->sortBy('language_order') as $language)
              <div class="left-box-languages-item">
                <span>{{ $language->language_name }}</span>
                <span>{{ $language->language_level }}</span>
              </div>
              @endforeach
            </div>
          </div>
        </div>
        <hr>
        @endif
        @if($resume->skills!=null && $resume->skills_status == '1')
        <div class="left-box-section no-break-inside">
          <div class="left-box-section-content">
            <div class="left-box-section-title">{{ __('Skills') }}</div>
            <div class="left-box-skills-items">
              @foreach( collect($resume->skills)->sortBy('skill_order') as $skill)
              <div class="left-box-skills-item">
                <span> {{ $skill->skill_name }}</span>
                <div class="left-box-rating-outline">
                  <div class="left-box-rating-line" style="width: {{ $skill->skill_rating }}%;"></div>
                </div>
                @if(isset($skill->skill_keywords) && $skill->skill_keywords!=null)
                <div class="left-box-skills-keywords">
                  <ul>
                    @foreach (explode(',', $skill->skill_keywords) as $skill->skill_keyword)
                      <li class="left-box-skills-keyword">
                        <span> {{  $skill->skill_keyword }}</span>
                      </li>
                    @endforeach
                  </ul>
                </div>
                @endif
              </div>
              @endforeach
            </div>
          </div>
        </div>
        @endif
        @if($resume->interests!=null && $resume->interests_status == '1')
        <hr>
        <div class="left-box-section no-break-inside">
          <div class="left-box-section-content">
            <div class="left-box-section-title">{{ __('Interests') }}</div>
            <div class="left-box-interests-items">
              <ul>
                @foreach( collect($resume->interests)->sortBy('interest_order') as $interest)
                  <li class="left-box-interests-item">
                    <span> {{ $interest->interest_name }}</span>
                    @if(isset($interest->interest_keywords) && $interest->interest_keywords!=null)
                    <ul>
                      @foreach (explode(',', $interest->interest_keywords) as $interest->interest_keyword)
                        <li class="left-box-interests-keyword">
                          <span> {{  $interest->interest_keyword }}</span>
                        </li>
                      @endforeach
                    </ul>
                    @endif
                  </li>
                @endforeach
              </ul>
            </div>
          </div>
        </div>
        @endif
      </div>
      <div class="right-box">
        <div class="right-box-content">
          @if($resume->professional_summary!=null)
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Professional Summary') }}</div>
            <div class="right-box-section-description">
              <p>{!! $resume->professional_summary !!}</p>
            </div>
          </div>
          <hr>
          @endif
          @if($resume->employments!=null && $resume->employments_status == '1')
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Work Experience') }}</div>
            @foreach( collect($resume->employments)->sortBy('job_order') as $employment)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $employment->job_title }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($employment->job_website) && $employment->job_website!=null ? $employment->job_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $employment->job_employer }}</a> &bull; {{ $employment->job_location }}</span> <span class="right-box-section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($employment->job_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $employment->job_ended!=null ? mb_ucwords(Carbon\Carbon::parse($employment->job_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{!! $employment->job_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          <hr>
          @endif
          @if($resume->volunteer!=null && $resume->volunteer_status == '1')
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Volunteer Experience') }}</div>
            @foreach( collect($resume->volunteer)->sortBy('volunteer_order') as $volunteer)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $volunteer->volunteer_title }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($volunteer->volunteer_website) && $volunteer->volunteer_website!=null ? $volunteer->volunteer_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $volunteer->volunteer_employer }}</a> &bull; {{ $volunteer->volunteer_location }}</span> <span class="right-box-section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($volunteer->volunteer_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $volunteer->volunteer_ended!=null ? mb_ucwords(Carbon\Carbon::parse($volunteer->volunteer_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{!! $volunteer->volunteer_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          <hr>
          @endif
          @if($resume->education!=null && $resume->education_status == '1')
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Education') }}</div>
            @foreach( collect($resume->education)->sortBy('school_order') as $education)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $education->school_degree }}{{ isset($education->school_major) && $education->school_major!=null ? ', '. $education->school_major : null }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($education->school_website) && $education->school_website!=null ? $education->school_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $education->school_name }}</a> {!! isset($education->school_gpa) && $education->school_gpa!=null ? '&bull; '. __('GPA: ') . $education->school_gpa : null !!}</span> <span class="right-box-section-lead-right">{{ mb_ucwords(Carbon\Carbon::parse($education->school_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $education->school_ended!=null ? mb_ucwords(Carbon\Carbon::parse($education->school_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{!! $education->school_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
          @if($resume->certificates!=null && $resume->certificates_status == '1')
          <hr>
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Certificates') }}</div>
            @foreach( collect($resume->certificates)->sortBy('certificate_order') as $certificate)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $certificate->certificate_title }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($certificate->certificate_website) && $certificate->certificate_website!=null ? $certificate->certificate_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ isset($certificate->certificate_institution) && $certificate->certificate_institution!=null ? $certificate->certificate_institution : null }}</a> &bull; {{ mb_ucwords(Carbon\Carbon::parse($certificate->certificate_started)->locale(config('settings.language'))->translatedFormat('M Y')) }}{{ $certificate->certificate_ended!=null ? ' - '. mb_ucwords(Carbon\Carbon::parse($certificate->certificate_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : '' }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{!! $certificate->certificate_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
          @if($resume->awards!=null && $resume->awards_status == '1')
          <hr>
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Awards') }}</div>
            @foreach( collect($resume->awards)->sortBy('award_order') as $award)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $award->award_title }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($award->award_website) && $award->award_website!=null ? $award->award_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ isset($award->award_institution) && $award->award_institution!=null ? $award->award_institution : null }}</a> &bull; {{ mb_ucwords(Carbon\Carbon::parse($award->award_started)->locale(config('settings.language'))->translatedFormat('M Y')) }}{{ $award->award_ended!=null ? ' - '. mb_ucwords(Carbon\Carbon::parse($award->award_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : '' }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{!! $award->award_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
          @if($resume->publications!=null && $resume->publications_status == '1')
          <hr>
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Publications') }}</div>
            @foreach( collect($resume->publications)->sortBy('publication_order') as $publication)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $publication->publication_name }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left"><a href="{{ isset($publication->publication_website) && $publication->publication_website!=null ? $publication->publication_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $publication->publication_publisher }}</a> &bull; {{ mb_ucwords(Carbon\Carbon::parse($publication->publication_date)->locale(config('settings.language'))->translatedFormat('M Y')) }}</span></div>
              <div class="right-box-section-subdescription">
                <p>{{ strip_tags($publication->publication_description) }}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
          @if($resume->projects!=null && $resume->projects_status == '1')
          <hr>
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('Personal Projects') }}</div>
            @foreach( collect($resume->projects)->sortBy('project_order') as $project)
            <div class="right-box-section-subheader no-break-inside">
              <h1><a href="{{ isset($project->project_website) && $project->project_website!=null ? $project->project_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $project->project_title }}</a> &bull; <span class="right-box-section-lead">{{ mb_ucwords(Carbon\Carbon::parse($project->project_started)->locale(config('settings.language'))->translatedFormat('M Y')) }} - {{ $project->project_ended!=null ? mb_ucwords(Carbon\Carbon::parse($project->project_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') }}</span></h1>
              <div class="right-box-section-subdescription">
                <p>{!! $project->project_description !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
          @if($resume->references!=null && $resume->references_status == '1')
          <hr>
          <div class="row mt-2">
            <div class="right-box-section-title">{{ __('References') }}</div>
            @foreach( collect($resume->references)->sortBy('reference_order') as $reference)
            <div class="right-box-section-subheader no-break-inside">
              <h1>{{ $reference->reference_referee }}</h1>
              <div class="right-box-section-lead"><span class="right-box-section-lead-left">{{ $reference->reference_referee_title }} &bull; <a href="{{ isset($reference->reference_referee_website) && $reference->reference_referee_website!=null ? $reference->reference_referee_website : '#' }}" class="text-reset text-decoration-none" target="_blank">{{ $reference->reference_referee_company }}</a></span></div>
                <div class="right-box-references-items">
                  <ul>
                    @if($reference->reference_referee_phone!=null)
                    <li class="right-box-references-item">
                      <span><i class="ion-ios-telephone"></i> {{ $reference->reference_referee_phone }}</span>
                    </li>
                    @endif
                    @if($reference->reference_referee_email!=null)
                    <li class="right-box-references-item">
                      <span><i class="ion-ios-email"></i> {{ $reference->reference_referee_email }}</span>
                    </li>
                    @endif
                </ul>
              </div>
              <div class="right-box-section-subdescription">
                <p>{!! isset($reference->reference_referee_description) && $reference->reference_referee_description!=null ? $reference->reference_referee_description : null !!}</p>
              </div>
            </div>
            @endforeach
          </div>
          @endif
        </div>
      </div>
    </div>
  </div>
</div>
   