<ul class="nav nav-pills flex-column">
    <li class="nav-item">
        <a href="#template-card"
            class="nav-link" onclick="resumeScrollToElement('#template-card'); return false;"><i class="fa-solid fa-palette"></i> <span>{{ __('Template') }}</span></a></li>
    <li class="nav-item">
        <a href="#privacy-card"
            class="nav-link" onclick="resumeScrollToElement('#privacy-card'); return false;"><i class="fa-solid fa-fingerprint"></i> <span>{{ __('Privacy') }}</span></a></li>
    <li class="nav-item">
        <a href="#profile-card"
            class="nav-link" onclick="resumeScrollToElement('#profile-card'); return false;"><i class="fa-solid fa-id-badge"></i> <span>{{ __('Profile') }}</span></a></li>
    <li class="nav-item">
        <a href="#address-card"
            class="nav-link" onclick="resumeScrollToElement('#address-card'); return false;"><i class="fa-solid fa-address-card"></i> <span>{{ __('Address') }}</span></a></li>
    <li class="nav-item">
        <a href="#professional-title-card"
            class="nav-link" onclick="resumeScrollToElement('#professional-title-card'); return false;"><i class="fa-solid fa-user-tie"></i> <span>{{ __('Professional Title') }}</span></a></li>
    <li class="nav-item">
        <a href="#professional-summary-card"
            class="nav-link" onclick="resumeScrollToElement('#professional-summary-card'); return false;"><i class="fa-solid fa-rectangle-list"></i> <span>{{ __('Professional Summary') }}</span></a></li>
    <li class="nav-item">
        <a href="#employments-card"
            class="nav-link" onclick="resumeScrollToElement('#employments-card'); return false;"><i class="fa-solid fa-briefcase"></i> <span>{{ __('Work Experience') }}</span></a></li>
    <li class="nav-item">
        <a href="#volunteer-card"
            class="nav-link" onclick="resumeScrollToElement('#volunteer-card'); return false;"><i class="fa-solid fa-hands-helping"></i> <span>{{ __('Volunteer Experience') }}</span></a></li>
    <li class="nav-item">
        <a href="#projects-card"
            class="nav-link" onclick="resumeScrollToElement('#projects-card'); return false;"><i class="fa-solid fa-umbrella"></i> <span>{{ __('Personal Projects') }}</span></a></li>
    <li class="nav-item">
        <a href="#education-card"
            class="nav-link" onclick="resumeScrollToElement('#education-card'); return false;"><i class="fa-solid fa-university"></i> <span>{{ __('Education') }}</span></a></li>
    <li class="nav-item">
        <a href="#certificates-card"
            class="nav-link" onclick="resumeScrollToElement('#certificates-card'); return false;"><i class="fa-solid fa-certificate"></i> <span>{{ __('Certificates') }}</span></a></li>
    <li class="nav-item">
        <a href="#awards-card"
            class="nav-link" onclick="resumeScrollToElement('#awards-card'); return false;"><i class="fa-solid fa-award"></i> <span>{{ __('Awards') }}</span></a></li>
    <li class="nav-item">
        <a href="#publications-card"
            class="nav-link" onclick="resumeScrollToElement('#publications-card'); return false;"><i class="fa-solid fa-book-reader"></i> <span>{{ __('Publications') }}</span></a></li>
    <li class="nav-item">
        <a href="#languages-card"
            class="nav-link" onclick="resumeScrollToElement('#languages-card'); return false;"><i class="fa-solid fa-language"></i> <span>{{ __('Languages') }}</span></a></li>
    <li class="nav-item">
        <a href="#skills-card"
            class="nav-link" onclick="resumeScrollToElement('#skills-card'); return false;"><i class="fa-solid fa-bolt"></i> <span>{{ __('Skills') }}</span></a></li>
    <li class="nav-item">
        <a href="#interests-card"
            class="nav-link" onclick="resumeScrollToElement('#interests-card'); return false;"><i class="fa-solid fa-icons"></i> <span>{{ __('Interests') }}</span></a></li>
    <li class="nav-item">
        <a href="#references-card"
            class="nav-link" onclick="resumeScrollToElement('#references-card'); return false;"><i class="fa-solid fa-project-diagram"></i> <span>{{ __('References') }}</span></a></li>
</ul>
