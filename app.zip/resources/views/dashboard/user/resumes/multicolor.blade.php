@if( $resume!=null && $resume->top_colors!=null && ( $resume->top_colors->background!=null || $resume->top_colors->header_background!=null || $resume->top_colors->header_title!=null || $resume->top_colors->header_description!=null || $resume->top_colors->subheader_background!=null || $resume->top_colors->subheader_title!=null || $resume->top_colors->subheader_byline!=null || $resume->top_colors->subheader_description!=null) )
    @if($resume->top_colors->background!=null)
        @if($template->top_colors->background == 'Yes')
            .top-box, .top-box-wrapper, .top-box-section {
                background: {{ $resume->top_colors->background }} !important;
            }
            .top-box-header-job-title {
                color: {{ $resume->top_colors->background }} !important;
            }
        @endif
    @endif
    @if($resume->top_colors->header_title!=null)
        @if($template->top_colors->header_title == 'Yes')
            .top-box, .top-box-wrapper, .top-box-header-title, .top-box-header-borderless, .right-box-section-header h1, .left-box-section-header h1, .top-box-header-name span {
                color: {{ $resume->top_colors->header_title }} !important;
            }
            .top-box-header-nb-name h1 span:nth-child(2) {
                color: {{ $resume->top_colors->header_title }} !important;
            }
            .top-box-header-job-wrapper {
                background: {{ $resume->top_colors->header_title }} !important;
            }
            .top-box-header {
                border: 2px solid {{ $resume->top_colors->header_title }} !important;
            }
            .top-box-header-initials {
                border: 2px solid {{ $resume->top_colors->header_title }} !important;
            }
            hr.top-box-header-divider{
                border-top: 1px solid {{ $resume->top_colors->header_title }} !important;
            }
            .top-box-right-contact-item, .top-box-right-contact-icon  {
                color: {{ $resume->top_colors->header_title }} !important;
            }
        @endif
    @endif
    @if($resume->top_colors->subheader_background!=null)
        @if($template->top_colors->subheader_background == 'Yes')
            .top-box-header-bottom-border {
                border-bottom: 1px solid {{ $resume->top_colors->subheader_background }} !important;
            }
            .top-box-header-job-left-wrapper, .top-box-wrapper:after {
                background: {{ $resume->top_colors->subheader_background }} !important;
            }
            .top-box-contact-items {
                background: {{ $resume->top_colors->subheader_background }} !important;
            }
        @endif
    @endif
    @if($resume->top_colors->subheader_title!=null)
        @if($template->top_colors->subheader_title == 'Yes')
            .top-box-header-job-title, .right-box-section-header .text-job, .left-box-section-header .text-job  {
                color: {{ $resume->top_colors->subheader_title }} !important;
            }
        @endif
    @endif
    @if($resume->top_colors->subheader_byline!=null)
        @if($template->top_colors->subheader_byline == 'Yes')
            .top-box-contact-item, .top-box-contact-icon  {
                color: {{ $resume->top_colors->subheader_byline }} !important;
            }
        @endif
    @endif
@endif
@if( $resume!=null && $resume->sidebar_colors!=null && ( $resume->sidebar_colors->background!=null || $resume->sidebar_colors->header_background!=null || $resume->sidebar_colors->header_title!=null || $resume->sidebar_colors->header_description!=null || $resume->sidebar_colors->subheader_background!=null || $resume->sidebar_colors->subheader_title!=null || $resume->sidebar_colors->subheader_byline!=null || $resume->sidebar_colors->subheader_description!=null) )
    @if($resume->sidebar_colors->background!=null)
        @if($template->sidebar_colors->background == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box {
                    background-color: {{ $resume->sidebar_colors->background }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box {
                    background-color: {{ $resume->sidebar_colors->background }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->sidebar_colors->header_background!=null)
        @if($template->sidebar_colors->header_background == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box-section-header-title {
                    background-color: {{ $resume->sidebar_colors->header_background }} !important;
                }
                .left-box-section-header::after {
                    border-bottom: 1px solid {{ $resume->sidebar_colors->header_background }} !important;
                }
                .left-box-initials span {
                    background-color: {{ $resume->sidebar_colors->header_background }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box-section-header-title {
                    background-color: {{ $resume->sidebar_colors->header_background }} !important;
                }
                .right-box-section-header::after {
                    border-bottom: 1px solid {{ $resume->sidebar_colors->header_background }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->sidebar_colors->header_title!=null)
        @if($template->sidebar_colors->header_title == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box hr {
                    border-top: 1px solid {{ $resume->sidebar_colors->header_title }} !important;
                }
                .left-box-avatar {
                    /*border: 1px solid {{ $resume->sidebar_colors->header_title }} !important;*/
                }
                .left-box-section-title, .left-box-section-header-title {
                    color: {{ $resume->sidebar_colors->header_title }} !important;
                }
                .left-box-section-title:before {
                    background-color: {{ $resume->sidebar_colors->header_title }} !important;
                }
                .left-box-section-name span, .left-box-initials span {
                    color: {{ $resume->sidebar_colors->header_title }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box hr {
                    border-top: 1px solid {{ $resume->sidebar_colors->header_title }} !important;
                }
                .right-box-avatar {
                    /*border: 1px solid {{ $resume->sidebar_colors->header_title }} !important;*/
                }
                .right-box-section-title, .right-box-section-header-title {
                    color: {{ $resume->sidebar_colors->header_title }} !important;
                }
                .right-box-section-title:before {
                    background-color: {{ $resume->sidebar_colors->header_title }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->sidebar_colors->subheader_title!=null)
        @if($template->sidebar_colors->subheader_title == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box-section-subheader h1 {
                    color: {{ $resume->sidebar_colors->subheader_title }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box-section-subheader h1 {
                    color: {{ $resume->sidebar_colors->subheader_title }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->sidebar_colors->subheader_byline!=null)
        @if($template->sidebar_colors->subheader_byline == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box-section-lead {
                    color: {{ $resume->sidebar_colors->subheader_byline }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box-section-lead {
                    color: {{ $resume->sidebar_colors->subheader_byline }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->sidebar_colors->subheader_description!=null)
        @if($template->sidebar_colors->subheader_description == 'Yes')
            @if($template->sidebar_colors->position == 'left')
                .left-box-contact-items ul, .left-box-section-summary-description {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-contact-icon {
                    fill: {{ $resume->sidebar_colors->subheader_description }} !important;
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-languages-item {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-skills-items, .left-box-skills-keywords, .left-box-interests-items {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-rating-outline {
                    border: 1px solid {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-rating-line {
                    background-color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .left-box-section-subheader span {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
            @endif
            @if($template->sidebar_colors->position == 'right')
                .right-box-contact-items ul, .right-box-section-summary-description {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-contact-icon {
                    fill: {{ $resume->sidebar_colors->subheader_description }} !important;
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-languages-item {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-skills-items, .right-box-skills-keywords, .right-box-interests-items  {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-rating-outline {
                    border: 1px solid {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-rating-line {
                    background-color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
                .right-box-section-subheader span {
                    color: {{ $resume->sidebar_colors->subheader_description }} !important;
                }
            @endif
        @endif
    @endif
@endif
@if( $resume!=null && $resume->content_colors!=null && ( $resume->content_colors->background!=null || $resume->content_colors->header_background!=null || $resume->content_colors->header_title!=null || $resume->content_colors->header_description!=null || $resume->content_colors->subheader_background!=null || $resume->content_colors->subheader_title!=null || $resume->content_colors->subheader_byline!=null || $resume->content_colors->subheader_description!=null) )
    @if($resume->content_colors->background!=null)
        @if($template->content_colors->background == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box {
                    background-color: {{ $resume->content_colors->background }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box, .middle-box {
                    background-color: {{ $resume->content_colors->background }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->header_background!=null)
        @if($template->content_colors->header_background == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-header-title {
                    background-color: {{ $resume->content_colors->header_background }} !important;
                }
                .right-box-section-header::after {
                    border-bottom: 1px solid {{ $resume->content_colors->header_background }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-header-title {
                    background-color: {{ $resume->content_colors->header_background }} !important;
                }
                .left-box-section-header::after {
                    border-bottom: 1px solid {{ $resume->content_colors->header_background }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->header_title!=null)
        @if($template->content_colors->header_title == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-title:before {
                    background-color: {{ $resume->content_colors->header_title }} !important;
                }
                .right-box-section-title, .right-box-section-header-title {
                    color: {{ $resume->content_colors->header_title }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-title:before, .left-box-section-title:after, .middle-left-box-section-title:after, .middle-right-box-section-title:after {
                    background-color: {{ $resume->content_colors->header_title }} !important;
                }
                .left-box-section-title, .left-box-section-header-title, .middle-left-box-section-title, .middle-right-box-section-title {
                    color: {{ $resume->content_colors->header_title }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->header_description!=null)
        @if($template->content_colors->header_description == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-description {
                    color: {{ $resume->content_colors->header_description }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-description, .middle-right-box-section-description, .middle-left-box-contact-item, .middle-left-box-contact-icon {
                    color: {{ $resume->content_colors->header_description }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->subheader_background!=null)
        @if($template->content_colors->subheader_background == 'Yes')
            .left-box-skills-badge-item, .left-box-skills-badge-keyword, .left-box-interests-badge-item, .left-box-interests-badge-keyword, .left-box-languages-badge-item {
                background-color: {{ $resume->content_colors->subheader_background }} !important;
            }
            @if($template->content_colors->position == 'right')
                .right-box-skills-badge-item, .right-box-skills-badge-keyword, .right-box-interests-badge-item, .right-box-interests-badge-keyword, .right-box-languages-badge-item {
                    background-color: {{ $resume->content_colors->subheader_background }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->subheader_title!=null)
        @if($template->content_colors->subheader_title == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-subheader h1 {
                    color: {{ $resume->content_colors->subheader_title }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-subheader h1 {
                    color: {{ $resume->content_colors->subheader_title }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->subheader_byline!=null)
        @if($template->content_colors->subheader_byline == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-lead {
                    color: {{ $resume->content_colors->subheader_byline }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-lead {
                    color: {{ $resume->content_colors->subheader_byline }} !important;
                }
                .left-box-skills-badge-item, .left-box-skills-badge-keyword, .left-box-interests-badge-item, .left-box-interests-badge-keyword, .left-box-languages-badge-item {
                    color: {{ $resume->content_colors->subheader_byline }} !important;
                }
            @endif
        @endif
    @endif
    @if($resume->content_colors->subheader_description!=null)
        @if($template->content_colors->subheader_description == 'Yes')
            @if($template->content_colors->position == 'right')
                .right-box-section-subdescription, .right-box-references-items {
                    color: {{ $resume->content_colors->subheader_description }} !important;
                }
                .right-box-skills-badge-item, .right-box-skills-badge-keyword, .right-box-interests-badge-item, .right-box-interests-badge-keyword, .right-box-languages-badge-item {
                    color: {{ $resume->content_colors->subheader_description }} !important;
                }
            @endif
            @if($template->content_colors->position == 'left')
                .left-box-section-subdescription, .left-box-references-items {
                    color: {{ $resume->content_colors->subheader_description }} !important;
                }
                @if($template->sidebar_colors_status === '0')
                    .left-box-skills-items, .left-box-skills-keywords, .left-box-interests-items, .left-box-languages-items {
                        color: {{ $resume->content_colors->subheader_description }} !important;
                    }
                @endif
            @endif
        @endif
    @endif
@endif