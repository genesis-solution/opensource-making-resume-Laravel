<div id="template-top-color" class="card @if( $template->top_colors_status == '1' ) @else d-none @endif">
    <div class="card-header">
        <h4 data-toggle="collapse" href="#collapseTemplateTopColor" aria-expanded="true" aria-controls="collapseTemplateTopColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Template Top Color') }}</h4>
        @if( $item!=null && $item->top_colors!=null )
        <div class="card-header-form">
            <button type="button" id="reset-top-color-btn" onclick="resetColorPalette('top-color', {{ $item->id }}); return false;" class="btn btn-secondary btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Reset Top Color Palette') }}">
                <i class="fa-solid fa-palette"></i> {{ __('Reset') }}
            </button>
        </div>
        @endif
    </div>
    <div class="card-body collapse" id="collapseTemplateTopColor">
        <div class="row">
            <div id="template-top-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topbgcolor"
                        id="tpl_topbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->background : ( $template->top_default_colors!=null ? $template->top_default_colors->background : '#3d3e42' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophdbgcolor"
                        id="tpl_tophdbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_background : ( $template->top_default_colors!=null ? $template->top_default_colors->header_background : '#3d3e42' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophdbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophdtltxtcolor"
                        id="tpl_tophdtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_title : ( $template->top_default_colors!=null ? $template->top_default_colors->header_title : '#a19191' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophdtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophddesctxtcolor"
                        id="tpl_tophddesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_description : ( $template->top_default_colors!=null ? $template->top_default_colors->header_description : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophddesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubbgcolor"
                        id="tpl_topsubbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_background : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_background : '#3d3e42' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubtltxtcolor"
                        id="tpl_topsubtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_title : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_title : '#b4b7c5' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Byline Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubbltxtcolor"
                        id="tpl_topsubbltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_byline : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_byline : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubbltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubdesctxtcolor"
                        id="tpl_topsubdesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_description : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_description : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubdesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
</div>
<div id="template-sidebar-color" class="card @if( $template->sidebar_colors_status == '1' ) @else d-none @endif">
    <div class="card-header">
        <h4 data-toggle="collapse" href="#collapseTemplateSidebarColor" aria-expanded="true" aria-controls="collapseTemplateSidebarColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Template Sidebar Color') }}</h4>
        @if( $item!=null && $item->sidebar_colors!=null )
        <div class="card-header-form">
            <button type="button" id="reset-sidebar-color-btn" onclick="resetColorPalette('sidebar-color', {{ $item->id }}); return false;" class="btn btn-secondary btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Reset Sidebar Color Palette') }}">
                <i class="fa-solid fa-palette"></i> {{ __('Reset') }}
            </button>
        </div>
        @endif
    </div>
    <div class="card-body collapse" id="collapseTemplateSidebarColor">
        <div class="row">
            <div id="template-sidebar-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidebgcolor"
                        id="tpl_sidebgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->background : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->background : '#f5f5f5' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidebgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-header-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Header Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidehdbgcolor"
                        id="tpl_sidehdbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->header_background : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_background : '#f5f5f5' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidehdbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-header-title-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Header Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidehdtltxtcolor"
                        id="tpl_sidehdtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->header_title : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_title : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidehdtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-header-description-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->header_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Header Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidehddesctxtcolor"
                        id="tpl_sidehddesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->header_description : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->header_description : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidehddesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Subheader Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidesubbgcolor"
                        id="tpl_sidesubbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->subheader_background : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_background : '#f5f5f5' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidesubbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Subheader Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidesubtltxtcolor"
                        id="tpl_sidesubtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->subheader_title : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_title : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidesubtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Subheader Byline Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidesubbltxtcolor"
                        id="tpl_sidesubbltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null ) ? $item->sidebar_colors->subheader_byline : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_byline : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidesubbltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-sidebar-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->sidebar_colors->subheader_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Sidebar Subheader Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_sidesubdesctxtcolor"
                        id="tpl_sidesubdesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->sidebar_colors!=null )  ? $item->sidebar_colors->subheader_description : ( $template->sidebar_default_colors!=null ? $template->sidebar_default_colors->subheader_description : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_sidesubdesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
</div>
<div id="template-content-color" class="card @if( $template->content_colors_status == '1' ) @else d-none @endif">
    <div class="card-header">
        <h4 data-toggle="collapse" href="#collapseTemplateContentColor" aria-expanded="true" aria-controls="collapseTemplateContentColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Template Content Color') }}</h4>
        @if( $item!=null && $item->content_colors!=null )
        <div class="card-header-form">
            <button type="button" id="reset-content-color-btn" onclick="resetColorPalette('content-color', {{ $item->id }}); return false;" class="btn btn-secondary btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Reset Content Color Palette') }}">
                <i class="fa-solid fa-palette"></i> {{ __('Reset') }}
            </button>
        </div>
        @endif
    </div>
    <div class="card-body collapse" id="collapseTemplateContentColor">
        <div class="row">
            <div id="template-content-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_contbgcolor"
                        id="tpl_contbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->background : ( $template->content_default_colors!=null ? $template->content_default_colors->background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_contbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-header-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Header Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_conthdbgcolor"
                        id="tpl_conthdbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->header_background : ( $template->content_default_colors!=null ? $template->content_default_colors->header_background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_conthdbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-header-title-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Header Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_conthdtltxtcolor"
                        id="tpl_conthdtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->header_title : ( $template->content_default_colors!=null ? $template->content_default_colors->header_title : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_conthdtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-header-description-color" class="form-group col-md-6 col-12 @if( $template->content_colors->header_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Header Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_conthddesctxtcolor"
                        id="tpl_conthddesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->header_description : ( $template->content_default_colors!=null ? $template->content_default_colors->header_description : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_conthddesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Subheader Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_contsubbgcolor"
                        id="tpl_contsubbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->subheader_background : ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_contsubbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Subheader Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_contsubtltxtcolor"
                        id="tpl_contsubtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->subheader_title : ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_title : '#191d21' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_contsubtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Subheader Byline Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_contsubbltxtcolor"
                        id="tpl_contsubbltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null )  ? $item->content_colors->subheader_byline : ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_byline : '#98a6ad' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_contsubbltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-content-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->content_colors->subheader_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Content Subheader Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_contsubdesctxtcolor"
                        id="tpl_contsubdesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->content_colors!=null ) ? $item->content_colors->subheader_description : ( $template->content_default_colors!=null ? $template->content_default_colors->subheader_description : '#3b3b3b' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_contsubdesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
</div>