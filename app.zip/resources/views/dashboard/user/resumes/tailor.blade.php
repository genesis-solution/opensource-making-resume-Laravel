@extends('layouts.app')

@section('title', __('Resume Tailoring'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">

@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.resumes.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Resume Tailoring') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.resumes.index') }}"> {{ __('Resumes') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Resume Tailoring') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Resume Tailoring') }}</h2>
                <p class="section-lead">
                    {{ __('Resume tailoring is the process of adapting your resume to a specific job opening or industry.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <form id="resume-tailor" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="resume-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Resume Tailoring') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label class="form-label" for="resume_type">{{ __('Resume Type') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Whether or not the resume is created using an external application.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Internal') }}">
                                                    <input type="radio"
                                                        id="resume-type-internal"
                                                        name="resume_type"
                                                        class="selectgroup-input"
                                                        value="internal" checked="checked">
                                                    <span class="selectgroup-button selectgroup-button-icon">
                                                        <i class="fa-solid fa-map-location-dot"></i> {{ __('Internal') }}
                                                    </span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('External') }}">
                                                    <input type="radio"
                                                        id="resume-type-external"
                                                        name="resume_type"
                                                        class="selectgroup-input"
                                                        value="external">
                                                    <span class="selectgroup-button selectgroup-button-icon">
                                                        <i class="fa-solid fa-map"></i> {{ __('External') }}
                                                    </span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="resume-block-internal" class="row d-block">
                                        <div class="form-group col-12">
                                            <label for="resume_internal">{{ __('Resume') }}</label>
                                            <select id="resume_internal" 
                                                name="resume_internal" 
                                                class="form-control select2 @error('resume_internal') is-invalid @enderror">
                                                @foreach($resumes as $resume)
                                                   <option value="{{ $resume->r_id ?? null }}" {{ $resume->r_id == $user->resume ? 'selected' : '' }}>{{ $resume->name }}</option>
                                                @endforeach 
                                            </select>

                                            <div class="form-text text-muted"><i class="fa-solid fa-info-circle"></i> {{ __('The resume to be tailored based on provided job description.') }}</div>

                                            @error('resume_internal')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div id="resume-block-external" class="row d-none">
                                        <div class="form-group col-12">
                                            <label for="resume_external">{{ __('Resume') }}</label>
                                            <textarea id="resume_external" 
                                                name="resume_external"
                                                class="form-control"
                                                data-height="250"
                                                style="height:250px;"
                                            >{{ old('resume_external') ?? null }}</textarea>

                                            <div class="form-text text-muted"><i class="fa-solid fa-info-circle"></i> {{ __('The resume to be tailored based on provided job description. Copy and paste the entire resume from external application as plain text.') }}</div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="target-job-description-card">
                                <div class="card-header">
                                    <h4>{{ __('Target Job Description') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="target_job_description">{{ __('Target Job Description') }}</label>
                                            <textarea id="target_job_description" 
                                                name="target_job_description"
                                                class="form-control"
                                                data-height="250"
                                                style="height:250px;"
                                            >{{ old('target_job_description') ?? null }}</textarea>

                                            <div class="form-text text-muted"><i class="fa-solid fa-info-circle"></i> {{ __('The target job description interested to apply for. Copy and paste the entire job description from job provider site as plain text.') }}</div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="cover-letter-card">
                                <div class="card-header">
                                    <h4>{{ __('Cover Letter') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label class="form-label" for="cover_letter">{{ __('Cover Letter') }}</label>
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('No') }}">
                                                    <input type="radio"
                                                        id="cover_letter-off"
                                                        name="cover_letter"
                                                        class="selectgroup-input"
                                                        value="0" checked="checked">
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-regular fa-comments"></i> {{ __('No') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Yes') }}">
                                                    <input type="radio"
                                                        id="cover_letter-on"
                                                        name="cover_letter"
                                                        class="selectgroup-input"
                                                        value="1">
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-comments"></i> {{ __('Yes') }}</span>
                                                </label>
                                            </div>

                                            <div class="form-text text-muted"><i class="fa-solid fa-info-circle"></i> {{ __('Whether or not to generate a cover letter to complement the revised resume.') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-resume-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    @if( config('settings.openai') )
                                        <button type="button" id="generate-tailored-resume-btn" onclick="generateAITailoredResume(); return false;" class="btn btn-warning btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ $aiGeneratedContentDescription }}">
                                            <i class="fa-solid fa-magic"></i> {{ __('Analyze with AI') }} @if($aiGeneratedContentLeft >= 0)<span class="badge badge-transparent">{{ $aiGeneratedContentLeft }}</span>@endif
                                        </button>
                                    @endif
                                </div>
                            </div>
                        </form>
                        <div class="card d-none" id="tailored-resume-output-card">
                            <div class="card-header">
                                <h4>{{ __('Tailored Resume') }}</h4>
                                <div class="card-header-form">
                                    <div id="download-txt-format" class="btn btn-sm btn-info" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Download TXT Format') }}"><i class="fa-solid fa-file-alt"></i> {{ __('TXT') }}</div>
                                    <div id="download-html-format" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Download HTML Format') }}"><i class="fa-solid fa-file-code"></i> {{ __('HTML') }}</div>
                                    <div class="btn btn-sm btn-success" data-tooltip-copy="true" title="{{ __('Copy') }}" data-text-copy="{{ __('Copy') }}" data-text-copied="{{ __('Copied') }}" data-clipboard="true" data-clipboard-target="#tailored-resume-output"><i class="fa-solid fa-copy"></i> {{ __('Copy') }}</div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <div id="tailored-resume-output"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/scrollup/dist/jquery.scrollUp.min.js?v='. config('info.software.version')) }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var resumeTailoredGeneratedSuccess = "{{ __('Resume Tailored Generated Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-resume-tailor.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('vendor/clipboard/dist/clipboard.min.js') }}"></script>
@endpush
