@if( $coverLetter!=null && $coverLetter->top_colors!=null && ( $coverLetter->top_colors->background!=null || $coverLetter->top_colors->header_background!=null || $coverLetter->top_colors->header_title!=null || $coverLetter->top_colors->header_description!=null || $coverLetter->top_colors->subheader_background!=null || $coverLetter->top_colors->subheader_title!=null || $coverLetter->top_colors->subheader_byline!=null || $coverLetter->top_colors->subheader_description!=null) )
    @if($coverLetter->top_colors->background!=null)
        @if($template->top_colors->background == 'Yes')
        .top-box-wrapper, .top-box-header-borderless {
            background: {{ $coverLetter->top_colors->background }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->header_background!=null)
        @if($template->top_colors->header_background == 'Yes')
        .top-box-header {
            border: 3px solid {{ $coverLetter->top_colors->header_background }} !important;
        }
        hr.top-box-header-divider {
            border-top: 1px solid {{ $coverLetter->top_colors->header_background }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->header_title!=null)
        @if($template->top_colors->header_title == 'Yes')
        .top-box-header h1, .top-box-header-title, .top-box-header h1 span:nth-child(2) {
            color: {{ $coverLetter->top_colors->header_title }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->header_description!=null)
        @if($template->top_colors->header_description == 'Yes')
        .top-box-header-initials  {
            color: {{ $coverLetter->top_colors->header_description }} !important;
            border: 2px solid {{ $coverLetter->top_colors->header_description }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->subheader_background!=null)
        @if($template->top_colors->subheader_background == 'Yes')
        .top-box-contact-items {
            background: {{ $coverLetter->top_colors->subheader_background }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->subheader_title!=null)
        @if($template->top_colors->subheader_title == 'Yes')
        .top-box-header-job {
            color: {{ $coverLetter->top_colors->subheader_title }} !important;
        }
        @endif
    @endif
    @if($coverLetter->top_colors->subheader_byline!=null)
        @if($template->top_colors->subheader_byline == 'Yes')
        .top-box-contact-item, .top-box-contact-icon  {
            color: {{ $coverLetter->top_colors->subheader_byline }} !important;
        }
        @endif
    @endif
@endif