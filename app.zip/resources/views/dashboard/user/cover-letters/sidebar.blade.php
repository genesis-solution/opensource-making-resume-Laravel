<ul class="nav nav-pills flex-column">
    <li class="nav-item">
        <a href="#template-card"
            class="nav-link" onclick="coverLetterScrollToElement('#template-card'); return false;"><i class="fa-solid fa-palette"></i> <span>{{ __('Template') }}</span></a></li>
    <li class="nav-item">
        <a href="#privacy-card"
            class="nav-link" onclick="coverLetterScrollToElement('#privacy-card'); return false;"><i class="fa-solid fa-fingerprint"></i> <span>{{ __('Privacy') }}</span></a></li>
    <li class="nav-item">
        <a href="#profile-card"
            class="nav-link" onclick="coverLetterScrollToElement('#profile-card'); return false;"><i class="fa-solid fa-id-badge"></i> <span>{{ __('Profile') }}</span></a></li>
    <li class="nav-item">
        <a href="#address-card"
            class="nav-link" onclick="coverLetterScrollToElement('#address-card'); return false;"><i class="fa-solid fa-address-card"></i> <span>{{ __('Address') }}</span></a></li>
    <li class="nav-item">
        <a href="#professional-title-card"
            class="nav-link" onclick="coverLetterScrollToElement('#professional-title-card'); return false;"><i class="fa-solid fa-user-tie"></i> <span>{{ __('Professional Title') }}</span></a></li>
    <li class="nav-item">
        <a href="#employer-card"
            class="nav-link" onclick="coverLetterScrollToElement('#employer-card'); return false;"><i class="fa-solid fa-briefcase"></i> <span>{{ __('Employer') }}</span></a></li>
    <li class="nav-item">
        <a href="#skills-card"
            class="nav-link" onclick="coverLetterScrollToElement('#skills-card'); return false;"><i class="fa-solid fa-bolt"></i> <span>{{ __('Skills') }}</span></a></li>
    <li class="nav-item">
        <a href="#content-card"
            class="nav-link" onclick="coverLetterScrollToElement('#content-card'); return false;"><i class="fa-solid fa-rectangle-list"></i> <span>{{ __('Content') }}</span></a></li>
</ul>
