<div class="cover-letter-wrapper">
  <div id="cover-letter" class="cover-letter-page">
    <div class="cover-letter-container">
      
      <div class="top-box-section">
        @if($user->phone!=null || $user->email!=null || $user->address!=null)
        <div class="top-box-header">
          <h1><span>{{ $user->firstname }}</span> <span>{{ $user->lastname }}</span></h1>
        </div>
          <div class="top-box-contact-items">
            <ul>
              @if($user->address!=null && $user->address->city!=null && $user->address->state!=null)
              <li>              
                <div class="top-box-contact-item">
                  <span width="10" height="10" class="top-box-contact-icon"><i class="ion-ios-location"></i></span>
                  <span> {{ $user->address->city }}, {{ $user->address->state }} {{ $user->address->postal ?? null }}</span>
                </div>                
              </li>
              @endif
              @if($user->phone!=null)
              <li>               
                <div class="top-box-contact-item">
                   &bull; <span width="10" height="10" class="top-box-contact-icon"><i class="ion-ios-telephone"></i></span>
                  <span> {{ $user->phone }}</span> 
                </div>                
              </li>
              @endif
              @if($user->email!=null)
              <li>               
                <div class="top-box-contact-item">
                  &bull; <span width="10" height="10" class="top-box-contact-icon"><i class="ion-ios-email"></i></span>
                  <span> {{ $user->email }}</span>
                </div>    
              </li>
              @endif
            </ul>
          </div>
        @endif
      </div>

      <div class="middle-box-section">
        <div class="middle-box-items">
          <div class="middle-box-item">
            <div class="middle-box-date">{{ mb_ucwords(Carbon\Carbon::now()->locale(config('settings.language'))->translatedFormat('M d, Y')) }}</div>
          </div>
          @if($coverLetter->employer!=null)
          <div class="middle-box-item">
            <div class="middle-box-recipient"> 
              <span>{{ $coverLetter->employer->employer_name }}</span>
              <span>{{ $coverLetter->employer->company_name }}</span>
              <span>{{ $coverLetter->employer->company_location }}</span>
              <span>{{ $coverLetter->employer->company_phone }}</span>
              <span>{{ $coverLetter->employer->company_email }}</span>
            </div>
          </div>
          @endif
          <div class="middle-box-item">
            <div class="middle-box-subject"> 
              {{ $coverLetter->employer->job_title!=null ? __('RE') .': '. $coverLetter->employer->job_title .',' : '' }} {{ $coverLetter->employer->job_reference!=null ? 'Ref#'. $coverLetter->employer->job_reference .',' : '' }} {{ $coverLetter->employer->job_reference_date!=null ? mb_ucwords(Carbon\Carbon::parse($coverLetter->employer->job_reference_date)->locale(config('settings.language'))->translatedFormat('M Y')) : '' }}
            </div>
          </div>
          <div class="middle-box-item">
            <div class="middle-box-greeting">
              {{ __('Dear') }} {{ $coverLetter->employer->employer_name }},
            </div>
          </div>
          <div class="middle-box-item">
            <div class="middle-box-body">
              {!! $coverLetter->content !!}
            </div>
          </div>
        </div>
      </div>

      <div class="bottom-box-section">
        <div class="bottom-box-closing">
          <span>{{ __('Sincerely') }},</span>
          <span>{{ $user->firstname .' '. $user->lastname }}</span>
        </div>
      </div>

    </div>
  </div>
</div>
   