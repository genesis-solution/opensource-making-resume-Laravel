@extends('layouts.auth')

@section('title', __('Protected Cover Letter'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">

@endpush

@section('main')
<div class="card card-primary">
  <div class="card-header">
      <h4>{{ __('Protected Cover Letter') }}</h4>
  </div>

  <div class="card-body">
    @if (session('status'))
        <div class="p-2 mb-2 bg-success text-white">
            {{ session('status') }}
        </div>
    @endif
    <form onsubmit="return false;" class="needs-validation" novalidate="">
        @csrf

        <input type="hidden" id="cover_letter_id" name="cover_letter_id" value="{{ $coverLetter->cover_letter_id }}">

        <div class="form-group">
            <label for="password">{{ __('Password') }}</label>
            <input id="password"
                type="password"
                class="form-control @error('password') is-invalid @enderror"
                name="password"
                required
                autocomplete="password">

            @error('password')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>
        <div id="password-error" class="mt-3"></div>

        <div class="form-group">
            <button type="button" 
                onclick="validateCoverLetterPassword(); return false;"
                id="password-validate"
                class="btn btn-primary btn-lg btn-block">
                {{ __('Validate') }}
            </button>
        </div>
    </form>
  </div>
</div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var coverLetterPassBtnValidateMsg = "{{ __('Validate') }}";
        var coverLetterPassBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var coverLetterPassValidatedSuccess = "{{ __('Password Validated Successfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-cover-letter-password.min.js?v='. config('info.software.version')) }}"></script>
@endpush
