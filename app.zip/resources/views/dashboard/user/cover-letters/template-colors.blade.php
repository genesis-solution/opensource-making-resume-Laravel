<div id="template-top-color" class="card @if( $template->top_colors_status == '1' ) @else d-none @endif">
    <div class="card-header">
        <h4 data-toggle="collapse" href="#collapseTemplateTopColor" aria-expanded="true" aria-controls="collapseTemplateTopColor" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Template Top Color') }}</h4>
        @if( $item!=null && $item->top_colors!=null )
        <div class="card-header-form">
            <button type="button" id="reset-top-color-btn" onclick="resetColorPalette('top-color', {{ $item->id }}); return false;" class="btn btn-secondary btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Reset Top Color Palette') }}">
                <i class="fa-solid fa-palette"></i> {{ __('Reset') }}
            </button>
        </div>
        @endif
    </div>
    <div class="card-body collapse" id="collapseTemplateTopColor">
        <div class="row">
            <div id="template-top-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topbgcolor"
                        id="tpl_topbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->background : ( $template->top_default_colors!=null ? $template->top_default_colors->background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophdbgcolor"
                        id="tpl_tophdbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_background : ( $template->top_default_colors!=null ? $template->top_default_colors->header_background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophdbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophdtltxtcolor"
                        id="tpl_tophdtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_title : ( $template->top_default_colors!=null ? $template->top_default_colors->header_title : '#4b4d5e' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophdtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-header-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->header_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Header Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_tophddesctxtcolor"
                        id="tpl_tophddesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->header_description : ( $template->top_default_colors!=null ? $template->top_default_colors->header_description : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_tophddesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-background-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_background == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Background Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubbgcolor"
                        id="tpl_topsubbgcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_background : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_background : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubbgcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-title-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_title == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Title Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubtltxtcolor"
                        id="tpl_topsubtltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_title : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_title : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubtltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-byline-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_byline == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Byline Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubbltxtcolor"
                        id="tpl_topsubbltxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_byline : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_byline : '#4b4d5e' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubbltxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="template-top-subheader-description-color" class="form-group col-md-6 col-12 @if( $template->top_colors->subheader_description == 'Yes' ) @else d-none @endif">
                <label>{{ __('Top Subheader Description Color') }}</label>
                <div class="input-group">
                    <input type="color"
                        name="tpl_topsubdesctxtcolor"
                        id="tpl_topsubdesctxtcolor"
                        class="form-control"
                        value="{{ ( $item!=null && $item->top_colors!=null ) ? $item->top_colors->subheader_description : ( $template->top_default_colors!=null ? $template->top_default_colors->subheader_description : '#ffffff' ) }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="fa-solid fa-fill-drip"></i>
                        </div>
                    </div>
                </div>

                @error('tpl_topsubdesctxtcolor')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
</div>