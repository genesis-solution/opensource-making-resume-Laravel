@extends('layouts.app')

@section('title', __('Cover Letters'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/prismjs/themes/prism.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.payments.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Cover Letters') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.settings.index') }}">{{ __('Settings') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Cover Letters') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Cover Letters') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all cover letters') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.settings.sidebar')
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Cover Letters') }}</h4>
                                <div class="card-header-form">
                                    @if($cover_letter_left == 0)
                                    <span class="badge badge-light text-truncate" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Cover Letter Left') }}"><i class="fa-solid fa-file-alt"></i> {{ $cover_letter_left }}</span>
                                    @else
                                    <a class="btn btn-primary text-md-right" href="{{route('dashboard.user.cover-letters.item')}}">{{ __('Add New') }}</a>
                                    @endif
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table-striped table-md table">
                                        <tr>
                                            <th>{{__('Name')}}</th>
                                            <th>{{__('Date')}}</th>
                                            <th>{{__('Privacy')}}</th>
                                            <th>{{__('Progress')}}</th>
                                            <th>{{__('Views')}}</th>
                                            <th>{{__('Status')}}</th>
                                            <th>{{__('Actions')}}</th>
                                        </tr>
                                        @foreach($coverLetters as $entry)
                                            <td>{{$entry->name}}</td>
                                            <td data-date="{{strtotime($entry->cl_created_at)}}">
                                                <p class="m-0">{{date(config('settings.date_format'), strtotime($entry->cl_created_at))}}</p>
                                            </td>
                                            <td>
                                                <div @if( $entry->cl_privacy == '0') class="badge badge-secondary" @elseif( $entry->cl_privacy == '1') class="badge badge-primary" @elseif( $entry->cl_privacy == '2') class="badge badge-success" @endif>@if( $entry->cl_privacy == '0') <i class="fa-solid fa-globe"></i> {{__('Public')}} @elseif( $entry->cl_privacy == '1') <i class="fa-solid fa-lock"></i> {{__('Private')}} @elseif( $entry->cl_privacy == '2') <i class="fa-solid fa-fingerprint"></i> {{__('Protected')}} @endif</div>
                                            </td>
                                            <td>
                                                <div class="badge badge-{{ displayBgColorProgress(calculateCoverLetterPercentageCompleted($entry->cl_id, $entry->user_id)) }}">{{ calculateCoverLetterPercentageCompleted($entry->cl_id, $entry->user_id) }}%</div>
                                            </td>
                                            <td>
                                                <div class="badge badge-light">{{ $entry->views }}</div>
                                            </td>
                                            <td>
                                                <div @if( $entry->cl_status == '1') class="badge badge-success" @else class="badge badge-primary" @endif>@if( $entry->cl_status == '1') {{__('Active')}} @else {{__('Inactive')}} @endif</div>
                                            </td>
                                            <td class="text-nowrap">
                                                <button class="btn btn-info" data-toggle="modal" data-clid="{{ $entry->cl_id }}" data-clname="{{ $entry->name }}" data-target="#coverLetterQrCodeModal"><i class="fa-solid fa-qrcode"></i></button>
                                                <a href="{{ URL::to('/c/'. $entry->cover_letter_id) }}" class="btn btn-info" target="_blank" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Share Cover Letter') }}"><i class="fa-solid fa-share-alt"></i></a>
                                                @if($exportCoverLetter == '1')
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fa-solid fa-file-export"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="{{ URL::to('/dashboard/user/cover-letters/item/'. $entry->cl_id .'/export/pdf') }}" target="_blank"><i class="fa-solid fa-file-pdf"></i> {{ __('Export PDF Cover Letter') }}</a>
                                                        <a class="dropdown-item" href="{{ URL::to('/dashboard/user/cover-letters/item/'. $entry->cl_id .'/export/txt') }}" target="_blank"><i class="fa-solid fa-file-alt"></i> {{ __('Export TXT Cover Letter') }}</a>
                                                  </div>
                                                </div>
                                                @endif
                                                @if($cover_letter_left != 0)
                                                <a href="{{ URL::to('/dashboard/user/cover-letters/item/'. $entry->cl_id .'/clone') }}" class="btn btn-primary" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Clone Cover Letter') }}"><i class="fa-solid fa-clone"></i></a>
                                                @endif
                                                <a href="{{ route('dashboard.user.cover-letters.item', $entry->cl_id) }}" class="btn btn-warning" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Edit Cover Letter') }}"><i class="fa-solid fa-pencil-alt"></i></a>
                                                <a type="button" class="btn btn-danger delete-confirm-item" data-item-id="{{ $entry->cl_id }}" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Delete Cover Letter') }}"><i class="fa-solid fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </table>
                                </div>
                                @if($cover_letter_left != -1) <div class="text-muted text-center">{{ $cover_letter_left_description }}</div>@endif
                            </div>
                            <div class="pull-right">
                                <div class="card-footer text-right">
                                    {!! $coverLetters->links() !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade"
            tabindex="-1"
            role="dialog"
            id="coverLetterQrCodeModal">
            <div class="modal-dialog"
                role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title w-100 text-center">{{ __('QR Code') }}</h5>
                        <button type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"></div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/prismjs/prism.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/sweetalert/dist/sweetalert.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var coverLetterDesc = "{{ __('Cover Letter') }}";
        var coverLetterConfirmDeleteMsg = "{{__('Are you sure?')}}";
        var coverLetterDeleteNoRecoveryMsg = "{{__('You will not be able to recover the deleted item!')}}";
        var coverLetterDeletedSuccess = "{{ __('Cover Letter Deleted Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-cover-letter-list.min.js?v='. config('info.software.version')) }}"></script>
@endpush
