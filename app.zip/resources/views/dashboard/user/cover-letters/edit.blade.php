@extends('layouts.app')

@section('title', __('Cover Letter'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/summernote/dist/summernote-bs4.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('css/page/user-template-card.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('css/page/user-cover-letter-preview.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        id="user-cover-letter-template"
        href="{{ asset('css/page/user-cover-letter-template-'. ($item->template ?? '1') .'.min.css?v='. config('info.software.version')) }}">
    <style id="user-cover-letter-multicolor">
        @include('dashboard.user.cover-letters.multicolor', [ 'coverLetter' => $item ])
    </style>
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.user.cover-letters.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Cover Letter') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.user.cover-letters.index') }}"> {{ __('Cover Letters') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Cover Letter') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Cover Letter') }}</h2>
                <p class="section-lead">
                    {{ __('The cover letter details') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Jump To') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.cover-letters.sidebar')
                            </div>
                        </div>
                        @if($item!=null)
                        <div id="cover-letter-preview-wrapper" class="row d-none d-md-block col-12">
                            <div class="d-block d-flex col-12">
                                <div id="cover-letter-preview">
                                  @include('dashboard.user.cover-letters.templates.template-'. ( $item->template ?? '1'), [ 'coverLetter' => $item ])
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                    <div class="col-md-8">
                        <form id="cover-letter-item" 
                            onsubmit="coverLetterCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" 
                            enctype="multipart/form-data"
                            class="needs-validation"
                                novalidate="">
                            @csrf

                            <div class="card"
                                id="cover-letter-settings-card">
                                <div class="card-header">
                                    <h4>{{ __('Cover Letter') }}</h4>
                                    @if( isset($item->cover_letter_id) && $item->cover_letter_id != '' )
                                     <div class="card-header-action">
                                        @if($item!=null)
                                        <div class="dropdown dropleft text-right float-md-left mb-lg-0 mb-3 mx-2 d-none d-md-block">
                                            <button type="button"
                                                class="btn btn-danger dropdown-toggle"
                                                data-toggle="dropdown"
                                                aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="fa-solid fa-arrows-to-dot"></i> {{ __('Actions') }}
                                            </button>
                                            <div class="dropdown-menu">
                                                <a type="button" class="dropdown-item save-cover-letter-page" onclick="coverLetterCreateUpdate({{ $item !=null ? $item->id : null }}); return false;">
                                                    <i class="fa-solid fa-floppy-disk"></i> {{ __('Save') }}
                                                </a>
                                                <a type="button" class="dropdown-item download-pdf-page">
                                                    <i class="fa-solid fa-cloud-download-alt"></i> {{ __('Download') }}
                                                </a>
                                                <a type="button" class="dropdown-item print-cover-letter-page">
                                                    <i class="fa-solid fa-print"></i> {{ __('Print/PDF') }}
                                                </a>
                                            </div>
                                        </div>
                                        @endif
                                        <div class="dropdown d-inline dropleft text-right">
                                            <button class="btn btn-primary dropdown-toggle"
                                                type="button"
                                                id="share-btn"
                                                data-toggle="dropdown"
                                                aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="fa-solid fa-share-alt"></i> {{ __('Share') }}
                                            </button>
                                            <div class="dropdown-menu medium">
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="share"
                                                    href="{{ URL::to('/c/'. $item->cover_letter_id) }}"
                                                    target="_blank">
                                                    <i class="fa-solid fa-file-pdf"></i> <span>{{ __('Share Cover Letter') }}</span>
                                                </a>
                                                @if($exportCoverLetter == '1')
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="exportPDF"
                                                    href="{{ URL::to('/dashboard/user/cover-letters/item/'. $item->id .'/export/pdf') }}"
                                                    target="_blank">
                                                    <i class="fa-solid fa-file-code"></i> <span>{{ __('Export PDF Cover Letter') }}</span>
                                                </a>
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="exportTXT"
                                                    href="{{ URL::to('/dashboard/user/cover-letters/item/'. $item->id .'/export/txt') }}"
                                                    target="_blank">
                                                    <i class="fa-solid fa-file-alt"></i> <span>{{ __('Export TXT Cover Letter') }}</span>
                                                </a>
                                                @endif
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="qrcode"
                                                    data-toggle="modal" 
                                                    data-clid="{{ $item->id }}" 
                                                    data-clname="{{ $item->name }}" 
                                                    data-target="#coverLetterQrCodeModal">
                                                    <i class="fa-solid fa-qrcode"></i> <span>{{ __('QR Code') }}</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="name">{{ __('Name') }}</label>
                                            <input type="text"
                                                name="name"
                                                class="form-control @error('name') is-invalid @enderror"
                                                id="name"
                                                value="{{ $item!=null ? $item->name : null }}"
                                                autofocus
                                                required
                                            >

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="cover_letter_id">{{ __('Id') }}</label>
                                            <div class="input-group">
                                                <input type="text"
                                                    name="cover_letter_id"
                                                    class="form-control @error('cover_letter_id') is-invalid @enderror"
                                                    id="cover_letter_id"
                                                    value="{{ $item!=null ? $item->cover_letter_id : Str::random(16) }}"
                                                    readonly>
                                                <div class="input-group-append">
                                                    <div class="btn btn-sm btn-primary form-control" data-tooltip-copy="true" title="{{ __('Copy') }}" data-text-copy="{{ __('Copy') }}" data-text-copied="{{ __('Copied') }}" data-clipboard="true" data-clipboard-target="#cover_letter_id">{{ __('Copy') }}</div>
                                                </div>
                                            </div>

                                            <p class="text-muted text-small">{{ config('settings.site_url') }}/c/<span class="text-primary">{{ $item!=null ? $item->cover_letter_id : Str::random(16) }}</span></p>

                                            @error('cover_letter_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" 
                                            class="form-control-label mt-1 ml-3 text-md-left">{{ __('Status') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('Switch the cover letter status between active and inactive.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                                        <div class="col-sm-6 col-md-9">
                                            <label class="custom-switch p-1">
                                                <input type="checkbox"
                                                    name="status"
                                                    id="status"
                                                    class="custom-switch-input"
                                                    @if( $item!=null && $item->status == '1') checked="checked" @endif>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </div>
                                    </div>
                                    @if($item!=null)
                                    <div class="text-muted text-small mt-3"><i class="fa-solid fa-info-circle"></i> {{ __('Save changes before downloading or printing the cover letter.') }}</div>
                                    @endif
                                </div>
                            </div>
                            <div class="card" id="template-card">
                                <div class="card-header">
                                    <h4>{{ __('Template') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div id="cover-letter-template" class="template-carousel">
                                            <div class="selectgroup w-100">
                                                @if($templates!=null)
                                                    @foreach( collect($templates)->sortBy('order') as $coverTemplate)
                                                        @if($coverTemplate->top_colors!=null)
                                                        <label for="template-{{ $coverTemplate->resource_id }}" class="radio-label selectgroup-item cursor-pointer d-block" data-toggle="tooltip" data-placement="top" data-original-title="{{ $coverTemplate->name }}">
                                                            <input type="radio" id="template-{{ $coverTemplate->resource_id }}" name="template" @if($item!=null) onclick="resetCoverLetterTemplateColors('{{ $coverTemplate->resource_id }}', '{{ $item->id }}'); return false;" @else onclick="resetCoverLetterTemplateColors('{{ $coverTemplate->resource_id }}'); return false;" @endif class="radio-button @if($coverTemplate->top_colors_status == '1') hasTopColor @endif @if($coverTemplate->top_colors->background == 'Yes') hasTopBgColor @endif @if($coverTemplate->top_colors->header_background == 'Yes') hasTopHdBgColor @endif @if($coverTemplate->top_colors->header_title == 'Yes') hasTopHdTlColor @endif @if($coverTemplate->top_colors->header_description == 'Yes') hasTopHdDscColor @endif @if($coverTemplate->top_colors->subheader_background == 'Yes') hasTopSubBgColor @endif @if($coverTemplate->top_colors->subheader_title == 'Yes') hasTopSubTlColor @endif @if($coverTemplate->top_colors->subheader_byline == 'Yes') hasTopSubBlColor @endif @if($coverTemplate->top_colors->subheader_description == 'Yes') hasTopSubDscColor @endif selectgroup-input @error('template') is-invalid @enderror" value="{{ $coverTemplate->resource_id }}" @if($item!=null && $item->template == $coverTemplate->resource_id && old('template') == null || old('template') == $coverTemplate->resource_id || $loop->first && old('template') == null ) checked @endif>
                                                            <img id="template-{{ $coverTemplate->resource_id }}" class="selectgroup-button selectgroup-button-icon" src="{{ asset($coverTemplate->image .'?v='. config('info.software.version')) }}" alt="{{ $coverTemplate->name }}" style="height: auto !important;">
                                                        </label>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </div>
                                        </div>
                                        <div>
                                            <button role="button" class="button-template scroll-left" onclick="scrollCoverLetterTemplate(-450); return false;"><i class="fa-solid fa-chevron-left"></i></button>
                                            <button role="button" class="button-template scroll-right" onclick="scrollCoverLetterTemplate(450); return false;"><i class="fa-solid fa-chevron-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="cover-letter-template-colors">
                                @include('dashboard.user.cover-letters.template-colors', [ 'coverLetter' => $item, 'template' => $template ])
                            </div>
                            <div class="card" id="privacy-card">
                                <div class="card-header">
                                    <h4>{{ __('Privacy') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label class="form-label" for="privacy">{{ __('Privacy') }}</label>
                                            <div class="selectgroup w-100">
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Public') }}">
                                                    <input type="radio"
                                                        id="privacy-public"
                                                        name="privacy"
                                                        class="selectgroup-input"
                                                        value="0" @if( $item==null || ($item!=null && $item->privacy == '0') ) checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-globe"></i> {{ __('Public') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Private') }}">
                                                    <input type="radio"
                                                        id="privacy-private"
                                                        name="privacy"
                                                        class="selectgroup-input"
                                                        value="1" @if( $item!=null && $item->privacy == '1') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-lock"></i> {{ __('Private') }}</span>
                                                </label>
                                                <label 
                                                    class="selectgroup-item" 
                                                    data-toggle="tooltip"
                                                    data-placement="top"
                                                    title="{{ __('Password') }}">
                                                    <input type="radio"
                                                        id="privacy-password"
                                                        name="privacy"
                                                        class="selectgroup-input"
                                                        value="2" @if( $item!=null && $item->privacy == '2') checked="checked" @endif>
                                                    <span class="selectgroup-button selectgroup-button-icon"><i
                                                            class="fa-solid fa-fingerprint"></i> {{ __('Password') }}</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="cover-letter-password" class="row @if($item!=null && $item->password!=null) d-block @else d-none @endif">
                                        <div class="form-group col-12">
                                            <label for="password">{{ __('Password') }}</label>
                                            <input type="password"
                                                name="password"
                                                class="form-control @error('password') is-invalid @enderror"
                                                id="password"
                                                value="{{ $item!=null ? $item->password : null }}">

                                            @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="profile-card">
                                <div class="card-header">
                                    <h4>Profile</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="firstname">{{ __('First Name') }}</label>
                                            <input id="firstname"
                                                type="text"
                                                class="form-control @error('firstname') is-invalid @enderror"
                                                name="firstname"
                                                required 
                                                value="{{ old('firstname') ?? $user->firstname }}"
                                                autocomplete="firstname"
                                            >

                                            @error('firstname')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-group col-md-6 col-12">
                                            <label for="lastname">{{ __('Last Name') }}</label>
                                            <input id="lastname"
                                                type="text"
                                                class="form-control @error('lastname') is-invalid @enderror"
                                                name="lastname"
                                                required 
                                                value="{{ old('lastname') ?? $user->lastname }}"
                                                autocomplete="lastname"
                                            >

                                            @error('lastname')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="email">{{ __('Email Address') }}</label>
                                            <input id="email"
                                                type="email"
                                                class="form-control @error('email') is-invalid @enderror"
                                                name="email"
                                                value="{{ old('email') ?? $user->email }}"
                                                required
                                                autocomplete="email"
                                            >

                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="phone">{{ __('Phone') }}</label>
                                            <input id="phone"
                                                type="tel"
                                                class="form-control @error('phone') is-invalid @enderror"
                                                name="phone"
                                                value="{{ old('full_phone') ?? $user->phone }}"
                                                autocomplete="tel"
                                            >
                                            
                                            <span id="phone_output"></span>

                                            @error('phone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="address-card">
                                <div class="card-header">
                                    <h4>{{ __('Address') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="street">{{ __('Street') }}</label>
                                            <input id="street"
                                                type="text"
                                                class="form-control @error('street') is-invalid @enderror"
                                                name="street"
                                                value="{{ $user->address->street ?? null }}"
                                                autocomplete="street"
                                            >

                                            @error('street')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-5 col-12">
                                            <label for="city">{{ __('City') }}</label>
                                            <input id="city"
                                                type="text"
                                                class="form-control @error('city') is-invalid @enderror"
                                                name="city"
                                                value="{{ $user->address->city ?? null }}"
                                                autocomplete="city"
                                            >

                                            @error('city')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <label for="state">{{ __('State') }}</label>
                                            <input id="state"
                                                type="text"
                                                class="form-control @error('state') is-invalid @enderror"
                                                name="state"
                                                value="{{ $user->address->state ?? null }}"
                                                autocomplete="state"
                                            >

                                            @error('state')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-3 col-12">
                                            <label for="postal">{{ __('Postal') }}</label>
                                            <input id="postal"
                                                type="text"
                                                class="form-control @error('postal') is-invalid @enderror"
                                                name="postal"
                                                value="{{ $user->address->postal ?? null }}"
                                                maxlength="10"
                                                autocomplete="postal"
                                            >

                                            @error('postal')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="country">{{ __('Country') }}</label>
                                            <select id="country" 
                                                name="country" 
                                                class="form-control select2"
                                            >
                                                @include('dashboard.admin.settings.countries', [ 'provided_country' => ( $user->address->country ?? config('settings.country') ) ])
                                            </select>

                                            @error('country')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="professional-title-card">
                                <div class="card-header">
                                    <h4>{{ __('Professional Title') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="professional_title">{{ __('Professional Title') }}</label>
                                            <input id="professional_title"
                                                type="text"
                                                class="form-control @error('professional_title') is-invalid @enderror"
                                                name="professional_title"
                                                value="{{ ( $item!=null ? $item->professional_title : ( $user->occupation!=null ? $user->occupation : null ) ) }}"
                                                autocomplete="professional_title"
                                                required>

                                            @error('professional_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-muted text-small mt-3"><i class="fa-solid fa-info-circle"></i> {{ __('Provide your job position or role within an organization or professional society. It is important to tailor your professional title to match with the specific job title you are seeking.') }}</div>
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="professional_yoe">{{ __('Years of Experience') }}</label>
                                            <input id="professional_yoe"
                                                type="number"
                                                class="form-control @error('professional_yoe') is-invalid @enderror"
                                                name="professional_yoe"
                                                min="0"
                                                value="{{ ( $item!=null ? $item->professional_yoe : ( $user->yoe!=null ? $user->yoe : null ) ) }}"
                                                autocomplete="professional_yoe"
                                                required>

                                            @error('professional_yoe')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <div class="text-muted text-small mt-3"><i class="fa-solid fa-info-circle"></i> {{ __('Years of experience in this job position or role.') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="employer-card">
                                <div class="card-header">
                                    <h4>{{ __('Employer') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="job_title">{{ __('Job Title') }}</label>
                                            <input type="text"
                                                id="job_title"
                                                name="job_title"
                                                class="form-control @error('job_title') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->job_title : null }}"
                                                required>

                                            @error('job_title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="employer_name">{{ __('Employer Name') }}</label>
                                            <input type="text"
                                                id="employer_name"
                                                name="employer_name"
                                                class="form-control @error('employer_name') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->employer_name : null }}"
                                                required>

                                            @error('employer_name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="company_name">{{ __('Company Name') }}</label>
                                            <input type="text"
                                                id="company_name"
                                                name="company_name"
                                                class="form-control @error('company_name') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->company_name : null }}"
                                                required>

                                            @error('company_name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="company_location">{{ __('Company Location') }}</label>
                                            <input type="text"
                                                id="company_location"
                                                name="company_location"
                                                class="form-control @error('company_location') is-invalid @enderror"
                                                placeholder="e.g.: London, UK"
                                                value="{{ $item!=null ? $item->employer->company_location : null }}"
                                                required>

                                            @error('company_location')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-6 col-12">
                                            <label for="company_phone">{{ __('Company Phone') }}</label>
                                            <input type="phone"
                                                id="company_phone"
                                                name="company_phone"
                                                class="form-control @error('company_phone') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->company_phone : null }}"
                                                minlength="8"
                                                maxlength="15"
                                                data-mask="+000000000000" 
                                                data-mask-visible="true" 
                                                placeholder="+000000000000"
                                                autocomplete="phone">

                                            @error('company_phone')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-6 col-12">
                                            <label for="company_email">{{ __('Company Email') }}</label>
                                            <input type="email"
                                                id="company_email"
                                                name="company_email"
                                                class="form-control @error('company_email') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->company_email : null }}">

                                            @error('company_email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <label for="job_reference">{{ __('Job Reference') }}</label>
                                            <input type="text"
                                                id="job_reference"
                                                name="job_reference"
                                                class="form-control @error('job_reference') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->job_reference : null }}">

                                            @error('job_reference')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-group col-md-8 col-12">
                                            <label for="job_reference_date">{{ __('Job Reference Date') }}</label>
                                            <input
                                                id="job_reference_date"
                                                name="job_reference_date"
                                                type="month"
                                                placeholder="yyyy-mm" 
                                                pattern="\d{4}-\d{2}"
                                                class="form-control datetimepicker @error('job_reference_date') is-invalid @enderror"
                                                value="{{ $item!=null ? $item->employer->job_reference_date : null }}">

                                            @error('job_reference_date')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="skills-card">
                                <div class="card-header">
                                    <h4>{{ __('Skills') }}</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="skills">{{ __('Skills') }}</label>
                                            <select id="skills"
                                                name="skills"
                                                class="form-control select2 @error('skills') is-invalid @enderror"
                                                data-maximum-selection-length="3"
                                                multiple="multiple">
                                                @php
                                                $skills = $item!=null && $item->skills!=null ? explode(',', $item->skills) : null;

                                                if($skills!=null) {
                                                    foreach($skills as $skill)
                                                    {
                                                        echo '<option value="'. $skill. '" selected>'. $skill. '</option>';
                                                    }
                                                }
                                                @endphp
                                                @include('dashboard.admin.settings.soft-skills', ['provided_soft_skill' => ( $item!=null && $item->keyword ? $item->keyword : null) ])
                                            </select>

                                            @error('skills')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <small class="form-text text-muted">{{ __('Select three skills in order of importance.') }}</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="content-card">
                                <div class="card-header">
                                    <h4>{{ __('Content') }}</h4>
                                    <div class="card-header-form">
                                        <div class="d-inline text-right">
                                            @if( config('settings.openai') )
                                            <button type="button" id="generate-content-btn" onclick="generateAICoverLetterContent(); return false;" class="btn btn-warning btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ $aiGeneratedContentDescription }}">
                                                <i class="fa-solid fa-magic"></i> {{ __('Generate with AI') }} @if($aiGeneratedContentLeft >= 0)<span class="badge badge-transparent">{{ $aiGeneratedContentLeft }}</span>@endif
                                            </button>
                                            @endif
                                        </div>
                                        <div class="dropdown d-inline dropleft text-right">
                                            <button class="btn btn-primary dropdown-toggle"
                                                type="button"
                                                id="work-styles-btn"
                                                data-toggle="dropdown"
                                                aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="fa-solid fa-palette"></i> {{ __('Work Styles') }}
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="artistic" onclick="generateWorkStyleBasedContent('artistic'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You excel in dynamic settings that are fueled by innovation and creativity.') }}">
                                                    <i class="fa-solid fa-theater-masks"></i> <span>{{ __('Artistic') }}</span>
                                                </a>
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="enterprising" onclick="generateWorkStyleBasedContent('enterprising'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You are used to leading teams by giving them authority and delegating tasks decisively.') }}">
                                                    <i class="fa-solid fa-city"></i> <span>{{ __('Enterprising') }}</span>
                                                </a>
                                                <a class="dropdown-item has-icon"
                                                    type="button" id="investigative" onclick="generateWorkStyleBasedContent('investigative'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You possess a creative mindset and a talent for finding solutions to problems.') }}">
                                                    <i class="fa-solid fa-search-location"></i> <span>{{ __('Investigative') }}</span>
                                                </a>
                                                    <a class="dropdown-item has-icon"
                                                    type="button" id="organized" onclick="generateWorkStyleBasedContent('organized'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You provide organization and concentration to simplify tasks.') }}">
                                                    <i class="fa-solid fa-sitemap"></i> <span>{{ __('Organized') }}</span>
                                                </a>
                                                    <a class="dropdown-item has-icon"
                                                    type="button" id="practical" onclick="generateWorkStyleBasedContent('practical'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You strive to surpass expectations and guarantee that tasks are completed on time.') }}">
                                                    <i class="fa-solid fa-hands"></i> <span>{{ __('Practical') }}</span>
                                                </a>
                                                    <a class="dropdown-item has-icon"
                                                    type="button" id="service-oriented" onclick="generateWorkStyleBasedContent('service-oriented'); return false;" data-toggle="tooltip" data-placement="right" title="" data-original-title="{{ __('You thrive in collaborative environments and find pleasure in assisting others.') }}">
                                                   <i class="fa-solid fa-cogs"></i> <span>{{ __('Service-Oriented') }}</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-12">
                                            <label for="content">{{ __('Content') }}</label>
                                            <textarea
                                                id="content"
                                                name="content"
                                                class="form-control summernote-simple"
                                                style="height:75px;"
                                            >{{ $item!=null ? $item->content : null }}</textarea>

                                            @error('content')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                            <small class="form-text text-muted">{{ __('Three Paragraphs = Opener + Body + Call to Action') }}</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card"
                                id="button-item-card">
                                <div class="card-footer bg-whitesmoke text-md-right">
                                    @if($item!=null)
                                    <div class="float-lg-left mb-lg-0 mb-3 d-none d-md-block">
                                        <div class="btn-group dropup">
                                            <button type="button"
                                                class="btn btn-danger dropdown-toggle"
                                                data-toggle="dropdown"
                                                aria-haspopup="true"
                                                aria-expanded="false">
                                                {{ __('Actions') }}
                                            </button>
                                            <div class="dropdown-menu">
                                                <a type="button" class="dropdown-item download-pdf-page">
                                                    <i class="fa-solid fa-cloud-download-alt"></i> {{ __('Download') }}
                                                </a>
                                                <a type="button" class="dropdown-item print-cover-letter-page">
                                                    <i class="fa-solid fa-print"></i> {{ __('Print/PDF') }}
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    <button class="btn btn-primary"
                                        id="save-btn">{{ __('Save') }}</button>
                                    <button class="btn btn-secondary"
                                        type="reset">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            @if($item!=null)
            <div id="cover-letter-download-button" class="d-none coverLetterDownloadButton">
                <img src="{{ asset('img/download.png') }}" class="download-pdf-page" alt="{{ __('Download') }}">
            </div>
            <div id="cover-letter-print-button" class="d-none coverLetterPrintButton">
                <img src="{{ asset('img/printer.png') }}" class="print-cover-letter-page" alt="{{ __('Print') }}">
            </div>
            <div class="coverLetterPreviewButton">
                <img id="cover-letter-preview-button" src="{{ asset('img/preview.png') }}" alt="{{ __('Preview') }}">
            </div>
            @endif
            <div id="cover-letter-save-button" class="coverLetterSaveButton">
                <img src="{{ asset('img/save.png') }}" onclick="coverLetterCreateUpdate({{ $item !=null ? $item->id : null }}); return false;" alt="{{ __('Save') }}">
            </div>
        </section>
        <div class="modal fade"
            tabindex="-1"
            role="dialog"
            id="coverLetterQrCodeModal">
            <div class="modal-dialog"
                role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title w-100 text-center">{{ __('QR Code') }}</h5>
                        <button type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"></div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/summernote/dist/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
    @if($item!=null)
    <script src="{{ asset('vendor/html2canvas/dist/html2canvas.min.js') }}"></script>
    <script src="{{ asset('vendor/jspdf/dist/jspdf.umd.min.js') }}"></script>
    @endif
    <script src="{{ asset('vendor/scrollup/dist/jquery.scrollUp.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        // International Phone Input
        var intlTelUtilInputSelector = '#phone';
        var intlTelUtilOutputSelector = '#phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}"; 

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";

        var coverLetterBtnSaveMsg = "{{ __('Save') }}";
        var coverLetterBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var coverLetterSavedSuccess = "{{ __('Cover Letter Saved Succesfully.') }}";
        var coverLetterPrintedSuccess = "{{ __('Cover Letter Printed Successfully.') }}";
        var coverLetterContentGeneratedSuccess = "{{ __('Cover Letter Content Generated Succesfully.') }}";
        var coverLetterResetPaletteSuccess = "{{ __('Cover Letter Color Palette Reset Successfully.') }}";

        var coverLetterTemplateAssetPath = "{{ asset('css/page') }}";
        var coverLetterTemplateCssAppVer = "{{ config('info.software.version') }}";

        @if($item!=null)
        var isWatermarked = "{{ $watermark!=null ? $watermark : '0' }}";
        var watermarkLeft = "{{ config('settings.watermark_position_left') }}";
        var watermarkBottom = "{{ config('settings.watermark_position_bottom') }}";
        var watermarkWidth = "{{ config('settings.watermark_dimension_width') }}";
        var watermarkHeight = "{{ config('settings.watermark_dimension_height') }}";
        var watermarkOpacity = "{{ config('settings.watermark_background_opacity') }}";
        @endif

        // ScrollUp
        $.scrollUp({
            animation: 'fade',
            scrollImg: true
        });

        // Cover Letter QR Code Modal
        $('#coverLetterQrCodeModal').on('show.bs.modal', function (event) {
            var coverLetterDesc = "{{ __('Cover Letter') }}";
            var coverLetterId = $(event.relatedTarget).data('clid');
            var coverLetterName = $(event.relatedTarget).data('clname');
            var coverLetterShareURL = "/dashboard/user/cover-letters/item/"+ coverLetterId +"/qrcode";
            $(this).find(".modal-title").text(coverLetterName);
            $(this).find(".modal-body").html('<div class="visible-print text-center"><img src="'+ coverLetterShareURL +'" width="250" height="250" /><div class="text-job text-muted"><p>'+ coverLetterDesc +'</p></div></div>');
        });
    </script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/page/user-cover-letters.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('vendor/clipboard/dist/clipboard.min.js') }}"></script>
@endpush
