<!doctype html>
<html lang="{{ config('settings.language') ?? 'en' }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ $user->firstname. ' '. $user->lastname .' - '. $coverLetter->name }} - {{ __('Cover Letter') }}</title>
        <link rel="shortcut icon" href="{{ asset('/img/favicon.png') }}">

        <!-- General CSS Files -->
        <link rel="stylesheet" type="text/css" media="screen"
            href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}">

        <!-- CSS Libraries -->
        <link rel="stylesheet" type="text/css" media="screen"
            href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">
        <!-- Template CSS -->
        <link rel="stylesheet" type="text/css" media="screen"
            href="{{ asset('css/page/user-cover-letter-template-'. $coverLetter->template .'.min.css?v='. config('info.software.version')) }}">
        <style>
            @include('dashboard.user.cover-letters.multicolor', [ 'coverLetter' => $coverLetter ])
        </style>
        <style>
            div.page {
                position: absolute;
                top: 0px;
                bottom: 0px;
                left: 0px;
                right: 0px;
                width: 100%;
                height: 100%;
                overflow: hidden;
                page-break-before: always;
            }
            div.page:first-child {
                page-break-before: avoid;
            }
            div.cover-letter-container {
                padding: 0px !important;
            }
            .top-box-header h1 {
                display: block !important;
            }
            .top-box-contact-item {
                margin-left: 5px !important;
                margin-top: 4px !important;
            }
            @if($watermark == true)
            .top-box-contact-icon {
                display: none !important;
            }
            @else
            .top-box-contact-icon {
                margin-top: 0px !important;
                position: relative;
                top: 4px;
                left: 6px;
                z-index: 99;
            }
            @endif
            @if(!in_array($coverLetter->template, ["5", "6", "7"]))

            .top-box-header {
                padding: 0px !important;
            }
            @endif
            @if($coverLetter->template == '7')

            .top-box-wrapper {
                padding-top: 15px !important;
                text-align: center !important;
            }
            .top-box-header {
                display: inline-block !important;
                text-align: center !important;
                margin: 0px auto !important;
            }
            @endif

        </style>
    </head>
    <body>
        <div id="app">
            <section class="section">
                <div class="page">
                    @include('dashboard.user.cover-letters.templates.template-'. $coverLetter->template)
                </div>
            </section>
        </div>
    </body>
</html>
