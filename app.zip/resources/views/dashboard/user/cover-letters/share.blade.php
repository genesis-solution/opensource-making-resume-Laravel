@extends('layouts.share')

@section('title', ( $coverLetter!=null ? ( $user->firstname. ' '. $user->lastname .' - '. $coverLetter->name .' - '.  __('Cover Letter') ) : __('Share Cover Letter') ) )

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/ionicons201/css/ionicons.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('css/page/user-cover-letter-template-'. $coverLetter->template .'.min.css?v='. config('info.software.version')) }}">
    <style>
        @include('dashboard.user.cover-letters.multicolor', [ 'coverLetter' => $coverLetter ])
    </style>
@endpush

@section('main')
  <div class="col-12">
    @include('dashboard.user.cover-letters.templates.template-'. $coverLetter->template)
  </div>
  <div class="col-12">
    <div class="buttons-share text-md-center">
        <button id="download-pdf-page" class="btn btn-primary mr-1 download-pdf-page"><i class="fa-solid fa-cloud-download-alt"></i> {{ __('Download') }}</button>
        <button id="print-cover-letter-page" class="btn btn-warning ml-2 print-cover-letter-page"><i class="fa-solid fa-print"></i> {{ __('Print/PDF') }}</button>
    </div>
  </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/html2canvas/dist/html2canvas.min.js') }}"></script>
    <script src="{{ asset('vendor/jspdf/dist/jspdf.umd.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        var coverLetterId = "{{ $coverLetter->cl_id }}";
        var isWatermarked = "{{ $watermark!=null ? $watermark : '0' }}";

        var watermarkLeft = "{{ config('settings.watermark_position_left') }}";
        var watermarkBottom = "{{ config('settings.watermark_position_bottom') }}";
        var watermarkWidth = "{{ config('settings.watermark_dimension_width') }}";
        var watermarkHeight = "{{ config('settings.watermark_dimension_height') }}";
        var watermarkOpacity = "{{ config('settings.watermark_background_opacity') }}";

        var coverLetterDownloadFileName = "{{ ( $coverLetter!=null ? Str::lower( $user->firstname .'_'. $user->lastname .'_'. preg_replace('/\s+/', '_', $coverLetter->name) .'_'. now()->format('mdY') ) : null ) }}";
    </script>
    <script src="{{ asset('js/page/user-cover-letter-template.min.js?v='. config('info.software.version')) }}"></script>
@endpush
