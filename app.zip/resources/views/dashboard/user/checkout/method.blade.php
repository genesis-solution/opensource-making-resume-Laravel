<div class="row m-1 pt-2">
    @foreach( paymentProcessors() as $key => $value )
        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-4 my-1 d-flex d-flex text-sm-center custom-control">
            <input type="radio" id="payment-method-{{ $key }}" name="payment_processor" class="custom-control-input @error('payment_processor') is-invalid @enderror" value="{{ $key }}" @if( request()->input('payment') == $key && old('payment_processor') == null || old('payment_processor') == $key || $loop->first && old('payment_processor') == null ) checked @endif>
            <label class="custom-control-label cursor-pointer d-block" for="payment-method-{{ $key }}">
                <img id="payment-img-{{ $key }}" class="btn btn-outline-primary" src="{{ url('/') }}/img/payment/{{ $key }}.png" alt="{{ $key }}"> <span class="font-weight-bold mx-2">{{ $value['name'] == 'Bank' ? __('Bank') : $value['name'] }}</span>
            </label>
        </div>

        @error('payment_processor')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror

        @if($key == 'bank')
        <div class="d-none" id="bank-instructions">
            <div class="card mx-1 my-2">
                <div class="card-body mb-0">
                    @if( config('settings.bank_account_owner') )
                        <div class="mb-2"><strong>{{ __('Account owner') }}</strong>: {{ config('settings.bank_account_owner') }}</div>
                    @endif

                    @if( config('settings.bank_name') )
                        <div class="mb-2"><strong>{{ __('Bank name') }}</strong>: {{ config('settings.bank_name') }}</div>
                    @endif

                    @if( config('settings.bank_routing_number') )
                        <div class="mb-2"><strong>{{ __('Routing number') }}</strong>: {{ config('settings.bank_routing_number') }}</div>
                    @endif

                    @if( config('settings.bank_account_number') )
                        <div class="mb-2"><strong>{{ __('Account number') }}</strong>: {{ config('settings.bank_account_number') }}</div>
                    @endif

                    @if( config('settings.bank_iban') )
                        <div class="mb-2"><strong>{{ __('IBAN') }}</strong>: {{ config('settings.bank_iban') }}</div>
                    @endif

                    @if( config('settings.bank_bic_swift') )
                        <div class="mb-2"><strong>{{ __('BIC') }} / {{ __('SWIFT') }}</strong>: {{ config('settings.bank_bic_swift') }}</div>
                    @endif
                </div>
            </div>

            <div class="form-group m-1">
                <label for="payment-id"><strong>{{ __('Payment Id') }}</strong></label>
                <div class="input-group">
                    <input type="text" name="payment_id" id="payment-id" class="form-control form-control-sm @error('payment_id') is-invalid @enderror" value="{{ old('payment_id') ?? Str::random(16) }}" readonly>
                    <div class="input-group-append">
                        <div class="btn btn-sm btn-primary" data-tooltip-copy="true" title="{{ __('Copy') }}" data-text-copy="{{ __('Copy') }}" data-text-copied="{{ __('Copied') }}" data-clipboard="true" data-clipboard-target="#payment-id">{{ __('Copy') }}</div>
                    </div>
                </div>
                
                @error('payment_id')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror

                <small>{!! __('Please include the value of the :id field as payment reference.', ['id' => '<strong>' . __('Payment Id') . '</strong>']) !!}</small>
            </div>

        </div>
    @endif

    @endforeach
</div>
