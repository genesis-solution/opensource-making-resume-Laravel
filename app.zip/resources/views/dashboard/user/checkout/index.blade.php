@extends('layouts.app')

@section('title', __('Checkout'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/izitoast/dist/css/iziToast.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('dashboard.admin.plans.index') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Checkout') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.admin.plans.index') }}">{{ __('Plans') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Checkout') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Checkout') }}</h2>
                <p class="section-lead">
                    {{ __('The list of all checkout details') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                
                <form id="form-payment"
                    method="post" 
                    enctype="multipart/form-data"
                    class="row needs-validation"
                        novalidate="">
                    @csrf

                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-8">
                        <div class="card border-0 shadow-sm mb-3 overflow-hidden @if(($plan->trial_days && !$user->plan_trial_ends_at) || ($coupon && $coupon->type)) d-none @endif">
                            <div class="card-header">
                                <h4>{{ __('Payment Method') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.checkout.method')
                            </div>
                        </div>
                         <div class="card border-0 shadow-sm">
                            <div class="card-header">
                                <h4>{{ __('Billing Information') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.checkout.billing')
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-md-6 col-lg-6 col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('Order Summary') }}</h4>
                            </div>
                            <div class="card-body">
                                @include('dashboard.user.checkout.order')
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>
@endsection

@push('scripts')

    <!-- JS Libraries -->
    <script src="{{ asset('vendor/izitoast/dist/js/iziToast.min.js') }}"></script>
    <script src="{{ asset('vendor/select2/dist/js/select2.min.js') }}"></script>
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script>
        // International Phone Input
        var intlTelUtilInputSelector = '#phone';
        var intlTelUtilOutputSelector = '#phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}";

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";
        
        // Payment Processors
        var interval = "{{ request()->input('interval') }}";
        var processor = "{{ request()->input('processor') }}";

        var couponBtnApplyMsg = "{{ __('Apply') }}";
        var couponBtnPleaseWaitMsg = "{{ __('Please Wait...') }}";
        var couponValidatedSuccess = "{{ __('Coupon Validated Succesfully.') }}";
    </script>
    <script src="{{ asset('js/page/user-checkout.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('vendor/clipboard/dist/clipboard.min.js') }}"></script>

@endpush
