@extends('layouts.app')

@section('title', __('Payment Completed'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="{{ route('pricing') }}"
                        class="btn btn-icon"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <h1>{{ __('Checkout') }}</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="{{ route('dashboard.index') }}">{{ __('Dashboard') }}</a></div>
                    <div class="breadcrumb-item active"><a href="{{ route('pricing') }}">{{ __('Plans') }}</a></div>
                    <div class="breadcrumb-item">{{ __('Checkout') }}</div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">{{ __('All About Checkout') }}</h2>
                <p class="section-lead">
                    {{ __('The payment was successful.') }}
                </p>

                <div id="output-status">
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                </div>
                
                <div class="col-xs-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>{{ __('Payment Completed') }}</h4>
                        </div>
                        <div class="card-body">
                            <div class="d-flex flex-column justify-content-center align-items-center my-5">
                                <div class="card-large-icons align-items-center justify-content-center">
                                    <div class="card-icon text-primary">
                                        <i class="fa-solid fa-check" style="font-size: 100px;"></i>
                                    </div>
                                </div>

                                <div>
                                    <h5 class="mt-4 text-center">{{ __('Payment Completed') }}</h5>
                                    <p class="text-center text-muted">{{ __('The payment was successful.') }}</p>
                                    <script>
                                       setTimeout(function() {
                                           window.location.href = "{{ route('dashboard.user.payments.index') }}"
                                       }, 5000); // 5 second
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
