
@if( ($plan->trial_days && !$user->plan_trial_ends_at) || ($coupon && $coupon->type) )
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <div class="row">
                <div class="col">
                    <div>{{ __(':name plan', ['name' => $plan->name]) }}</div>

                    <div>
                        <div class="small text-muted">{{ __('Not billed.') }}</div>
                    </div>
                </div>
            </div>
        </li>
    </ul>

    <div class="card-footer">
        <div class="row">
            <div class="col">
                <div>
                    @if($plan->trial_days && !$user->plan_trial_ends_at)
                        {{ __('Trial days') }}
                    @else
                        {{ __('Days') }}
                    @endif
                </div>
            </div>
            <div class="col-auto">
                @if($plan->trial_days && !$user->plan_trial_ends_at)
                    {{ $plan->trial_days }}
                @else
                    {{ $coupon->days < 0 ? __('Unlimited') : $coupon->days }}
                    <input type="hidden" name="coupon" value="{{ $coupon->code }}">
                    <input type="hidden" name="coupon_set" value="true">
                @endif
            </div>
        </div>
    </div>

    <input type="hidden" name="interval" value="month">

    <div class="mt-3">
        <div class="small text-muted">{!! __('By continuing, you agree with the :terms.', ['terms' => mb_strtolower('<a href="'. config('settings.legal_terms_url') .'" target="_blank">'. __('Terms of Use') .'</a>')]) !!}</div>
    </div>
    
    <button type="submit" name="submit" class="btn btn-success btn-block mt-3 my-3">
        {{ __('Start') }}
    </button>

    @if($plan->trial_days && !$user->plan_trial_ends_at)
        <button type="submit" name="skip_trial" class="btn btn-secondary btn-block my-3" value="1">
            {{ __('Skip trial') }}
        </button>
    @endif
@else
    <div class="btn-group btn-group-toggle d-flex" data-toggle="buttons">
        <label class="btn {{ $errors->has('interval') ? 'btn-outline-danger' : 'btn-outline-primary' }} w-100{{ request()->input('interval') == 'month' ? ' active' : ''}}" id="plan-month">
            <input type="radio" name="interval" value="month" @if(request()->input('interval') == 'month') checked="checked" @endif>{{ __('Monthly') }}
        </label>
        <label class="btn {{ $errors->has('interval') ? 'btn-outline-danger' : 'btn-outline-primary' }} w-100{{ request()->input('interval') == 'year' ? ' active' : ''}}" id="plan-year">
            <input type="radio" name="interval" value="year" @if(request()->input('interval') == 'year') checked="checked" @endif>{{ __('Yearly') }}

            @if(($plan->amount_month * 12) > $plan->amount_year)
                <span class="badge bg-success text-white">-{{ number_format(((($plan->amount_month * 12) - $plan->amount_year)/($plan->amount_month * 12) * 100), 0) }}%</span>
            @endif
        </label>
    </div>

    @error('interval')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
    @enderror

    <ul class="list-group list-group-flush">
        <li class="list-group-item pt-0">
            <div class="row">
                <div class="col">
                    <div>{{ __(':name plan', ['name' => $plan->name]) }}</div>

                    <div class="d-none checkout-month">
                        <div class="small text-muted">
                            <span class="d-none checkout-subscription">{!! ($plan->trial_days && !$user->plan_trial_ends_at) ? __('Billed :interval, after trial ends.', ['interval' => mb_strtolower(__('Monthly'))]) :__('Billed :interval.', ['interval' => mb_strtolower(__('Monthly'))]) !!}</span>
                            <span class="d-none checkout-one-time">{!! __('Billed once.') !!}</span>
                        </div>
                    </div>
                    <div class="d-none checkout-year">
                        <div class="small text-muted">
                            <span class="d-none checkout-subscription">{!! ($plan->trial_days && !$user->plan_trial_ends_at) ? __('Billed :interval, after trial ends.', ['interval' => mb_strtolower(__('Yearly'))]) :__('Billed :interval.', ['interval' => mb_strtolower(__('Yearly'))]) !!}</span>
                            <span class="d-none checkout-one-time">{!! __('Billed once.') !!}</span>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="d-none checkout-month">
                        {{ formatMoney($plan->amount_month, config('settings.currency')) }} <span class="text-muted">{{ config('settings.currency') }}</span>
                    </div>
                    <div class="d-none checkout-year">
                        {{ formatMoney($plan->amount_year, config('settings.currency')) }} <span class="text-muted">{{ config('settings.currency') }}</span>
                    </div>
                </div>
            </div>
        </li>

        @if($coupon==null || $coupon->type == 0)
            @if(!$taxRates->isEmpty())
            <li class="list-group-item">
                @foreach($taxRates as $taxRate)
                <div class="row">
                    <div class="col">
                        <div>{{ $taxRate->name }} ({{ $taxRate->percentage }}% {{ $taxRate->type ? __('excl.') : __('incl.') }})</div>
                    </div>
                    <div class="col-auto">
                        @if($taxRate->type)
                        <span class="d-none checkout-month">
                            {{ formatMoney(checkoutExclusiveTaxRate($plan->amount_month, $coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                        </span>
                            <span class="d-none checkout-year">
                            {{ formatMoney(checkoutExclusiveTaxRate($plan->amount_year, $coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                        </span>
                        @else
                        <span class="d-none checkout-month">
                            {{ formatMoney(calculateInclusiveTaxRate($plan->amount_month, $coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                        </span>
                            <span class="d-none checkout-year">
                            {{ formatMoney(calculateInclusiveTaxRate($plan->amount_year, $coupon->percentage ?? null, $taxRate->percentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                        </span>
                        @endif
                        <span class="text-muted">{{ config('settings.currency') }}</span>
                    </div>
                </div>
                @endforeach
            </li>
            @endif
        @endif

        @if($coupon!== null)
        <li class="list-group-item text-success">
            <div class="row">
                <div class="col">
                    <div>{{ __('Discount') }} ({{ $coupon->percentage }}%)</div>
                </div>
                <div class="col-auto">
                <span class="d-none checkout-month">
                    -{{ formatMoney(calculateDiscount($plan->amount_month, $coupon->percentage), config('settings.currency')) }}
                </span>
                    <span class="d-none checkout-year">
                    -{{ formatMoney(calculateDiscount($plan->amount_year, $coupon->percentage), config('settings.currency')) }}
                </span>
                    <span class="text-muted">{{ config('settings.currency') }}</span>
                </div>
            </div>
            <input type="hidden" name="coupon" value="{{ $coupon->code }}">
            <input type="hidden" name="coupon_set" value="true">
        </li>
        @else
        <li class="list-group-item">
            <a href="#" id="coupon" class="{{ $errors->has('coupon') || old('coupon') ? 'd-none' : '' }}">{{ __('Have a coupon code?') }}</a>

            <div class="form-row {{ $errors->has('coupon') || old('coupon') ? '' : 'd-none' }}" id="coupon-input">
                <div class="form-group mb-0">
                    <div class="input-group br">
                    <input type="text" name="coupon" id="coupon-code" class="form-control mb-2 form-control-sm {{ $errors->has('coupon') || old('coupon') ? ' is-invalid' : '' }}" value="{{ old('coupon') }}" placeholder="{{ __('Coupon code') }}"{{ $errors->has('coupon') || old('coupon') ? '' : ' disabled' }}>

                     <span class="input-group-btn">
                    <button id="coupon-cancel" class="btn btn-sm btn-secondary">{{ __('Cancel') }}</button>
                    <button onclick="checkCouponCode(); return false;" id="coupon-apply" class="btn btn-primary btn-sm">{{ __('Apply') }}</button>
                </span>
                </div>

                @error('coupon')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div id="coupon-error" class="mt-3"></div>
        </li>
        @endif
    </ul>

    <div class="card-footer font-weight-bold">
        <div class="row">
            <div class="col">
                <span>{{ __('Total') }}</span>
            </div>
            <div class="col-auto">
                <span class="d-none checkout-month">
                    {{ formatMoney(checkoutTotalAmount($plan->amount_month, $coupon->percentage ?? null, $exclTaxRatesPercentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                </span>
                <span class="d-none checkout-year">
                    {{ formatMoney(checkoutTotalAmount($plan->amount_year, $coupon->percentage ?? null, $exclTaxRatesPercentage, $inclTaxRatesPercentage), config('settings.currency')) }}
                </span>
                <span>{{ config('settings.currency') }}</span>
            </div>
        </div>
    </div>

    <div class="mt-3">
        <span class="small text-muted">
            <span class="checkout-subscription">
                {!! __('By continuing, you agree to the :terms and authorize :title to charge your designated payment method on a recurring basis.', ['terms' => mb_strtolower('<a href="'. config('settings.legal_terms_url') .'" target="_blank">'. __('Terms of Use') .'</a>'), 'title' => '<strong>'. e(config('settings.site_name')) .'</strong>']) !!} {{ __('You can cancel your subscription at any time, with no early termination fees.') }}
            </span>
            <span class="checkout-one-time">
                {!! __('By continuing, you agree to the :terms.', ['terms' => mb_strtolower('<a href="'. config('settings.legal_terms_url') .'" target="_blank">'. __('Terms of Use') .'</a>')]) !!}
            </span>
        </span>
    </div>

    <button type="submit" name="submit" class="btn btn-success btn-block my-3">
        <span class="d-none checkout-month">
            {{ __('Pay :amount :currency', ['amount' => formatMoney(checkoutTotalAmount($plan->amount_month, $coupon->percentage ?? null, $exclTaxRatesPercentage, $inclTaxRatesPercentage), config('settings.currency')), 'currency' => e(config('settings.currency'))]) }}
        </span>
        <span class="d-none checkout-year">
            {{ __('Pay :amount :currency', ['amount' => formatMoney(checkoutTotalAmount($plan->amount_year, $coupon->percentage ?? null, $exclTaxRatesPercentage, $inclTaxRatesPercentage), config('settings.currency')), 'currency' => e(config('settings.currency'))]) }}
        </span>
    </button>
@endif
 