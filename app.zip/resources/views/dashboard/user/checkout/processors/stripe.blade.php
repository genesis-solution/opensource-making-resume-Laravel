@extends('layouts.auth')

@section('title', __('Confirm Payment'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <script src="https://js.stripe.com/v3/"></script>

    <script>
        'use strict';

        const stripe = Stripe('{{ config('settings.stripe_publishable_key') }}');

        stripe.redirectToCheckout({
            sessionId: '{{ $stripeSession->id }}'
        });
    </script>
@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush

