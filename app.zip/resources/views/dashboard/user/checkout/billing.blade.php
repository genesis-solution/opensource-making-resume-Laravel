<div class="row">
    <div class="form-group col-md-6 col-12">
        <label for="firstname">{{ __('First Name') }}</label>
        <input id="firstname"
            type="text"
            class="form-control @error('firstname') is-invalid @enderror"
            name="firstname"
            required 
            value="{{ old('firstname') ?? $user->firstname }}"
            autocomplete="firstname"
            autofocus
        >

        @error('firstname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-group col-md-6 col-12">
        <label for="lastname">{{ __('Last Name') }}</label>
        <input id="lastname"
            type="text"
            class="form-control @error('lastname') is-invalid @enderror"
            name="lastname"
            required 
            value="{{ old('lastname') ?? $user->lastname }}"
            autocomplete="lastname"
        >

        @error('lastname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>

<div class="row">
    <div class="form-group col-12">
        <label for="phone">{{ __('Phone') }}</label>
        <input id="phone"
            type="tel"
            class="form-control @error('phone') is-invalid @enderror"
            name="phone"
            value="{{ old('phone') ?? $user->phone }}"
            autocomplete="tel">

        <span id="phone_output"></span>

        @error('phone')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>

<div class="row">
    <div class="form-group col-12">
        <label for="street">{{ __('Street') }}</label>
        <input id="street"
            type="text"
            class="form-control @error('street') is-invalid @enderror"
            name="street"
            value="{{ $user->address->street ?? null }}"
            autocomplete="street"
        >

        @error('street')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>
<div class="row">
    <div class="form-group col-md-4 col-12">
        <label for="city">{{ __('City') }}</label>
        <input id="city"
            type="text"
            class="form-control @error('city') is-invalid @enderror"
            name="city"
            value="{{ $user->address->city ?? null }}"
            autocomplete="city"
        >

        @error('city')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-group col-md-4 col-12">
        <label for="state">{{ __('State') }}</label>
        <input id="state"
            type="text"
            class="form-control @error('state') is-invalid @enderror"
            name="state"
            value="{{ $user->address->state ?? null }}"
            autocomplete="state"
        >

        @error('state')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-group col-md-4 col-12">
        <label for="postal">{{ __('Postal') }}</label>
        <input id="postal"
            type="text"
            class="form-control @error('postal') is-invalid @enderror"
            name="postal"
            value="{{ $user->address->postal ?? null }}"
            maxlength="10"
            autocomplete="postal"
        >

        @error('postal')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>
<div class="row">
    <div class="form-group col-12">
        <label for="country">{{ __('Country') }}</label>
        <select id="country" 
            name="country"  
            class="form-control select2 @error('country') is-invalid @enderror"
        >
            @include('dashboard.admin.settings.countries', [ 'provided_country' => ( $user->address->country ?? config('settings.country') ) ])
        </select>

        @error('country')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>
 