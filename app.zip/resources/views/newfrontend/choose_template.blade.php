<!DOCTYPE html>
<html lang="en-US" xml:lang="en-US">
<head>
<meta charset="utf-8" /><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info = {"beacon":"bam.nr-data.net","errorBeacon":"bam.nr-data.net","licenseKey":"83635f2ecf","applicationID":"27301380","transactionName":"NQBbY0FWWBBYVk1fDgxKdGFwGGEKQ1RLUiINC01FXFtaBksael4ODRZcY1ZaRg9YQVw=","queueTime":0,"applicationTime":93,"agent":"","atts":""}</script><script type="text/javascript">(window.NREUM||(NREUM={})).init={privacy:{cookies_enabled:true},ajax:{deny_list:["bam.nr-data.net"]},distributed_tracing:{enabled:true}};(window.NREUM||(NREUM={})).loader_config={agentID:"27301395",accountID:"1357435",trustKey:"1160914",xpid:"VQUCVlJQDRACU1JSBgIPVg==",licenseKey:"83635f2ecf",applicationID:"27301380"};;

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://cdn.segment.com/">
<link rel="preconnect" href="https://www.googletagmanager.com/">
<link rel="preconnect" href="https://cdn.mxpnl.com/">
<link rel="preconnect" href="https://ajax.googleapis.com/">
<script>
</script>
<script>!function(c){function o(e){var n=c.console;n&&n.log(e)}function n(e,n){try{var t={type:n};t={message:e.message,url:c.location.href};e.error&&(t.stack=e.error.stack,t.errMessage=e.error.message),t.stack||(t.filename=e.filename,t.lineno=e.lineno,t.colno=e.colno);var r=c.console;r&&r.trace&&(t.trace=r.trace()),function(e,n,t){if(c.XMLHttpRequest){var r=new XMLHttpRequest;r.open("POST",t,!0),r.setRequestHeader("Content-type","application/json; charset=utf-8");var o={};o[n]=e,r.send(JSON.stringify(o))}else{var a=document.createElement("img");a.style.display="none",a.src=t+"?"+n+"="+encodeURI(JSON.stringify(e))}}(t,"logData","/logger/error")}catch(e){o(e)}}var e,t,r;t="error",r=function(e){n(e,"window.onerror")},(e=c).addEventListener?e.addEventListener(t,r):e.attachEvent?e.attachEvent("on"+t,r):e["on"+t]=function(e){r(e)},c.RB3=c.RB3||{},c.RB3.Logger={LogError:function(e){n(e,"handled"),o(e)},LogAjaxError:function(e){n(e,"ajax"),o(e)}}}(window);</script>
<title>Choose Template | ACE My Resume</title>
{{--<link rel="apple-touch-icon" sizes="120x120" type="image/png" href="https://cdnprod3.resumehelp.com/img/fav/favicon-120x120.png?v=2500"> <link rel="apple-touch-icon" sizes="180x180" type="image/png" href="https://cdnprod3.resumehelp.com/img/fav/favicon-180x180.png?v=2500"> <link rel="apple-touch-icon" sizes="167x167" type="image/png" href="https://cdnprod3.resumehelp.com/img/fav/favicon-167x167.png?v=2500"> <link rel="apple-touch-icon" sizes="152x152" type="image/png" href="https://cdnprod3.resumehelp.com/img/fav/favicon-152x152.png?v=2500"> <link rel="icon" type="image/svg+xml" href="https://cdnprod3.resumehelp.com/img/fav/favicon.svg?v=2500">--}}
<meta name="google-signin-scope" content="profile email">
<div id="g_id_onload" data-client_id data-context="signup" data-itp_support="true" data-ux_mode="popup" data-callback="onSignIn"></div>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700%7CSource+Sans+Pro:400,600,700&display=swap" rel="stylesheet" />


{{-- <link href="https://cdnprod4.resumehelp.com/distcss/builder.min.css?v=2500" rel="stylesheet" /> --}}{{--<link href="https://cdnprod4.resumehelp.com/distcss/exp-onboarding.min.css?v=2500" rel="stylesheet" /> --}} {{-- <link href="https://cdnprod4.resumehelp.com/distcss/base.min.css?v=2500" rel="stylesheet" /> --}}
<link href="{{url('/')}}/assets/css/builder.min.css" rel="stylesheet" /> 
<link href="{{url('/')}}/assets/css/base.min.css" rel="stylesheet" />
<link href="{{url('/')}}/assets/css/exp-onboarding.min.css" rel="stylesheet" />

</head>
<body class="rhus    pdfonly-badges     exp-onboarding">
<header class="header">
<div class="container-main clearfix">
<div class="rh-logo">
{{--<img src="{{url('/')}}/assets/img/upload/logo1.png" alt="ACEMyResumeLogo" width="20px" height="" />--}}
</div>
</div>
</header>
<section class="template-page-title">
<div class="template-page-layout">
<div class="template-page-title-wrap display-flex y-center flex-space-between">
<h1 id="hdntxt1" class="y-center text-bold display-none">Choose one of our professional templates</h1>
<div class="exp-dropdown-option">
<h1 id="hdntxt" class="recommonded-heading  y-center text-bold display-none">These templates are great for <span id="explevtext" class="exp-label">no experience<i class="fas fa-chevron-down"></i></span> </h1>
<div class="select-experience">
<button type="button" class="exp-box" value="No experience" aria-label="no experience">
<span class="exp-level display-block text-bold">No experience</span>
</button>
<button type="button" class="exp-box" value="0-3 Years" aria-label="entry-level">
<span class="exp-level display-block text-bold">Entry-Level</span>
<span class="exp-period display-block">Less than 3 years</span>
</button>
<button type="button" class="exp-box" value="3-5 Years" aria-label="intermediate">
<span class="exp-level display-block text-bold">Intermediate</span>
<span class="exp-period display-block">3 to 5 years</span>
</button>
<button type="button" class="exp-box" value="5-10 Years" aria-label="mid-level">
<span class="exp-level display-block text-bold">Mid-Level</span>
<span class="exp-period display-block">5 to 10 years</span>
</button>
<button type="button" class="exp-box" value="10+ Years" aria-label="senior-level">
<span class="exp-level display-block text-bold">Senior-Level</span>
<span class="exp-period display-block">10+ years</span>
</button>
</div>
</div>
<div class="section-choose-later display-flex y-center">
<p>You can always change your template later</p>
<a href="{{url('/')}}/upload" id="btnSaveColor" class="button-primary btn-medium btn-arrow-right"> Choose later</a>
{{--<button id="btnSaveColor" class="button-primary btn-medium btn-arrow-right">Choose later</button>--}}
</div>
</div>
</div>
</section>
<input id="allTemplates" name="resumeTemplates" type="radio" checked>
<input id="recommended" name="resumeTemplates" type="radio">
<section class="template-options">
<div class="template-page-layout">
<div class="templates-tabs">
<label class="select-option" id="allTemplateTab" for="allTemplates"><i class="far fa-columns"></i>All Templates</label>
<label class="select-option" id="recommendedTab" for="recommended"><i class="fas fa-badge-check"></i>Recommended</label>
</div>
</div>
</section>
<section class="template-selection">
<div id="template-tabs-content" class="template-page-layout">
<div id class="template-tab-content">
<div id="allTabContent" class="template-card-wrapper">
<div id="KGF1" data-skin-cd="KGF1" data-skin-name="Kingfish" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color alltemplate">
<div class="template-doc  selected">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="30" class="svg-name">
<tspan x="70" y="40" style="letter-spacing: 6px;" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="255" y="40" style="letter-spacing: 6px;" id="PreviewUserLastName">CARTER</tspan>
</text>
<path fill="#305fec" d="M0 0h56v58H0z" class="svg-section-bg" />
<text fill="#fff" font-family="'Century Gothic','Arial'" font-size="20" class="font-bld">
<tspan x="10" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="30" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text font-family="'Century Gothic','Arial'" font-size="13" letter-spacing=".79">
<tspan x="530" y="15" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">mCARTER@address.com</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="83">PROFESSIONAL SUMMARY</tspan>
</text>
<line x1="0" y1="93" x2="705" y2="93" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="115">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="20">Implement cost control measures to ensure operations remain within company targets. Maximize</tspan>
<tspan x="0" dy="20">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="20">inventory management initiatives.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="200">SKILLS</tspan>
</text>
<line x1="0" y1="210" x2="705" y2="210" style="stroke:#333333; stroke-width:2" />
<circle cx="5" cy="230" r="2" style="fill:#333333" />
<circle cx="5" cy="250" r="2" style="fill:#333333" />
<circle cx="5" cy="270" r="2" style="fill:#333333" />
<circle cx="5" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="234">Executive team leadership</tspan>
<tspan x="20" dy="20">Inventory report generation</tspan>
<tspan x="20" dy="20">Client/Vendor relations</tspan>
<tspan x="20" dy="20">Market analysis</tspan>
</text>
<circle cx="275" cy="230" r="2" style="fill:#333333" />
<circle cx="275" cy="250" r="2" style="fill:#333333" />
<circle cx="275" cy="270" r="2" style="fill:#333333" />
<circle cx="275" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="290" y="234">Sales Management</tspan>
<tspan x="290" dy="20">Staff training</tspan>
<tspan x="290" dy="20">Customer relations</tspan>
<tspan x="290" dy="20">Process improvements</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="330">EXPERIENCE</tspan>
</text>
<line x1="0" y1="340" x2="705" y2="340" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="367" font-weight="700">District Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="367">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="390" r="2" style="fill:#333333" />
<circle cx="5" cy="410" r="2" style="fill:#333333" />
<circle cx="5" cy="430" r="2" style="fill:#333333" />
<circle cx="5" cy="450" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="394">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="490" font-weight="700">Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="490">Oct 1997 – Sept 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="513" r="2" style="fill:#333333" />
<circle cx="5" cy="533" r="2" style="fill:#333333" />
<circle cx="5" cy="553" r="2" style="fill:#333333" />
<circle cx="5" cy="573" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="517">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="610" font-weight="700">General Manager, <tspan>Woodranch Restaurant</tspan> - <tspan>San Jose, CA</tspan></tspan>
<tspan x="410" y="610">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="5" cy="633" r="2" style="fill:#333333" />
<circle cx="5" cy="653" r="2" style="fill:#333333" />
<circle cx="5" cy="673" r="2" style="fill:#333333" />
<circle cx="5" cy="693" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="637">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="730" font-weight="700">Senior Executive, Woodranch Restaurant - San Jose, CA</tspan>
<tspan x="400" y="730">Aug 1993 – Jan 1994</tspan>
</text>
<circle cx="5" cy="748" r="2" style="fill:#333333" />
<circle cx="5" cy="768" r="2" style="fill:#333333" />
<circle cx="5" cy="788" r="2" style="fill:#333333" />
<circle cx="5" cy="808" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="752">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="855">EDUCATION</tspan>
</text>
<line x1="0" y1="865" x2="705" y2="865" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="885">Master of Arts: Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="905">San Francisco State University - San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="935">Master of Arts: Business Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="955">University of San Francisco - San Francisco, CA</tspan>
</text>
</svg>
</div>
<p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP2" data-skin-cd="MLP2" data-skin-name="Fold" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color alltemplate">
<div class="template-doc full-page-resume">

<svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');
        .name { height:50px; width:335px; color:#FFFFFF; font-family:'Source Sans Pro',Arial; font-weight:400; font-size:40px; letter-spacing:5.91px; line-height:30px; }
      </style>
</defs>
<rect x="37" y="0" width="410" height="160" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<rect x="470" y="0" width="240" height="1024" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Source Sans Pro',Arial;fill:#fff;font-weight:700">
<tspan class="name" x="44" y="100" id="PreviewUserFirstName">JOHN</tspan>
<tspan class="name" x="44" dy="40" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="37" y="180" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="194.5">PROFESSIONAL SUMMARY</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79" line-height="11" height="44" width="320">
<tspan x="43" y="220" width="320">Successful sales professional with 10+ years</tspan>
<tspan x="43" dy="16"> experience in large-scale food and retail environments.</tspan>
<tspan x="43" dy="16">Implement cost control measures to ensure operations</tspan>
<tspan x="43" dy="16"> remain within company targets.</tspan>
</text>
<rect x="37" y="293" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="308">WORK EXPERIENCE</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="340" font-weight="700">Verizon Wireless, San Francisco, CA - <tspan font-weight="500">Aug 2016 - Present</tspan></tspan>
<tspan font-weight="700" x="43" y="356">District Manager</tspan>
</text>
<text style="font-size:13px;fill:#333333;font-family:'Source Sans Pro',Arial;font-style:italic;"></text>
<circle cx="44" cy="380" r="2" style="fill:#333333" />
<circle cx="44" cy="420" r="2" style="fill:#333333" />
<circle cx="44" cy="460" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="383">Directed recruitment/training/staff development </tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="524" font-weight="700">Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Oct 1997 – Sept 2009</tspan></tspan>
<tspan font-weight="700" x="43" y="540">Manager</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="44" cy="564" r="2" style="fill:#333333" />
<circle cx="44" cy="604" r="2" style="fill:#333333" />
<circle cx="44" cy="644" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="567">Directed recruitment/training/staff development</tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="706" font-weight="700"><tspan>Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Jan 1994 – Aug 1997</tspan></tspan>
<tspan font-weight="700" x="43" y="722"> General Manager</tspan></tspan>
</text>
<circle cx="44" cy="746" r="2" style="fill:#333333" />
<circle cx="44" cy="766" r="2" style="fill:#333333" />
<circle cx="44" cy="806" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="750">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="55" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="55" dy="20">$110,000 store remodel.</tspan>
<tspan x="55" dy="20">Directed departmental alignment on strategies </tspan>
<tspan x="55" dy="20">to create strong sales.</tspan>
</text>
<rect x="37" y="860" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="874.5">EDUCATION</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="898">Jun 2010</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="918"><tspan font-weight="700">Master of Arts,</tspan> Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="938">San Francisco State University, San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="963">Jul 2008</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="983"><tspan font-weight="700">Master of Arts,</tspan> Business Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="1003">University of San Francisco, San Francisco, CA</tspan>
</text>
<rect x="490" y="180" width="200" height="20" style="fill:#E3E3E3;" />
<svg x="500" y="211" width="10" height="11" viewBox="0 0 512 512">
<path fill="#fff" d="M384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192H384z" />
</svg>
<svg x="500" y="252" width="12" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M511.2 387l-23.25 100.8c-3.266 14.25-15.79 24.22-30.46 24.22C205.2 512 0 306.8 0 54.5c0-14.66 9.969-27.2 24.22-30.45l100.8-23.25C139.7-2.602 154.7 5.018 160.8 18.92l46.52 108.5c5.438 12.78 1.77 27.67-8.98 36.45L144.5 207.1c33.98 69.22 90.26 125.5 159.5 159.5l44.08-53.8c8.688-10.78 23.69-14.51 36.47-8.975l108.5 46.51C506.1 357.2 514.6 372.4 511.2 387z"></path>
</svg>
<svg x="500" y="272" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="194.5">CONTACT</text>
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro';line-height: 14px; fill:#575757;letter-spacing: 0.79px;" x="530" y="192.5">
<tspan x="515" y="220" fill="#FFF">123 Main Street,</tspan>
<tspan x="515" dy="20" fill="#FFF">SanFrancisco, CA 94122</tspan>
<tspan x="515" dy="20" fill="#FFF">415-123-1200</tspan>
<tspan x="515" dy="20" fill="#FFF">mCARTER@address.com</tspan>
</text>
<rect x="490" y="310" width="200" height="20" style="fill:#E3E3E3;" />
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="324.5">skills</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="495" cy="352" r="2" style="fill:#ffffff" />
<circle cx="495" cy="390" r="2" style="fill:#ffffff" />
<circle cx="495" cy="410" r="2" style="fill:#ffffff" />
<circle cx="495" cy="430" r="2" style="fill:#ffffff" />
<circle cx="495" cy="450" r="2" style="fill:#ffffff" />
<circle cx="495" cy="470" r="2" style="fill:#ffffff" />
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro',Arial;text-transform:uppercase;line-height: 14px; fill:#ffffff;letter-spacing: 0.79px;" x="525" y="355">
<tspan x="502">Trained in Point-of-Sale </tspan>
<tspan x="502" dy="18">Systems</tspan>
<tspan x="502" dy="20">Spanish</tspan>
<tspan x="502" dy="20">Loyalty Program Promotion</tspan>
<tspan x="502" dy="20">Team Member Support</tspan>
<tspan x="502" dy="20">Menu Item Recommendation</tspan>
<tspan x="502" dy="20">Western Union Agent</tspan>
<tspan x="502" dy="18">Cashier</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR4" data-skin-cd="MLR4" data-skin-name="Blueprint" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color alltemplate">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Roboto:400,900');
        .font-bld{font-weight:900;}
        .li-disc {fill:#000;} 
      </style>
</defs>
<line x1="0" y1="90" x2="710" y2="90" stroke="#e7e7e7" stroke-width="2" />
<line x1="258" y1="90" x2="258" y2="1300" stroke="#e7e7e7" stroke-width="2" />
<rect class="rect1 svg-section-bg" fill="#305fec" height="119" width="54" x="48" />
<polygon points="73,110 103,120 29,125" style="fill:#fff;" />
<text class="font-bld" style="font-size:21px;font-family:'Roboto';fill:#fff;">
<tspan x="66" y="40" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="66" y="65" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text style="font-size:28px;font-family:'Roboto';fill:#000;" class="text-upper">
<tspan x="133" y="55" class="font-bld" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="263" y="55" class="font-bld" id="PreviewUserLastName">CARTER</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="170">Contact</text>
<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="187" width="13" height="13" viewBox="0 0 512 512">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="220" width="12" height="12" viewBox="0 0 512 512">
<path fill="#000" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="48" y="250" width="10" height="13" viewBox="0 0 384 512">
<path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
</svg>
<text style="font-size:14px;font-weight:400;font-family:'Roboto';fill:#000;">
<tspan x="68" y="200">415-123-0012</tspan>
<tspan x="68" dy="30">mCARTER@address.com</tspan>
<tspan x="68" dy="30">123 Main Street, </tspan>
<tspan x="68" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<line x1="0" y1="320" x2="258" y2="320" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="360">professional Summary</text>
<text style="font-size:14px;fill:#000;font-family:'Roboto';font-weight:400;">
<tspan x="48" y="390">Successful sales </tspan>
<tspan x="48" dy="25">professional with 10+ </tspan>
<tspan x="48" dy="25">years experience in </tspan>
<tspan x="48" dy="25">large-scale food and retail </tspan>
<tspan x="48" dy="25">environments.</tspan>
</text>
<line x1="0" y1="520" x2="258" y2="520" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="560">SKILLS</text>
<circle cx="48" cy="585" r="1.3" class="li-disc" />
<circle cx="48" cy="635" r="1.3" class="li-disc" />
<circle cx="48" cy="660" r="1.3" class="li-disc" />
<circle cx="48" cy="710" r="1.3" class="li-disc" />
<circle cx="48" cy="760" r="1.3" class="li-disc" />
<circle cx="48" cy="810" r="1.3" class="li-disc" />
<circle cx="48" cy="785" r="1.3" class="li-disc" />
<circle cx="48" cy="835" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="58" y="590">Executive team </tspan>
<tspan x="58" dy="25">leadership</tspan>
<tspan x="58" dy="25">Sales Management</tspan>
<tspan x="58" dy="25">Inventory report </tspan>
<tspan x="58" dy="25">generation</tspan>
<tspan x="58" dy="25">Staff training and </tspan>
<tspan x="58" dy="25">development</tspan>
<tspan x="58" dy="25">Client/Vendor relation</tspan>
<tspan x="58" dy="25">Customer relations</tspan>
<tspan x="58" dy="25">Market analysis</tspan>
<tspan x="58" dy="25">Process Improvements</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="273" y="130">Experience</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="160" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">District Manager </tspan><tspan style="font-style:italic;">Sep 2009 - Current</tspan> </tspan>
<tspan x="273" dy="25" style="font-style:italic;">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="278" cy="205" r="1.3" class="li-disc" />
<circle cx="278" cy="230" r="1.3" class="li-disc" />
<circle cx="278" cy="280" r="1.3" class="li-disc" />
<circle cx="278" cy="330" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="210">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="293" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="293" dy="25">work environment.</tspan>
<tspan x="293" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="400" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">General Manager </tspan> <tspan style="font-style:italic;">Jan 1994 - Aug 1997</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="455" r="1.3" class="li-disc" />
<circle cx="278" cy="480" r="1.3" class="li-disc" />
<circle cx="278" cy="530" r="1.3" class="li-disc" />
<circle cx="278" cy="580" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="460">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="293" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="293" dy="25">$110,000 store remodel.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to </tspan>
<tspan x="293" dy="25">create strong sales.</tspan>
<tspan x="293" dy="25">Cultivated strong franchise owner relationships to </tspan>
<tspan x="293" dy="25">achieve high standards.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="650" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Senior Executive </tspan><tspan style="font-style:italic;">Aug 1993 - Jan 1994</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="705" r="1.3" class="li-disc" />
<circle cx="278" cy="755" r="1.3" class="li-disc" />
<circle cx="278" cy="805" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="710">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="293" dy="25">strong sales.</tspan>
</text>
<line x1="258" y1="870" x2="710" y2="870" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; text-transform:uppercase;fill:#305fec;" x="278" y="910">Education</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="278" y="940" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Master of Arts - Operations Management </tspan><tspan style="font-style:italic;">Jun 2009</tspan></tspan>
<tspan x="278" dy="25" style="fill:#000;font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP3" data-skin-cd="MLP3" data-skin-name="Vision" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color alltemplate">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,900');
          </style>
</defs>
<rect xmlns="http://www.w3.org/2000/svg" x="0" y="0" style="fill:#acb75a;" height="100" width="100%" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" fill="#ffffff" font-weight="900" font-size="30">
<tspan x="15" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="15" y="80" id="PreviewUserLastName">CARTER</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="15" y="145" id="PreviewUserLastName">CONTACT</tspan>
</text>
<svg width="12px" height="9px" viewBox="0 0 512 512" x="15" y="203" style="fill:#acb75a;">
<path style="fill:#acb75a;" class="svg-section-bg" d="M484.25 330l-101.59-43.55a45.86 45.86 0 0 0-53.39 13.1l-32.7 40a311.08 311.08 0 0 1-124.19-124.12l40-32.7a45.91 45.91 0 0 0 13.1-53.42L182 27.79a45.63 45.63 0 0 0-52.31-26.61L35.5 22.89A45.59 45.59 0 0 0 0 67.5C0 313.76 199.68 512.1 444.56 512a45.58 45.58 0 0 0 44.59-35.51l21.7-94.22a45.75 45.75 0 0 0-26.6-52.27zm-41.59 134.09C225.08 463.09 49 287 48 69.3l90.69-20.9 42.09 98.22-68.09 55.71c46.39 99 98.19 150.63 197 197l55.69-68.11 98.19 42.11z" />
</svg>
<svg width="12px" height="9px" viewBox="0 0 12 9" style="fill:#acb75a;" x="15" y="222">
<path class="svg-section-bg" d="M9.06247839,8 C9.58024602,8 9.99997616,7.58026986 9.99997616,7.06250224 L9.99997616,1.43751565 C9.99997616,0.919748021 9.58024602,0.500017881 9.06247839,0.500017881 L0.937497765,0.500017881 C0.419730139,0.500017881 0,0.919748021 0,1.43751565 L0,7.06250224 C0,7.58026986 0.419730139,8 0.937497765,8 L9.06247839,8 Z M4.99998808,5.18743041 C4.54670776,5.19475461 3.89493014,4.57299859 3.56614216,4.31436273 C2.07381708,3.1458093 1.37548119,2.59117272 0.937497765,2.2344803 L0.937497765,1.43751565 L9.06247839,1.43751565 L9.06247839,2.2344803 C8.62455219,2.5911155 7.92638796,3.14563764 6.433834,4.31436273 C6.10491251,4.57309396 5.45334469,5.19467832 4.99998808,5.18743041 Z M9.06247839,7.06250224 L0.937497765,7.06250224 L0.937497765,3.43748036 C1.38503698,3.7939439 2.01970573,4.29414488 2.9870725,5.05164659 C3.41395518,5.38768247 4.16155777,6.1295058 4.99998808,6.1249854 C5.83429853,6.1295058 6.57242162,5.39843989 7.012732,5.05179917 C7.9800797,4.29431654 8.6149201,3.79398204 9.06247839,3.43748036 L9.06247839,7.06250224 Z" id="email" fill-rule="nonzero"></path>
</svg>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="15" dy="175" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="15" dy="18" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">mCARTER@address.com</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'">
<tspan x="15" y="280" id="PreviewUserLastName" fill="#4f4f4f">SKILLS</tspan>
</text>
<circle cx="15" cy="307" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="343" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="363" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="400" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="420" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="440" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="460" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="480" r="2" style="fill:#4f4f4f" />
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="22" y="310" style="font-kerning:normal">Executive team</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">leadership</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Sales Management</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Inventory report</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">generation</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Staff training</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Client/Vendor relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Customer relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Market analysis</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Process improvements</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="145" id="PreviewUserLastName">PROFESSIONAL SUMMARY</tspan>
</text>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="207" y="175" style="font-kerning:normal">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">environments. Implement cost food and retail control measures to</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> ensure operations remain within line company targets. Maximize</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> bottom-performance through P &amp; L, merchanding, staff management,</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">loss control and inventory management initiatives.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="290" id="PreviewUserLastName">EXPERIENCE</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="325">Verizon Wireless</tspan> | <tspan>San Francisco, CA</tspan>
</text>
<circle cx="207" cy="342" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="345">February 2016 – Current</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="365">District Manager</tspan>
</text>
<circle cx="207" cy="381" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="401" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="421" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="461" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="385">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<circle cx="207" cy="502" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="505">Oct 1997 – Sept 2009</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="525">Manager</tspan>
</text>
<circle cx="207" cy="542" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="562" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="582" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="622" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="545">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="665">Woodranch Restaurant</tspan> | <tspan>San Jose, CA</tspan>
</text>
<circle cx="207" cy="682" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="685">Jan 1994 – Aug 1997</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="705">General Manager</tspan>
</text>
<circle cx="207" cy="722" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="742" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="762" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="782" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="725">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="212" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="212" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="212" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="835" id="PreviewUserLastName">EDUCATION</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="870">Jun 2010</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="890">Master of Arts - Operations Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="910">San Francisco State University , San Francisco, CA</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="940">Jun 2008</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="960">Master of Arts: Business Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="980">University of San Francisco , San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR1" data-skin-cd="MLR1" data-skin-name="Flapjack" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color alltemplate">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024" class="mlr1-skn">
<defs>
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Roboto:300,400,900');
        .font-bld{font-weight:700;}
        .h1{font-size:45px; font-weight:600;}
        .h2{font-size:18px; font-weight:500;}
        .li-disc {fill:#000;}              
      </style>
</defs>
<rect x="0" y="0" width="103.5" height="10" style="fill:#d6407a;" />
<rect x="102" y="0" width="103.5" height="10" style="fill:#eda813;" />
<rect x="204" y="0" width="103.5" height="10" style="fill:#ffda31;" />
<rect x="305" y="0" width="103.5" height="10" style="fill:#a9e09b;" />
<rect x="406" y="0" width="103.5" height="10" style="fill:#6a9ee1;" />
<rect x="507" y="0" width="103.5" height="10" style="fill:#525ec9;" />
<rect x="608" y="0" width="103.5" height="10" style="fill:#8358ca;" />
<text style="font-size:24px;font-family:'Roboto','Arial'; fill:#000;" class="text-capitalize">
<tspan x="30" y="65" class="font-bld" id="PreviewUserFirstName">JOHN </tspan>
<tspan style="font-weight:300;" id="PreviewUserLastName">CARTER</tspan>
</text>
<text style="font-size:14px; font-weight:400;font-family:'Roboto','Arial'; fill:#436975;" x="30" y="110" class="section-title">Professional Summary</text>
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="190" y="110">Successful sales professional with 10+ years </tspan>
<tspan x="190" dy="20">experience in large-scale food and retail environments.</tspan>
<tspan x="190" dy="20">Implement cost control measures to ensure operations</tspan>
<tspan x="190" dy="20">remain within company targets. Maximize bottom-line</tspan>
<tspan x="190" dy="20">performance through P&amp;L,merchandising, staff </tspan>
<tspan x="190" dy="20">management, loss control and inventory management </tspan>
<tspan x="190" dy="20">initiatives.</tspan>
</text>
<text style="font-size:14px; font-weight:400;font-family:'Roboto','Arial'; fill:#436975;" x="530" y="110" class="section-title">Contact</text>
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="530" y="135">415-123-0012</tspan>
<tspan x="530" dy="20">mCARTER@live.com</tspan>
<tspan x="530" dy="20">123 Main Street,</tspan>
<tspan x="530" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<text style="font-size:14px; font-weight:400;font-family:'Roboto','Arial'; fill:#436975;" x="530" y="245" class="section-title">Skills</text>
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="530" y="270">Executive team leadership</tspan>
<tspan x="530" dy="20">Inventory report generation</tspan>
<tspan x="530" dy="20">Client/Vendor relations</tspan>
<tspan x="530" dy="20">Market analysis</tspan>
<tspan x="530" dy="20">Sales Management</tspan>
<tspan x="530" dy="20">Staff training</tspan>
<tspan x="530" dy="20">Customer relations</tspan>
<tspan x="530" dy="20">Process Improvements</tspan>
</text>
<text style="font-size:14px; font-weight:400;font-family:'Roboto','Arial'; fill:#436975;" x="30" y="275" class="section-title">Experience</text>
<text style="font-size:12px;font-family:'Roboto','Arial';fill:#000000;letter-spacing: 0.712px;">
<tspan x="190" y="275" style="font-weight:700;">District Manager, Verizon Wireless, </tspan>
<tspan x="190" dy="20">Sep 2009 – Current, San Francisco, CA</tspan>
</text>
<circle cx="195" cy="320" r="1.3" class="li-disc" />
<circle cx="195" cy="365" r="1.3" class="li-disc" />
<circle cx="195" cy="410" r="1.3" class="li-disc" />
<circle cx="195" cy="455" r="1.3" class="li-disc" />
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="210" y="325">Directed recruitment/training/staff development</tspan>
<tspan x="210" dy="20">initiatives.</tspan>
<tspan x="210" dy="25">Successfully increased employee retention with</tspan>
<tspan x="210" dy="20">a positive work environment.</tspan>
<tspan x="210" dy="25">Administered daily operations to ensure policies</tspan>
<tspan x="210" dy="20">were adhered to by sales staff.</tspan>
<tspan x="210" dy="25">Cultivated strong business relationships with</tspan>
<tspan x="210" dy="20">customers to drive business.</tspan>
</text>
<text style="font-size:12px;font-family:'Roboto','Arial'; fill:#000000;letter-spacing: 0.712px;">
<tspan x="190" y="515" style="font-weight:700;">General Manager, Woodranch Restaurant, </tspan>
<tspan x="190" dy="20">Jan 1994 – Aug 1997, San Jose, CA</tspan>
</text>
<circle cx="195" cy="555" r="1.3" class="li-disc" />
<circle cx="195" cy="620" r="1.3" class="li-disc" />
<circle cx="195" cy="665" r="1.3" class="li-disc" />
<circle cx="195" cy="710" r="1.3" class="li-disc" />
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="210" y="560">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="210" dy="20">Developed the renovation strategy and oversaw</tspan>
<tspan x="210" dy="20">the $110,000 store remodel.</tspan>
<tspan x="210" dy="25">Directed departmental alignment on strategies to</tspan>
<tspan x="210" dy="20">create strong sales.</tspan>
<tspan x="210" dy="25">Cultivated strong franchise owner relationships</tspan>
<tspan x="210" dy="20">to achieve high standards.</tspan>
<tspan x="210" dy="25">Implemented process improvements to increase</tspan>
<tspan x="210" dy="20">guest loyalty.</tspan>
</text>
<text style="font-size:14px; font-weight:400;font-family:'Roboto','Arial'; fill:#436975;" x="30" y="785" class="section-title">Education</text>
<text style="font-size:12px;font-family:'Roboto','Arial';font-weight:400; fill:#000000;">
<tspan x="190" y="785">San Francisco State University, San Francisco, CA</tspan>
<tspan x="190" dy="25">Master of Arts: Operations Management</tspan>
</text>
<text style="font-size:12px;font-family:'Roboto','Arial'; font-weight:400;fill:#000000;">
<tspan x="190" y="845">University of San Francisco, San Francisco, CA</tspan>
<tspan x="190" dy="25">Bachelor of Arts: Business Management</tspan>
</text>
<rect x="0" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#8358ca;" />
<rect x="102" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#525ec9;" />
<rect x="204" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#6a9ee1;" />
<rect x="305" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#a9e09b;" />
<rect x="406" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#ffda31;" />
<rect x="507" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#eda813;" />
<rect x="608" y="1014" width="103.5" height="10" class="bottom-ribbon" style="fill:#d6407a;" />
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR3" data-skin-cd="MLR3" data-skin-name="Greetings" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<path id="lowerhalf" d="M568,-142 a22,27 0 0,0 87,0" />
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=DM+Serif+Display:400');
        .font-bld{font-weight:700;}     
        .li-disc {fill:#000;}     
        .top-bdr{fill:#000; }
        .top-bdr-black{fill:transparent; stroke-width:1px;stroke:#d0d0d0;}
        .top-bdr-white{fill:white; }     
        .line{stroke-width:1px;stroke:#d0d0d0;}    
      </style>
</defs>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="173">
<path fill="#305fec" class="svg-section-bg" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="204">
<path fill="#305fec" class="svg-section-bg" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg width="14" height="14" viewBox="0 0 24 24" x="462" y="233">
<path fill="#305fec" class="svg-section-bg" d="M12 0c-4.198 0-8 3.403-8 7.602 0 4.198 3.469 9.21 8 16.398 4.531-7.188 8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z" />
</svg>
<text style="font-size:34px;font-weight:400; -webkit-font-smoothing:antialiased; font-family:'DM Serif Display','Arial'; fill:#000;">
<tspan x="48" y="60">Hi, I'm</tspan>
<tspan x="153" y="60" id="PreviewUserFirstName" class="text-capitalize">JOHN</tspan>
<tspan x="276" y="60" id="PreviewUserLastName" class="text-capitalize">CARTER</tspan>.
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="120" class="section-title">Professional Summary</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="48" y="145">Successful sales professional with 10+ years experience in </tspan>
<tspan x="48" dy="20">large-scale food and retail environments. Implement cost </tspan>
<tspan x="48" dy="20">control measures to ensure operations remain within </tspan>
<tspan x="48" dy="20">company targets. Maximize bottom-line performance </tspan>
<tspan x="48" dy="20">through P&amp;L, merchandising, staff management, loss </tspan>
<tspan x="48" dy="20">control and inventory management initiatives.</tspan>
</text>
<rect x="447" y="120" width="210" height="180" class="top-bdr-black" />

<g transform="translate(555,35)"><g><g transform="rotate(-330 18.5 34.5)"><path fill="#305fec" class="svg-name" d="M19.28 37.191l-4.75-2.086-.053-1.131 4.54-2.501-5.35.246-.087-1.898 8.5-.391.117 2.567-4.568 2.405 4.77 1.988.117 2.554-8.5.391-.087-1.898z" /></g><g transform="rotate(-330 15 41.5)"><path fill="#305fec" class="svg-name" d="M19.008 39.83l.483 1.837-8.228 2.167-.483-1.838z" /></g><g transform="rotate(-330 49 61.5)"><g><path fill="#305fec" class="svg-name" d="M8.775 68.504c.392.847 1.048 1.384 1.967 1.612l-.627 1.632c-1.393-.42-2.364-1.225-2.914-2.415-.55-1.19-.628-2.344-.234-3.462.396-1.118 1.166-1.941 2.311-2.472 1.145-.53 2.282-.58 3.411-.15 1.129.43 1.956 1.213 2.48 2.347.587 1.268.595 2.552.026 3.854l-1.711-.51c.425-.859.45-1.694.076-2.504-.3-.649-.769-1.105-1.405-1.37-.637-.264-1.314-.23-2.032.102-.718.333-1.194.817-1.427 1.453a2.372 2.372 0 0 0 .08 1.883" /></g><g><path fill="#305fec" class="svg-name" d="M20.188 73.522L21.382 75l-6.62 5.35-1.192-1.478 2.603-2.105-2.126-2.634-2.604 2.105-1.193-1.478 6.619-5.35 1.193 1.478-2.765 2.235 2.126 2.634z" /></g><g><path fill="#305fec" class="svg-name" d="M22.082 86.356l.471-1.946-2.851-2.143-1.736.995-1.616-1.215 8.05-4.597 1.47 1.105-2.173 9.015zm1.537-6.325l-2.341 1.333 1.703 1.28z" /></g><g><path fill="#305fec" class="svg-name" d="M34.747 83.207l-.68 1.55-3.878-1.703-.705 1.606 3.489 1.532-.65 1.483-3.49-1.532-.709 1.617 4.002 1.757-.675 1.54-5.741-2.521 3.42-7.796z" /></g><g><path fill="#305fec" class="svg-name" d="M34.12 91.816l1.777-8.326 1.857.397-1.424 6.67 3.548.758-.354 1.656z" /></g><g><path fill="#305fec" class="svg-name" d="M48.104 89.612l.834-5.055 1.966-.268 2.145 4.649 1.015-5.08 2.038-.278-1.793 8.837-1.399.19-2.645-5.613-1.034 6.115-1.399.191-4.092-8.034 2.038-.278z" /></g><g><path fill="#305fec" class="svg-name" d="M56.26 82.938l1.778-.668 2.99 7.97-1.778.668z" /></g><g><path fill="#305fec" class="svg-name" d="M63.675 89.134l-4.135-7.44 1.66-.924 3.312 5.96 3.17-1.763.823 1.48z" /></g><g><path fill="#305fec" class="svg-name" d="M70.435 85.038l-5.445-6.542 1.46-1.216 4.362 5.24 2.787-2.322 1.083 1.3z" /></g><g><path fill="#305fec" class="svg-name" d="M69.79 74.206l1.266-1.416 6.343 5.674-1.266 1.417z" /></g><g><path fill="#305fec" class="svg-name" d="M82.564 71.017l-1.98-.294-1.874 3.036 1.147 1.64-1.062 1.72-5.305-7.605.966-1.564 9.17 1.347zm-6.434-.958l1.539 2.211 1.12-1.813z" /></g><g><path fill="#305fec" class="svg-name" d="M81.552 58.217l3.862 3.466-.304 1.09-5.093.958 5.159 1.438-.51 1.83-8.196-2.284.689-2.476 5.091-.856-3.912-3.38.686-2.463 8.197 2.285-.51 1.83z" /></g><g><path fill="#305fec" class="svg-name" d="M80.66 52.159c.147.185.344.28.592.284.248.003.446-.105.596-.326.15-.22.33-.733.542-1.538.212-.804.52-1.427.925-1.867.405-.44.989-.654 1.751-.642.763.013 1.377.31 1.842.89.466.58.691 1.336.676 2.27-.022 1.348-.54 2.553-1.556 3.617l-1.37-1.155c.819-.905 1.234-1.747 1.247-2.526.006-.35-.065-.624-.212-.826a.723.723 0 0 0-.604-.308.71.71 0 0 0-.614.307c-.153.209-.312.624-.476 1.247-.251.987-.57 1.706-.954 2.159-.385.452-.98.672-1.789.659-.806-.013-1.425-.314-1.854-.901-.428-.588-.635-1.316-.621-2.185a5.221 5.221 0 0 1 .32-1.7 4.573 4.573 0 0 1 .851-1.472l1.372.984c-.572.73-.864 1.489-.877 2.276-.005.317.066.568.213.753" /></g><g><path fill="#305fec" class="svg-name hide-initials" style="font-size:40px; font-family:'Source Sans Pro',sans-serif,Arial;" d="M54.86 44.058l-7.793 15.41h-3.834l-7.751-15.41v17.75H29.05V33.61h8.7L45.17 49.1l7.463-15.49h8.658v28.197H54.86z" /></g></g></g><g><path fill="none" stroke="#305fec" class="svg-stroke-full" stroke-miterlimit="20" stroke-width="2.5" d="M51.19 102.69c27.338 0 49.5-22.61 49.5-50.5s-22.162-50.5-49.5-50.5-49.5 22.61-49.5 50.5 22.162 50.5 49.5 50.5z" /></g></g>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="150" class="section-title">Contact</text>
<line x1="462" y1="165" x2="637" y2="165" class="line" />
<line x1="462" y1="195" x2="637" y2="195" class="line" />
<line x1="462" y1="225" x2="637" y2="225" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="482" y="185">415-123-0012</tspan>
<tspan x="482" dy="28">mCARTER@live.com</tspan>
<tspan x="482" dy="32">123 Main Street,</tspan>
<tspan x="482" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<rect x="447" y="335" width="210" height="270" class="top-bdr-black" />
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="363" class="section-title">Skills</text>
<circle cx="462" cy="385" r="1.3" class="li-disc" />
<circle cx="462" cy="410" r="1.3" class="li-disc" />
<circle cx="462" cy="435" r="1.3" class="li-disc" />
<circle cx="462" cy="460" r="1.3" class="li-disc" />
<circle cx="462" cy="485" r="1.3" class="li-disc" />
<circle cx="462" cy="510" r="1.3" class="li-disc" />
<circle cx="462" cy="535" r="1.3" class="li-disc" />
<circle cx="462" cy="560" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="472" y="390">Executive team leadership</tspan>
<tspan x="472" dy="25">Inventory report generation</tspan>
<tspan x="472" dy="25">Client/Vendor relations</tspan>
<tspan x="472" dy="25">Market analysis</tspan>
<tspan x="472" dy="25">Sales Management</tspan>
<tspan x="472" dy="25">Staff training</tspan>
<tspan x="472" dy="25">Customer relations</tspan>
<tspan x="472" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="285" class="section-title">Experience</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="305" r="4" class="svg-stroke-full" />
<line x1="51" y1="310" x2="51" y2="495" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="310"><tspan style="font-weight:700;">District Manager </tspan> <tspan style="font-style:italic;"> Sep 2009 – Current</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="330">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="68" cy="350" r="1.3" class="li-disc" />
<circle cx="68" cy="370" r="1.3" class="li-disc" />
<circle cx="68" cy="410" r="1.3" class="li-disc" />
<circle cx="68" cy="450" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="355">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="76" dy="20">Successfully increased employee retention with a </tspan>
<tspan x="76" dy="20">positive work environment.</tspan>
<tspan x="76" dy="20">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="20">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="500" r="4" class="svg-stroke-full" />
<line x1="51" y1="505" x2="51" y2="740" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="505"><tspan style="font-weight:700;">General Manager </tspan> <tspan style="font-style:italic;"> Jan 1994 – Aug 1997</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="525">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="550" r="1.3" class="li-disc" />
<circle cx="68" cy="570" r="1.3" class="li-disc" />
<circle cx="68" cy="610" r="1.3" class="li-disc" />
<circle cx="68" cy="650" r="1.3" class="li-disc" />
<circle cx="68" cy="690" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="555">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="76" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="76" dy="20">$110,000 store remodel.</tspan>
<tspan x="76" dy="20">Directed departmental alignment on strategies to create</tspan>
<tspan x="76" dy="20">strong sales.</tspan>
<tspan x="76" dy="20">Cultivated strong franchise owner relationships to </tspan>
<tspan x="76" dy="20">achieve high standards.</tspan>
<tspan x="76" dy="20">Implemented process improvements to increase guest</tspan>
<tspan x="76" dy="20">loyalty.</tspan></text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="745" r="4" class="svg-stroke-full" />
<line x1="51" y1="750" x2="51" y2="870" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="68" y="750"><tspan style="font-weight:700;">Senior Executive </tspan> <tspan style="font-style:italic;"> Aug 1993 – Jan 1994</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="68" y="770">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="795" r="1.5" style="fill:#333333" />
<circle cx="68" cy="840" r="1.5" style="fill:#333333" />
<text style="fill:#333333;font-family:'Source Sans Pro',sans-serif,Arial;font-size:14px">
<tspan x="76" y="800">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="25">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="900" class="section-title">Education</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="925" r="4" class="svg-stroke-full" />
<line x1="51" y1="930" x2="51" y2="975" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;font-weight:400; fill:#000000;">
<tspan x="76" y="930" class="font-bld">Master of Arts, Operations Management</tspan>
<tspan x="76" dy="20" style="font-style:italic;">Jun 2011</tspan>
<tspan x="76" dy="20" style="font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR5" data-skin-cd="MLR5" data-skin-name="Revival" data-skin-viewed="false" data-skin-pos="7" class="template-card change-color alltemplate">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Merriweather:300,400,700');
        .font-bld{font-weight:700;}
        .h1{font-size:45px; font-weight:600;}
        .h2{font-size:18px; font-weight:500;}
        .li-disc {fill:#808080;} 
        .li-white-disc {fill:#fff;}    
        .left-bg{fill:#0E9FC1;}            
        .section-bg{fill:#007D9E;}  
      </style>
</defs>
<rect x="0" y="0" width="245" height="1024" style="fill:#0E9FC1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Merriweather';fill:#fff;font-weight:700">
<tspan x="18" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="18" y="75" id="PreviewUserLastName">CARTER</tspan>
</text>
<svg x="18" y="98" width="9" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="18" y="129" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="18" y="160" width="9" height="9" viewBox="0 0 8 8">
<path fill="#fff" d="M5.71 4.754a2.913 2.913 0 0 1-1.877.696c-.69 0-1.318-.249-1.82-.648C.815 5.062.32 5.842.26 7.483h7.247c-.045-1.857-.47-2.548-1.797-2.729z" />
<path fill="#fff" d="M2.625 4.356c.281.185.609.298.959.338.083.01.163.025.248.025.085 0 .165-.016.247-.025a2.19 2.19 0 0 0 .984-.352c.142-.096.268-.212.384-.338.365-.394.593-.917.593-1.495A2.213 2.213 0 0 0 3.832.3c-1.219 0-2.21.992-2.21 2.21 0 .583.232 1.112.603 1.507.12.128.253.243.4.34z" />
</svg>
<text style="font-size:13px;font-family:'Merriweather';fill:#fff;font-weight:bold;">
<tspan x="35" y="107">415-123-0012</tspan>
<tspan x="35" dy="30">mCARTER@address.com</tspan>
<tspan x="35" dy="30">123 Main Street,</tspan>
<tspan x="35" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<rect x="0" y="225" width="245" height="28" class=" section-bg svg-heading-bg" />
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#fff;text-transform:uppercase;letter-spacing: 2.8px;" x="15" y="245">SKILLS</text>
<circle cx="17" cy="279" r="2" class="li-white-disc" />
<circle cx="17" cy="306" r="2" class="li-white-disc" />
<circle cx="17" cy="330" r="2" class="li-white-disc" />
<circle cx="17" cy="355" r="2" class="li-white-disc" />
<circle cx="17" cy="380" r="2" class="li-white-disc" />
<circle cx="17" cy="405" r="2" class="li-white-disc" />
<circle cx="17" cy="430" r="2" class="li-white-disc" />
<circle cx="17" cy="455" r="2" class="li-white-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:400;fill:#fff;">
<tspan x="25" y="285">Executive team leadership</tspan>
<tspan x="25" dy="25">Sales Management</tspan>
<tspan x="25" dy="25">Inventory report generation</tspan>
<tspan x="25" dy="25">Staff training and development</tspan>
<tspan x="25" dy="25">Client/Vendor relation</tspan>
<tspan x="25" dy="25">Customer relations</tspan>
<tspan x="25" dy="25">Market analysis</tspan>
<tspan x="25" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.4px;" x="260" y="29" class="svg-heading-color">professional Summary</text>
<text style="font-size:13px;fill:#808080;font-family:'Merriweather';font-weight:300;">
<tspan x="260" y="55">Successful sales professional with 10+ years experience in </tspan>
<tspan x="260" dy="25">large-scale food and retail environments. Implement cost</tspan>
<tspan x="260" dy="25">control measures to ensure operations remain within </tspan>
<tspan x="260" dy="25">company targets. Maximize bottom-line performance</tspan>
<tspan x="260" dy="25">through P &amp; L, merchanding, staff management, loss control </tspan>
<tspan x="260" dy="25">and inventory management initiatives.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="230" class="svg-heading-color">Experience</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="260" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">District Manager</tspan>
<tspan x="260" dy="25">Verizon Wireless</tspan>
<tspan x="260" dy="25">September 2009 - Current</tspan>
</text>
<circle cx="270" cy="335" r="2" class="li-disc" />
<circle cx="270" cy="360" r="2" class="li-disc" />
<circle cx="270" cy="410" r="2" class="li-disc" />
<circle cx="270" cy="460" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="340">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="285" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="285" dy="25">work environment.</tspan>
<tspan x="285" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="285" dy="25">adhered to by sales staff.</tspan>
<tspan x="285" dy="25">Cultivated strong business relationships with customers to </tspan>
<tspan x="285" dy="25">drive business.</tspan>
</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="520" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">General Manager</tspan>
<tspan x="260" dy="25">Woodranch Restaurant</tspan>
<tspan x="260" dy="25">August 2015 - October 2017</tspan>
</text>
<circle cx="270" cy="590" r="2" class="li-disc" />
<circle cx="270" cy="615" r="2" class="li-disc" />
<circle cx="270" cy="665" r="2" class="li-disc" />
<circle cx="270" cy="715" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="595">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="285" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="285" dy="25">$110,000 store remodel.</tspan>
<tspan x="285" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="285" dy="25">strong sales.</tspan>
<tspan x="285" dy="25">Cultivated strong franchise owner relationships to achieve </tspan>
<tspan x="285" dy="25">high standards.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="800" class="svg-heading-color">Education</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="830" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">Master of Arts: Operations Management</tspan>
<tspan x="260" dy="25">San Francisco State University </tspan>
<tspan x="260" dy="25">San Francisco, CA </tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR2" data-skin-cd="MLR2" data-skin-name="Hollywood" data-skin-viewed="false" data-skin-pos="8" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<path fill="none" stroke="#979797" stroke-linecap="square" stroke-miterlimit="50" d="M227.5 150v840" />
<text x="50%" y="80" text-anchor="middle" style="font-size:66px; font-weight:700;font-family:'Source Sans Pro', 'Arial'; fill:#436975;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text text-anchor="end" style="font-size:16px; font-weight:700;fill:#436975;font-family:'Source Sans Pro', 'Arial'; letter-spacing: 0.96px;" class="section-title">
<tspan x="200" y="160">CONTACT</tspan>
</text>
<text text-anchor="end" style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="205" y="190">415-123-0012</tspan>
<tspan x="205" dy="20">mCARTER@address.com</tspan>
<tspan x="205" dy="20">123 Main Street,</tspan>
<tspan x="202" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<text text-anchor="end" style="font-size:16px; font-weight:700;fill:#436975;font-family:'Source Sans Pro', 'Arial'; letter-spacing: 0.96px;" class="section-title">
<tspan x="205" y="295">SKILLS</tspan>
</text>
<text text-anchor="end" style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="205" y="325">Executive team leadership</tspan>
<tspan x="205" dy="20">Client/Vendor relations</tspan>
<tspan x="205" dy="20">Market analysis</tspan>
<tspan x="205" dy="20">Sales Management</tspan>
<tspan x="205" dy="20">Staff training</tspan>
<tspan x="205" dy="20">Customer relations</tspan>
<tspan x="202" dy="20">Process improvements</tspan>
</text>
<text text-anchor="end" style="font-size:16px; font-weight:700;fill:#436975;font-family:'Source Sans Pro', 'Arial'; letter-spacing: 0.96px;" class="section-title">
<tspan x="205" y="490">EDUCATION</tspan>
</text>
<text text-anchor="end" style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="205" y="520">San Francisco State University</tspan>
<tspan x="205" dy="20">Master of Arts</tspan>
<tspan x="205" dy="20">Operations Managements</tspan>
<tspan x="202" dy="20">San Francisco, CA</tspan>
</text>
<text text-anchor="end" style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="205" y="615">University of San Francisco</tspan>
<tspan x="205" dy="20">Bachelor of Arts</tspan>
<tspan x="205" dy="20">Business Management</tspan>
<tspan x="202" dy="20">San Francisco, CA</tspan>
</text>
<text style="font-size:16px; font-weight:700;fill:#436975;font-family:'Source Sans Pro', 'Arial'; letter-spacing: 0.96px;" class="section-title">
<tspan x="255" y="160">PROFESSIONAL SUMMARY</tspan>
</text>
<text style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="255" y="190">Successful sales professional with 10+ years experience in large-</tspan>
<tspan x="255" dy="20">scale food and retail environments. Implement cost control measures </tspan>
<tspan x="255" dy="20">to ensure operations remain within company targets. Maximize </tspan>
<tspan x="255" dy="20">bottom- line performance through P &amp; L, merchanding, staff </tspan>
<tspan x="255" dy="20">management, loss control and inventory management initiatives.</tspan>
</text>
<text style="font-size:16px; font-weight:700;fill:#436975;font-family:'Source Sans Pro', 'Arial'; letter-spacing: 0.96px;" class="section-title">
<tspan x="255" y="315">EXPERIENCE</tspan>
</text>
<text style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="255" y="345" style="font-weight:700;">Verizon Wireless, District Manager</tspan>
<tspan x="255" dy="20">San Francisco, CA - Sep 2009 - Current</tspan>
</text>
<circle cx="260" cy="385" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="410" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="460" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="510" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Source Sans Pro','Arial';font-size:14px">
<tspan x="280" y="390">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="280" dy="25">Successfully increased employee retention with a positive work</tspan>
<tspan x="280" dy="20">environment.</tspan>
<tspan x="280" dy="25">Administered daily operations to ensure policies were adhered</tspan>
<tspan x="280" dy="20">to by sales staff.</tspan>
<tspan x="280" dy="25">Cultivated strong business relationships with customers to drive</tspan>
<tspan x="280" dy="20">business.</tspan>
</text>
<text style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="255" y="550" style="font-weight:700;">Woodranch Restaurant, General Manager</tspan>
<tspan x="255" dy="20">San Jose, CA, Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="260" cy="595" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="620" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="666" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="710" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Source Sans Pro','Arial';font-size:14px">
<tspan x="280" y="600">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="280" dy="25">Developed the renovation strategy and oversaw the $110,000</tspan>
<tspan x="280" dy="20">store remodel.</tspan>
<tspan x="280" dy="25">Directed departmental alignment on strategies to create .</tspan>
<tspan x="280" dy="20">strong sales.</tspan>
<tspan x="280" dy="25">Cultivated strong franchise owner relationships to achieve</tspan>
<tspan x="280" dy="20">high standards.</tspan>
</text>
<text style="font-size:14px;fill:#333;font-family:'Source Sans Pro', 'Arial'">
<tspan x="255" y="760" style="font-weight:700;">Woodranch Restaurant, Senior Executive</tspan>
<tspan x="255" dy="20">San Jose, CA, Aug 1993 – Jan 1994</tspan>
</text>
<circle cx="260" cy="800" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="845" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="890" r="1.5" style="fill:#333333"></circle>
<circle cx="260" cy="935" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Source Sans Pro','Arial';font-size:14px">
<tspan x="280" y="805">Administered daily operations to ensure policies were</tspan>
<tspan x="280" dy="20">adhered to by sales staff.</tspan>
<tspan x="280" dy="25">Cultivated strong business relationships with customers</tspan>
<tspan x="280" dy="20">to drive business.</tspan>
<tspan x="280" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="280" dy="20">strong sales.</tspan>
<tspan x="280" dy="25">Developed the renovation strategy and oversaw the $110,000</tspan>
<tspan x="280" dy="20">store remodel.</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="CLS1" data-skin-cd="CLS1" data-skin-name="Angora" data-skin-viewed="false" data-skin-pos="9" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;fill:#000000;font-family: 'Georgia','Arial'" class="svg-name">
<tspan x="5" y="32" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="175" y="32" id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="53" x2="705" y2="53" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="1" y="78">123 Main Street,</tspan>
<tspan dx="1" y="78">SanFrancisco, CA 94122</tspan>
<tspan x="1" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="1" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="175">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="190" x2="705" y2="190" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="0" y="220">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="30">Implement cost control measures to ensure operations remain within company targets.Maximize </tspan>
<tspan x="0" dy="27">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="27">inventory management initiatives.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="360">Skills</tspan>
</text>
<line x1="0" y1="373" x2="705" y2="373" style="stroke:#000; stroke-width:2" />
<circle cx="5" cy="394" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="455" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="40" y="400">Executive team leadership</tspan>
<tspan x="40" dy="28">Inventory report generation</tspan>
<tspan x="40" dy="28">Client/Vendor relations</tspan>
<tspan x="40" dy="28">Market analysis</tspan>
</text>
<circle cx="275" cy="395" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="450" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="307" y="400">Sales Management</tspan>
<tspan x="307" dy="28">Staff training</tspan>
<tspan x="307" dy="28">Customer relations</tspan>
<tspan x="307" dy="28">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="532">Experience</tspan>
</text>
<line x1="0" y1="550" x2="705" y2="550" style="stroke:#000000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="575">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="680" y="575">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="605">Verizon Wireless -</tspan>
<tspan dx="1" y="605">San Francisco, CA</tspan>
</text>
<circle cx="5" cy="630" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="660" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="688" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="715" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="40" y="633">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="40" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="40" dy="30">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="765">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="765">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="790">Woodranch Restaurant -</tspan>
<tspan dx="1" y="790">San Jose, CA</tspan>
</text>
<circle cx="5" cy="815" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="850" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="878" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="905" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="38" y="822">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="950">Education</tspan>
</text>
<line x1="0" y1="965" x2="705" y2="965" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="990">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="990">Mar 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="1015">San Francisco State University -</tspan>
<tspan dx="1" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="UPT1" data-skin-cd="UPT1" data-skin-name="Empire" data-skin-viewed="false" data-skin-pos="10" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="100%" y="30" text-anchor="end" style="font-size:38px; font-weight:700;font-family:'Century Gothic','Arial'">
<tspan id="PreviewUserFirstName" class="text-upper">JOHN</tspan>
<tspan style="fill:#436975;" class="svg-last-name svg-name" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="0" y="50" style="fill:#436975;" height="30" width="100%" class="svg-section-bg" />
<text text-anchor="end" style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial';fill:#fff;text-align:center;width:100%">
<tspan x="99%" y="70">123 Main Street, SanFrancisco, CA 94122 | 508-278-2542 | 781-669-5989 | mCARTER@live.com </tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="138">Professional Summary</tspan>
</text>
<line x1="0" y1="147" x2="100%" y2="147" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="175">Accomplished operations executive with a successful track record overseeing marketing, IT, HR/training</tspan>
<tspan x="0" dy="30">and real estate in company and franchise operations for a large regional chain.</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="260">Skills</tspan>
</text>
<line x1="0" y1="270" x2="100%" y2="270" style="stroke:#333; stroke-width:1" />
<circle cx="25" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="335" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="365" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="397" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="40" y="310">Executive Team Leadership</tspan>
<tspan x="40" dy="29">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="40" dy="33">Expertise in New England Real Estate</tspan>
<tspan x="40" dy="33">Client/Vendor Relations</tspan>
</text>
<circle cx="373" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="333" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="400" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="388" y="310">Marketing/Product Line Development</tspan>
<tspan x="388" dy="30">Staff/Training Development Policy</tspan>
<tspan x="388" dy="30">Development</tspan>
<tspan x="388" dy="34">Process Improvement</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="460">Experience</tspan>
</text>
<line x1="0" y1="470" x2="100%" y2="470" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="507" style="font-weight:600;">District Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Verizon Wireless</tspan>
<tspan dx="5">- San Francisco, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="510" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="570" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="599" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="630" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="575">Directed recruitment/training/staff development initiatives to maximize productivity</tspan>
<tspan x="40" dy="30">Successfully increased employee retention by created a positive work environment in 18 stores.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to.</tspan>
</text>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="680" style="font-weight:600;">General Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Woodranch Restaurant</tspan>
<tspan dx="5">- San Jose, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="688" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="745" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="805" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="867" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="750">Successfully managed a team of 18 direct reports and reduced store turnover by 80% from</tspan>
<tspan x="40" dy="30">previous management.</tspan>
<tspan x="40" dy="30">Developed the renovation strategy and oversaw the $110,000 store remodel while open for</tspan>
<tspan x="40" dy="30"> business.</tspan>
<tspan x="40" dy="33">Directed departmental alignment on strategies to create strong.</tspan>
</text>
<text style="fill:#436975;font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" x="0" y="920" class="section-title">Education</text>
<line x1="0" y1="930" x2="100%" y2="930" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="955" style="font-weight:600;">Bachelor of Arts:</tspan>
<tspan x="0" dy="30">
<tspan style="font-weight:600">San Francisco State University </tspan>– San Francisco, CA
</tspan>
<tspan dx="5">Business Management</tspan>
<tspan x="0" dy="30">Coursework includes: Speech and Communication, Sociology and Psychology</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="680" y="965">Mar 1991</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="COL1" data-skin-cd="COL1" data-skin-name="Providence" data-skin-viewed="false" data-skin-pos="11" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="32" text-anchor="middle" style="font-size:38px; font-weight:600; font-family:'Georgia','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="162">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="0" y="193">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management,loss control and inventory management initiative.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="305">Skills</tspan>
</text>
<circle cx="15" cy="330" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="30" y="335">Executive team leadership</tspan>
<tspan x="30" dy="27">Inventory report generation</tspan>
<tspan x="30" dy="27">Client/Vendor relations</tspan>
<tspan x="30" dy="25">Market analysis</tspan>
</text>
<circle cx="258" cy="327" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="275" y="335">Sales Management</tspan>
<tspan x="275" dy="27">Staff training</tspan>
<tspan x="275" dy="27">Customer relations</tspan>
<tspan x="275" dy="25">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="470">Experience</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="498">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="498">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="520">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="520">San Francisco, CA</tspan>
</text>
<circle cx="12" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="576" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="603" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="630" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="28" y="553">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="28" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="28" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="28" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="678">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="678">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="700">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="700">San Jose, CA</tspan>
</text>
<circle cx="12" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="810" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="27" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="27" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="27" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="27" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="27" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="900">Education</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">Jul 2008</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="BOL1" data-skin-cd="BOL1" data-skin-name="Gazelle" data-skin-viewed="false" data-skin-pos="12" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:50px; font-weight:400;font-family:'Verdana','Arial';fill:#0E9FC1" class="svg-name">
<tspan x="0" y="60" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="250" y="60" id="PreviewUserLastName">CARTER</tspan>
</text>
<path d="M 0 75 L 280 75" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:12px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="0" y="100">123 Main Street, SanFrancisco, CA 94122 | 508-278-2542 | 781-669-5989 | mCARTER@live.com</tspan>
</text>
<text style="font-size:21px; font-weight:500;fill:#0E9FC1 ;font-family:'Verdana','Arial';" x="0" y="150" class="section-title">PROFESSIONAL SUMMARY</text>
<path d="M 0 160 L 280 160" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333" x="25">
<tspan x="0" y="185">Successful sales professional with 10+ years experience in large-scale food and retail</tspan>
<tspan x="0" dy="23">environments. Implement cost control measures to ensure operations remain within</tspan>
<tspan x="0" dy="23">company targets. Maximize bottom-line performance through P&amp;L, merchandising, loss</tspan>
<tspan x="0" dy="23">control and inventory management initiatives.</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="300" class="section-title">SKILLS</text>
<path d="M 0 310 L 280 310" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<circle cx="5" cy="332" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="354" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="400" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="422" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="444" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="20" y="335">Customer relations</tspan>
<tspan x="20" y="359">Inventory report generation</tspan>
<tspan x="20" y="383">Executive team leadership</tspan>
<tspan x="20" y="406">Inventory report generation</tspan>
<tspan x="20" y="428">Client/Vendor relations</tspan>
<tspan x="20" y="450">Market analysis</tspan>
</text>
<circle cx="236" cy="332" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="354" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="400" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="425" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="443" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="254" y="335">Market analysis</tspan>
<tspan x="254" y="359">Staff training</tspan>
<tspan x="254" y="385">Sales Management</tspan>
<tspan x="254" y="405">Staff training</tspan>
<tspan x="254" y="430">Customer relations</tspan>
<tspan x="254" y="450">Process improvements</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="505" class="section-title">EXPERIENCE</text>
<path d="M 0 518 L 280 518" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text x="0" y="545" style="font-size:14px;font-family:'Verdana','Arial';fill:#333;">AUGUST 2011-PRESENT</text>
<text x="0" y="565" style="font-style:italic;font-family:'Verdana','Arial';fill:#333333;font-weight:500; font-size: 14px;">District Manager | Verizon Wireless | San Francisco, CA</text>
<circle cx="4" cy="585" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="625" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="650" r="1.5" class="li-disc"></circle>
<text style="font-family:'Verdana','Arial';fill:#333333;font-size:14px;">
<tspan x="18" y="588">
Directed recruitment/training/staff development initiatives
development initiatives.
</tspan>
<tspan x="18" dy="22">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="18" dy="22">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="18" dy="22">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text x="0" y="690" style="font-size:14px;font-family:'Verdana','Arial';fill:#333333 ;">AUGUST 2009-2011</text>
<text x="0" y="710" style="font-style:italic;font-family:'Verdana','Arial';fill:#333333;font-weight:500; font-size: 14px;">District Manager | Verizon Wireless | San Francisco, CA</text>
<circle cx="4" cy="732" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="775" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="795" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333;">
<tspan x="18" y="735">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="18" dy="22">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="18" dy="22">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="18" dy="22">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="860" class="section-title">EDUCATION</text>
<path d="M 0 875 L 280 875" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333;" x="0" y="897">2011</text>
<text style="font-family:'Verdana','Arial';fill:#333333;">
<tspan x="0" y="920" style="font-size:14px; font-weight:500; font-style:italic;">Bachelor of Arts</tspan>
<tspan style="font-size:14px;" x="0" dy="24">San Francisco State University, San Francisco, CA</tspan>
</text>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333 ;" x="0" y="975">2008</text>
<text style="font-family:'Arial';fill:#333333;">
<tspan x="0" y="995" style="font-size:14px; font-weight:500; font-style:italic;">High School Diploma</tspan>
<tspan style="font-size:14px;" x="0" dy="24">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="CBG2" data-skin-cd="CBG2" data-skin-name="Splendid" data-skin-viewed="false" data-skin-pos="13" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style>
      .h1{font-size:45px; font-weight:600;}
      .h2{font-size:18px; font-weight:500;}
      .li-disc {fill:#333333;}
    </style>
</defs>
<line x1="0" y1="0" x2="100%" y2="0" style="stroke:#939598; stroke-width:2" />
<text x="50%" y="40" text-anchor="middle" style="font-size:45px; font-weight:700;font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-variant: small-caps;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="55" x2="100%" y2="55" style="stroke:#939598; stroke-width:1" />
<path d="M 0 60 L 720 60" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-size:15px; font-family:'Palatino Linotype', 'Arial';fill:#333333;">
<tspan x="60" y="95">123 Main Street, SanFrancisco, CA 94122 ■ 781-669-5989 ■ mCARTER@live.com</tspan>
</text>
<path d="M 0 135 L 240 135" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px; font-weight:700;" class="section-title">
<tspan x="260" y="140">Professional Summary</tspan>
</text>
<path d="M 500 135 L 710 135" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="172">
Accomplished operations executive with a successful track record overseeing marketing, IT,
</tspan>
<tspan x="0" dy="35">HR/training, and real estate in company and franchise operations for a large regional chain.</tspan>
</text>
<path d="M 0 257 L 295 257" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="330" y="262">Skills</tspan>
</text>
<path d="M 410 257 L 700 257" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<circle cx="7" cy="295" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="328" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="358" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="388" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="300">Executive Team Leadership</tspan>
<tspan x="20" dy="30">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="20" dy="33">Expertise in New England Real Estate</tspan>
<tspan x="20" dy="33">Client/Vendor Relations</tspan>
</text>
<circle cx="363" cy="290" r="1.5" class="li-disc"></circle>
<circle cx="363" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="363" cy="390" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="378" y="298">Marketing/Product Line Development</tspan>
<tspan x="378" dy="33">Staff/Training Development Policy</tspan>
<tspan x="378" dy="33">Development</tspan>
<tspan x="378" dy="33">Process Improvement</tspan>
</text>
<path d="M 0 452 L 290 452" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="310" y="455">Experience</tspan>
</text>
<text style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="490" style="font-weight:700;">Executive Vice President, </tspan>
<tspan dx="2" y="490">09/2011 to 03/2013</tspan>
<tspan x="0" dy="30" style="font-weight:700;">Verizon Wireless –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<path d="M 430 452 L 710 452" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<circle cx="7" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="615" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="555">Led all operations involved with running the brand including marketing, IT, HR/training,</tspan>
<tspan x="20" dy="33">development/construction, real estate, and P&amp;L for 200 store locations.</tspan>
<tspan x="20" dy="33">Oversaw operations for all company and franchise locations.</tspan>
</text>
<text style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="665" style="font-weight:700;">Executive Vice President,</tspan>
<tspan dx="2" y="665">09/2011 to 03/2013</tspan>
<tspan x="0" dy="35" style="font-weight:700;">Verizon Wireless -</tspan>
<tspan dx="2" dy="0"> San Francisco, CA</tspan>
</text>
<circle cx="7" cy="730" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="790" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="735">Led all operations involved with running the brand including marketing, IT, HR/training,</tspan>
<tspan x="20" dy="33">development/construction, real estate, and P&amp;L for 200 store locations.</tspan>
<tspan x="20" dy="33">Oversaw operations for all company and franchise locations.</tspan>
</text>
<path d="M 0 862 L 290 862" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="320" y="868">Education</tspan>
</text>
<text class="fnt-weight" style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="900" style="font-weight:700;">
Associate of Science :
</tspan>
<tspan dx="2" y="900">
Mar 2013
</tspan>
<tspan x="0" dy="35" style="font-weight:700;">San Francisco State University –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<text class="fnt-weight" style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="980" style="font-weight:700;">
Associate of Science :
</tspan>
<tspan dx="2" y="980">
Jun 2011
</tspan>
<tspan x="0" dy="35" style="font-weight:700;">San Francisco State University –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<path d="M 430 862 L 710 862" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="HRT2" data-skin-cd="HRT2" data-skin-name="Akimbo" data-skin-viewed="false" data-skin-pos="14" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="35" text-anchor="middle" style="font-size:38px; font-weight:600;font-family:'Century Gothic','Arial';fill:#7EBCA3;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text x="50%" y="70" text-anchor="middle" style="font-weight:400;font-family:'Century Gothic','Arial'">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="20">508-278-2542 – 781-669-5989 – mCARTER@live.com</tspan>
</text>
<path d="M 0 120 L 705 120" stroke="#7EBCA3" stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:20px; font-weight:600; fill:#7EBCA3;font-family:'Century Gothic','Arial'" class="h2 fnt-family section-title">
<tspan x="0" y="152">Professional</tspan>
<tspan x="120" y="152">Summary</tspan>
</text>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="150" y="182">Accomplished operations executive with a successful track record overseeing </tspan>
<tspan x="150" dy="25">marketing, IT,HR/training, and real estate in company and franchise </tspan>
<tspan x="150" dy="25">operations for a large regional.</tspan>
</text>
<path d="M 0 255 L 705 255" stroke="#7EBCA3" stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:20px; font-weight:600; fill:#7EBCA3 ;font-family:'Century Gothic','Arial'" x="0" y="286" class="section-title">Skills</text>
<circle cx="155" cy="312" r="1.5" class="li-disc"></circle>
<circle cx="155" cy="345" r="1.5" class="li-disc"></circle>
<circle cx="155" cy="375" r="1.5" class="li-disc"></circle>
<circle cx="155" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="170" y="317">Executive Team Leadership</tspan>
<tspan x="170" dy="32">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="170" dy="32">Expertise in New England Real Estate</tspan>
<tspan x="170" dy="32">Client/Vendor Relations</tspan>
</text>
<circle cx="430" cy="315" r="1.5" class="li-disc"></circle>
<circle cx="430" cy="346" r="1.5" class="li-disc"></circle>
<circle cx="430" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="445" y="320">Marketing/Product Line Development</tspan>
<tspan x="445" dy="30">Staff/Training Development Policy</tspan>
<tspan x="445" dy="32">Development</tspan>
<tspan x="445" dy="32">Process Improvement</tspan>
</text>
<path d="M 0 444 L 705 444" stroke="#7EBCA3" stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:20px; font-weight:600; fill:#7EBCA3 ;font-family:'Century Gothic','Arial'" x="0" y="473" class="section-title">Experience</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="510">09/1993 to 01/1997</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" x="150" y="510" fill="#7EBCA3" class="svg-subsection-title">Vice President of Operations</tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'" x="150" dy="25">
<tspan style="font-weight:600;font-style:italic;">Verizon Wireless</tspan> – San Francisco, CA
</tspan>
</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="580">02/1991 to 01/1993</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" x="150" y="580" fill="#7EBCA3" class="svg-subsection-title">General Manager</tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'" x="150" dy="25">
<tspan style="font-weight:600;font-style:italic;">Woodranch Restaurant</tspan> – San Jose, CA
</tspan>
</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="646">06/1988 to 06/1991</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" x="150" y="646" fill="#7EBCA3" class="svg-subsection-title">Manager</tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'" x="150" dy="26">
<tspan style="font-weight:600;font-style:italic;">Woodranch Restaurant</tspan> – San Jose, CA
</tspan>
</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="715">01/1985 to 06/1988</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" x="150" y="715" fill="#7EBCA3" class="svg-subsection-title">Manager</tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial';" x="150" dy="25">
<tspan style="font-weight:600;font-style:italic;">Woodranch Restaurant</tspan> – San Jose, CA
</tspan>
</text>
<path d="M 0 778 L 705 778" stroke="#7EBCA3" stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:20px; font-weight:600; fill:#7EBCA3;font-family:'Century Gothic','Arial';" x="0" y="815" class="section-title">Education</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="848">09/1988</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;;font-family:'Century Gothic','Arial'" y="848" dx="90" fill="#7EBCA3" class="svg-subsection-title">
Master of Arts: Operations Management
</tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial';" x="146" dy="25">
<tspan style="font-weight:600;font-style:italic;">San Francisco State University</tspan> – San Francisco, CA
</tspan>
</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="915">09/1986</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" y="915" dx="89" fill="#7EBCA3" class="svg-subsection-title">Bachelor of Arts: Operations Management </tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial';" x="146" dy="25">
<tspan style="font-weight:600;font-style:italic;">University of San Francisco</tspan> – San Francisco, CA
</tspan>
</text>
<text>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial'; fill:#999;" x="0" y="980">06/1983</tspan>
<tspan style="font-weight:400;font-weight:400;fill:#7EBCA3;font-family:'Century Gothic','Arial'" y="980" dx="89" fill="#7EBCA3" class="svg-subsection-title">High School Diploma </tspan>
<tspan style="font-size:14px;font-family:'Century Gothic','Arial';" x="146" dy="26">
<tspan style="font-weight:600;font-style:italic;">San Francisco State University</tspan> – San Francisco, CA
</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="IND1" data-skin-cd="IND1" data-skin-name="Craftsman" data-skin-viewed="false" data-skin-pos="15" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style>
      .h1{font-size:38px; font-weight:600;font-family:"Arial";fill:#9097BE;}
      .h2{font-size:18px; font-weight:600; fill:#9097BE;}
      .h3{font-size:14px;}
      .p1{font-size:16px;}
      .p2{font-size:14px;}
      .li-disc {fill:#333333;}
      .fnt-family{font-family:"Arial";}
      .rect{fill:#ebebeb;}
    </style>
</defs>
<text x="50%" y="32" text-anchor="middle" class="h1 svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text class="h3 fnt-family" x="50%" y="53" text-anchor="middle">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="25">mCARTER@address.com</tspan>
<tspan x="50%" dy="25">415-123-1200</tspan>
</text>
<text class="h2 fnt-family section-title">
<tspan x="0" y="164">PROFESSIONAL</tspan>
<tspan x="0" y="186">SUMMARY</tspan>
</text>
<text class="p2 fnt-family">
<tspan x="173" y="160">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="173" dy="30">food and retail environments. Implement cost control measures to ensure</tspan>
<tspan x="173" dy="30">operations remain within company targets. Maximize bottom-line perfor-</tspan>
<tspan x="173" dy="30">mance through P&amp;L, merchandising, staff management, loss control and</tspan>
<tspan x="173" dy="30">inventory management initiatives.</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="337">SKILLS</text>
<circle cx="182" cy="330" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="358" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="390" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="417" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="336">Executive team leadership</tspan>
<tspan x="210" dy="30">Inventory report generation</tspan>
<tspan x="210" dy="28">Client/Vendor relations</tspan>
<tspan x="210" dy="28">Market analysis</tspan>
</text>
<circle cx="414" cy="329" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="359" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="388" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="418" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="442" y="333">Sales Management</tspan>
<tspan x="442" dy="30">Staff training and development</tspan>
<tspan x="442" dy="30">Customer relations</tspan>
<tspan x="442" dy="30">Process improvements</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="490">EXPERIENCE</text>
<text class="p1 fnt-family">
<tspan x="175" y="490">District Manager, Sept 2009 – Current</tspan>
<tspan x="175" dy="27">Verizon Wireless: San Francisco, CA</tspan>
</text>
<circle cx="180" cy="545" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="572" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="603" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="631" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="548">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="210" dy="30">Successfully increased employee retention with a positive work environment</tspan>
<tspan x="210" dy="30">Administered daily operations to ensure policies were adhered to by staff</tspan>
<tspan x="210" dy="30">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text class="p1 fnt-family">
<tspan x="175" y="683">General Manager, Jan 1994 – Aug 1997</tspan>
<tspan x="175" dy="28">Woodranch Restaurant: San Jose, CA</tspan>
</text>
<circle cx="180" cy="740" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="768" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="798" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="827" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="855" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="743">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="210" dy="30">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="210" dy="30">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="210" dy="30">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="210" dy="30">Implemented process improvements to increase guest loyal</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="930">EDUCATION</text>
<text class="p1 fnt-family">
<tspan x="175" y="928">Master of Arts, Jun 2010</tspan>
<tspan x="175" dy="27">San Francisco State University, San Francisco, CA</tspan>
</text>
<text class="p1 fnt-family">
<tspan x="175" y="995">Bachelor of Arts, Jul 2008</tspan>
<tspan x="175" dy="27">University of San Francisco, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="AUT1" data-skin-cd="AUT1" data-skin-name="Cinematic" data-skin-viewed="false" data-skin-pos="16" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="30" text-anchor="middle" style="font-size:38px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="40" x2="705" y2="40" style="stroke:#b5b5b5; stroke-width:2" />
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="225" y="147">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="160" x2="705" y2="160" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="0" y="186">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="320" y="290">Skills</tspan>
</text>
<line x1="0" y1="303" x2="705" y2="303" style="stroke:#b5b5b5; stroke-width:2" />
<circle cx="17" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333; ">
<tspan x="55" y="328">Executive team leadership</tspan>
<tspan x="55" dy="27">Inventory report generation</tspan>
<tspan x="55" dy="27">Client/Vendor relations</tspan>
<tspan x="55" dy="25">Market analysis</tspan>
</text>
<circle cx="412" cy="324" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial','Arial';fill:#333333; ">
<tspan x="445" y="328">Sales Management</tspan>
<tspan x="445" dy="27">Staff training</tspan>
<tspan x="445" dy="27">Customer relations</tspan>
<tspan x="445" dy="25">Process improvements</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="460">Experience</tspan>
</text>
<line x1="0" y1="472" x2="705" y2="472" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="495">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="495">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="522">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="522">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="580" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="632" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="557">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="50" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="50" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="50" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="675">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="675">San Jose, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="703">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="703">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="805" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="50" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="50" dy="25">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="50" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="50" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="888">Education</tspan>
</text>
<line x1="0" y1="900" x2="705" y2="900" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">Jul 2008</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
<div id="CON1" data-skin-cd="CON1" data-skin-name="Bedrock" data-skin-viewed="false" data-skin-pos="17" class="template-card change-color alltemplate">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;font-family:'Arial'; fill:#000000;" class="svg-name">
<tspan x="0" y="38" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="190" y="38" id="PreviewUserLastName">CARTER</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="60">123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="0" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="0" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="160" class="section-title">PROFESSIONALSUMMARY:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="187">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="28">Implement cost control measures to ensure operations remain within company targets. Maximize bottom-line</tspan>
<tspan x="0" dy="28">performance through P &amp;L,merchanding,staff management,staffmanagement, loss control and inventory </tspan>
<tspan x="0" dy="28">management initiatives.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="320" class="section-title">SKILLS:</text>
<circle cx="6" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="35" y="348">Executive team leadership</tspan>
<tspan x="35" y="375">Inventory report generation</tspan>
<tspan x="35" y="406">Client/Vendor relations</tspan>
<tspan x="35" y="433">Market analysis</tspan>
</text>
<circle cx="260" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="290" y="348">Sales Management</tspan>
<tspan x="290" y="375">Staff training and development</tspan>
<tspan x="290" y="406">Customer relations</tspan>
<tspan x="290" y="433">Process Improvements</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="490" class="section-title">EXPERIENCE:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="516">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="516">Sep 2009 - Current</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="543">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="543">San Francisco, CA</tspan>
</text>
<circle cx="6" cy="569" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="595" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="620" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="37" y="573">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="37" dy="30">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="37" dy="26">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="680">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="680" x="680">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="706">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="706" x="680">San Jose, CA</tspan>
</text>
<circle cx="6" cy="728" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="756" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="786" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="814" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="842" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="38" y="735">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="38" dy="28">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="900" class="section-title">EDUCATION:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="930">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="930" x="680">Jun 2009</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="956">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="956" x="680">San Francisco, CA</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="994">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="994" x="680">Mar 2011</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="1019">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="1019">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt display-flex text-center xy-center">Use this template</p>
</div>
</div>
<div id="recommendedTabContent" class="template-card-wrapper ">
<div id="MLP2" data-skin-cd="MLP2" data-skin-name="Fold" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc full-page-resume">

<svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');
        .name { height:50px; width:335px; color:#FFFFFF; font-family:'Source Sans Pro',Arial; font-weight:400; font-size:40px; letter-spacing:5.91px; line-height:30px; }
      </style>
</defs>
<rect x="37" y="0" width="410" height="160" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<rect x="470" y="0" width="240" height="1024" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Source Sans Pro',Arial;fill:#fff;font-weight:700">
<tspan class="name" x="44" y="100" id="PreviewUserFirstName">JOHN</tspan>
<tspan class="name" x="44" dy="40" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="37" y="180" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="194.5">PROFESSIONAL SUMMARY</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79" line-height="11" height="44" width="320">
<tspan x="43" y="220" width="320">Successful sales professional with 10+ years</tspan>
<tspan x="43" dy="16"> experience in large-scale food and retail environments.</tspan>
<tspan x="43" dy="16">Implement cost control measures to ensure operations</tspan>
<tspan x="43" dy="16"> remain within company targets.</tspan>
</text>
<rect x="37" y="293" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="308">WORK EXPERIENCE</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="340" font-weight="700">Verizon Wireless, San Francisco, CA - <tspan font-weight="500">Aug 2016 - Present</tspan></tspan>
<tspan font-weight="700" x="43" y="356">District Manager</tspan>
</text>
<text style="font-size:13px;fill:#333333;font-family:'Source Sans Pro',Arial;font-style:italic;"></text>
<circle cx="44" cy="380" r="2" style="fill:#333333" />
<circle cx="44" cy="420" r="2" style="fill:#333333" />
<circle cx="44" cy="460" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="383">Directed recruitment/training/staff development </tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="524" font-weight="700">Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Oct 1997 – Sept 2009</tspan></tspan>
<tspan font-weight="700" x="43" y="540">Manager</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="44" cy="564" r="2" style="fill:#333333" />
<circle cx="44" cy="604" r="2" style="fill:#333333" />
<circle cx="44" cy="644" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="567">Directed recruitment/training/staff development</tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="706" font-weight="700"><tspan>Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Jan 1994 – Aug 1997</tspan></tspan>
<tspan font-weight="700" x="43" y="722"> General Manager</tspan></tspan>
</text>
<circle cx="44" cy="746" r="2" style="fill:#333333" />
<circle cx="44" cy="766" r="2" style="fill:#333333" />
<circle cx="44" cy="806" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="750">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="55" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="55" dy="20">$110,000 store remodel.</tspan>
<tspan x="55" dy="20">Directed departmental alignment on strategies </tspan>
<tspan x="55" dy="20">to create strong sales.</tspan>
</text>
<rect x="37" y="860" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="874.5">EDUCATION</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="898">Jun 2010</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="918"><tspan font-weight="700">Master of Arts,</tspan> Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="938">San Francisco State University, San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="963">Jul 2008</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="983"><tspan font-weight="700">Master of Arts,</tspan> Business Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="1003">University of San Francisco, San Francisco, CA</tspan>
</text>
<rect x="490" y="180" width="200" height="20" style="fill:#E3E3E3;" />
<svg x="500" y="211" width="10" height="11" viewBox="0 0 512 512">
<path fill="#fff" d="M384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192H384z" />
</svg>
<svg x="500" y="252" width="12" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M511.2 387l-23.25 100.8c-3.266 14.25-15.79 24.22-30.46 24.22C205.2 512 0 306.8 0 54.5c0-14.66 9.969-27.2 24.22-30.45l100.8-23.25C139.7-2.602 154.7 5.018 160.8 18.92l46.52 108.5c5.438 12.78 1.77 27.67-8.98 36.45L144.5 207.1c33.98 69.22 90.26 125.5 159.5 159.5l44.08-53.8c8.688-10.78 23.69-14.51 36.47-8.975l108.5 46.51C506.1 357.2 514.6 372.4 511.2 387z"></path>
</svg>
<svg x="500" y="272" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="194.5">CONTACT</text>
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro';line-height: 14px; fill:#575757;letter-spacing: 0.79px;" x="530" y="192.5">
<tspan x="515" y="220" fill="#FFF">123 Main Street,</tspan>
<tspan x="515" dy="20" fill="#FFF">SanFrancisco, CA 94122</tspan>
<tspan x="515" dy="20" fill="#FFF">415-123-1200</tspan>
<tspan x="515" dy="20" fill="#FFF">mCARTER@address.com</tspan>
</text>
<rect x="490" y="310" width="200" height="20" style="fill:#E3E3E3;" />
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="324.5">skills</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="495" cy="352" r="2" style="fill:#ffffff" />
<circle cx="495" cy="390" r="2" style="fill:#ffffff" />
<circle cx="495" cy="410" r="2" style="fill:#ffffff" />
<circle cx="495" cy="430" r="2" style="fill:#ffffff" />
<circle cx="495" cy="450" r="2" style="fill:#ffffff" />
<circle cx="495" cy="470" r="2" style="fill:#ffffff" />
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro',Arial;text-transform:uppercase;line-height: 14px; fill:#ffffff;letter-spacing: 0.79px;" x="525" y="355">
<tspan x="502">Trained in Point-of-Sale </tspan>
<tspan x="502" dy="18">Systems</tspan>
<tspan x="502" dy="20">Spanish</tspan>
<tspan x="502" dy="20">Loyalty Program Promotion</tspan>
<tspan x="502" dy="20">Team Member Support</tspan>
<tspan x="502" dy="20">Menu Item Recommendation</tspan>
<tspan x="502" dy="20">Western Union Agent</tspan>
<tspan x="502" dy="18">Cashier</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP3" data-skin-cd="MLP3" data-skin-name="Vision" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,900');
          </style>
</defs>
<rect xmlns="http://www.w3.org/2000/svg" x="0" y="0" style="fill:#acb75a;" height="100" width="100%" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" fill="#ffffff" font-weight="900" font-size="30">
<tspan x="15" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="15" y="80" id="PreviewUserLastName">CARTER</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="15" y="145" id="PreviewUserLastName">CONTACT</tspan>
</text>
<svg width="12px" height="9px" viewBox="0 0 512 512" x="15" y="203" style="fill:#acb75a;">
<path style="fill:#acb75a;" class="svg-section-bg" d="M484.25 330l-101.59-43.55a45.86 45.86 0 0 0-53.39 13.1l-32.7 40a311.08 311.08 0 0 1-124.19-124.12l40-32.7a45.91 45.91 0 0 0 13.1-53.42L182 27.79a45.63 45.63 0 0 0-52.31-26.61L35.5 22.89A45.59 45.59 0 0 0 0 67.5C0 313.76 199.68 512.1 444.56 512a45.58 45.58 0 0 0 44.59-35.51l21.7-94.22a45.75 45.75 0 0 0-26.6-52.27zm-41.59 134.09C225.08 463.09 49 287 48 69.3l90.69-20.9 42.09 98.22-68.09 55.71c46.39 99 98.19 150.63 197 197l55.69-68.11 98.19 42.11z" />
</svg>
<svg width="12px" height="9px" viewBox="0 0 12 9" style="fill:#acb75a;" x="15" y="222">
<path class="svg-section-bg" d="M9.06247839,8 C9.58024602,8 9.99997616,7.58026986 9.99997616,7.06250224 L9.99997616,1.43751565 C9.99997616,0.919748021 9.58024602,0.500017881 9.06247839,0.500017881 L0.937497765,0.500017881 C0.419730139,0.500017881 0,0.919748021 0,1.43751565 L0,7.06250224 C0,7.58026986 0.419730139,8 0.937497765,8 L9.06247839,8 Z M4.99998808,5.18743041 C4.54670776,5.19475461 3.89493014,4.57299859 3.56614216,4.31436273 C2.07381708,3.1458093 1.37548119,2.59117272 0.937497765,2.2344803 L0.937497765,1.43751565 L9.06247839,1.43751565 L9.06247839,2.2344803 C8.62455219,2.5911155 7.92638796,3.14563764 6.433834,4.31436273 C6.10491251,4.57309396 5.45334469,5.19467832 4.99998808,5.18743041 Z M9.06247839,7.06250224 L0.937497765,7.06250224 L0.937497765,3.43748036 C1.38503698,3.7939439 2.01970573,4.29414488 2.9870725,5.05164659 C3.41395518,5.38768247 4.16155777,6.1295058 4.99998808,6.1249854 C5.83429853,6.1295058 6.57242162,5.39843989 7.012732,5.05179917 C7.9800797,4.29431654 8.6149201,3.79398204 9.06247839,3.43748036 L9.06247839,7.06250224 Z" id="email" fill-rule="nonzero"></path>
</svg>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="15" dy="175" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="15" dy="18" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">mCARTER@address.com</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'">
<tspan x="15" y="280" id="PreviewUserLastName" fill="#4f4f4f">SKILLS</tspan>
</text>
<circle cx="15" cy="307" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="343" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="363" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="400" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="420" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="440" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="460" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="480" r="2" style="fill:#4f4f4f" />
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="22" y="310" style="font-kerning:normal">Executive team</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">leadership</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Sales Management</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Inventory report</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">generation</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Staff training</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Client/Vendor relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Customer relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Market analysis</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Process improvements</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="145" id="PreviewUserLastName">PROFESSIONAL SUMMARY</tspan>
</text>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="207" y="175" style="font-kerning:normal">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">environments. Implement cost food and retail control measures to</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> ensure operations remain within line company targets. Maximize</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> bottom-performance through P &amp; L, merchanding, staff management,</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">loss control and inventory management initiatives.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="290" id="PreviewUserLastName">EXPERIENCE</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="325">Verizon Wireless</tspan> | <tspan>San Francisco, CA</tspan>
</text>
<circle cx="207" cy="342" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="345">February 2016 – Current</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="365">District Manager</tspan>
</text>
<circle cx="207" cy="381" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="401" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="421" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="461" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="385">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<circle cx="207" cy="502" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="505">Oct 1997 – Sept 2009</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="525">Manager</tspan>
</text>
<circle cx="207" cy="542" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="562" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="582" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="622" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="545">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="665">Woodranch Restaurant</tspan> | <tspan>San Jose, CA</tspan>
</text>
<circle cx="207" cy="682" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="685">Jan 1994 – Aug 1997</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="705">General Manager</tspan>
</text>
<circle cx="207" cy="722" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="742" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="762" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="782" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="725">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="212" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="212" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="212" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="835" id="PreviewUserLastName">EDUCATION</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="870">Jun 2010</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="890">Master of Arts - Operations Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="910">San Francisco State University , San Francisco, CA</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="940">Jun 2008</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="960">Master of Arts: Business Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="980">University of San Francisco , San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR4" data-skin-cd="MLR4" data-skin-name="Blueprint" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Roboto:400,900');
        .font-bld{font-weight:900;}
        .li-disc {fill:#000;} 
      </style>
</defs>
<line x1="0" y1="90" x2="710" y2="90" stroke="#e7e7e7" stroke-width="2" />
<line x1="258" y1="90" x2="258" y2="1300" stroke="#e7e7e7" stroke-width="2" />
<rect class="rect1 svg-section-bg" fill="#305fec" height="119" width="54" x="48" />
<polygon points="73,110 103,120 29,125" style="fill:#fff;" />
<text class="font-bld" style="font-size:21px;font-family:'Roboto';fill:#fff;">
<tspan x="66" y="40" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="66" y="65" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text style="font-size:28px;font-family:'Roboto';fill:#000;" class="text-upper">
<tspan x="133" y="55" class="font-bld" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="263" y="55" class="font-bld" id="PreviewUserLastName">CARTER</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="170">Contact</text>
<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="187" width="13" height="13" viewBox="0 0 512 512">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="220" width="12" height="12" viewBox="0 0 512 512">
<path fill="#000" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="48" y="250" width="10" height="13" viewBox="0 0 384 512">
<path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
</svg>
<text style="font-size:14px;font-weight:400;font-family:'Roboto';fill:#000;">
<tspan x="68" y="200">415-123-0012</tspan>
<tspan x="68" dy="30">mCARTER@address.com</tspan>
<tspan x="68" dy="30">123 Main Street, </tspan>
<tspan x="68" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<line x1="0" y1="320" x2="258" y2="320" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="360">professional Summary</text>
<text style="font-size:14px;fill:#000;font-family:'Roboto';font-weight:400;">
<tspan x="48" y="390">Successful sales </tspan>
<tspan x="48" dy="25">professional with 10+ </tspan>
<tspan x="48" dy="25">years experience in </tspan>
<tspan x="48" dy="25">large-scale food and retail </tspan>
<tspan x="48" dy="25">environments.</tspan>
</text>
<line x1="0" y1="520" x2="258" y2="520" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="560">SKILLS</text>
<circle cx="48" cy="585" r="1.3" class="li-disc" />
<circle cx="48" cy="635" r="1.3" class="li-disc" />
<circle cx="48" cy="660" r="1.3" class="li-disc" />
<circle cx="48" cy="710" r="1.3" class="li-disc" />
<circle cx="48" cy="760" r="1.3" class="li-disc" />
<circle cx="48" cy="810" r="1.3" class="li-disc" />
<circle cx="48" cy="785" r="1.3" class="li-disc" />
<circle cx="48" cy="835" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="58" y="590">Executive team </tspan>
<tspan x="58" dy="25">leadership</tspan>
<tspan x="58" dy="25">Sales Management</tspan>
<tspan x="58" dy="25">Inventory report </tspan>
<tspan x="58" dy="25">generation</tspan>
<tspan x="58" dy="25">Staff training and </tspan>
<tspan x="58" dy="25">development</tspan>
<tspan x="58" dy="25">Client/Vendor relation</tspan>
<tspan x="58" dy="25">Customer relations</tspan>
<tspan x="58" dy="25">Market analysis</tspan>
<tspan x="58" dy="25">Process Improvements</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="273" y="130">Experience</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="160" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">District Manager </tspan><tspan style="font-style:italic;">Sep 2009 - Current</tspan> </tspan>
<tspan x="273" dy="25" style="font-style:italic;">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="278" cy="205" r="1.3" class="li-disc" />
<circle cx="278" cy="230" r="1.3" class="li-disc" />
<circle cx="278" cy="280" r="1.3" class="li-disc" />
<circle cx="278" cy="330" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="210">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="293" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="293" dy="25">work environment.</tspan>
<tspan x="293" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="400" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">General Manager </tspan> <tspan style="font-style:italic;">Jan 1994 - Aug 1997</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="455" r="1.3" class="li-disc" />
<circle cx="278" cy="480" r="1.3" class="li-disc" />
<circle cx="278" cy="530" r="1.3" class="li-disc" />
<circle cx="278" cy="580" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="460">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="293" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="293" dy="25">$110,000 store remodel.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to </tspan>
<tspan x="293" dy="25">create strong sales.</tspan>
<tspan x="293" dy="25">Cultivated strong franchise owner relationships to </tspan>
<tspan x="293" dy="25">achieve high standards.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="650" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Senior Executive </tspan><tspan style="font-style:italic;">Aug 1993 - Jan 1994</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="705" r="1.3" class="li-disc" />
<circle cx="278" cy="755" r="1.3" class="li-disc" />
<circle cx="278" cy="805" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="710">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="293" dy="25">strong sales.</tspan>
</text>
<line x1="258" y1="870" x2="710" y2="870" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; text-transform:uppercase;fill:#305fec;" x="278" y="910">Education</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="278" y="940" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Master of Arts - Operations Management </tspan><tspan style="font-style:italic;">Jun 2009</tspan></tspan>
<tspan x="278" dy="25" style="fill:#000;font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR5" data-skin-cd="MLR5" data-skin-name="Revival" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Merriweather:300,400,700');
        .font-bld{font-weight:700;}
        .h1{font-size:45px; font-weight:600;}
        .h2{font-size:18px; font-weight:500;}
        .li-disc {fill:#808080;} 
        .li-white-disc {fill:#fff;}    
        .left-bg{fill:#0E9FC1;}            
        .section-bg{fill:#007D9E;}  
      </style>
</defs>
<rect x="0" y="0" width="245" height="1024" style="fill:#0E9FC1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Merriweather';fill:#fff;font-weight:700">
<tspan x="18" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="18" y="75" id="PreviewUserLastName">CARTER</tspan>
</text>
<svg x="18" y="98" width="9" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="18" y="129" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="18" y="160" width="9" height="9" viewBox="0 0 8 8">
<path fill="#fff" d="M5.71 4.754a2.913 2.913 0 0 1-1.877.696c-.69 0-1.318-.249-1.82-.648C.815 5.062.32 5.842.26 7.483h7.247c-.045-1.857-.47-2.548-1.797-2.729z" />
<path fill="#fff" d="M2.625 4.356c.281.185.609.298.959.338.083.01.163.025.248.025.085 0 .165-.016.247-.025a2.19 2.19 0 0 0 .984-.352c.142-.096.268-.212.384-.338.365-.394.593-.917.593-1.495A2.213 2.213 0 0 0 3.832.3c-1.219 0-2.21.992-2.21 2.21 0 .583.232 1.112.603 1.507.12.128.253.243.4.34z" />
</svg>
<text style="font-size:13px;font-family:'Merriweather';fill:#fff;font-weight:bold;">
<tspan x="35" y="107">415-123-0012</tspan>
<tspan x="35" dy="30">mCARTER@address.com</tspan>
<tspan x="35" dy="30">123 Main Street,</tspan>
<tspan x="35" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<rect x="0" y="225" width="245" height="28" class=" section-bg svg-heading-bg" />
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#fff;text-transform:uppercase;letter-spacing: 2.8px;" x="15" y="245">SKILLS</text>
<circle cx="17" cy="279" r="2" class="li-white-disc" />
<circle cx="17" cy="306" r="2" class="li-white-disc" />
<circle cx="17" cy="330" r="2" class="li-white-disc" />
<circle cx="17" cy="355" r="2" class="li-white-disc" />
<circle cx="17" cy="380" r="2" class="li-white-disc" />
<circle cx="17" cy="405" r="2" class="li-white-disc" />
<circle cx="17" cy="430" r="2" class="li-white-disc" />
<circle cx="17" cy="455" r="2" class="li-white-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:400;fill:#fff;">
<tspan x="25" y="285">Executive team leadership</tspan>
<tspan x="25" dy="25">Sales Management</tspan>
<tspan x="25" dy="25">Inventory report generation</tspan>
<tspan x="25" dy="25">Staff training and development</tspan>
<tspan x="25" dy="25">Client/Vendor relation</tspan>
<tspan x="25" dy="25">Customer relations</tspan>
<tspan x="25" dy="25">Market analysis</tspan>
<tspan x="25" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.4px;" x="260" y="29" class="svg-heading-color">professional Summary</text>
<text style="font-size:13px;fill:#808080;font-family:'Merriweather';font-weight:300;">
<tspan x="260" y="55">Successful sales professional with 10+ years experience in </tspan>
<tspan x="260" dy="25">large-scale food and retail environments. Implement cost</tspan>
<tspan x="260" dy="25">control measures to ensure operations remain within </tspan>
<tspan x="260" dy="25">company targets. Maximize bottom-line performance</tspan>
<tspan x="260" dy="25">through P &amp; L, merchanding, staff management, loss control </tspan>
<tspan x="260" dy="25">and inventory management initiatives.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="230" class="svg-heading-color">Experience</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="260" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">District Manager</tspan>
<tspan x="260" dy="25">Verizon Wireless</tspan>
<tspan x="260" dy="25">September 2009 - Current</tspan>
</text>
<circle cx="270" cy="335" r="2" class="li-disc" />
<circle cx="270" cy="360" r="2" class="li-disc" />
<circle cx="270" cy="410" r="2" class="li-disc" />
<circle cx="270" cy="460" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="340">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="285" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="285" dy="25">work environment.</tspan>
<tspan x="285" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="285" dy="25">adhered to by sales staff.</tspan>
<tspan x="285" dy="25">Cultivated strong business relationships with customers to </tspan>
<tspan x="285" dy="25">drive business.</tspan>
</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="520" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">General Manager</tspan>
<tspan x="260" dy="25">Woodranch Restaurant</tspan>
<tspan x="260" dy="25">August 2015 - October 2017</tspan>
</text>
<circle cx="270" cy="590" r="2" class="li-disc" />
<circle cx="270" cy="615" r="2" class="li-disc" />
<circle cx="270" cy="665" r="2" class="li-disc" />
<circle cx="270" cy="715" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="595">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="285" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="285" dy="25">$110,000 store remodel.</tspan>
<tspan x="285" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="285" dy="25">strong sales.</tspan>
<tspan x="285" dy="25">Cultivated strong franchise owner relationships to achieve </tspan>
<tspan x="285" dy="25">high standards.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="800" class="svg-heading-color">Education</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="830" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">Master of Arts: Operations Management</tspan>
<tspan x="260" dy="25">San Francisco State University </tspan>
<tspan x="260" dy="25">San Francisco, CA </tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR3" data-skin-cd="MLR3" data-skin-name="Greetings" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<path id="lowerhalf" d="M568,-142 a22,27 0 0,0 87,0" />
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=DM+Serif+Display:400');
        .font-bld{font-weight:700;}     
        .li-disc {fill:#000;}     
        .top-bdr{fill:#000; }
        .top-bdr-black{fill:transparent; stroke-width:1px;stroke:#d0d0d0;}
        .top-bdr-white{fill:white; }     
        .line{stroke-width:1px;stroke:#d0d0d0;}    
      </style>
</defs>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="173">
<path fill="#305fec" class="svg-section-bg" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="204">
<path fill="#305fec" class="svg-section-bg" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg width="14" height="14" viewBox="0 0 24 24" x="462" y="233">
<path fill="#305fec" class="svg-section-bg" d="M12 0c-4.198 0-8 3.403-8 7.602 0 4.198 3.469 9.21 8 16.398 4.531-7.188 8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z" />
</svg>
<text style="font-size:34px;font-weight:400; -webkit-font-smoothing:antialiased; font-family:'DM Serif Display','Arial'; fill:#000;">
<tspan x="48" y="60">Hi, I'm</tspan>
<tspan x="153" y="60" id="PreviewUserFirstName" class="text-capitalize">JOHN</tspan>
<tspan x="276" y="60" id="PreviewUserLastName" class="text-capitalize">CARTER</tspan>.
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="120" class="section-title">Professional Summary</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="48" y="145">Successful sales professional with 10+ years experience in </tspan>
<tspan x="48" dy="20">large-scale food and retail environments. Implement cost </tspan>
<tspan x="48" dy="20">control measures to ensure operations remain within </tspan>
<tspan x="48" dy="20">company targets. Maximize bottom-line performance </tspan>
<tspan x="48" dy="20">through P&amp;L, merchandising, staff management, loss </tspan>
<tspan x="48" dy="20">control and inventory management initiatives.</tspan>
</text>
<rect x="447" y="120" width="210" height="180" class="top-bdr-black" />

<g transform="translate(555,35)"><g><g transform="rotate(-330 18.5 34.5)"><path fill="#305fec" class="svg-name" d="M19.28 37.191l-4.75-2.086-.053-1.131 4.54-2.501-5.35.246-.087-1.898 8.5-.391.117 2.567-4.568 2.405 4.77 1.988.117 2.554-8.5.391-.087-1.898z" /></g><g transform="rotate(-330 15 41.5)"><path fill="#305fec" class="svg-name" d="M19.008 39.83l.483 1.837-8.228 2.167-.483-1.838z" /></g><g transform="rotate(-330 49 61.5)"><g><path fill="#305fec" class="svg-name" d="M8.775 68.504c.392.847 1.048 1.384 1.967 1.612l-.627 1.632c-1.393-.42-2.364-1.225-2.914-2.415-.55-1.19-.628-2.344-.234-3.462.396-1.118 1.166-1.941 2.311-2.472 1.145-.53 2.282-.58 3.411-.15 1.129.43 1.956 1.213 2.48 2.347.587 1.268.595 2.552.026 3.854l-1.711-.51c.425-.859.45-1.694.076-2.504-.3-.649-.769-1.105-1.405-1.37-.637-.264-1.314-.23-2.032.102-.718.333-1.194.817-1.427 1.453a2.372 2.372 0 0 0 .08 1.883" /></g><g><path fill="#305fec" class="svg-name" d="M20.188 73.522L21.382 75l-6.62 5.35-1.192-1.478 2.603-2.105-2.126-2.634-2.604 2.105-1.193-1.478 6.619-5.35 1.193 1.478-2.765 2.235 2.126 2.634z" /></g><g><path fill="#305fec" class="svg-name" d="M22.082 86.356l.471-1.946-2.851-2.143-1.736.995-1.616-1.215 8.05-4.597 1.47 1.105-2.173 9.015zm1.537-6.325l-2.341 1.333 1.703 1.28z" /></g><g><path fill="#305fec" class="svg-name" d="M34.747 83.207l-.68 1.55-3.878-1.703-.705 1.606 3.489 1.532-.65 1.483-3.49-1.532-.709 1.617 4.002 1.757-.675 1.54-5.741-2.521 3.42-7.796z" /></g><g><path fill="#305fec" class="svg-name" d="M34.12 91.816l1.777-8.326 1.857.397-1.424 6.67 3.548.758-.354 1.656z" /></g><g><path fill="#305fec" class="svg-name" d="M48.104 89.612l.834-5.055 1.966-.268 2.145 4.649 1.015-5.08 2.038-.278-1.793 8.837-1.399.19-2.645-5.613-1.034 6.115-1.399.191-4.092-8.034 2.038-.278z" /></g><g><path fill="#305fec" class="svg-name" d="M56.26 82.938l1.778-.668 2.99 7.97-1.778.668z" /></g><g><path fill="#305fec" class="svg-name" d="M63.675 89.134l-4.135-7.44 1.66-.924 3.312 5.96 3.17-1.763.823 1.48z" /></g><g><path fill="#305fec" class="svg-name" d="M70.435 85.038l-5.445-6.542 1.46-1.216 4.362 5.24 2.787-2.322 1.083 1.3z" /></g><g><path fill="#305fec" class="svg-name" d="M69.79 74.206l1.266-1.416 6.343 5.674-1.266 1.417z" /></g><g><path fill="#305fec" class="svg-name" d="M82.564 71.017l-1.98-.294-1.874 3.036 1.147 1.64-1.062 1.72-5.305-7.605.966-1.564 9.17 1.347zm-6.434-.958l1.539 2.211 1.12-1.813z" /></g><g><path fill="#305fec" class="svg-name" d="M81.552 58.217l3.862 3.466-.304 1.09-5.093.958 5.159 1.438-.51 1.83-8.196-2.284.689-2.476 5.091-.856-3.912-3.38.686-2.463 8.197 2.285-.51 1.83z" /></g><g><path fill="#305fec" class="svg-name" d="M80.66 52.159c.147.185.344.28.592.284.248.003.446-.105.596-.326.15-.22.33-.733.542-1.538.212-.804.52-1.427.925-1.867.405-.44.989-.654 1.751-.642.763.013 1.377.31 1.842.89.466.58.691 1.336.676 2.27-.022 1.348-.54 2.553-1.556 3.617l-1.37-1.155c.819-.905 1.234-1.747 1.247-2.526.006-.35-.065-.624-.212-.826a.723.723 0 0 0-.604-.308.71.71 0 0 0-.614.307c-.153.209-.312.624-.476 1.247-.251.987-.57 1.706-.954 2.159-.385.452-.98.672-1.789.659-.806-.013-1.425-.314-1.854-.901-.428-.588-.635-1.316-.621-2.185a5.221 5.221 0 0 1 .32-1.7 4.573 4.573 0 0 1 .851-1.472l1.372.984c-.572.73-.864 1.489-.877 2.276-.005.317.066.568.213.753" /></g><g><path fill="#305fec" class="svg-name hide-initials" style="font-size:40px; font-family:'Source Sans Pro',sans-serif,Arial;" d="M54.86 44.058l-7.793 15.41h-3.834l-7.751-15.41v17.75H29.05V33.61h8.7L45.17 49.1l7.463-15.49h8.658v28.197H54.86z" /></g></g></g><g><path fill="none" stroke="#305fec" class="svg-stroke-full" stroke-miterlimit="20" stroke-width="2.5" d="M51.19 102.69c27.338 0 49.5-22.61 49.5-50.5s-22.162-50.5-49.5-50.5-49.5 22.61-49.5 50.5 22.162 50.5 49.5 50.5z" /></g></g>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="150" class="section-title">Contact</text>
<line x1="462" y1="165" x2="637" y2="165" class="line" />
<line x1="462" y1="195" x2="637" y2="195" class="line" />
<line x1="462" y1="225" x2="637" y2="225" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="482" y="185">415-123-0012</tspan>
<tspan x="482" dy="28">mCARTER@live.com</tspan>
<tspan x="482" dy="32">123 Main Street,</tspan>
<tspan x="482" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<rect x="447" y="335" width="210" height="270" class="top-bdr-black" />
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="363" class="section-title">Skills</text>
<circle cx="462" cy="385" r="1.3" class="li-disc" />
<circle cx="462" cy="410" r="1.3" class="li-disc" />
<circle cx="462" cy="435" r="1.3" class="li-disc" />
<circle cx="462" cy="460" r="1.3" class="li-disc" />
<circle cx="462" cy="485" r="1.3" class="li-disc" />
<circle cx="462" cy="510" r="1.3" class="li-disc" />
<circle cx="462" cy="535" r="1.3" class="li-disc" />
<circle cx="462" cy="560" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="472" y="390">Executive team leadership</tspan>
<tspan x="472" dy="25">Inventory report generation</tspan>
<tspan x="472" dy="25">Client/Vendor relations</tspan>
<tspan x="472" dy="25">Market analysis</tspan>
<tspan x="472" dy="25">Sales Management</tspan>
<tspan x="472" dy="25">Staff training</tspan>
<tspan x="472" dy="25">Customer relations</tspan>
<tspan x="472" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="285" class="section-title">Experience</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="305" r="4" class="svg-stroke-full" />
<line x1="51" y1="310" x2="51" y2="495" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="310"><tspan style="font-weight:700;">District Manager </tspan> <tspan style="font-style:italic;"> Sep 2009 – Current</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="330">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="68" cy="350" r="1.3" class="li-disc" />
<circle cx="68" cy="370" r="1.3" class="li-disc" />
<circle cx="68" cy="410" r="1.3" class="li-disc" />
<circle cx="68" cy="450" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="355">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="76" dy="20">Successfully increased employee retention with a </tspan>
<tspan x="76" dy="20">positive work environment.</tspan>
<tspan x="76" dy="20">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="20">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="500" r="4" class="svg-stroke-full" />
<line x1="51" y1="505" x2="51" y2="740" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="505"><tspan style="font-weight:700;">General Manager </tspan> <tspan style="font-style:italic;"> Jan 1994 – Aug 1997</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="525">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="550" r="1.3" class="li-disc" />
<circle cx="68" cy="570" r="1.3" class="li-disc" />
<circle cx="68" cy="610" r="1.3" class="li-disc" />
<circle cx="68" cy="650" r="1.3" class="li-disc" />
<circle cx="68" cy="690" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="555">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="76" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="76" dy="20">$110,000 store remodel.</tspan>
<tspan x="76" dy="20">Directed departmental alignment on strategies to create</tspan>
<tspan x="76" dy="20">strong sales.</tspan>
<tspan x="76" dy="20">Cultivated strong franchise owner relationships to </tspan>
<tspan x="76" dy="20">achieve high standards.</tspan>
<tspan x="76" dy="20">Implemented process improvements to increase guest</tspan>
<tspan x="76" dy="20">loyalty.</tspan></text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="745" r="4" class="svg-stroke-full" />
<line x1="51" y1="750" x2="51" y2="870" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="68" y="750"><tspan style="font-weight:700;">Senior Executive </tspan> <tspan style="font-style:italic;"> Aug 1993 – Jan 1994</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="68" y="770">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="795" r="1.5" style="fill:#333333" />
<circle cx="68" cy="840" r="1.5" style="fill:#333333" />
<text style="fill:#333333;font-family:'Source Sans Pro',sans-serif,Arial;font-size:14px">
<tspan x="76" y="800">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="25">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="900" class="section-title">Education</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="925" r="4" class="svg-stroke-full" />
<line x1="51" y1="930" x2="51" y2="975" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;font-weight:400; fill:#000000;">
<tspan x="76" y="930" class="font-bld">Master of Arts, Operations Management</tspan>
<tspan x="76" dy="20" style="font-style:italic;">Jun 2011</tspan>
<tspan x="76" dy="20" style="font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="IND1" data-skin-cd="IND1" data-skin-name="Craftsman" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color display-none recommendedskn Noexperience">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style>
      .h1{font-size:38px; font-weight:600;font-family:"Arial";fill:#9097BE;}
      .h2{font-size:18px; font-weight:600; fill:#9097BE;}
      .h3{font-size:14px;}
      .p1{font-size:16px;}
      .p2{font-size:14px;}
      .li-disc {fill:#333333;}
      .fnt-family{font-family:"Arial";}
      .rect{fill:#ebebeb;}
    </style>
</defs>
<text x="50%" y="32" text-anchor="middle" class="h1 svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text class="h3 fnt-family" x="50%" y="53" text-anchor="middle">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="25">mCARTER@address.com</tspan>
<tspan x="50%" dy="25">415-123-1200</tspan>
</text>
<text class="h2 fnt-family section-title">
<tspan x="0" y="164">PROFESSIONAL</tspan>
<tspan x="0" y="186">SUMMARY</tspan>
</text>
<text class="p2 fnt-family">
<tspan x="173" y="160">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="173" dy="30">food and retail environments. Implement cost control measures to ensure</tspan>
<tspan x="173" dy="30">operations remain within company targets. Maximize bottom-line perfor-</tspan>
<tspan x="173" dy="30">mance through P&amp;L, merchandising, staff management, loss control and</tspan>
<tspan x="173" dy="30">inventory management initiatives.</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="337">SKILLS</text>
<circle cx="182" cy="330" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="358" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="390" r="1.5" class="li-disc"></circle>
<circle cx="182" cy="417" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="336">Executive team leadership</tspan>
<tspan x="210" dy="30">Inventory report generation</tspan>
<tspan x="210" dy="28">Client/Vendor relations</tspan>
<tspan x="210" dy="28">Market analysis</tspan>
</text>
<circle cx="414" cy="329" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="359" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="388" r="1.5" class="li-disc"></circle>
<circle cx="414" cy="418" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="442" y="333">Sales Management</tspan>
<tspan x="442" dy="30">Staff training and development</tspan>
<tspan x="442" dy="30">Customer relations</tspan>
<tspan x="442" dy="30">Process improvements</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="490">EXPERIENCE</text>
<text class="p1 fnt-family">
<tspan x="175" y="490">District Manager, Sept 2009 – Current</tspan>
<tspan x="175" dy="27">Verizon Wireless: San Francisco, CA</tspan>
</text>
<circle cx="180" cy="545" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="572" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="603" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="631" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="548">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="210" dy="30">Successfully increased employee retention with a positive work environment</tspan>
<tspan x="210" dy="30">Administered daily operations to ensure policies were adhered to by staff</tspan>
<tspan x="210" dy="30">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text class="p1 fnt-family">
<tspan x="175" y="683">General Manager, Jan 1994 – Aug 1997</tspan>
<tspan x="175" dy="28">Woodranch Restaurant: San Jose, CA</tspan>
</text>
<circle cx="180" cy="740" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="768" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="798" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="827" r="1.5" class="li-disc"></circle>
<circle cx="180" cy="855" r="1.5" class="li-disc"></circle>
<text class="p2 fnt-family">
<tspan x="210" y="743">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="210" dy="30">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="210" dy="30">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="210" dy="30">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="210" dy="30">Implemented process improvements to increase guest loyal</tspan>
</text>
<text class="h2 fnt-family section-title" x="0" y="930">EDUCATION</text>
<text class="p1 fnt-family">
<tspan x="175" y="928">Master of Arts, Jun 2010</tspan>
<tspan x="175" dy="27">San Francisco State University, San Francisco, CA</tspan>
</text>
<text class="p1 fnt-family">
<tspan x="175" y="995">Bachelor of Arts, Jul 2008</tspan>
<tspan x="175" dy="27">University of San Francisco, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP2" data-skin-cd="MLP2" data-skin-name="Fold" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc full-page-resume">

<svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');
        .name { height:50px; width:335px; color:#FFFFFF; font-family:'Source Sans Pro',Arial; font-weight:400; font-size:40px; letter-spacing:5.91px; line-height:30px; }
      </style>
</defs>
<rect x="37" y="0" width="410" height="160" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<rect x="470" y="0" width="240" height="1024" style="fill:#0e9fc1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Source Sans Pro',Arial;fill:#fff;font-weight:700">
<tspan class="name" x="44" y="100" id="PreviewUserFirstName">JOHN</tspan>
<tspan class="name" x="44" dy="40" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="37" y="180" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="194.5">PROFESSIONAL SUMMARY</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79" line-height="11" height="44" width="320">
<tspan x="43" y="220" width="320">Successful sales professional with 10+ years</tspan>
<tspan x="43" dy="16"> experience in large-scale food and retail environments.</tspan>
<tspan x="43" dy="16">Implement cost control measures to ensure operations</tspan>
<tspan x="43" dy="16"> remain within company targets.</tspan>
</text>
<rect x="37" y="293" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="308">WORK EXPERIENCE</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="340" font-weight="700">Verizon Wireless, San Francisco, CA - <tspan font-weight="500">Aug 2016 - Present</tspan></tspan>
<tspan font-weight="700" x="43" y="356">District Manager</tspan>
</text>
<text style="font-size:13px;fill:#333333;font-family:'Source Sans Pro',Arial;font-style:italic;"></text>
<circle cx="44" cy="380" r="2" style="fill:#333333" />
<circle cx="44" cy="420" r="2" style="fill:#333333" />
<circle cx="44" cy="460" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="383">Directed recruitment/training/staff development </tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="524" font-weight="700">Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Oct 1997 – Sept 2009</tspan></tspan>
<tspan font-weight="700" x="43" y="540">Manager</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="44" cy="564" r="2" style="fill:#333333" />
<circle cx="44" cy="604" r="2" style="fill:#333333" />
<circle cx="44" cy="644" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="567">Directed recruitment/training/staff development</tspan>
<tspan x="55" dy="20">initiatives</tspan>
<tspan x="55" dy="20">Successfully increased employee retention with </tspan>
<tspan x="55" dy="20">a positive work environment.</tspan>
<tspan x="55" dy="20">Administered daily operations to ensure policies were </tspan>
<tspan x="55" dy="20">adhered to by sales staff.</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="706" font-weight="700"><tspan>Woodranch Restaurant, San Jose, CA - <tspan font-weight="500">Jan 1994 – Aug 1997</tspan></tspan>
<tspan font-weight="700" x="43" y="722"> General Manager</tspan></tspan>
</text>
<circle cx="44" cy="746" r="2" style="fill:#333333" />
<circle cx="44" cy="766" r="2" style="fill:#333333" />
<circle cx="44" cy="806" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="55" y="750">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="55" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="55" dy="20">$110,000 store remodel.</tspan>
<tspan x="55" dy="20">Directed departmental alignment on strategies </tspan>
<tspan x="55" dy="20">to create strong sales.</tspan>
</text>
<rect x="37" y="860" width="410" height="20" style="fill:#E3E3E3;" />
<text style="font-size:14px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="43" y="874.5">EDUCATION</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="898">Jun 2010</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="918"><tspan font-weight="700">Master of Arts,</tspan> Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="938">San Francisco State University, San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="963">Jul 2008</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="983"><tspan font-weight="700">Master of Arts,</tspan> Business Management</tspan>
</text>
<text fill="#333333" font-family="'Source Sans Pro',Arial" font-size="13" letter-spacing=".79">
<tspan x="43" y="1003">University of San Francisco, San Francisco, CA</tspan>
</text>
<rect x="490" y="180" width="200" height="20" style="fill:#E3E3E3;" />
<svg x="500" y="211" width="10" height="11" viewBox="0 0 512 512">
<path fill="#fff" d="M384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192H384z" />
</svg>
<svg x="500" y="252" width="12" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M511.2 387l-23.25 100.8c-3.266 14.25-15.79 24.22-30.46 24.22C205.2 512 0 306.8 0 54.5c0-14.66 9.969-27.2 24.22-30.45l100.8-23.25C139.7-2.602 154.7 5.018 160.8 18.92l46.52 108.5c5.438 12.78 1.77 27.67-8.98 36.45L144.5 207.1c33.98 69.22 90.26 125.5 159.5 159.5l44.08-53.8c8.688-10.78 23.69-14.51 36.47-8.975l108.5 46.51C506.1 357.2 514.6 372.4 511.2 387z"></path>
</svg>
<svg x="500" y="272" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="194.5">CONTACT</text>
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro';line-height: 14px; fill:#575757;letter-spacing: 0.79px;" x="530" y="192.5">
<tspan x="515" y="220" fill="#FFF">123 Main Street,</tspan>
<tspan x="515" dy="20" fill="#FFF">SanFrancisco, CA 94122</tspan>
<tspan x="515" dy="20" fill="#FFF">415-123-1200</tspan>
<tspan x="515" dy="20" fill="#FFF">mCARTER@address.com</tspan>
</text>
<rect x="490" y="310" width="200" height="20" style="fill:#E3E3E3;" />
<text style="font-size:13px;height: 14px; font-weight:bold;font-family:'Source Sans Pro',Arial;line-height: 14px; fill:#575757;text-transform:uppercase;letter-spacing: 0.96px;" x="503" y="324.5">skills</text>
<text style="font-size:16px;fill:#333333;font-family:'Source Sans Pro',Arial;"></text>
<circle cx="495" cy="352" r="2" style="fill:#ffffff" />
<circle cx="495" cy="390" r="2" style="fill:#ffffff" />
<circle cx="495" cy="410" r="2" style="fill:#ffffff" />
<circle cx="495" cy="430" r="2" style="fill:#ffffff" />
<circle cx="495" cy="450" r="2" style="fill:#ffffff" />
<circle cx="495" cy="470" r="2" style="fill:#ffffff" />
<text style="font-size:13px;height: 14px; font-weight:600;font-family:'Source Sans Pro',Arial;text-transform:uppercase;line-height: 14px; fill:#ffffff;letter-spacing: 0.79px;" x="525" y="355">
<tspan x="502">Trained in Point-of-Sale </tspan>
<tspan x="502" dy="18">Systems</tspan>
<tspan x="502" dy="20">Spanish</tspan>
<tspan x="502" dy="20">Loyalty Program Promotion</tspan>
<tspan x="502" dy="20">Team Member Support</tspan>
<tspan x="502" dy="20">Menu Item Recommendation</tspan>
<tspan x="502" dy="20">Western Union Agent</tspan>
<tspan x="502" dy="18">Cashier</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP3" data-skin-cd="MLP3" data-skin-name="Vision" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,900');
          </style>
</defs>
<rect xmlns="http://www.w3.org/2000/svg" x="0" y="0" style="fill:#acb75a;" height="100" width="100%" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" fill="#ffffff" font-weight="900" font-size="30">
<tspan x="15" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="15" y="80" id="PreviewUserLastName">CARTER</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="15" y="145" id="PreviewUserLastName">CONTACT</tspan>
</text>
<svg width="12px" height="9px" viewBox="0 0 512 512" x="15" y="203" style="fill:#acb75a;">
<path style="fill:#acb75a;" class="svg-section-bg" d="M484.25 330l-101.59-43.55a45.86 45.86 0 0 0-53.39 13.1l-32.7 40a311.08 311.08 0 0 1-124.19-124.12l40-32.7a45.91 45.91 0 0 0 13.1-53.42L182 27.79a45.63 45.63 0 0 0-52.31-26.61L35.5 22.89A45.59 45.59 0 0 0 0 67.5C0 313.76 199.68 512.1 444.56 512a45.58 45.58 0 0 0 44.59-35.51l21.7-94.22a45.75 45.75 0 0 0-26.6-52.27zm-41.59 134.09C225.08 463.09 49 287 48 69.3l90.69-20.9 42.09 98.22-68.09 55.71c46.39 99 98.19 150.63 197 197l55.69-68.11 98.19 42.11z" />
</svg>
<svg width="12px" height="9px" viewBox="0 0 12 9" style="fill:#acb75a;" x="15" y="222">
<path class="svg-section-bg" d="M9.06247839,8 C9.58024602,8 9.99997616,7.58026986 9.99997616,7.06250224 L9.99997616,1.43751565 C9.99997616,0.919748021 9.58024602,0.500017881 9.06247839,0.500017881 L0.937497765,0.500017881 C0.419730139,0.500017881 0,0.919748021 0,1.43751565 L0,7.06250224 C0,7.58026986 0.419730139,8 0.937497765,8 L9.06247839,8 Z M4.99998808,5.18743041 C4.54670776,5.19475461 3.89493014,4.57299859 3.56614216,4.31436273 C2.07381708,3.1458093 1.37548119,2.59117272 0.937497765,2.2344803 L0.937497765,1.43751565 L9.06247839,1.43751565 L9.06247839,2.2344803 C8.62455219,2.5911155 7.92638796,3.14563764 6.433834,4.31436273 C6.10491251,4.57309396 5.45334469,5.19467832 4.99998808,5.18743041 Z M9.06247839,7.06250224 L0.937497765,7.06250224 L0.937497765,3.43748036 C1.38503698,3.7939439 2.01970573,4.29414488 2.9870725,5.05164659 C3.41395518,5.38768247 4.16155777,6.1295058 4.99998808,6.1249854 C5.83429853,6.1295058 6.57242162,5.39843989 7.012732,5.05179917 C7.9800797,4.29431654 8.6149201,3.79398204 9.06247839,3.43748036 L9.06247839,7.06250224 Z" id="email" fill-rule="nonzero"></path>
</svg>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="15" dy="175" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="15" dy="18" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">mCARTER@address.com</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'">
<tspan x="15" y="280" id="PreviewUserLastName" fill="#4f4f4f">SKILLS</tspan>
</text>
<circle cx="15" cy="307" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="343" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="363" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="400" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="420" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="440" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="460" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="480" r="2" style="fill:#4f4f4f" />
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="22" y="310" style="font-kerning:normal">Executive team</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">leadership</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Sales Management</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Inventory report</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">generation</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Staff training</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Client/Vendor relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Customer relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Market analysis</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Process improvements</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="145" id="PreviewUserLastName">PROFESSIONAL SUMMARY</tspan>
</text>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="207" y="175" style="font-kerning:normal">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">environments. Implement cost food and retail control measures to</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> ensure operations remain within line company targets. Maximize</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> bottom-performance through P &amp; L, merchanding, staff management,</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">loss control and inventory management initiatives.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="290" id="PreviewUserLastName">EXPERIENCE</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="325">Verizon Wireless</tspan> | <tspan>San Francisco, CA</tspan>
</text>
<circle cx="207" cy="342" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="345">February 2016 – Current</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="365">District Manager</tspan>
</text>
<circle cx="207" cy="381" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="401" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="421" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="461" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="385">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<circle cx="207" cy="502" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="505">Oct 1997 – Sept 2009</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="525">Manager</tspan>
</text>
<circle cx="207" cy="542" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="562" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="582" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="622" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="545">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="665">Woodranch Restaurant</tspan> | <tspan>San Jose, CA</tspan>
</text>
<circle cx="207" cy="682" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="685">Jan 1994 – Aug 1997</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="705">General Manager</tspan>
</text>
<circle cx="207" cy="722" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="742" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="762" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="782" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="725">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="212" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="212" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="212" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="835" id="PreviewUserLastName">EDUCATION</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="870">Jun 2010</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="890">Master of Arts - Operations Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="910">San Francisco State University , San Francisco, CA</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="940">Jun 2008</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="960">Master of Arts: Business Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="980">University of San Francisco , San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR4" data-skin-cd="MLR4" data-skin-name="Blueprint" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Roboto:400,900');
        .font-bld{font-weight:900;}
        .li-disc {fill:#000;} 
      </style>
</defs>
<line x1="0" y1="90" x2="710" y2="90" stroke="#e7e7e7" stroke-width="2" />
<line x1="258" y1="90" x2="258" y2="1300" stroke="#e7e7e7" stroke-width="2" />
<rect class="rect1 svg-section-bg" fill="#305fec" height="119" width="54" x="48" />
<polygon points="73,110 103,120 29,125" style="fill:#fff;" />
<text class="font-bld" style="font-size:21px;font-family:'Roboto';fill:#fff;">
<tspan x="66" y="40" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="66" y="65" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text style="font-size:28px;font-family:'Roboto';fill:#000;" class="text-upper">
<tspan x="133" y="55" class="font-bld" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="263" y="55" class="font-bld" id="PreviewUserLastName">CARTER</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="170">Contact</text>
<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="187" width="13" height="13" viewBox="0 0 512 512">
<path fill="#000" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="48" y="220" width="12" height="12" viewBox="0 0 512 512">
<path fill="#000" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="48" y="250" width="10" height="13" viewBox="0 0 384 512">
<path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
</svg>
<text style="font-size:14px;font-weight:400;font-family:'Roboto';fill:#000;">
<tspan x="68" y="200">415-123-0012</tspan>
<tspan x="68" dy="30">mCARTER@address.com</tspan>
<tspan x="68" dy="30">123 Main Street, </tspan>
<tspan x="68" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<line x1="0" y1="320" x2="258" y2="320" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="360">professional Summary</text>
<text style="font-size:14px;fill:#000;font-family:'Roboto';font-weight:400;">
<tspan x="48" y="390">Successful sales </tspan>
<tspan x="48" dy="25">professional with 10+ </tspan>
<tspan x="48" dy="25">years experience in </tspan>
<tspan x="48" dy="25">large-scale food and retail </tspan>
<tspan x="48" dy="25">environments.</tspan>
</text>
<line x1="0" y1="520" x2="258" y2="520" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="48" y="560">SKILLS</text>
<circle cx="48" cy="585" r="1.3" class="li-disc" />
<circle cx="48" cy="635" r="1.3" class="li-disc" />
<circle cx="48" cy="660" r="1.3" class="li-disc" />
<circle cx="48" cy="710" r="1.3" class="li-disc" />
<circle cx="48" cy="760" r="1.3" class="li-disc" />
<circle cx="48" cy="810" r="1.3" class="li-disc" />
<circle cx="48" cy="785" r="1.3" class="li-disc" />
<circle cx="48" cy="835" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="58" y="590">Executive team </tspan>
<tspan x="58" dy="25">leadership</tspan>
<tspan x="58" dy="25">Sales Management</tspan>
<tspan x="58" dy="25">Inventory report </tspan>
<tspan x="58" dy="25">generation</tspan>
<tspan x="58" dy="25">Staff training and </tspan>
<tspan x="58" dy="25">development</tspan>
<tspan x="58" dy="25">Client/Vendor relation</tspan>
<tspan x="58" dy="25">Customer relations</tspan>
<tspan x="58" dy="25">Market analysis</tspan>
<tspan x="58" dy="25">Process Improvements</tspan>
</text>
<text class="font-bld section-title" style="font-size:15px; font-family:'Roboto'; fill:#305fec;text-transform:uppercase;" x="273" y="130">Experience</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="160" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">District Manager </tspan><tspan style="font-style:italic;">Sep 2009 - Current</tspan> </tspan>
<tspan x="273" dy="25" style="font-style:italic;">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="278" cy="205" r="1.3" class="li-disc" />
<circle cx="278" cy="230" r="1.3" class="li-disc" />
<circle cx="278" cy="280" r="1.3" class="li-disc" />
<circle cx="278" cy="330" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="210">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="293" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="293" dy="25">work environment.</tspan>
<tspan x="293" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="400" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">General Manager </tspan> <tspan style="font-style:italic;">Jan 1994 - Aug 1997</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="455" r="1.3" class="li-disc" />
<circle cx="278" cy="480" r="1.3" class="li-disc" />
<circle cx="278" cy="530" r="1.3" class="li-disc" />
<circle cx="278" cy="580" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="460">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="293" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="293" dy="25">$110,000 store remodel.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to </tspan>
<tspan x="293" dy="25">create strong sales.</tspan>
<tspan x="293" dy="25">Cultivated strong franchise owner relationships to </tspan>
<tspan x="293" dy="25">achieve high standards.</tspan>
</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="273" y="650" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Senior Executive </tspan><tspan style="font-style:italic;">Aug 1993 - Jan 1994</tspan></tspan>
<tspan x="273" dy="25" style="font-style:italic;">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="278" cy="705" r="1.3" class="li-disc" />
<circle cx="278" cy="755" r="1.3" class="li-disc" />
<circle cx="278" cy="805" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="293" y="710">Administered daily operations to ensure policies were </tspan>
<tspan x="293" dy="25">adhered to by sales staff.</tspan>
<tspan x="293" dy="25">Cultivated strong business relationships with customers </tspan>
<tspan x="293" dy="25">to drive business.</tspan>
<tspan x="293" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="293" dy="25">strong sales.</tspan>
</text>
<line x1="258" y1="870" x2="710" y2="870" stroke="#e7e7e7" stroke-width="2" />
<text class="font-bld section-title" style="font-size:15px;font-family:'Roboto'; text-transform:uppercase;fill:#305fec;" x="278" y="910">Education</text>
<text style="font-size:14px;font-family:'Roboto'; font-weight:400;fill:#000;">
<tspan x="278" y="940" style="fill:#000;"><tspan class="font-bld" style="text-transform:uppercase;">Master of Arts - Operations Management </tspan><tspan style="font-style:italic;">Jun 2009</tspan></tspan>
<tspan x="278" dy="25" style="fill:#000;font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR5" data-skin-cd="MLR5" data-skin-name="Revival" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Merriweather:300,400,700');
        .font-bld{font-weight:700;}
        .h1{font-size:45px; font-weight:600;}
        .h2{font-size:18px; font-weight:500;}
        .li-disc {fill:#808080;} 
        .li-white-disc {fill:#fff;}    
        .left-bg{fill:#0E9FC1;}            
        .section-bg{fill:#007D9E;}  
      </style>
</defs>
<rect x="0" y="0" width="245" height="1024" style="fill:#0E9FC1;" class="svg-sidebar-bg" />
<text class="revival-name" style="font-size:24px;font-family:'Merriweather';fill:#fff;font-weight:700">
<tspan x="18" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="18" y="75" id="PreviewUserLastName">CARTER</tspan>
</text>
<svg x="18" y="98" width="9" height="9" viewBox="0 0 512 512">
<path fill="#fff" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg x="18" y="129" width="11" height="10" viewBox="0 0 512 512">
<path fill="#fff" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg x="18" y="160" width="9" height="9" viewBox="0 0 8 8">
<path fill="#fff" d="M5.71 4.754a2.913 2.913 0 0 1-1.877.696c-.69 0-1.318-.249-1.82-.648C.815 5.062.32 5.842.26 7.483h7.247c-.045-1.857-.47-2.548-1.797-2.729z" />
<path fill="#fff" d="M2.625 4.356c.281.185.609.298.959.338.083.01.163.025.248.025.085 0 .165-.016.247-.025a2.19 2.19 0 0 0 .984-.352c.142-.096.268-.212.384-.338.365-.394.593-.917.593-1.495A2.213 2.213 0 0 0 3.832.3c-1.219 0-2.21.992-2.21 2.21 0 .583.232 1.112.603 1.507.12.128.253.243.4.34z" />
</svg>
<text style="font-size:13px;font-family:'Merriweather';fill:#fff;font-weight:bold;">
<tspan x="35" y="107">415-123-0012</tspan>
<tspan x="35" dy="30">mCARTER@address.com</tspan>
<tspan x="35" dy="30">123 Main Street,</tspan>
<tspan x="35" dy="25">SanFrancisco, CA 94122</tspan>
</text>
<rect x="0" y="225" width="245" height="28" class=" section-bg svg-heading-bg" />
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#fff;text-transform:uppercase;letter-spacing: 2.8px;" x="15" y="245">SKILLS</text>
<circle cx="17" cy="279" r="2" class="li-white-disc" />
<circle cx="17" cy="306" r="2" class="li-white-disc" />
<circle cx="17" cy="330" r="2" class="li-white-disc" />
<circle cx="17" cy="355" r="2" class="li-white-disc" />
<circle cx="17" cy="380" r="2" class="li-white-disc" />
<circle cx="17" cy="405" r="2" class="li-white-disc" />
<circle cx="17" cy="430" r="2" class="li-white-disc" />
<circle cx="17" cy="455" r="2" class="li-white-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:400;fill:#fff;">
<tspan x="25" y="285">Executive team leadership</tspan>
<tspan x="25" dy="25">Sales Management</tspan>
<tspan x="25" dy="25">Inventory report generation</tspan>
<tspan x="25" dy="25">Staff training and development</tspan>
<tspan x="25" dy="25">Client/Vendor relation</tspan>
<tspan x="25" dy="25">Customer relations</tspan>
<tspan x="25" dy="25">Market analysis</tspan>
<tspan x="25" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.4px;" x="260" y="29" class="svg-heading-color">professional Summary</text>
<text style="font-size:13px;fill:#808080;font-family:'Merriweather';font-weight:300;">
<tspan x="260" y="55">Successful sales professional with 10+ years experience in </tspan>
<tspan x="260" dy="25">large-scale food and retail environments. Implement cost</tspan>
<tspan x="260" dy="25">control measures to ensure operations remain within </tspan>
<tspan x="260" dy="25">company targets. Maximize bottom-line performance</tspan>
<tspan x="260" dy="25">through P &amp; L, merchanding, staff management, loss control </tspan>
<tspan x="260" dy="25">and inventory management initiatives.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="230" class="svg-heading-color">Experience</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="260" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">District Manager</tspan>
<tspan x="260" dy="25">Verizon Wireless</tspan>
<tspan x="260" dy="25">September 2009 - Current</tspan>
</text>
<circle cx="270" cy="335" r="2" class="li-disc" />
<circle cx="270" cy="360" r="2" class="li-disc" />
<circle cx="270" cy="410" r="2" class="li-disc" />
<circle cx="270" cy="460" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="340">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="285" dy="25">Successfully increased employee retention with a positive </tspan>
<tspan x="285" dy="25">work environment.</tspan>
<tspan x="285" dy="25">Administered daily operations to ensure policies were </tspan>
<tspan x="285" dy="25">adhered to by sales staff.</tspan>
<tspan x="285" dy="25">Cultivated strong business relationships with customers to </tspan>
<tspan x="285" dy="25">drive business.</tspan>
</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="520" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">General Manager</tspan>
<tspan x="260" dy="25">Woodranch Restaurant</tspan>
<tspan x="260" dy="25">August 2015 - October 2017</tspan>
</text>
<circle cx="270" cy="590" r="2" class="li-disc" />
<circle cx="270" cy="615" r="2" class="li-disc" />
<circle cx="270" cy="665" r="2" class="li-disc" />
<circle cx="270" cy="715" r="2" class="li-disc" />
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="285" y="595">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="285" dy="25">Developed the renovation strategy and oversaw the </tspan>
<tspan x="285" dy="25">$110,000 store remodel.</tspan>
<tspan x="285" dy="25">Directed departmental alignment on strategies to create </tspan>
<tspan x="285" dy="25">strong sales.</tspan>
<tspan x="285" dy="25">Cultivated strong franchise owner relationships to achieve </tspan>
<tspan x="285" dy="25">high standards.</tspan>
</text>
<text style="font-size:15px; font-weight:bold;font-family:'Merriweather'; fill:#007D9E;text-transform:uppercase;letter-spacing: 2.8px;" x="260" y="800" class="svg-heading-color">Education</text>
<text style="font-size:13px;font-family:'Merriweather'; font-weight:300;fill:#808080;">
<tspan x="260" y="830" style="text-transform:uppercase;fill:#0E9FC1;" class="svg-subsection-title">Master of Arts: Operations Management</tspan>
<tspan x="260" dy="25">San Francisco State University </tspan>
<tspan x="260" dy="25">San Francisco, CA </tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="AUT1" data-skin-cd="AUT1" data-skin-name="Cinematic" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="30" text-anchor="middle" style="font-size:38px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="40" x2="705" y2="40" style="stroke:#b5b5b5; stroke-width:2" />
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="225" y="147">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="160" x2="705" y2="160" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="0" y="186">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="320" y="290">Skills</tspan>
</text>
<line x1="0" y1="303" x2="705" y2="303" style="stroke:#b5b5b5; stroke-width:2" />
<circle cx="17" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333; ">
<tspan x="55" y="328">Executive team leadership</tspan>
<tspan x="55" dy="27">Inventory report generation</tspan>
<tspan x="55" dy="27">Client/Vendor relations</tspan>
<tspan x="55" dy="25">Market analysis</tspan>
</text>
<circle cx="412" cy="324" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial','Arial';fill:#333333; ">
<tspan x="445" y="328">Sales Management</tspan>
<tspan x="445" dy="27">Staff training</tspan>
<tspan x="445" dy="27">Customer relations</tspan>
<tspan x="445" dy="25">Process improvements</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="460">Experience</tspan>
</text>
<line x1="0" y1="472" x2="705" y2="472" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="495">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="495">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="522">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="522">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="580" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="632" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="557">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="50" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="50" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="50" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="675">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="675">San Jose, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="703">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="703">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="805" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="50" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="50" dy="25">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="50" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="50" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="888">Education</tspan>
</text>
<line x1="0" y1="900" x2="705" y2="900" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">Jul 2008</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR3" data-skin-cd="MLR3" data-skin-name="Greetings" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color display-none recommendedskn Lessthan3years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<path id="lowerhalf" d="M568,-142 a22,27 0 0,0 87,0" />
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=DM+Serif+Display:400');
        .font-bld{font-weight:700;}     
        .li-disc {fill:#000;}     
        .top-bdr{fill:#000; }
        .top-bdr-black{fill:transparent; stroke-width:1px;stroke:#d0d0d0;}
        .top-bdr-white{fill:white; }     
        .line{stroke-width:1px;stroke:#d0d0d0;}    
      </style>
</defs>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="173">
<path fill="#305fec" class="svg-section-bg" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="204">
<path fill="#305fec" class="svg-section-bg" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg width="14" height="14" viewBox="0 0 24 24" x="462" y="233">
<path fill="#305fec" class="svg-section-bg" d="M12 0c-4.198 0-8 3.403-8 7.602 0 4.198 3.469 9.21 8 16.398 4.531-7.188 8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z" />
</svg>
<text style="font-size:34px;font-weight:400; -webkit-font-smoothing:antialiased; font-family:'DM Serif Display','Arial'; fill:#000;">
<tspan x="48" y="60">Hi, I'm</tspan>
<tspan x="153" y="60" id="PreviewUserFirstName" class="text-capitalize">JOHN</tspan>
<tspan x="276" y="60" id="PreviewUserLastName" class="text-capitalize">CARTER</tspan>.
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="120" class="section-title">Professional Summary</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="48" y="145">Successful sales professional with 10+ years experience in </tspan>
<tspan x="48" dy="20">large-scale food and retail environments. Implement cost </tspan>
<tspan x="48" dy="20">control measures to ensure operations remain within </tspan>
<tspan x="48" dy="20">company targets. Maximize bottom-line performance </tspan>
<tspan x="48" dy="20">through P&amp;L, merchandising, staff management, loss </tspan>
<tspan x="48" dy="20">control and inventory management initiatives.</tspan>
</text>
<rect x="447" y="120" width="210" height="180" class="top-bdr-black" />

<g transform="translate(555,35)"><g><g transform="rotate(-330 18.5 34.5)"><path fill="#305fec" class="svg-name" d="M19.28 37.191l-4.75-2.086-.053-1.131 4.54-2.501-5.35.246-.087-1.898 8.5-.391.117 2.567-4.568 2.405 4.77 1.988.117 2.554-8.5.391-.087-1.898z" /></g><g transform="rotate(-330 15 41.5)"><path fill="#305fec" class="svg-name" d="M19.008 39.83l.483 1.837-8.228 2.167-.483-1.838z" /></g><g transform="rotate(-330 49 61.5)"><g><path fill="#305fec" class="svg-name" d="M8.775 68.504c.392.847 1.048 1.384 1.967 1.612l-.627 1.632c-1.393-.42-2.364-1.225-2.914-2.415-.55-1.19-.628-2.344-.234-3.462.396-1.118 1.166-1.941 2.311-2.472 1.145-.53 2.282-.58 3.411-.15 1.129.43 1.956 1.213 2.48 2.347.587 1.268.595 2.552.026 3.854l-1.711-.51c.425-.859.45-1.694.076-2.504-.3-.649-.769-1.105-1.405-1.37-.637-.264-1.314-.23-2.032.102-.718.333-1.194.817-1.427 1.453a2.372 2.372 0 0 0 .08 1.883" /></g><g><path fill="#305fec" class="svg-name" d="M20.188 73.522L21.382 75l-6.62 5.35-1.192-1.478 2.603-2.105-2.126-2.634-2.604 2.105-1.193-1.478 6.619-5.35 1.193 1.478-2.765 2.235 2.126 2.634z" /></g><g><path fill="#305fec" class="svg-name" d="M22.082 86.356l.471-1.946-2.851-2.143-1.736.995-1.616-1.215 8.05-4.597 1.47 1.105-2.173 9.015zm1.537-6.325l-2.341 1.333 1.703 1.28z" /></g><g><path fill="#305fec" class="svg-name" d="M34.747 83.207l-.68 1.55-3.878-1.703-.705 1.606 3.489 1.532-.65 1.483-3.49-1.532-.709 1.617 4.002 1.757-.675 1.54-5.741-2.521 3.42-7.796z" /></g><g><path fill="#305fec" class="svg-name" d="M34.12 91.816l1.777-8.326 1.857.397-1.424 6.67 3.548.758-.354 1.656z" /></g><g><path fill="#305fec" class="svg-name" d="M48.104 89.612l.834-5.055 1.966-.268 2.145 4.649 1.015-5.08 2.038-.278-1.793 8.837-1.399.19-2.645-5.613-1.034 6.115-1.399.191-4.092-8.034 2.038-.278z" /></g><g><path fill="#305fec" class="svg-name" d="M56.26 82.938l1.778-.668 2.99 7.97-1.778.668z" /></g><g><path fill="#305fec" class="svg-name" d="M63.675 89.134l-4.135-7.44 1.66-.924 3.312 5.96 3.17-1.763.823 1.48z" /></g><g><path fill="#305fec" class="svg-name" d="M70.435 85.038l-5.445-6.542 1.46-1.216 4.362 5.24 2.787-2.322 1.083 1.3z" /></g><g><path fill="#305fec" class="svg-name" d="M69.79 74.206l1.266-1.416 6.343 5.674-1.266 1.417z" /></g><g><path fill="#305fec" class="svg-name" d="M82.564 71.017l-1.98-.294-1.874 3.036 1.147 1.64-1.062 1.72-5.305-7.605.966-1.564 9.17 1.347zm-6.434-.958l1.539 2.211 1.12-1.813z" /></g><g><path fill="#305fec" class="svg-name" d="M81.552 58.217l3.862 3.466-.304 1.09-5.093.958 5.159 1.438-.51 1.83-8.196-2.284.689-2.476 5.091-.856-3.912-3.38.686-2.463 8.197 2.285-.51 1.83z" /></g><g><path fill="#305fec" class="svg-name" d="M80.66 52.159c.147.185.344.28.592.284.248.003.446-.105.596-.326.15-.22.33-.733.542-1.538.212-.804.52-1.427.925-1.867.405-.44.989-.654 1.751-.642.763.013 1.377.31 1.842.89.466.58.691 1.336.676 2.27-.022 1.348-.54 2.553-1.556 3.617l-1.37-1.155c.819-.905 1.234-1.747 1.247-2.526.006-.35-.065-.624-.212-.826a.723.723 0 0 0-.604-.308.71.71 0 0 0-.614.307c-.153.209-.312.624-.476 1.247-.251.987-.57 1.706-.954 2.159-.385.452-.98.672-1.789.659-.806-.013-1.425-.314-1.854-.901-.428-.588-.635-1.316-.621-2.185a5.221 5.221 0 0 1 .32-1.7 4.573 4.573 0 0 1 .851-1.472l1.372.984c-.572.73-.864 1.489-.877 2.276-.005.317.066.568.213.753" /></g><g><path fill="#305fec" class="svg-name hide-initials" style="font-size:40px; font-family:'Source Sans Pro',sans-serif,Arial;" d="M54.86 44.058l-7.793 15.41h-3.834l-7.751-15.41v17.75H29.05V33.61h8.7L45.17 49.1l7.463-15.49h8.658v28.197H54.86z" /></g></g></g><g><path fill="none" stroke="#305fec" class="svg-stroke-full" stroke-miterlimit="20" stroke-width="2.5" d="M51.19 102.69c27.338 0 49.5-22.61 49.5-50.5s-22.162-50.5-49.5-50.5-49.5 22.61-49.5 50.5 22.162 50.5 49.5 50.5z" /></g></g>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="150" class="section-title">Contact</text>
<line x1="462" y1="165" x2="637" y2="165" class="line" />
<line x1="462" y1="195" x2="637" y2="195" class="line" />
<line x1="462" y1="225" x2="637" y2="225" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="482" y="185">415-123-0012</tspan>
<tspan x="482" dy="28">mCARTER@live.com</tspan>
<tspan x="482" dy="32">123 Main Street,</tspan>
<tspan x="482" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<rect x="447" y="335" width="210" height="270" class="top-bdr-black" />
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="363" class="section-title">Skills</text>
<circle cx="462" cy="385" r="1.3" class="li-disc" />
<circle cx="462" cy="410" r="1.3" class="li-disc" />
<circle cx="462" cy="435" r="1.3" class="li-disc" />
<circle cx="462" cy="460" r="1.3" class="li-disc" />
<circle cx="462" cy="485" r="1.3" class="li-disc" />
<circle cx="462" cy="510" r="1.3" class="li-disc" />
<circle cx="462" cy="535" r="1.3" class="li-disc" />
<circle cx="462" cy="560" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="472" y="390">Executive team leadership</tspan>
<tspan x="472" dy="25">Inventory report generation</tspan>
<tspan x="472" dy="25">Client/Vendor relations</tspan>
<tspan x="472" dy="25">Market analysis</tspan>
<tspan x="472" dy="25">Sales Management</tspan>
<tspan x="472" dy="25">Staff training</tspan>
<tspan x="472" dy="25">Customer relations</tspan>
<tspan x="472" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="285" class="section-title">Experience</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="305" r="4" class="svg-stroke-full" />
<line x1="51" y1="310" x2="51" y2="495" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="310"><tspan style="font-weight:700;">District Manager </tspan> <tspan style="font-style:italic;"> Sep 2009 – Current</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="330">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="68" cy="350" r="1.3" class="li-disc" />
<circle cx="68" cy="370" r="1.3" class="li-disc" />
<circle cx="68" cy="410" r="1.3" class="li-disc" />
<circle cx="68" cy="450" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="355">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="76" dy="20">Successfully increased employee retention with a </tspan>
<tspan x="76" dy="20">positive work environment.</tspan>
<tspan x="76" dy="20">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="20">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="500" r="4" class="svg-stroke-full" />
<line x1="51" y1="505" x2="51" y2="740" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="505"><tspan style="font-weight:700;">General Manager </tspan> <tspan style="font-style:italic;"> Jan 1994 – Aug 1997</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="525">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="550" r="1.3" class="li-disc" />
<circle cx="68" cy="570" r="1.3" class="li-disc" />
<circle cx="68" cy="610" r="1.3" class="li-disc" />
<circle cx="68" cy="650" r="1.3" class="li-disc" />
<circle cx="68" cy="690" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="555">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="76" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="76" dy="20">$110,000 store remodel.</tspan>
<tspan x="76" dy="20">Directed departmental alignment on strategies to create</tspan>
<tspan x="76" dy="20">strong sales.</tspan>
<tspan x="76" dy="20">Cultivated strong franchise owner relationships to </tspan>
<tspan x="76" dy="20">achieve high standards.</tspan>
<tspan x="76" dy="20">Implemented process improvements to increase guest</tspan>
<tspan x="76" dy="20">loyalty.</tspan></text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="745" r="4" class="svg-stroke-full" />
<line x1="51" y1="750" x2="51" y2="870" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="68" y="750"><tspan style="font-weight:700;">Senior Executive </tspan> <tspan style="font-style:italic;"> Aug 1993 – Jan 1994</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="68" y="770">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="795" r="1.5" style="fill:#333333" />
<circle cx="68" cy="840" r="1.5" style="fill:#333333" />
<text style="fill:#333333;font-family:'Source Sans Pro',sans-serif,Arial;font-size:14px">
<tspan x="76" y="800">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="25">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="900" class="section-title">Education</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="925" r="4" class="svg-stroke-full" />
<line x1="51" y1="930" x2="51" y2="975" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;font-weight:400; fill:#000000;">
<tspan x="76" y="930" class="font-bld">Master of Arts, Operations Management</tspan>
<tspan x="76" dy="20" style="font-style:italic;">Jun 2011</tspan>
<tspan x="76" dy="20" style="font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="KGF1" data-skin-cd="KGF1" data-skin-name="Kingfish" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="30" class="svg-name">
<tspan x="70" y="40" style="letter-spacing: 6px;" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="255" y="40" style="letter-spacing: 6px;" id="PreviewUserLastName">CARTER</tspan>
</text>
<path fill="#305fec" d="M0 0h56v58H0z" class="svg-section-bg" />
<text fill="#fff" font-family="'Century Gothic','Arial'" font-size="20" class="font-bld">
<tspan x="10" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="30" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text font-family="'Century Gothic','Arial'" font-size="13" letter-spacing=".79">
<tspan x="530" y="15" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">mCARTER@address.com</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="83">PROFESSIONAL SUMMARY</tspan>
</text>
<line x1="0" y1="93" x2="705" y2="93" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="115">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="20">Implement cost control measures to ensure operations remain within company targets. Maximize</tspan>
<tspan x="0" dy="20">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="20">inventory management initiatives.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="200">SKILLS</tspan>
</text>
<line x1="0" y1="210" x2="705" y2="210" style="stroke:#333333; stroke-width:2" />
<circle cx="5" cy="230" r="2" style="fill:#333333" />
<circle cx="5" cy="250" r="2" style="fill:#333333" />
<circle cx="5" cy="270" r="2" style="fill:#333333" />
<circle cx="5" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="234">Executive team leadership</tspan>
<tspan x="20" dy="20">Inventory report generation</tspan>
<tspan x="20" dy="20">Client/Vendor relations</tspan>
<tspan x="20" dy="20">Market analysis</tspan>
</text>
<circle cx="275" cy="230" r="2" style="fill:#333333" />
<circle cx="275" cy="250" r="2" style="fill:#333333" />
<circle cx="275" cy="270" r="2" style="fill:#333333" />
<circle cx="275" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="290" y="234">Sales Management</tspan>
<tspan x="290" dy="20">Staff training</tspan>
<tspan x="290" dy="20">Customer relations</tspan>
<tspan x="290" dy="20">Process improvements</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="330">EXPERIENCE</tspan>
</text>
<line x1="0" y1="340" x2="705" y2="340" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="367" font-weight="700">District Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="367">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="390" r="2" style="fill:#333333" />
<circle cx="5" cy="410" r="2" style="fill:#333333" />
<circle cx="5" cy="430" r="2" style="fill:#333333" />
<circle cx="5" cy="450" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="394">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="490" font-weight="700">Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="490">Oct 1997 – Sept 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="513" r="2" style="fill:#333333" />
<circle cx="5" cy="533" r="2" style="fill:#333333" />
<circle cx="5" cy="553" r="2" style="fill:#333333" />
<circle cx="5" cy="573" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="517">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="610" font-weight="700">General Manager, <tspan>Woodranch Restaurant</tspan> - <tspan>San Jose, CA</tspan></tspan>
<tspan x="410" y="610">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="5" cy="633" r="2" style="fill:#333333" />
<circle cx="5" cy="653" r="2" style="fill:#333333" />
<circle cx="5" cy="673" r="2" style="fill:#333333" />
<circle cx="5" cy="693" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="637">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="730" font-weight="700">Senior Executive, Woodranch Restaurant - San Jose, CA</tspan>
<tspan x="400" y="730">Aug 1993 – Jan 1994</tspan>
</text>
<circle cx="5" cy="748" r="2" style="fill:#333333" />
<circle cx="5" cy="768" r="2" style="fill:#333333" />
<circle cx="5" cy="788" r="2" style="fill:#333333" />
<circle cx="5" cy="808" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="752">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="855">EDUCATION</tspan>
</text>
<line x1="0" y1="865" x2="705" y2="865" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="885">Master of Arts: Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="905">San Francisco State University - San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="935">Master of Arts: Business Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="955">University of San Francisco - San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="CLS1" data-skin-cd="CLS1" data-skin-name="Angora" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;fill:#000000;font-family: 'Georgia','Arial'" class="svg-name">
<tspan x="5" y="32" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="175" y="32" id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="53" x2="705" y2="53" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="1" y="78">123 Main Street,</tspan>
<tspan dx="1" y="78">SanFrancisco, CA 94122</tspan>
<tspan x="1" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="1" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="175">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="190" x2="705" y2="190" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="0" y="220">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="30">Implement cost control measures to ensure operations remain within company targets.Maximize </tspan>
<tspan x="0" dy="27">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="27">inventory management initiatives.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="360">Skills</tspan>
</text>
<line x1="0" y1="373" x2="705" y2="373" style="stroke:#000; stroke-width:2" />
<circle cx="5" cy="394" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="455" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="40" y="400">Executive team leadership</tspan>
<tspan x="40" dy="28">Inventory report generation</tspan>
<tspan x="40" dy="28">Client/Vendor relations</tspan>
<tspan x="40" dy="28">Market analysis</tspan>
</text>
<circle cx="275" cy="395" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="450" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="307" y="400">Sales Management</tspan>
<tspan x="307" dy="28">Staff training</tspan>
<tspan x="307" dy="28">Customer relations</tspan>
<tspan x="307" dy="28">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="532">Experience</tspan>
</text>
<line x1="0" y1="550" x2="705" y2="550" style="stroke:#000000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="575">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="680" y="575">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="605">Verizon Wireless -</tspan>
<tspan dx="1" y="605">San Francisco, CA</tspan>
</text>
<circle cx="5" cy="630" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="660" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="688" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="715" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="40" y="633">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="40" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="40" dy="30">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="765">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="765">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="790">Woodranch Restaurant -</tspan>
<tspan dx="1" y="790">San Jose, CA</tspan>
</text>
<circle cx="5" cy="815" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="850" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="878" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="905" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="38" y="822">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="950">Education</tspan>
</text>
<line x1="0" y1="965" x2="705" y2="965" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="990">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="990">Mar 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="1015">San Francisco State University -</tspan>
<tspan dx="1" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLP3" data-skin-cd="MLP3" data-skin-name="Vision" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc full-page-resume">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style type="text/css">
       @import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,900');
          </style>
</defs>
<rect xmlns="http://www.w3.org/2000/svg" x="0" y="0" style="fill:#acb75a;" height="100" width="100%" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" fill="#ffffff" font-weight="900" font-size="30">
<tspan x="15" y="45" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="15" y="80" id="PreviewUserLastName">CARTER</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="15" y="145" id="PreviewUserLastName">CONTACT</tspan>
</text>
<svg width="12px" height="9px" viewBox="0 0 512 512" x="15" y="203" style="fill:#acb75a;">
<path style="fill:#acb75a;" class="svg-section-bg" d="M484.25 330l-101.59-43.55a45.86 45.86 0 0 0-53.39 13.1l-32.7 40a311.08 311.08 0 0 1-124.19-124.12l40-32.7a45.91 45.91 0 0 0 13.1-53.42L182 27.79a45.63 45.63 0 0 0-52.31-26.61L35.5 22.89A45.59 45.59 0 0 0 0 67.5C0 313.76 199.68 512.1 444.56 512a45.58 45.58 0 0 0 44.59-35.51l21.7-94.22a45.75 45.75 0 0 0-26.6-52.27zm-41.59 134.09C225.08 463.09 49 287 48 69.3l90.69-20.9 42.09 98.22-68.09 55.71c46.39 99 98.19 150.63 197 197l55.69-68.11 98.19 42.11z" />
</svg>
<svg width="12px" height="9px" viewBox="0 0 12 9" style="fill:#acb75a;" x="15" y="222">
<path class="svg-section-bg" d="M9.06247839,8 C9.58024602,8 9.99997616,7.58026986 9.99997616,7.06250224 L9.99997616,1.43751565 C9.99997616,0.919748021 9.58024602,0.500017881 9.06247839,0.500017881 L0.937497765,0.500017881 C0.419730139,0.500017881 0,0.919748021 0,1.43751565 L0,7.06250224 C0,7.58026986 0.419730139,8 0.937497765,8 L9.06247839,8 Z M4.99998808,5.18743041 C4.54670776,5.19475461 3.89493014,4.57299859 3.56614216,4.31436273 C2.07381708,3.1458093 1.37548119,2.59117272 0.937497765,2.2344803 L0.937497765,1.43751565 L9.06247839,1.43751565 L9.06247839,2.2344803 C8.62455219,2.5911155 7.92638796,3.14563764 6.433834,4.31436273 C6.10491251,4.57309396 5.45334469,5.19467832 4.99998808,5.18743041 Z M9.06247839,7.06250224 L0.937497765,7.06250224 L0.937497765,3.43748036 C1.38503698,3.7939439 2.01970573,4.29414488 2.9870725,5.05164659 C3.41395518,5.38768247 4.16155777,6.1295058 4.99998808,6.1249854 C5.83429853,6.1295058 6.57242162,5.39843989 7.012732,5.05179917 C7.9800797,4.29431654 8.6149201,3.79398204 9.06247839,3.43748036 L9.06247839,7.06250224 Z" id="email" fill-rule="nonzero"></path>
</svg>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="15" dy="175" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="15" dy="18" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="30" dy="18" style="font-kerning:normal">mCARTER@address.com</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'">
<tspan x="15" y="280" id="PreviewUserLastName" fill="#4f4f4f">SKILLS</tspan>
</text>
<circle cx="15" cy="307" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="343" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="363" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="400" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="420" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="440" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="460" r="2" style="fill:#4f4f4f" />
<circle cx="15" cy="480" r="2" style="fill:#4f4f4f" />
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="22" y="310" style="font-kerning:normal">Executive team</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">leadership</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Sales Management</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Inventory report</tspan>
<tspan x="22" dy="17" style="font-kerning:normal">generation</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Staff training</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Client/Vendor relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Customer relations</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Market analysis</tspan>
<tspan x="22" dy="20" style="font-kerning:normal">Process improvements</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="145" id="PreviewUserLastName">PROFESSIONAL SUMMARY</tspan>
</text>
<text font-size="13" fill="#4f4f4f" font-family="'Source Sans Pro','Arial'">
<tspan x="207" y="175" style="font-kerning:normal">Successful sales professional with 10+ years experience in large-scale</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">environments. Implement cost food and retail control measures to</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> ensure operations remain within line company targets. Maximize</tspan>
<tspan x="207" dy="18" style="font-kerning:normal"> bottom-performance through P &amp; L, merchanding, staff management,</tspan>
<tspan x="207" dy="18" style="font-kerning:normal">loss control and inventory management initiatives.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="290" id="PreviewUserLastName">EXPERIENCE</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="325">Verizon Wireless</tspan> | <tspan>San Francisco, CA</tspan>
</text>
<circle cx="207" cy="342" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="345">February 2016 – Current</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="365">District Manager</tspan>
</text>
<circle cx="207" cy="381" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="401" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="421" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="461" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="385">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<circle cx="207" cy="502" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="505">Oct 1997 – Sept 2009</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="525">Manager</tspan>
</text>
<circle cx="207" cy="542" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="562" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="582" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="622" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="545">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="212" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="212" dy="20">Administered daily operations to ensure policies were adhered to by sales</tspan>
<tspan x="212" dy="20">staff.</tspan>
<tspan x="212" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="665">Woodranch Restaurant</tspan> | <tspan>San Jose, CA</tspan>
</text>
<circle cx="207" cy="682" r="2" style="fill:#acb75a" class="svg-section-bg" />
<text font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="685">Jan 1994 – Aug 1997</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="212" y="705">General Manager</tspan>
</text>
<circle cx="207" cy="722" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="742" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="762" r="2" style="fill:#4f4f4f" />
<circle cx="207" cy="782" r="2" style="fill:#4f4f4f" />
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13">
<tspan x="212" y="725">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="212" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="212" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="212" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text font-size="16" font-weight="900" letter-spacing="2" font-family="'Source Sans Pro','Arial'" fill="#4f4f4f">
<tspan x="207" y="835" id="PreviewUserLastName">EDUCATION</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="870">Jun 2010</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="890">Master of Arts - Operations Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="910">San Francisco State University , San Francisco, CA</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F">
<tspan x="207" y="940">Jun 2008</tspan>
</text>
<text fill="#4f4f4f" font-family="'Source Sans Pro','Arial'" font-size="13" font-weight="700">
<tspan x="207" y="960">Master of Arts: Business Management</tspan>
</text>
<text font-family="'Source Sans Pro','Arial'" font-size="13" fill="#4F4F4F" font-weight="700">
<tspan x="207" y="980">University of San Francisco , San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="CBG2" data-skin-cd="CBG2" data-skin-name="Splendid" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<style>
      .h1{font-size:45px; font-weight:600;}
      .h2{font-size:18px; font-weight:500;}
      .li-disc {fill:#333333;}
    </style>
</defs>
<line x1="0" y1="0" x2="100%" y2="0" style="stroke:#939598; stroke-width:2" />
<text x="50%" y="40" text-anchor="middle" style="font-size:45px; font-weight:700;font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-variant: small-caps;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="55" x2="100%" y2="55" style="stroke:#939598; stroke-width:1" />
<path d="M 0 60 L 720 60" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-size:15px; font-family:'Palatino Linotype', 'Arial';fill:#333333;">
<tspan x="60" y="95">123 Main Street, SanFrancisco, CA 94122 ■ 781-669-5989 ■ mCARTER@live.com</tspan>
</text>
<path d="M 0 135 L 240 135" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px; font-weight:700;" class="section-title">
<tspan x="260" y="140">Professional Summary</tspan>
</text>
<path d="M 500 135 L 710 135" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="172">
Accomplished operations executive with a successful track record overseeing marketing, IT,
</tspan>
<tspan x="0" dy="35">HR/training, and real estate in company and franchise operations for a large regional chain.</tspan>
</text>
<path d="M 0 257 L 295 257" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="330" y="262">Skills</tspan>
</text>
<path d="M 410 257 L 700 257" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<circle cx="7" cy="295" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="328" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="358" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="388" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="300">Executive Team Leadership</tspan>
<tspan x="20" dy="30">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="20" dy="33">Expertise in New England Real Estate</tspan>
<tspan x="20" dy="33">Client/Vendor Relations</tspan>
</text>
<circle cx="363" cy="290" r="1.5" class="li-disc"></circle>
<circle cx="363" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="363" cy="390" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="378" y="298">Marketing/Product Line Development</tspan>
<tspan x="378" dy="33">Staff/Training Development Policy</tspan>
<tspan x="378" dy="33">Development</tspan>
<tspan x="378" dy="33">Process Improvement</tspan>
</text>
<path d="M 0 452 L 290 452" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="310" y="455">Experience</tspan>
</text>
<text style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="490" style="font-weight:700;">Executive Vice President, </tspan>
<tspan dx="2" y="490">09/2011 to 03/2013</tspan>
<tspan x="0" dy="30" style="font-weight:700;">Verizon Wireless –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<path d="M 430 452 L 710 452" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<circle cx="7" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="615" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="555">Led all operations involved with running the brand including marketing, IT, HR/training,</tspan>
<tspan x="20" dy="33">development/construction, real estate, and P&amp;L for 200 store locations.</tspan>
<tspan x="20" dy="33">Oversaw operations for all company and franchise locations.</tspan>
</text>
<text style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="665" style="font-weight:700;">Executive Vice President,</tspan>
<tspan dx="2" y="665">09/2011 to 03/2013</tspan>
<tspan x="0" dy="35" style="font-weight:700;">Verizon Wireless -</tspan>
<tspan dx="2" dy="0"> San Francisco, CA</tspan>
</text>
<circle cx="7" cy="730" r="1.5" class="li-disc"></circle>
<circle cx="7" cy="790" r="1.5" class="li-disc"></circle>
<text style="font-size:15px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="20" y="735">Led all operations involved with running the brand including marketing, IT, HR/training,</tspan>
<tspan x="20" dy="33">development/construction, real estate, and P&amp;L for 200 store locations.</tspan>
<tspan x="20" dy="33">Oversaw operations for all company and franchise locations.</tspan>
</text>
<path d="M 0 862 L 290 862" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
<text style="font-family:'Palatino Linotype','Times New Roman';fill:#000000;font-size:18px;font-weight:700;" class="section-title">
<tspan x="320" y="868">Education</tspan>
</text>
<text class="fnt-weight" style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="900" style="font-weight:700;">
Associate of Science :
</tspan>
<tspan dx="2" y="900">
Mar 2013
</tspan>
<tspan x="0" dy="35" style="font-weight:700;">San Francisco State University –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<text class="fnt-weight" style="font-size:16px;font-family:'Palatino Linotype','Times New Roman';fill:#333333;">
<tspan x="0" y="980" style="font-weight:700;">
Associate of Science :
</tspan>
<tspan dx="2" y="980">
Jun 2011
</tspan>
<tspan x="0" dy="35" style="font-weight:700;">San Francisco State University –</tspan>
<tspan dx="2" dy="0">San Francisco, CA</tspan>
</text>
<path d="M 430 862 L 710 862" stroke="#939598" stroke-linecap="round" stroke-width="2" stroke-dasharray="1,5" fill="none" />
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="AUT1" data-skin-cd="AUT1" data-skin-name="Cinematic" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="30" text-anchor="middle" style="font-size:38px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="40" x2="705" y2="40" style="stroke:#b5b5b5; stroke-width:2" />
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="225" y="147">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="160" x2="705" y2="160" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="0" y="186">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="320" y="290">Skills</tspan>
</text>
<line x1="0" y1="303" x2="705" y2="303" style="stroke:#b5b5b5; stroke-width:2" />
<circle cx="17" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333; ">
<tspan x="55" y="328">Executive team leadership</tspan>
<tspan x="55" dy="27">Inventory report generation</tspan>
<tspan x="55" dy="27">Client/Vendor relations</tspan>
<tspan x="55" dy="25">Market analysis</tspan>
</text>
<circle cx="412" cy="324" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial','Arial';fill:#333333; ">
<tspan x="445" y="328">Sales Management</tspan>
<tspan x="445" dy="27">Staff training</tspan>
<tspan x="445" dy="27">Customer relations</tspan>
<tspan x="445" dy="25">Process improvements</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="460">Experience</tspan>
</text>
<line x1="0" y1="472" x2="705" y2="472" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="495">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="495">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="522">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="522">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="580" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="632" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="557">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="50" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="50" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="50" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="675">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="675">San Jose, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="703">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="703">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="805" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="50" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="50" dy="25">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="50" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="50" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="888">Education</tspan>
</text>
<line x1="0" y1="900" x2="705" y2="900" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">Jul 2008</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="MLR3" data-skin-cd="MLR3" data-skin-name="Greetings" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color display-none recommendedskn 3to5years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="710" height="1024" viewBox="0 0 710 1024">
<defs>
<path id="lowerhalf" d="M568,-142 a22,27 0 0,0 87,0" />
<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=DM+Serif+Display:400');
        .font-bld{font-weight:700;}     
        .li-disc {fill:#000;}     
        .top-bdr{fill:#000; }
        .top-bdr-black{fill:transparent; stroke-width:1px;stroke:#d0d0d0;}
        .top-bdr-white{fill:white; }     
        .line{stroke-width:1px;stroke:#d0d0d0;}    
      </style>
</defs>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="173">
<path fill="#305fec" class="svg-section-bg" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</svg>
<svg width="12" height="12" viewBox="0 0 512 512" x="462" y="204">
<path fill="#305fec" class="svg-section-bg" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</svg>
<svg width="14" height="14" viewBox="0 0 24 24" x="462" y="233">
<path fill="#305fec" class="svg-section-bg" d="M12 0c-4.198 0-8 3.403-8 7.602 0 4.198 3.469 9.21 8 16.398 4.531-7.188 8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z" />
</svg>
<text style="font-size:34px;font-weight:400; -webkit-font-smoothing:antialiased; font-family:'DM Serif Display','Arial'; fill:#000;">
<tspan x="48" y="60">Hi, I'm</tspan>
<tspan x="153" y="60" id="PreviewUserFirstName" class="text-capitalize">JOHN</tspan>
<tspan x="276" y="60" id="PreviewUserLastName" class="text-capitalize">CARTER</tspan>.
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="120" class="section-title">Professional Summary</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="48" y="145">Successful sales professional with 10+ years experience in </tspan>
<tspan x="48" dy="20">large-scale food and retail environments. Implement cost </tspan>
<tspan x="48" dy="20">control measures to ensure operations remain within </tspan>
<tspan x="48" dy="20">company targets. Maximize bottom-line performance </tspan>
<tspan x="48" dy="20">through P&amp;L, merchandising, staff management, loss </tspan>
<tspan x="48" dy="20">control and inventory management initiatives.</tspan>
</text>
<rect x="447" y="120" width="210" height="180" class="top-bdr-black" />

<g transform="translate(555,35)"><g><g transform="rotate(-330 18.5 34.5)"><path fill="#305fec" class="svg-name" d="M19.28 37.191l-4.75-2.086-.053-1.131 4.54-2.501-5.35.246-.087-1.898 8.5-.391.117 2.567-4.568 2.405 4.77 1.988.117 2.554-8.5.391-.087-1.898z" /></g><g transform="rotate(-330 15 41.5)"><path fill="#305fec" class="svg-name" d="M19.008 39.83l.483 1.837-8.228 2.167-.483-1.838z" /></g><g transform="rotate(-330 49 61.5)"><g><path fill="#305fec" class="svg-name" d="M8.775 68.504c.392.847 1.048 1.384 1.967 1.612l-.627 1.632c-1.393-.42-2.364-1.225-2.914-2.415-.55-1.19-.628-2.344-.234-3.462.396-1.118 1.166-1.941 2.311-2.472 1.145-.53 2.282-.58 3.411-.15 1.129.43 1.956 1.213 2.48 2.347.587 1.268.595 2.552.026 3.854l-1.711-.51c.425-.859.45-1.694.076-2.504-.3-.649-.769-1.105-1.405-1.37-.637-.264-1.314-.23-2.032.102-.718.333-1.194.817-1.427 1.453a2.372 2.372 0 0 0 .08 1.883" /></g><g><path fill="#305fec" class="svg-name" d="M20.188 73.522L21.382 75l-6.62 5.35-1.192-1.478 2.603-2.105-2.126-2.634-2.604 2.105-1.193-1.478 6.619-5.35 1.193 1.478-2.765 2.235 2.126 2.634z" /></g><g><path fill="#305fec" class="svg-name" d="M22.082 86.356l.471-1.946-2.851-2.143-1.736.995-1.616-1.215 8.05-4.597 1.47 1.105-2.173 9.015zm1.537-6.325l-2.341 1.333 1.703 1.28z" /></g><g><path fill="#305fec" class="svg-name" d="M34.747 83.207l-.68 1.55-3.878-1.703-.705 1.606 3.489 1.532-.65 1.483-3.49-1.532-.709 1.617 4.002 1.757-.675 1.54-5.741-2.521 3.42-7.796z" /></g><g><path fill="#305fec" class="svg-name" d="M34.12 91.816l1.777-8.326 1.857.397-1.424 6.67 3.548.758-.354 1.656z" /></g><g><path fill="#305fec" class="svg-name" d="M48.104 89.612l.834-5.055 1.966-.268 2.145 4.649 1.015-5.08 2.038-.278-1.793 8.837-1.399.19-2.645-5.613-1.034 6.115-1.399.191-4.092-8.034 2.038-.278z" /></g><g><path fill="#305fec" class="svg-name" d="M56.26 82.938l1.778-.668 2.99 7.97-1.778.668z" /></g><g><path fill="#305fec" class="svg-name" d="M63.675 89.134l-4.135-7.44 1.66-.924 3.312 5.96 3.17-1.763.823 1.48z" /></g><g><path fill="#305fec" class="svg-name" d="M70.435 85.038l-5.445-6.542 1.46-1.216 4.362 5.24 2.787-2.322 1.083 1.3z" /></g><g><path fill="#305fec" class="svg-name" d="M69.79 74.206l1.266-1.416 6.343 5.674-1.266 1.417z" /></g><g><path fill="#305fec" class="svg-name" d="M82.564 71.017l-1.98-.294-1.874 3.036 1.147 1.64-1.062 1.72-5.305-7.605.966-1.564 9.17 1.347zm-6.434-.958l1.539 2.211 1.12-1.813z" /></g><g><path fill="#305fec" class="svg-name" d="M81.552 58.217l3.862 3.466-.304 1.09-5.093.958 5.159 1.438-.51 1.83-8.196-2.284.689-2.476 5.091-.856-3.912-3.38.686-2.463 8.197 2.285-.51 1.83z" /></g><g><path fill="#305fec" class="svg-name" d="M80.66 52.159c.147.185.344.28.592.284.248.003.446-.105.596-.326.15-.22.33-.733.542-1.538.212-.804.52-1.427.925-1.867.405-.44.989-.654 1.751-.642.763.013 1.377.31 1.842.89.466.58.691 1.336.676 2.27-.022 1.348-.54 2.553-1.556 3.617l-1.37-1.155c.819-.905 1.234-1.747 1.247-2.526.006-.35-.065-.624-.212-.826a.723.723 0 0 0-.604-.308.71.71 0 0 0-.614.307c-.153.209-.312.624-.476 1.247-.251.987-.57 1.706-.954 2.159-.385.452-.98.672-1.789.659-.806-.013-1.425-.314-1.854-.901-.428-.588-.635-1.316-.621-2.185a5.221 5.221 0 0 1 .32-1.7 4.573 4.573 0 0 1 .851-1.472l1.372.984c-.572.73-.864 1.489-.877 2.276-.005.317.066.568.213.753" /></g><g><path fill="#305fec" class="svg-name hide-initials" style="font-size:40px; font-family:'Source Sans Pro',sans-serif,Arial;" d="M54.86 44.058l-7.793 15.41h-3.834l-7.751-15.41v17.75H29.05V33.61h8.7L45.17 49.1l7.463-15.49h8.658v28.197H54.86z" /></g></g></g><g><path fill="none" stroke="#305fec" class="svg-stroke-full" stroke-miterlimit="20" stroke-width="2.5" d="M51.19 102.69c27.338 0 49.5-22.61 49.5-50.5s-22.162-50.5-49.5-50.5-49.5 22.61-49.5 50.5 22.162 50.5 49.5 50.5z" /></g></g>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="150" class="section-title">Contact</text>
<line x1="462" y1="165" x2="637" y2="165" class="line" />
<line x1="462" y1="195" x2="637" y2="195" class="line" />
<line x1="462" y1="225" x2="637" y2="225" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="482" y="185">415-123-0012</tspan>
<tspan x="482" dy="28">mCARTER@live.com</tspan>
<tspan x="482" dy="32">123 Main Street,</tspan>
<tspan x="482" dy="20">SanFrancisco, CA 94122</tspan>
</text>
<rect x="447" y="335" width="210" height="270" class="top-bdr-black" />
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="462" y="363" class="section-title">Skills</text>
<circle cx="462" cy="385" r="1.3" class="li-disc" />
<circle cx="462" cy="410" r="1.3" class="li-disc" />
<circle cx="462" cy="435" r="1.3" class="li-disc" />
<circle cx="462" cy="460" r="1.3" class="li-disc" />
<circle cx="462" cy="485" r="1.3" class="li-disc" />
<circle cx="462" cy="510" r="1.3" class="li-disc" />
<circle cx="462" cy="535" r="1.3" class="li-disc" />
<circle cx="462" cy="560" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="472" y="390">Executive team leadership</tspan>
<tspan x="472" dy="25">Inventory report generation</tspan>
<tspan x="472" dy="25">Client/Vendor relations</tspan>
<tspan x="472" dy="25">Market analysis</tspan>
<tspan x="472" dy="25">Sales Management</tspan>
<tspan x="472" dy="25">Staff training</tspan>
<tspan x="472" dy="25">Customer relations</tspan>
<tspan x="472" dy="25">Process Improvements</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="285" class="section-title">Experience</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="305" r="4" class="svg-stroke-full" />
<line x1="51" y1="310" x2="51" y2="495" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="310"><tspan style="font-weight:700;">District Manager </tspan> <tspan style="font-style:italic;"> Sep 2009 – Current</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="330">Verizon Wireless, San Francisco, CA</tspan>
</text>
<circle cx="68" cy="350" r="1.3" class="li-disc" />
<circle cx="68" cy="370" r="1.3" class="li-disc" />
<circle cx="68" cy="410" r="1.3" class="li-disc" />
<circle cx="68" cy="450" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="355">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="76" dy="20">Successfully increased employee retention with a </tspan>
<tspan x="76" dy="20">positive work environment.</tspan>
<tspan x="76" dy="20">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="20">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="500" r="4" class="svg-stroke-full" />
<line x1="51" y1="505" x2="51" y2="740" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="63" y="505"><tspan style="font-weight:700;">General Manager </tspan> <tspan style="font-style:italic;"> Jan 1994 – Aug 1997</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="63" y="525">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="550" r="1.3" class="li-disc" />
<circle cx="68" cy="570" r="1.3" class="li-disc" />
<circle cx="68" cy="610" r="1.3" class="li-disc" />
<circle cx="68" cy="650" r="1.3" class="li-disc" />
<circle cx="68" cy="690" r="1.3" class="li-disc" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;">
<tspan x="76" y="555">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="76" dy="20">Developed the renovation strategy and oversaw the </tspan>
<tspan x="76" dy="20">$110,000 store remodel.</tspan>
<tspan x="76" dy="20">Directed departmental alignment on strategies to create</tspan>
<tspan x="76" dy="20">strong sales.</tspan>
<tspan x="76" dy="20">Cultivated strong franchise owner relationships to </tspan>
<tspan x="76" dy="20">achieve high standards.</tspan>
<tspan x="76" dy="20">Implemented process improvements to increase guest</tspan>
<tspan x="76" dy="20">loyalty.</tspan></text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="745" r="4" class="svg-stroke-full" />
<line x1="51" y1="750" x2="51" y2="870" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;fill:#000000;letter-spacing: 0.710px;">
<tspan x="68" y="750"><tspan style="font-weight:700;">Senior Executive </tspan> <tspan style="font-style:italic;"> Aug 1993 – Jan 1994</tspan></tspan>
</text>
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial; font-weight:400;fill:#000000;letter-spacing: 0.710px;font-style:italic;">
<tspan x="68" y="770">Woodranch Restaurant, San Jose, CA</tspan>
</text>
<circle cx="68" cy="795" r="1.5" style="fill:#333333" />
<circle cx="68" cy="840" r="1.5" style="fill:#333333" />
<text style="fill:#333333;font-family:'Source Sans Pro',sans-serif,Arial;font-size:14px">
<tspan x="76" y="800">Administered daily operations to ensure policies were</tspan>
<tspan x="76" dy="20">adhered to by sales staff.</tspan>
<tspan x="76" dy="25">Cultivated strong business relationships with customers</tspan>
<tspan x="76" dy="20">to drive business.</tspan>
</text>
<text style="font-size:15px; font-weight:400;font-family:'DM Serif Display','Arial'; fill:#305fec;" x="48" y="900" class="section-title">Education</text>
<circle fill-opacity="0.05" stroke="#305fec" style="stroke-width:2px;fill:#fff;" cx="51" cy="925" r="4" class="svg-stroke-full" />
<line x1="51" y1="930" x2="51" y2="975" class="line" />
<text style="font-size:14px;font-family:'Source Sans Pro',sans-serif,Arial;font-weight:400; fill:#000000;">
<tspan x="76" y="930" class="font-bld">Master of Arts, Operations Management</tspan>
<tspan x="76" dy="20" style="font-style:italic;">Jun 2011</tspan>
<tspan x="76" dy="20" style="font-style:italic;">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="KGF1" data-skin-cd="KGF1" data-skin-name="Kingfish" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="30" class="svg-name">
<tspan x="70" y="40" style="letter-spacing: 6px;" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="255" y="40" style="letter-spacing: 6px;" id="PreviewUserLastName">CARTER</tspan>
</text>
<path fill="#305fec" d="M0 0h56v58H0z" class="svg-section-bg" />
<text fill="#fff" font-family="'Century Gothic','Arial'" font-size="20" class="font-bld">
<tspan x="10" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="30" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text font-family="'Century Gothic','Arial'" font-size="13" letter-spacing=".79">
<tspan x="530" y="15" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">mCARTER@address.com</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="83">PROFESSIONAL SUMMARY</tspan>
</text>
<line x1="0" y1="93" x2="705" y2="93" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="115">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="20">Implement cost control measures to ensure operations remain within company targets. Maximize</tspan>
<tspan x="0" dy="20">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="20">inventory management initiatives.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="200">SKILLS</tspan>
</text>
<line x1="0" y1="210" x2="705" y2="210" style="stroke:#333333; stroke-width:2" />
<circle cx="5" cy="230" r="2" style="fill:#333333" />
<circle cx="5" cy="250" r="2" style="fill:#333333" />
<circle cx="5" cy="270" r="2" style="fill:#333333" />
<circle cx="5" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="234">Executive team leadership</tspan>
<tspan x="20" dy="20">Inventory report generation</tspan>
<tspan x="20" dy="20">Client/Vendor relations</tspan>
<tspan x="20" dy="20">Market analysis</tspan>
</text>
<circle cx="275" cy="230" r="2" style="fill:#333333" />
<circle cx="275" cy="250" r="2" style="fill:#333333" />
<circle cx="275" cy="270" r="2" style="fill:#333333" />
<circle cx="275" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="290" y="234">Sales Management</tspan>
<tspan x="290" dy="20">Staff training</tspan>
<tspan x="290" dy="20">Customer relations</tspan>
<tspan x="290" dy="20">Process improvements</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="330">EXPERIENCE</tspan>
</text>
<line x1="0" y1="340" x2="705" y2="340" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="367" font-weight="700">District Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="367">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="390" r="2" style="fill:#333333" />
<circle cx="5" cy="410" r="2" style="fill:#333333" />
<circle cx="5" cy="430" r="2" style="fill:#333333" />
<circle cx="5" cy="450" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="394">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="490" font-weight="700">Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="490">Oct 1997 – Sept 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="513" r="2" style="fill:#333333" />
<circle cx="5" cy="533" r="2" style="fill:#333333" />
<circle cx="5" cy="553" r="2" style="fill:#333333" />
<circle cx="5" cy="573" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="517">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="610" font-weight="700">General Manager, <tspan>Woodranch Restaurant</tspan> - <tspan>San Jose, CA</tspan></tspan>
<tspan x="410" y="610">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="5" cy="633" r="2" style="fill:#333333" />
<circle cx="5" cy="653" r="2" style="fill:#333333" />
<circle cx="5" cy="673" r="2" style="fill:#333333" />
<circle cx="5" cy="693" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="637">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="730" font-weight="700">Senior Executive, Woodranch Restaurant - San Jose, CA</tspan>
<tspan x="400" y="730">Aug 1993 – Jan 1994</tspan>
</text>
<circle cx="5" cy="748" r="2" style="fill:#333333" />
<circle cx="5" cy="768" r="2" style="fill:#333333" />
<circle cx="5" cy="788" r="2" style="fill:#333333" />
<circle cx="5" cy="808" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="752">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="855">EDUCATION</tspan>
</text>
<line x1="0" y1="865" x2="705" y2="865" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="885">Master of Arts: Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="905">San Francisco State University - San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="935">Master of Arts: Business Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="955">University of San Francisco - San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="CLS1" data-skin-cd="CLS1" data-skin-name="Angora" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;fill:#000000;font-family: 'Georgia','Arial'" class="svg-name">
<tspan x="5" y="32" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="175" y="32" id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="53" x2="705" y2="53" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="1" y="78">123 Main Street,</tspan>
<tspan dx="1" y="78">SanFrancisco, CA 94122</tspan>
<tspan x="1" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="1" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="175">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="190" x2="705" y2="190" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="0" y="220">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="30">Implement cost control measures to ensure operations remain within company targets.Maximize </tspan>
<tspan x="0" dy="27">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="27">inventory management initiatives.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="1" y="360">Skills</tspan>
</text>
<line x1="0" y1="373" x2="705" y2="373" style="stroke:#000; stroke-width:2" />
<circle cx="5" cy="394" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="455" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="40" y="400">Executive team leadership</tspan>
<tspan x="40" dy="28">Inventory report generation</tspan>
<tspan x="40" dy="28">Client/Vendor relations</tspan>
<tspan x="40" dy="28">Market analysis</tspan>
</text>
<circle cx="275" cy="395" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="422" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="450" r="1.5" style="fill:#333333"></circle>
<circle cx="275" cy="480" r="1.5" style="fill:#333333"></circle>
<text style="fill:#333333;font-family:'Georgia','Arial';font-size:16px">
<tspan x="307" y="400">Sales Management</tspan>
<tspan x="307" dy="28">Staff training</tspan>
<tspan x="307" dy="28">Customer relations</tspan>
<tspan x="307" dy="28">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="532">Experience</tspan>
</text>
<line x1="0" y1="550" x2="705" y2="550" style="stroke:#000000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="575">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="680" y="575">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic;">
<tspan x="0" y="605">Verizon Wireless -</tspan>
<tspan dx="1" y="605">San Francisco, CA</tspan>
</text>
<circle cx="5" cy="630" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="660" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="688" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="715" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="40" y="633">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="40" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="40" dy="30">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="765">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="765">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="790">Woodranch Restaurant -</tspan>
<tspan dx="1" y="790">San Jose, CA</tspan>
</text>
<circle cx="5" cy="815" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="850" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="878" r="1.5" style="fill:#333333"></circle>
<circle cx="5" cy="905" r="1.5" style="fill:#333333"></circle>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial'">
<tspan x="38" y="822">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text style="font-size:23px; font-weight:700;fill:#000000;font-family:'Arial'" class="section-title">
<tspan x="5" y="950">Education</tspan>
</text>
<line x1="0" y1="965" x2="705" y2="965" style="stroke:#000; stroke-width:2" />
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="990">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="680" y="990">Mar 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Georgia','Arial';font-style:italic">
<tspan x="0" y="1015">San Francisco State University -</tspan>
<tspan dx="1" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="UPT1" data-skin-cd="UPT1" data-skin-name="Empire" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="100%" y="30" text-anchor="end" style="font-size:38px; font-weight:700;font-family:'Century Gothic','Arial'">
<tspan id="PreviewUserFirstName" class="text-upper">JOHN</tspan>
<tspan style="fill:#436975;" class="svg-last-name svg-name" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="0" y="50" style="fill:#436975;" height="30" width="100%" class="svg-section-bg" />
<text text-anchor="end" style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial';fill:#fff;text-align:center;width:100%">
<tspan x="99%" y="70">123 Main Street, SanFrancisco, CA 94122 | 508-278-2542 | 781-669-5989 | mCARTER@live.com </tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="138">Professional Summary</tspan>
</text>
<line x1="0" y1="147" x2="100%" y2="147" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="175">Accomplished operations executive with a successful track record overseeing marketing, IT, HR/training</tspan>
<tspan x="0" dy="30">and real estate in company and franchise operations for a large regional chain.</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="260">Skills</tspan>
</text>
<line x1="0" y1="270" x2="100%" y2="270" style="stroke:#333; stroke-width:1" />
<circle cx="25" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="335" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="365" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="397" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="40" y="310">Executive Team Leadership</tspan>
<tspan x="40" dy="29">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="40" dy="33">Expertise in New England Real Estate</tspan>
<tspan x="40" dy="33">Client/Vendor Relations</tspan>
</text>
<circle cx="373" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="333" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="400" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="388" y="310">Marketing/Product Line Development</tspan>
<tspan x="388" dy="30">Staff/Training Development Policy</tspan>
<tspan x="388" dy="30">Development</tspan>
<tspan x="388" dy="34">Process Improvement</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="460">Experience</tspan>
</text>
<line x1="0" y1="470" x2="100%" y2="470" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="507" style="font-weight:600;">District Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Verizon Wireless</tspan>
<tspan dx="5">- San Francisco, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="510" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="570" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="599" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="630" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="575">Directed recruitment/training/staff development initiatives to maximize productivity</tspan>
<tspan x="40" dy="30">Successfully increased employee retention by created a positive work environment in 18 stores.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to.</tspan>
</text>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="680" style="font-weight:600;">General Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Woodranch Restaurant</tspan>
<tspan dx="5">- San Jose, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="688" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="745" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="805" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="867" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="750">Successfully managed a team of 18 direct reports and reduced store turnover by 80% from</tspan>
<tspan x="40" dy="30">previous management.</tspan>
<tspan x="40" dy="30">Developed the renovation strategy and oversaw the $110,000 store remodel while open for</tspan>
<tspan x="40" dy="30"> business.</tspan>
<tspan x="40" dy="33">Directed departmental alignment on strategies to create strong.</tspan>
</text>
<text style="fill:#436975;font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" x="0" y="920" class="section-title">Education</text>
<line x1="0" y1="930" x2="100%" y2="930" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="955" style="font-weight:600;">Bachelor of Arts:</tspan>
<tspan x="0" dy="30">
<tspan style="font-weight:600">San Francisco State University </tspan>– San Francisco, CA
</tspan>
<tspan dx="5">Business Management</tspan>
<tspan x="0" dy="30">Coursework includes: Speech and Communication, Sociology and Psychology</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="680" y="965">Mar 1991</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="COL1" data-skin-cd="COL1" data-skin-name="Providence" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="32" text-anchor="middle" style="font-size:38px; font-weight:600; font-family:'Georgia','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="162">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="0" y="193">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management,loss control and inventory management initiative.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="305">Skills</tspan>
</text>
<circle cx="15" cy="330" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="30" y="335">Executive team leadership</tspan>
<tspan x="30" dy="27">Inventory report generation</tspan>
<tspan x="30" dy="27">Client/Vendor relations</tspan>
<tspan x="30" dy="25">Market analysis</tspan>
</text>
<circle cx="258" cy="327" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="275" y="335">Sales Management</tspan>
<tspan x="275" dy="27">Staff training</tspan>
<tspan x="275" dy="27">Customer relations</tspan>
<tspan x="275" dy="25">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="470">Experience</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="498">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="498">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="520">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="520">San Francisco, CA</tspan>
</text>
<circle cx="12" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="576" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="603" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="630" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="28" y="553">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="28" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="28" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="28" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="678">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="678">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="700">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="700">San Jose, CA</tspan>
</text>
<circle cx="12" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="810" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="27" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="27" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="27" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="27" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="27" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="900">Education</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">Jul 2008</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="AUT1" data-skin-cd="AUT1" data-skin-name="Cinematic" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="30" text-anchor="middle" style="font-size:38px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="40" x2="705" y2="40" style="stroke:#b5b5b5; stroke-width:2" />
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="225" y="147">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="160" x2="705" y2="160" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="0" y="186">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="320" y="290">Skills</tspan>
</text>
<line x1="0" y1="303" x2="705" y2="303" style="stroke:#b5b5b5; stroke-width:2" />
<circle cx="17" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333; ">
<tspan x="55" y="328">Executive team leadership</tspan>
<tspan x="55" dy="27">Inventory report generation</tspan>
<tspan x="55" dy="27">Client/Vendor relations</tspan>
<tspan x="55" dy="25">Market analysis</tspan>
</text>
<circle cx="412" cy="324" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial','Arial';fill:#333333; ">
<tspan x="445" y="328">Sales Management</tspan>
<tspan x="445" dy="27">Staff training</tspan>
<tspan x="445" dy="27">Customer relations</tspan>
<tspan x="445" dy="25">Process improvements</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="460">Experience</tspan>
</text>
<line x1="0" y1="472" x2="705" y2="472" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="495">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="495">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="522">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="522">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="580" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="632" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="557">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="50" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="50" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="50" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="675">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="675">San Jose, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="703">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="703">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="805" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="50" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="50" dy="25">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="50" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="50" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="888">Education</tspan>
</text>
<line x1="0" y1="900" x2="705" y2="900" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">Jul 2008</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="CON1" data-skin-cd="CON1" data-skin-name="Bedrock" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color display-none recommendedskn 5to10years">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;font-family:'Arial'; fill:#000000;" class="svg-name">
<tspan x="0" y="38" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="190" y="38" id="PreviewUserLastName">CARTER</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="60">123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="0" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="0" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="160" class="section-title">PROFESSIONALSUMMARY:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="187">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="28">Implement cost control measures to ensure operations remain within company targets. Maximize bottom-line</tspan>
<tspan x="0" dy="28">performance through P &amp;L,merchanding,staff management,staffmanagement, loss control and inventory </tspan>
<tspan x="0" dy="28">management initiatives.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="320" class="section-title">SKILLS:</text>
<circle cx="6" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="35" y="348">Executive team leadership</tspan>
<tspan x="35" y="375">Inventory report generation</tspan>
<tspan x="35" y="406">Client/Vendor relations</tspan>
<tspan x="35" y="433">Market analysis</tspan>
</text>
<circle cx="260" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="290" y="348">Sales Management</tspan>
<tspan x="290" y="375">Staff training and development</tspan>
<tspan x="290" y="406">Customer relations</tspan>
<tspan x="290" y="433">Process Improvements</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="490" class="section-title">EXPERIENCE:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="516">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="516">Sep 2009 - Current</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="543">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="543">San Francisco, CA</tspan>
</text>
<circle cx="6" cy="569" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="595" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="620" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="37" y="573">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="37" dy="30">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="37" dy="26">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="680">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="680" x="680">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="706">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="706" x="680">San Jose, CA</tspan>
</text>
<circle cx="6" cy="728" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="756" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="786" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="814" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="842" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="38" y="735">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="38" dy="28">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="900" class="section-title">EDUCATION:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="930">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="930" x="680">Jun 2009</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="956">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="956" x="680">San Francisco, CA</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="994">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="994" x="680">Mar 2011</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="1019">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="1019">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="KGF1" data-skin-cd="KGF1" data-skin-name="Kingfish" data-skin-viewed="false" data-skin-pos="1" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="30" class="svg-name">
<tspan x="70" y="40" style="letter-spacing: 6px;" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="255" y="40" style="letter-spacing: 6px;" id="PreviewUserLastName">CARTER</tspan>
</text>
<path fill="#305fec" d="M0 0h56v58H0z" class="svg-section-bg" />
<text fill="#fff" font-family="'Century Gothic','Arial'" font-size="20" class="font-bld">
<tspan x="10" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserFirstName-Initials">M</tspan>
<tspan x="30" y="50" style="letter-spacing:1.75px; font-weight:700;" id="PreviewUserLastName-Initials">W</tspan>
</text>
<text font-family="'Century Gothic','Arial'" font-size="13" letter-spacing=".79">
<tspan x="530" y="15" style="font-kerning:normal">415-123-1200</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">mCARTER@address.com</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">123 Main Street,</tspan>
<tspan x="530" dy="15" style="font-kerning:normal">SanFrancisco, CA 94122</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','Arial'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="83">PROFESSIONAL SUMMARY</tspan>
</text>
<line x1="0" y1="93" x2="705" y2="93" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="115">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="20">Implement cost control measures to ensure operations remain within company targets. Maximize</tspan>
<tspan x="0" dy="20">bottom-line performance through P &amp; L, merchanding, staff management, loss control and </tspan>
<tspan x="0" dy="20">inventory management initiatives.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="200">SKILLS</tspan>
</text>
<line x1="0" y1="210" x2="705" y2="210" style="stroke:#333333; stroke-width:2" />
<circle cx="5" cy="230" r="2" style="fill:#333333" />
<circle cx="5" cy="250" r="2" style="fill:#333333" />
<circle cx="5" cy="270" r="2" style="fill:#333333" />
<circle cx="5" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="234">Executive team leadership</tspan>
<tspan x="20" dy="20">Inventory report generation</tspan>
<tspan x="20" dy="20">Client/Vendor relations</tspan>
<tspan x="20" dy="20">Market analysis</tspan>
</text>
<circle cx="275" cy="230" r="2" style="fill:#333333" />
<circle cx="275" cy="250" r="2" style="fill:#333333" />
<circle cx="275" cy="270" r="2" style="fill:#333333" />
<circle cx="275" cy="290" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="290" y="234">Sales Management</tspan>
<tspan x="290" dy="20">Staff training</tspan>
<tspan x="290" dy="20">Customer relations</tspan>
<tspan x="290" dy="20">Process improvements</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="330">EXPERIENCE</tspan>
</text>
<line x1="0" y1="340" x2="705" y2="340" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="367" font-weight="700">District Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="367">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="390" r="2" style="fill:#333333" />
<circle cx="5" cy="410" r="2" style="fill:#333333" />
<circle cx="5" cy="430" r="2" style="fill:#333333" />
<circle cx="5" cy="450" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="394">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="490" font-weight="700">Manager, Verizon Wireless - San Francisco, CA</tspan>
<tspan x="380" y="490">Oct 1997 – Sept 2009</tspan>
</text>
<text style="font-size:16px;fill:#333333;font-family:'Century Gothic','Arial';font-style:italic;"></text>
<circle cx="5" cy="513" r="2" style="fill:#333333" />
<circle cx="5" cy="533" r="2" style="fill:#333333" />
<circle cx="5" cy="553" r="2" style="fill:#333333" />
<circle cx="5" cy="573" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="517">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="20" dy="20">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="20" dy="20">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="610" font-weight="700">General Manager, <tspan>Woodranch Restaurant</tspan> - <tspan>San Jose, CA</tspan></tspan>
<tspan x="410" y="610">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="5" cy="633" r="2" style="fill:#333333" />
<circle cx="5" cy="653" r="2" style="fill:#333333" />
<circle cx="5" cy="673" r="2" style="fill:#333333" />
<circle cx="5" cy="693" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="637">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="730" font-weight="700">Senior Executive, Woodranch Restaurant - San Jose, CA</tspan>
<tspan x="400" y="730">Aug 1993 – Jan 1994</tspan>
</text>
<circle cx="5" cy="748" r="2" style="fill:#333333" />
<circle cx="5" cy="768" r="2" style="fill:#333333" />
<circle cx="5" cy="788" r="2" style="fill:#333333" />
<circle cx="5" cy="808" r="2" style="fill:#333333" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="20" y="752">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="20" dy="20">Cultivated strong business relationships with customers to drive business.</tspan>
<tspan x="20" dy="20">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="20" dy="20">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
</text>
<text fill="#305fec" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing="1" font-weight="700" class="section-title">
<tspan x="1" y="855">EDUCATION</tspan>
</text>
<line x1="0" y1="865" x2="705" y2="865" style="stroke:#333333; stroke-width:2" />
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="885">Master of Arts: Operations Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="905">San Francisco State University - San Francisco, CA</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="935">Master of Arts: Business Management</tspan>
</text>
<text fill="#333333" font-family="'Century Gothic','CenturyGothic'" font-size="13" letter-spacing=".79">
<tspan x="0" y="955">University of San Francisco - San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="UPT1" data-skin-cd="UPT1" data-skin-name="Empire" data-skin-viewed="false" data-skin-pos="2" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="100%" y="30" text-anchor="end" style="font-size:38px; font-weight:700;font-family:'Century Gothic','Arial'">
<tspan id="PreviewUserFirstName" class="text-upper">JOHN</tspan>
<tspan style="fill:#436975;" class="svg-last-name svg-name" id="PreviewUserLastName">CARTER</tspan>
</text>
<rect x="0" y="50" style="fill:#436975;" height="30" width="100%" class="svg-section-bg" />
<text text-anchor="end" style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial';fill:#fff;text-align:center;width:100%">
<tspan x="99%" y="70">123 Main Street, SanFrancisco, CA 94122 | 508-278-2542 | 781-669-5989 | mCARTER@live.com </tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="138">Professional Summary</tspan>
</text>
<line x1="0" y1="147" x2="100%" y2="147" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="175">Accomplished operations executive with a successful track record overseeing marketing, IT, HR/training</tspan>
<tspan x="0" dy="30">and real estate in company and franchise operations for a large regional chain.</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="260">Skills</tspan>
</text>
<line x1="0" y1="270" x2="100%" y2="270" style="stroke:#333; stroke-width:1" />
<circle cx="25" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="335" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="365" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="397" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="40" y="310">Executive Team Leadership</tspan>
<tspan x="40" dy="29">Multi-Million Dollar P&amp;L Management</tspan>
<tspan x="40" dy="33">Expertise in New England Real Estate</tspan>
<tspan x="40" dy="33">Client/Vendor Relations</tspan>
</text>
<circle cx="373" cy="303" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="333" r="1.5" style="fill:#333333"></circle>
<circle cx="373" cy="400" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px; font-weight:400;font-family:'Century Gothic','Arial'">
<tspan x="388" y="310">Marketing/Product Line Development</tspan>
<tspan x="388" dy="30">Staff/Training Development Policy</tspan>
<tspan x="388" dy="30">Development</tspan>
<tspan x="388" dy="34">Process Improvement</tspan>
</text>
<text style="fill:#436975; font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" class="section-title">
<tspan x="0" y="460">Experience</tspan>
</text>
<line x1="0" y1="470" x2="100%" y2="470" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="507" style="font-weight:600;">District Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Verizon Wireless</tspan>
<tspan dx="5">- San Francisco, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="510" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="570" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="599" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="630" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="575">Directed recruitment/training/staff development initiatives to maximize productivity</tspan>
<tspan x="40" dy="30">Successfully increased employee retention by created a positive work environment in 18 stores.</tspan>
<tspan x="40" dy="30">Administered daily operations to ensure policies were adhered to.</tspan>
</text>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="680" style="font-weight:600;">General Manager</tspan>
<tspan x="0" dy="30" style="font-weight:600;">Woodranch Restaurant</tspan>
<tspan dx="5">- San Jose, CA</tspan>
</text>
<text text-anchor="end" style="font-size:15px;font-family:'Century Gothic','Arial'">
<tspan y="688" x="680">08/2009 to 09/2013</tspan>
</text>
<circle cx="25" cy="745" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="805" r="1.5" style="fill:#333333"></circle>
<circle cx="25" cy="867" r="1.5" style="fill:#333333"></circle>
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="40" y="750">Successfully managed a team of 18 direct reports and reduced store turnover by 80% from</tspan>
<tspan x="40" dy="30">previous management.</tspan>
<tspan x="40" dy="30">Developed the renovation strategy and oversaw the $110,000 store remodel while open for</tspan>
<tspan x="40" dy="30"> business.</tspan>
<tspan x="40" dy="33">Directed departmental alignment on strategies to create strong.</tspan>
</text>
<text style="fill:#436975;font-size:23px; font-weight:700;font-family:'Century Gothic','Arial'" x="0" y="920" class="section-title">Education</text>
<line x1="0" y1="930" x2="100%" y2="930" style="stroke:#333; stroke-width:1" />
<text style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="0" y="955" style="font-weight:600;">Bachelor of Arts:</tspan>
<tspan x="0" dy="30">
<tspan style="font-weight:600">San Francisco State University </tspan>– San Francisco, CA
</tspan>
<tspan dx="5">Business Management</tspan>
<tspan x="0" dy="30">Coursework includes: Speech and Communication, Sociology and Psychology</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Century Gothic','Arial'">
<tspan x="680" y="965">Mar 1991</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="COL1" data-skin-cd="COL1" data-skin-name="Providence" data-skin-viewed="false" data-skin-pos="3" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="32" text-anchor="middle" style="font-size:38px; font-weight:600; font-family:'Georgia','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="162">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="0" y="193">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management,loss control and inventory management initiative.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="305">Skills</tspan>
</text>
<circle cx="15" cy="330" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="15" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="30" y="335">Executive team leadership</tspan>
<tspan x="30" dy="27">Inventory report generation</tspan>
<tspan x="30" dy="27">Client/Vendor relations</tspan>
<tspan x="30" dy="25">Market analysis</tspan>
</text>
<circle cx="258" cy="327" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="357" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="258" cy="408" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="275" y="335">Sales Management</tspan>
<tspan x="275" dy="27">Staff training</tspan>
<tspan x="275" dy="27">Customer relations</tspan>
<tspan x="275" dy="25">Process improvements</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="470">Experience</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="498">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="498">Sept 2009 – Current</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="520">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="520">San Francisco, CA</tspan>
</text>
<circle cx="12" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="576" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="603" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="630" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="28" y="553">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="28" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="28" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="28" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="678">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="678">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="700">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="700">San Jose, CA</tspan>
</text>
<circle cx="12" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="810" r="1.5" class="li-disc"></circle>
<circle cx="12" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia','Arial';fill:#333333;">
<tspan x="27" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="27" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="27" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="27" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="27" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:23px; font-weight:600;font-family:'Georgia','Arial';fill:#000000;" class="section-title">
<tspan x="0" y="900">Education</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">Jul 2008</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="AUT1" data-skin-cd="AUT1" data-skin-name="Cinematic" data-skin-viewed="false" data-skin-pos="4" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text x="50%" y="30" text-anchor="middle" style="font-size:38px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="svg-name">
<tspan id="PreviewUserFirstName">JOHN</tspan>
<tspan id="PreviewUserLastName">CARTER</tspan>
</text>
<line x1="0" y1="40" x2="705" y2="40" style="stroke:#b5b5b5; stroke-width:2" />
<text x="50%" y="60" text-anchor="middle" style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan>123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="50%" dy="23">mCARTER@address.com</tspan>
<tspan x="50%" dy="23">415-123-1200</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="225" y="147">Professional</tspan>
<tspan dx="6">Summary</tspan>
</text>
<line x1="0" y1="160" x2="705" y2="160" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="0" y="186">Successful sales professional with 10+ years experience in large-scale food and retail environments. Implement</tspan>
<tspan x="0" dy="30">cost control measures to ensure operations remain within company targets. Maximize bottom-line performance</tspan>
<tspan x="0" dy="27">through P &amp; L, merchanding, staff management.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="320" y="290">Skills</tspan>
</text>
<line x1="0" y1="303" x2="705" y2="303" style="stroke:#b5b5b5; stroke-width:2" />
<circle cx="17" cy="322" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333; ">
<tspan x="55" y="328">Executive team leadership</tspan>
<tspan x="55" dy="27">Inventory report generation</tspan>
<tspan x="55" dy="27">Client/Vendor relations</tspan>
<tspan x="55" dy="25">Market analysis</tspan>
</text>
<circle cx="412" cy="324" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="350" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="377" r="1.5" class="li-disc"></circle>
<circle cx="412" cy="406" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial','Arial';fill:#333333; ">
<tspan x="445" y="328">Sales Management</tspan>
<tspan x="445" dy="27">Staff training</tspan>
<tspan x="445" dy="27">Customer relations</tspan>
<tspan x="445" dy="25">Process improvements</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="460">Experience</tspan>
</text>
<line x1="0" y1="472" x2="705" y2="472" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="495">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="495">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="522">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="522">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="550" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="580" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="632" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="557">Directed recruitment/training/staff development initiatives</tspan>
<tspan x="50" dy="27">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="50" dy="27">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="50" dy="25">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="675">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="675">San Jose, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="703">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="703">Jan 1994 – Aug 1997</tspan>
</text>
<circle cx="17" cy="728" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="780" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="805" r="1.5" class="li-disc"></circle>
<circle cx="17" cy="835" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Georgia', 'serif','Arial';fill:#333333;">
<tspan x="50" y="733">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="50" dy="25">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="50" dy="25">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="50" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="50" dy="29">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:25px; font-weight:700;font-family:'Georgia', 'serif','Arial';fill:#000000;" class="section-title">
<tspan x="293" y="888">Education</tspan>
</text>
<line x1="0" y1="900" x2="705" y2="900" style="stroke:#b5b5b5; stroke-width:2" />
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="928">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="928">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="955">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="955">Jun 2010</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="990">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="990">San Francisco, CA</tspan>
</text>
<text style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="0" y="1015">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:16px;font-family:'Georgia', 'serif','Arial';fill:#333333;font-style:italic;">
<tspan x="680" y="1015">Jul 2008</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="CON1" data-skin-cd="CON1" data-skin-name="Bedrock" data-skin-viewed="false" data-skin-pos="5" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:38px; font-weight:600;font-family:'Arial'; fill:#000000;" class="svg-name">
<tspan x="0" y="38" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="190" y="38" id="PreviewUserLastName">CARTER</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="60">123 Main Street, SanFrancisco, CA 94122</tspan>
<tspan x="0" dy="23">415-123-0012 | 415-123-1200</tspan>
<tspan x="0" dy="23">mCARTER@address.com</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="160" class="section-title">PROFESSIONALSUMMARY:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="0" y="187">Successful sales professional with 10+ years experience in large-scale food and retail environments.</tspan>
<tspan x="0" dy="28">Implement cost control measures to ensure operations remain within company targets. Maximize bottom-line</tspan>
<tspan x="0" dy="28">performance through P &amp;L,merchanding,staff management,staffmanagement, loss control and inventory </tspan>
<tspan x="0" dy="28">management initiatives.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="320" class="section-title">SKILLS:</text>
<circle cx="6" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="35" y="348">Executive team leadership</tspan>
<tspan x="35" y="375">Inventory report generation</tspan>
<tspan x="35" y="406">Client/Vendor relations</tspan>
<tspan x="35" y="433">Market analysis</tspan>
</text>
<circle cx="260" cy="345" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="375" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="403" r="1.3" class="li-disc"></circle>
<circle cx="260" cy="431" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="290" y="348">Sales Management</tspan>
<tspan x="290" y="375">Staff training and development</tspan>
<tspan x="290" y="406">Customer relations</tspan>
<tspan x="290" y="433">Process Improvements</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="490" class="section-title">EXPERIENCE:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="516">District Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="516">Sep 2009 - Current</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="543">Verizon Wireless</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="543">San Francisco, CA</tspan>
</text>
<circle cx="6" cy="569" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="595" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="620" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="37" y="573">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="37" dy="30">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="37" dy="26">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="680">General Manager</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="680" x="680">Jan 1994 – Aug 1997</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="706">Woodranch Restaurant</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="706" x="680">San Jose, CA</tspan>
</text>
<circle cx="6" cy="728" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="756" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="786" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="814" r="1.3" class="li-disc"></circle>
<circle cx="6" cy="842" r="1.3" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Arial'; fill:#333333;">
<tspan x="38" y="735">Successfully managed a team of 18 direct reports.</tspan>
<tspan x="38" dy="28">Developed the renovation strategy and oversaw the $110,000 store remodel.</tspan>
<tspan x="38" dy="28">Directed departmental alignment on strategies to create strong sales.</tspan>
<tspan x="38" dy="28">Cultivated strong franchise owner relationships to achieve high standards.</tspan>
<tspan x="38" dy="28">Implemented process improvements to increase guest loyalty.</tspan>
</text>
<text style="font-size:21px; font-weight:600;font-family:'Arial'; fill:#000000;" x="0" y="900" class="section-title">EDUCATION:</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="930">Master of Arts: Operations Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="930" x="680">Jun 2009</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="956">San Francisco State University</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="956" x="680">San Francisco, CA</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="994">Bachelor of Arts: Business Management</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan y="994" x="680">Mar 2011</tspan>
</text>
<text style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="0" y="1019">University of San Francisco</tspan>
</text>
<text text-anchor="end" style="font-size:14px;font-family:'Arial'; fill:#333333; font-style:italic;">
<tspan x="680" y="1019">San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
<div id="BOL1" data-skin-cd="BOL1" data-skin-name="Gazelle" data-skin-viewed="false" data-skin-pos="6" class="template-card change-color display-none recommendedskn 10plusyears">
<div class="template-doc ">

<svg xmlns="http://www.w3.org/2000/svg" width="710" height="1024" viewBox="0 0 710 1024">
<text style="font-size:50px; font-weight:400;font-family:'Verdana','Arial';fill:#0E9FC1" class="svg-name">
<tspan x="0" y="60" id="PreviewUserFirstName">JOHN</tspan>
<tspan x="250" y="60" id="PreviewUserLastName">CARTER</tspan>
</text>
<path d="M 0 75 L 280 75" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:12px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="0" y="100">123 Main Street, SanFrancisco, CA 94122 | 508-278-2542 | 781-669-5989 | mCARTER@live.com</tspan>
</text>
<text style="font-size:21px; font-weight:500;fill:#0E9FC1 ;font-family:'Verdana','Arial';" x="0" y="150" class="section-title">PROFESSIONAL SUMMARY</text>
<path d="M 0 160 L 280 160" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333" x="25">
<tspan x="0" y="185">Successful sales professional with 10+ years experience in large-scale food and retail</tspan>
<tspan x="0" dy="23">environments. Implement cost control measures to ensure operations remain within</tspan>
<tspan x="0" dy="23">company targets. Maximize bottom-line performance through P&amp;L, merchandising, loss</tspan>
<tspan x="0" dy="23">control and inventory management initiatives.</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="300" class="section-title">SKILLS</text>
<path d="M 0 310 L 280 310" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<circle cx="5" cy="332" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="354" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="400" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="422" r="1.5" class="li-disc"></circle>
<circle cx="5" cy="444" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="20" y="335">Customer relations</tspan>
<tspan x="20" y="359">Inventory report generation</tspan>
<tspan x="20" y="383">Executive team leadership</tspan>
<tspan x="20" y="406">Inventory report generation</tspan>
<tspan x="20" y="428">Client/Vendor relations</tspan>
<tspan x="20" y="450">Market analysis</tspan>
</text>
<circle cx="236" cy="332" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="354" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="380" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="400" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="425" r="1.5" class="li-disc"></circle>
<circle cx="236" cy="443" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333">
<tspan x="254" y="335">Market analysis</tspan>
<tspan x="254" y="359">Staff training</tspan>
<tspan x="254" y="385">Sales Management</tspan>
<tspan x="254" y="405">Staff training</tspan>
<tspan x="254" y="430">Customer relations</tspan>
<tspan x="254" y="450">Process improvements</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="505" class="section-title">EXPERIENCE</text>
<path d="M 0 518 L 280 518" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text x="0" y="545" style="font-size:14px;font-family:'Verdana','Arial';fill:#333;">AUGUST 2011-PRESENT</text>
<text x="0" y="565" style="font-style:italic;font-family:'Verdana','Arial';fill:#333333;font-weight:500; font-size: 14px;">District Manager | Verizon Wireless | San Francisco, CA</text>
<circle cx="4" cy="585" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="605" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="625" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="650" r="1.5" class="li-disc"></circle>
<text style="font-family:'Verdana','Arial';fill:#333333;font-size:14px;">
<tspan x="18" y="588">
Directed recruitment/training/staff development initiatives
development initiatives.
</tspan>
<tspan x="18" dy="22">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="18" dy="22">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="18" dy="22">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text x="0" y="690" style="font-size:14px;font-family:'Verdana','Arial';fill:#333333 ;">AUGUST 2009-2011</text>
<text x="0" y="710" style="font-style:italic;font-family:'Verdana','Arial';fill:#333333;font-weight:500; font-size: 14px;">District Manager | Verizon Wireless | San Francisco, CA</text>
<circle cx="4" cy="732" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="754" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="775" r="1.5" class="li-disc"></circle>
<circle cx="4" cy="795" r="1.5" class="li-disc"></circle>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333;">
<tspan x="18" y="735">Directed recruitment/training/staff development initiatives.</tspan>
<tspan x="18" dy="22">Successfully increased employee retention with a positive work environment.</tspan>
<tspan x="18" dy="22">Administered daily operations to ensure policies were adhered to by sales staff.</tspan>
<tspan x="18" dy="22">Cultivated strong business relationships with customers to drive business.</tspan>
</text>
<text style="font-size:21px; font-weight:500;font-family:'Verdana','Arial';fill:#0E9FC1 ;" x="0" y="860" class="section-title">EDUCATION</text>
<path d="M 0 875 L 280 875" stroke="#0E9FC1 " stroke-linecap="round" stroke-width="2" stroke-dasharray="3,3" fill="none" class="svg-stroke" />
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333;" x="0" y="897">2011</text>
<text style="font-family:'Verdana','Arial';fill:#333333;">
<tspan x="0" y="920" style="font-size:14px; font-weight:500; font-style:italic;">Bachelor of Arts</tspan>
<tspan style="font-size:14px;" x="0" dy="24">San Francisco State University, San Francisco, CA</tspan>
</text>
<text style="font-size:14px;font-family:'Verdana','Arial';fill:#333333 ;" x="0" y="975">2008</text>
<text style="font-family:'Arial';fill:#333333;">
<tspan x="0" y="995" style="font-size:14px; font-weight:500; font-style:italic;">High School Diploma</tspan>
<tspan style="font-size:14px;" x="0" dy="24">San Francisco State University, San Francisco, CA</tspan>
</text>
</svg>
</div> <p class="hover-txt text-bold display-flex text-center xy-center">Use this template</p>
</div>
</div>
</div>
</div>
<div class="color-pallete" id="divColorPallete">
<div id="btnCancelColorTablet" class="no-color selected"></div>
<div class="color-pallete-box skin-cl-1" data-skin-cl-id="skin-cl-1" data-code="#000000" data-color-name="Classic Black"></div>
<div class="color-pallete-box skin-cl-2" data-skin-cl-id="skin-cl-2" data-code="#436975" data-color-name="Night Sky"></div>
<div class="color-pallete-box skin-cl-3" data-skin-cl-id="skin-cl-3" data-code="#305fec" data-color-name="Blueprint Blue"></div>
<div class="color-pallete-box skin-cl-4" data-skin-cl-id="skin-cl-4" data-code="#0e9fc1" data-color-name="Sea Side"></div>
<div class="color-pallete-box skin-cl-5" data-skin-cl-id="skin-cl-5" data-code="#7ebca3" data-color-name="Mint Teal"></div>
<div class="color-pallete-box skin-cl-6" data-skin-cl-id="skin-cl-6" data-code="#acb75a" data-color-name="Martini Green"></div>
<div class="color-pallete-box skin-cl-7" data-skin-cl-id="skin-cl-7" data-code="#9097be" data-color-name="Electric Purple"></div>
<div class="color-pallete-box skin-cl-8" data-skin-cl-id="skin-cl-8" data-code="#ac7bae" data-color-name="Booming Violet"></div>
<div class="color-pallete-box skin-cl-9" data-skin-cl-id="skin-cl-9" data-code="#f46464" data-color-name="Vibrant Salmon"></div>
<div class="color-pallete-box skin-cl-10" data-skin-cl-id="skin-cl-10" data-code="#96006f" data-color-name="Vineyard Plum"></div>
<div class="color-pallete-box skin-cl-11" data-skin-cl-id="skin-cl-11" data-code="#c5a3ab" data-color-name="Blush Pink"></div>
<div class="color-pallete-box skin-cl-12" data-skin-cl-id="skin-cl-12" data-code="#d39c00" data-color-name="Autumn Mustard"></div>
</div>
</section>
<input type="hidden" id="funnel-tagging-info" data-portal="https://www.resumehelp.com/" data-screen-name="choose template" data-login-status="FALSE" data-builder-type="resumes" data-domain-cd="RHU" data-click-option="next" data-portal-name="ResumeHelp" />
<input type="hidden" id="hdnSegmentConstants" data-skinPreview="template viewed" data-skin-select="template selected" data-skin-preview="template viewed" data-color="Color" data-template-name="template name" data-document-type="document type" data-userid="userId" data-resume="resume" data-resumes="resumes" data-template-color-changed="template color changed" data-buildertype="builder type" data-templatecategory="template category" data-displayposition="display position" data-screenname="screen name" data-templateid="template id" data-platform="Platform" data-platformvalue="Web" data-loginstatus="Login Status" data-loginstatusvalue="False" data-pagename="choose template" data-portal="Portal" data-portalvalue="ResumeHelp" data-templatecolor="template color" data-expLevel="experience level" data-clickoption="click option" />
<input type="hidden" id="templatePreview" data-color-code data-skin-cd="KGF1" data-skin-name="Kingfish" data-color-class data-skin-category="all" />
<input type="hidden" id="hdnEnableRHIO" value="false" />
<input type="hidden" id="hdnchoosetemplateexpvalue" value="false" />
<input type="hidden" id="hdnIsSignedIn" value="False" />
<input type="hidden" id="hdnEmailRegex" value="^[A-Za-z0-9_][A-Za-z0-9._%+-]+@[A-Za-z0-9.-]*[A-Za-z0-9-]+\.[A-Za-z]+$" data-invalid-keywords="[&quot;info@&quot;,&quot;abuse@&quot;,&quot;webmaster@&quot;,&quot;information@&quot;,&quot;groups@&quot;,&quot;sales@&quot;,&quot;spam@&quot;,&quot;services@&quot;,&quot;inquiry@&quot;,&quot;customercare@&quot;,&quot;null@&quot;,&quot;@yahoogroups.com&quot;,&quot;@googlegroups.com&quot;,&quot;@spamhaus.com&quot;]" />
<input type="hidden" id="hdnDocumentId" />
<input type="hidden" id="hdnIsNewChooseTemplatePageUs" value="false" />
<input type="hidden" id="hdnNextRouteUrl" value="{{url('/')}}/upload" />
<input type="hidden" id="hdnIsEnabledTemplateTracking" value="true" />
<input type="hidden" id="hdnIsBuilderUsageEventAllowed" value="true" />
<input type="hidden" id="hdnIsrhusonboardingv2test" value="true" />
<footer class="footer clearfix">
<div class="container-main">
<div class="float-left footer-nav">
<a target="_blank" href="https://www.resumehelp.com/user-agreement" rel="nofollow">User Agreement</a>
<a target="_blank" href="https://www.resumehelp.com/privacy-policy" rel="nofollow">Privacy Policy</a>
<a target="_blank" rel="nofollow" href="https://www.resumehelp.com/non-affiliation-disclaimer">Disclaimer</a>
<a target="_blank" href="https://www.resumehelp.com/contact-us">Contact Us</a>
<a href="https://www.resumehelp.com/accessibility">Accessibility</a>
</div>
<div class="float-right copy-rights">
<span class="copy-rights-text">&#169; 2024, Hiring Products Limited, All rights reserved.</span>
<span id="nortonWrapper" class="norton-iframe"></span>
</div>
</div>
</footer>
<input type="hidden" id="checkSigninvalueandccpaValue" data-signedin="False" data-enableCCPA="False" data-showCCPALink="False" />
<input type="hidden" id="hdnshowFreshChat" data-freshChatBodyJS="https://cdnprod4.resumehelp.com/distjs/freshchat.min.js" data-siteId="resumehelp" data-locale="en" data-tags="resumehelp" data-applogo="https://cdnprod4.resumehelp.com/img/rh-logo-mark.svg?v=2500" data-appname="ResumeHelp" data-value="true" data-preChatJS="https://cdnprod4.resumehelp.com/distjs/plugins/fc-pre-chat-form-v2.min.js" data-widgetJS="https://wchat.freshchat.com/js/widget.js" />
<input type="hidden" id="hdnshowzendesktext" data-title="Let&#39;s Talk!" data-description="We can&#39;t wait to talk to you. But first, please tell us a bit about yourself." data-departmentlabel="Select a topic" data-chatLabel="Chat" />
<input type="hidden" id="hdnshowzendeskchat" data-ZendeskChatBodyJS="https://cdnprod4.resumehelp.com/distjs/ZendeskChat.min.js" data-locale="en" data-zendeskwidgetjs="https://static.zdassets.com/ekr/snippet.js?key=dd1b3434-b680-4b2e-9a6f-6eaab178af8d" data-enabled="true" />
<div id="loader" class="loader display-none"></div>
<div id="clientResources" class="display-none">
<input type="hidden" data-app-name="gtm" data-app-key="GTM-KDF4Z7" />
<input type="hidden" id="userSubscriptionStatus" data-sub-status-name="Subscription Status" data-sub-status-value="FALSE" />
<input type="hidden" id="userPaymentStatus" data-payment-status-name="Payment Status" data-payment-status-value="Not Started" />
<input type="hidden" data-app-name="analytics" data-app-key="hBgFpsIDwQZCp2RvTBs9pBA4lAgCf7d5" data-app-portal="ResumeHelp" data-app-login-status="FALSE" data-app-visitor-type="Returning" data-app-platform="Web" /><input type="hidden" data-app-name="norton" data-app-src="/app/Norton" />
<input type="hidden" id="hdnUserStage" value="STYLES" data-url="/users/stage" />
<input data-url-key="SaveTemplate" data-url-value="/documents/save-template" type="hidden" />
<input data-url-key="NextRoute" data-url-value="{{url('/')}}/upload" type="hidden" />
<input data-url-key="SwitchDomain" data-url-value="/app/execute-redirect" type="hidden" />
<input data-url-key="GetContactInfoURL" data-url-value type="hidden" />
<input data-url-key="SaveFavSkinURL" data-url-value="/SaveFavouriteTemplate" type="hidden" />
<input data-url-key="FetchFavSkinURL" data-url-value="/GetFavouriteTemplate" type="hidden" />
<input data-url-key="getonboardingurl" data-url-value="/users/GetOnboardingName" type="hidden" />
<input data-url-key="getexplevelurl" data-url-value="/users/GetExperienceLevel" type="hidden" />
</div>
<input type="hidden" id="hdnGdprPreferences" data-privacyconsentenabled="False" data-url="/compliance/SetPrivacyConsentPreferences?isPerformanceChecked=False&amp;isMarketingChecked=False&amp;isSettingsChanged=False" data-userconsent-url="/users/SavePrivacyConsentPreferences?isPerformanceChecked=False&amp;isMarketingChecked=False&amp;isSettingsChanged=False" data-consentapplicable="/users/privacyconsentapplicable" />
<script defer="defer" src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script defer="defer" src="https://cdnprod3.resumehelp.com/distjs/app.min.js?v=2500"></script>
<script defer="defer" src="https://cdnprod4.resumehelp.com/distjs/wizard.min.js?v=2500"></script>
<script defer="defer" src="https://cdnprod4.resumehelp.com/distjs/plugins/scrollbar.min.js?v=2500"></script><script defer="defer" src="https://cdnprod3.resumehelp.com/distjs/wizard/choose-template-withfilters.min.js?v=2500"></script>
<input type="hidden" id="hdnRemarketingUserId" value="52732354" />
<input type="hidden" id="hdnVisitId" value="4b271830-2936-42dd-8a0e-2b2fb882d712" />
<input type="hidden" id="vDomainCd" value="RHU" />
<input type="hidden" id="sessionIdCookieName" value="_hptd" />
<input type="hidden" id="hdnenablemixpanelcookie" value="false" />
</body>
</html>
