<!DOCTYPE html>

<html lang="en">





<!-- Mirrored from themewagon.github.io/HighTechIT/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2024 07:15:17 GMT -->

<!-- Added by HTTrack -->

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<!-- /Added by HTTrack -->



<head>

    <meta charset="utf-8">

    <title>ACE My Resumes</title>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <meta content="" name="keywords">

    <meta content="" name="description">



    <!-- Google Web Fonts -->

    <link rel="preconnect" href="https://fonts.googleapis.com/">

    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&amp;family=Saira:wght@500;600;700&amp;display=swap" rel="stylesheet">



    <!-- Icon Font Stylesheet -->

    <link href="{{url('/')}}/assets/theme/cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <link href="{{url('/')}}/assets/theme/cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">



    <!-- Libraries Stylesheet -->

    <link href="{{url('/')}}/assets/theme/lib/animate/animate.min.css" rel="stylesheet">

    <link href="{{url('/')}}/assets/theme/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">



    <!-- Customized Bootstrap Stylesheet -->

    <link href="{{url('/')}}/assets/theme/bootstrap.min.css" rel="stylesheet">



    <!-- Template Stylesheet -->

    <link href="{{url('/')}}/assets/theme/style.css" rel="stylesheet">

</head>


<body>

    <!-- Spinner Start -->

    {{-- <div id="spinner" class="show position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">

        <div class="spinner-grow text-primary" role="status"></div>

    </div> --}}

    <!-- Spinner End -->



    <!-- Topbar Start -->

    <!-- <div class="container-fluid bg-dark py-2 d-none d-md-flex">

            <div class="container">

                <div class="d-flex justify-content-between topbar">

                    <div class="top-info">

                        <small class="me-3 text-white-50"><a href="#"><i class="fas fa-map-marker-alt me-2 text-secondary"></i></a>23 Ranking Street, New York</small>

                        <small class="me-3 text-white-50"><a href="#"><i class="fas fa-envelope me-2 text-secondary"></i></a>Email@Example.com</small>

                    </div>

                    <div id="note" class="text-secondary d-none d-xl-flex"><small>Note : We help you to Grow your Business</small></div>

                    <div class="top-link">

                        <a href="#" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i class="fab fa-facebook-f text-primary"></i></a>

                        <a href="#" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i class="fab fa-twitter text-primary"></i></a>

                        <a href="#" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i class="fab fa-instagram text-primary"></i></a>

                        <a href="#" class="bg-light nav-fill btn btn-sm-square rounded-circle me-0"><i class="fab fa-linkedin-in text-primary"></i></a>

                    </div>

                </div>

            </div>

        </div> -->

    <!-- Topbar End -->



    <!-- Navbar Start -->

    <div class="container-fluid bg-primary">

        <div class="container">

            <nav class="navbar navbar-dark navbar-expand-lg py-0">

                <a href="{{url('/')}}/" class="navbar-brand">

                    <h1 class="text-white fw-bold d-block">ACE<span class="text-secondary">My</span>Resume</h1>

                </a>

                <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">

                        <span class="navbar-toggler-icon"></span>

                    </button>

                <div class="collapse navbar-collapse bg-transparent" id="navbarCollapse">

                    <div class="navbar-nav ms-auto mx-xl-auto p-10">

                        <!-- <a href="index.html" class="nav-item nav-link active text-secondary">Resumes</a> -->

                        <div class="nav-item dropdown">

                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Resumes</a>

                            <div class="dropdown-menu rounded">

                                <a href="{{url('/')}}/resume_template" class="dropdown-item">Resume Templates</a>

                                <a href="{{url('/')}}/work_experience" class="dropdown-item">Resume Builder</a>

                                <a href="#" class="dropdown-item">Resume Examples</a>

                                <a href="#" class="dropdown-item">Resume Formats</a>

                                <!-- <a href="#" class="btn btn-primary btn-lg active font-weight-light" role="button" aria-pressed="true"> Build a Resume</a> -->

                            </div>

                        </div>

                        <!-- <a href="about.html" class="nav-item nav-link">CV</a> -->

                        <div class="nav-item dropdown">

                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">CV</a>

                            <div class="dropdown-menu rounded">

                                <a href="#" class="dropdown-item">CV Templates</a>

                                <a href="#" class="dropdown-item">CV Builder</a>

                                <a href="#" class="dropdown-item">CV Examples</a>

                                <a href="#" class="dropdown-item">CV Formats</a>

                                <!-- <a href="#" class="btn btn-primary btn-lg active font-weight-light" role="button" aria-pressed="true"> Build a CV</a> -->

                            </div>

                        </div>

                        <!-- <a href="service.html" class="nav-item nav-link">Cover Letters</a> -->

                        <div class="nav-item dropdown">

                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Cover Letters</a>

                            <div class="dropdown-menu rounded">

                                <a href="#" class="dropdown-item">Cover Letters Templates</a>

                                <a href="#" class="dropdown-item">Cover Letters Builder</a>

                                <a href="#" class="dropdown-item">Cover Letters Examples</a>

                                <a href="#" class="dropdown-item">Cover Leeters Formats</a>

                                <!-- <a href="#" class="btn btn-primary btn-lg active font-weight-light" role="button" aria-pressed="true"> Build a Cover Letters</a> -->

                            </div>

                        </div>

                        <a href="{{url('/')}}/career_blog" class="nav-item nav-link">Career Blog</a>

                        <!-- <div class="nav-item dropdown">

                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>

                            <div class="dropdown-menu rounded">

                                <a href="blog.html" class="dropdown-item">Our Blog</a>

                                <a href="team.html" class="dropdown-item">Our Team</a>

                                <a href="testimonial.html" class="dropdown-item">Testimonial</a>

                                <a href="404.html" class="dropdown-item">404 Page</a>

                            </div>

                        </div> -->

                        <a href="{{url('/')}}/contact" class="nav-item nav-link">Contact</a>

                    </div>

                </div>

                <div class="d-none d-xl-flex flex-shirink-0">

                    <div id="phone-tada" class="d-flex align-items-center justify-content-center me-4">

                        <a href="#" class="position-relative animated tada infinite">

                            <button type="button">Login</button>

                            <!-- <i class="fa fa-phone-alt text-white fa-2x"></i>

                            <div class="position-absolute" style="top: -7px; left: 20px;">

                                <span><i class="fa fa-comment-dots text-secondary"></i></span>

                            </div> -->

                        </a>

                    </div>

                    <!-- <div class="d-flex flex-column pe-4 border-end">

                        <span class="text-white-50">Have any questions?</span>

                        <span class="text-secondary">Call: + 0123 456 7890</span>

                    </div> -->

                    <div class="d-flex align-items-center justify-content-center ms-4 ">

                        <a href="#"><i class="bi bi-search text-white fa-2x"></i> </a>

                    </div>

                </div>

            </nav>

        </div>

    </div>

    <!-- Navbar End -->