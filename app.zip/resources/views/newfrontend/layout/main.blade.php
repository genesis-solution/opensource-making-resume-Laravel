@include('newfrontend.layout.header')
@yield('main-container')
@include('newfrontend.layout.footer')