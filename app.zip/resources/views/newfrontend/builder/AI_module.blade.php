<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<header class="header">
        <!-- Header content -->
    </header>

    <div class="container">
        <!-- Job Details Section -->
        <div class="input-section">
            <!-- Job details form -->
        </div>

        <!-- Resume Preview Section -->
        <div class="container">
        <h1>Generate Resume</h1>
        <form action="{{ route('generate') }}" method="post">
            @csrf
            <label for="profession">Enter Your Profession:</label><br>
            <input type="text" id="profession" name="profession"><br><br>
            <button type="submit">Generate Resume</button>
        </form>
    </div>
    </div>

</body>
</html>


