<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="{{url('/')}}/assets/css/template_style.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    <title>Template</title>
  </head>

  
  <body>
  <div class="container">
  <div class="header">
    <div class="full-name">
      <span class="first-name" id="display_name" placeholder=""></span> 
    </div>
    <div class="contact-info">
      <span class="email">Email: </span>
      <span class="email-val" id="display_email"></span>
      <span class="separator"></span>
      <span class="phone">Phone: </span>
      <span class="phone-val"  id="display_phone"></span>
      <!-- Add more fields here as needed -->
    </div>
    <div class="contact-info">
      <span class="email">Add: </span>
      <span class="email-val" id="display_address"></span>
      <span class="separator"></span>
      <span class="phone"> </span>
      <span class="phone-val"  id="display_city"></span>
      <span class="separator"></span>
      <span class="phone"> </span>
      <span class="phone-val"  id="display_state"></span>
      <span class="separator"></span>
      <span class="phone"> </span>
      <span class="phone-val"  id="display_country"></span>
    </div>
    <div class="about">
      <!-- <span class="desc"  id="display_summary">
        I am a front-end developer with more than 3 years of experience writing HTML, CSS, and JavaScript. I'm motivated, result-focused, and seeking a successful team-oriented company with an opportunity to grow.
      </span> -->
    </div>
  </div>
   <div class="details">
    <div class="section">
      <div class="section__title" >Experience</div>
      <div class="section__list" id="experience_list">
        <!-- Experience items will be dynamically added here -->
      </div>
    </div>
    <div class="section">
      <div class="section__title">Education</div>
      <div class="section__list" id="education_list">
        <!-- Education items will be dynamically added here -->
      </div>
    </div>
     <!-- Add more sections here as needed -->
  </div>
</div>
<script src="{{url('/')}}/public/assets/js/template_script.js"></script>
<script>
  // Function to update resume fields
// Function to update resume fields and send data via AJAX
function updateResumeFields() {
    // Get form input values
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var summary = document.getElementById("summary").value;
    var phone = document.getElementById("phone").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var state = document.getElementById("state").value;
    var country = document.getElementById("country").value;
    
    // Update resume fields
    document.getElementById("display_name").textContent = name;
    document.getElementById("display_email").textContent = email;
    document.getElementById("display_summary").textContent = summary;
    document.getElementById("display_phone").textContent = phone;
    document.getElementById("display_address").textContent = address;
    document.getElementById("display_city").textContent = city;
    document.getElementById("display_state").textContent = state;
    
    // Send data via AJAX
    $.ajax({
        type: 'GET',
        url: '{{ url("/contact_info1") }}',
        data: {
            name: name,
            email: email,
            summary: summary,
            phone: phone,
            address: address,
            city: city,
            state: state,
            country: country
        },
        success: function(response) {
            // Log success message if needed
            console.log('Resume fields updated successfully on another page.');
        },
        error: function(xhr, status, error) {
            console.error('Error occurred while updating resume fields:', xhr.responseText);
        }
    });
}

// Listen for changes in form inputs and update resume
document.getElementById("name").addEventListener("input", updateResumeFields);
document.getElementById("email").addEventListener("input", updateResumeFields);
document.getElementById("summary").addEventListener("input", updateResumeFields);
document.getElementById("city").addEventListener("input", updateResumeFields);
document.getElementById("state").addEventListener("input", updateResumeFields);
document.getElementById("country").addEventListener("input", updateResumeFields);
// Listen for more form inputs as needed

</script>

</body>
</html>


<!-- <!doctype html>
<html lang="en">
  <head> -->
    <!-- Required meta tags -->
    <!-- <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="{{url('/')}}/public/assets/css/template_style.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'> -->
<!-- <link href="style.scss" rel="stylesheet"> -->
    <!-- <title>Template</title>
  </head>
  <body>
  <div class="container">
  <div class="header">
    <div class="full-name">
      <span class="first-name" id="display_name">John Doe</span>  -->
      <!-- <span class="last-name">Doe</span> -->
    <!-- </div>
    <div class="contact-info">
      <span class="email">Email: </span>
      <span class="email-val" id="display_email">john.doe@gmail.com</span>
      <span class="separator"></span>
      <span class="phone">Phone: </span>
      <span class="phone-val"  id="display_phone">111-222-3333</span>
    </div>
    <div class="contact-info">
      <span class="email">Add: </span>
      <span class="email-val" id="display_address"></span>
      <span class="separator"></span>
      <span class="phone"> </span>
      <span class="phone-val"  id="display_city"></span>
      <span class="separator"></span>
      <span class="phone">Phone: </span>
      <span class="phone-val"  id="display_state"></span>
      <span class="separator"></span>
      <span class="phone">Phone: </span>
      <span class="phone-val"  id="display_country"></span>
    </div>
    
    <div class="about"> -->
      <!-- <span class="position">Front-End Developer </span> -->
      <!-- <span class="desc"  id="display_summary">
        I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow. 
      </span>
    </div>
  </div>
   <div class="details">
    <div class="section">
      <div class="section__title" >Experience</div>
      <div class="section__list">
        <div class="section__list-item">
          <div class="left">
            <div class="name">KlowdBox</div>
            <div class="addr">San Fr, CA</div>
            <div class="duration">Jan 2011 - Feb 2015</div>
          </div>
          <div class="right">
            <div class="name">Fr developer</div>
            <div class="desc">did This and that</div>
          </div>
        </div>
                <div class="section__list-item">
          <div class="left">
            <div class="name">Akount</div>
            <div class="addr">San Monica, CA</div>
            <div class="duration">Jan 2011 - Feb 2015</div>
          </div>
          <div class="right">
            <div class="name">Fr developer</div>
            <div class="desc">did This and that</div>
          </div>
        </div>

      </div>
    </div>
    <div class="section">
      <div class="section__title">Education</div>
      <div class="section__list">
        <div class="section__list-item">
          <div class="left">
            <div class="name">Sample Institute of technology</div>
            <div class="addr">San Fr, CA</div>
            <div class="duration">Jan 2011 - Feb 2015</div>
          </div>
          <div class="right">
            <div class="name">Fr developer</div>
            <div class="desc">did This and that</div>
          </div>
        </div>
        <div class="section__list-item">
          <div class="left">
            <div class="name">Akount</div>
            <div class="addr">San Monica, CA</div>
            <div class="duration">Jan 2011 - Feb 2015</div>
          </div>
          <div class="right">
            <div class="name">Fr developer</div>
            <div class="desc">did This and that</div>
          </div>
        </div>

      </div>
      
  </div>
     <div class="section">
      <div class="section__title">Projects</div> 
       <div class="section__list">
         <div class="section__list-item">
           <div class="name">DSP</div>
           <div class="text">I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow.</div>
         </div>
         
         <div class="section__list-item">
                    <div class="name">DSP</div>
           <div class="text">I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow. <a href="/login">link</a>
           </div>
         </div>
       </div>
    </div>
     <div class="section">
       <div class="section__title">Skills</div>
       <div class="skills">
         <div class="skills__item">
           <div class="left"><div class="name">
             Javascript
             </div></div>
           <div class="right">
                          <input  id="ck1" type="checkbox" checked/>

             <label for="ck1"></label>
                          <input id="ck2" type="checkbox" checked/>

              <label for="ck2"></label>
                         <input id="ck3" type="checkbox" />

              <label for="ck3"></label>
                           <input id="ck4" type="checkbox" />
            <label for="ck4"></label>
                          <input id="ck5" type="checkbox" />
              <label for="ck5"></label>

           </div>
         </div>
         
       </div>
       <div class="skills__item">
           <div class="left"><div class="name">
             CSS</div></div>
           <div class="right">
                          <input  id="ck1" type="checkbox" checked/>

             <label for="ck1"></label>
                          <input id="ck2" type="checkbox" checked/>

              <label for="ck2"></label>
                         <input id="ck3" type="checkbox" />

              <label for="ck3"></label>
                           <input id="ck4" type="checkbox" />
            <label for="ck4"></label>
                          <input id="ck5" type="checkbox" />
              <label for="ck5"></label>

           </div>
         </div>
         
       </div>
     <div class="section">
     <div class="section__title">
       Interests
       </div>
       <div class="section__list">
         <div class="section__list-item">
                  Football, programming.
          </div>
       </div>
     </div>
     </div>
  </div>
</div>
<script src="{{url('/')}}/public/assets/js/template_script.js"></script>
  </body>
</html> -->