<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>

    <!-- Include CSS files here -->
    <link href="{{url('/')}}/assets/css/style4.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    
</head>

<body>
    <div class="container">
    <div class="header_content_wrapper">
    <!-- Header content here -->            
        <div class="c-media_content">
            <h1 class="l-header_title">Kevin Magnussen</h1>
        </div> 
        <div class="l-header_text">
            <strong>Product Designer&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Mountain View, CA</strong>
        </div>           
    </div>

    <main class="l-wrapper">
        <div class="grid">
            <div class="grid__col grid__col--1-of-3">

                <!-- Contact and Skills content here -->
                <h4 class="u-text--primary">Contact</h4>
                <ul class="c-list">
                    <li class="c-list__item">
                        <img id="icons" src="assets/img/icons_dark/link.png" width="15px">
                        <a class="c-list__link" href="#">
                            www.ryanparag.com
                        </a>
                    </li><hr>
                    <li class="c-list__item">
                        <img id="icons" src="assets/img/icons_dark/email.png" width="15px">
                        <a class="c-list__link" href="#">
                            parag.ryan@gmail.com
                        </a>
                    </li><hr>
                    <li class="c-list__item">
                        <img id="icons" src="assets/img/icons_dark/phone-call.png" width="15px">
                        <a class="c-list__link" href="#">
                            (123) 456-7890
                        </a>
                    </li><hr>
                </ul>
                <h4 class="u-text--primary">Skills</h4>
                <h5 class="u-text--secondary">Design</h5>
                <ul class="c-list">
                    <li class="c-list__item">Adobe Creative Suite</li><hr>
                    <li class="c-list__item">Sketch</li><hr>
                    <li class="c-list__item">Figma</li><hr>
                    <li class="c-list__item">InVision</li><hr>
                </ul>
                <h5 class="u-text--secondary">Technical</h5>
                <ul class="c-list">
                    <li class="c-list__item">HTML, CSS, Python, Javascript, SQL</li><hr>
                </ul>
                <h5 class="u-text--secondary">Process</h5>
                <ul class="c-list">
                    <li class="c-list__item">User Research, Prototyping, Interaction Design</li><hr>
                </ul>
                <h4 class="u-text--primary">Education</h4>
                <ul class="c-list">
                    <li class="c-list__item">
                        <strong>University of Central Florida</strong><br>
                        <span>BA Honors HCI</span><br>
                        <span>Graduated 2014</span><br>
                        <small class="u-text--secondary">Orlando, FL, USA</small>
                    </li><hr>
                </ul>
            </div>

            <div class="grid__col grid__col--2-of-3">
                <!-- Experience content here -->
                <h4 class="u-text--primary">Experience</h4>
                <ul class="c-list">
                    <li class="c-list__item">
                        <strong>Company 1</strong> - Product Designer<br>
                        <span class="u-text--secondary">Mountain View | 2018 - Current</span><br>
                        <p id="job_description"></p>
                    </li><hr>

                    <li class="c-list__item">
                        <strong>Company 2</strong> - Product Designer<br>
                        <span class="u-text--secondary">Mountain View | 2018 - Current</span><br>
                        <p id="job_description"></p>
                    </li><hr>                                
                </ul>
            </div>
        </div>
    </main>
    </div>

<script src="{{url('/')}}/public/assets/js/template_script.js"></script>
<script>
function updateResumeFields() {
// Get form input values
var name = document.getElementById("name").value;
var email = document.getElementById("email").value;
var summary = document.getElementById("summary").value;
var phone = document.getElementById("phone").value;
var address = document.getElementById("address").value;
var city = document.getElementById("city").value;
var state = document.getElementById("state").value;
var country = document.getElementById("country").value;

  // Update resume fields
document.getElementById("display_name").textContent = name;
document.getElementById("display_email").textContent = email;
document.getElementById("display_summary").textContent = summary;
document.getElementById("display_phone").textContent = phone;
document.getElementById("display_address").textContent = address;
document.getElementById("display_city").textContent = city;
document.getElementById("display_state").textContent = state;

    // Send data via AJAX
$.ajax({
    type: 'GET',
    url: '{{ url("/contact_info1") }}',
    data: {
        name: name,
        email: email,
        summary: summary,
        phone: phone,
        address: address,
        city: city,
        state: state,
        country: country
    },
success: function(response) {
    // Log success message if needed
    console.log('Resume fields updated successfully on another page.');
},

error: function(xhr, status, error) {
    console.error('Error occurred while updating resume fields:', xhr.responseText);
}
});
}

// Listen for changes in form inputs and update resume
document.getElementById("name").addEventListener("input", updateResumeFields);
document.getElementById("email").addEventListener("input", updateResumeFields);
document.getElementById("summary").addEventListener("input", updateResumeFields);
document.getElementById("city").addEventListener("input", updateResumeFields);
document.getElementById("state").addEventListener("input", updateResumeFields);
document.getElementById("country").addEventListener("input", updateResumeFields);
// Listen for more form inputs as needed
</script>
</body>
</html>
