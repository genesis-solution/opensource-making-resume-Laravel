@extends('newfrontend.layout.main')  

  

@section('main-container')

<div class="container-fluid py-5 my-5">



        <div class="container pt-5">



            <div class="row g-5">

            <div class="col-lg-7 col-md-6 col-sm-12 wow fadeIn" data-wow-delay=".5s">



<!-- <h5 class="text-primary">Build a resume and cover letter with help from our experts</h5> -->



<h1 class="mb-4">Build a resume and cover letter with help from our experts</h1>



<p>ACS's Resume Builder and Cover Letter Builder provide a simple and quick solution to resume and cover letter writing with custom help and feedback from certified resume writers.</p>



<!-- <p class="mb-4">Pellentesque aliquam dolor eget urna ultricies tincidunt. Nam volutpat libero sit amet leo cursus, ac viverra eros tristique. Morbi quis quam mi. Cras vel gravida eros. Proin scelerisque quam nec elementum viverra. Suspendisse viverra



    hendrerit diam in tempus.</p> -->



<a href="#" class="btn btn-secondary rounded-pill px-5 py-3 text-white">Build My Resume</a>



</div>



                <div class="col-lg-5 col-md-6 col-sm-12 wow fadeIn" data-wow-delay=".3s">



                    <div class="h-100 position-relative">



                        <img src="{{url('/')}}/public/assets/img/template/resume-templates-hero.webp" class="img-fluid w-85 rounded" alt="" style="margin-bottom: 25%;">



                        <!-- <div class="position-absolute w-75" style="top: 25%; left: 25%;">



                            <img src="{{url('/')}}/public/assets/img/about-2.jpg" class="img-fluid w-100 rounded" alt="">



                        </div> -->



                    </div>



                </div>



                



            </div>



        </div>





@endsection