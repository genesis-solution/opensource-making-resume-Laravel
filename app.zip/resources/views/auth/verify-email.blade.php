@extends('layouts.auth')

@section('title', __('Verify Your Email Address'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="card card-primary">
        <div class="card-header">
            <h4>{{ __('Verify Your Email Address') }}</h4>
        </div>

        <div class="card-body">
            @if (session('resent'))
                <div class="alert alert-success" role="alert">
                    {{ __('A fresh verification link has been sent to your email address.') }}
                </div>
            @endif

            @if (session('status') == 'verification-link-sent')
                <div class="p-2 mb-2 bg-success text-white">
                    {{ __('A new email verification link has been emailed to you!') }}
                </div>
            @endif

            <div class="p-2 mb-2">
                {{ __('Before proceeding, please check your email for a verification link.') }} <br/>
                {{ __('If you did not receive the email ...') }}
            </div>

            <form class="d-inline" method="POST" action="{{ route('verification.send') }}">
                @csrf

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-block"
                        tabindex="1">
                        {{ __('Request Again') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
