@extends('layouts.auth')

@section('title', __('Register'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/selectric/public/selectric.css') }}">
@endpush

@section('main')
    <div class="card card-primary">
        <div class="card-header-register card-header">
            <h1>{{ __('Register') }}</h1>
        </div>

        <div class="card-body">
            <form method="POST" 
                action="{{ route('register') }}" 
                id="register"
                class="needs-validation"
                novalidate="">
                @csrf
                
                <div class="row">
                    <div class="form-group col-md-6 col-12">
                        <label for="firstname">{{ __('First Name') }}</label>
                        <input id="firstname"
                            type="text"
                            class="form-control @error('firstname') is-invalid @enderror"
                            tabindex="1"
                            name="firstname"
                            required 
                            value="{{ old('firstname') }}"
                            autocomplete="firstname"
                            autofocus
                        >

                        @error('firstname')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group col-md-6 col-12">
                        <label for="lastname">{{ __('Last Name') }}</label>
                        <input id="lastname"
                            type="text"
                            class="form-control @error('lastname') is-invalid @enderror"
                            tabindex="2"
                            name="lastname"
                            required 
                            value="{{ old('lastname') }}"
                            autocomplete="lastname"
                        >

                        @error('lastname')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">{{ __('Email Address') }}</label>
                    <input id="email"
                        type="email"
                        class="form-control @error('email') is-invalid @enderror"
                        tabindex="3"
                        name="email"
                        required 
                        value="{{ old('email') }}" 
                        required autocomplete="email"
                    >
                    
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="row">
                    <div class="form-group col-md-6 col-12">
                        <label for="password"
                            class="d-block">{{ __('Password') }}</label>
                        <input id="password"
                            type="password"
                            class="form-control pwstrength @error('password') is-invalid @enderror"
                            tabindex="4"
                            data-indicator="pwindicator"
                            name="password"
                            required 
                            autocomplete="new-password"
                        >
                        <div id="pwindicator"
                            class="pwindicator">
                            <div class="bar"></div>
                            <div class="label"></div>
                        </div>

                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group col-md-6 col-12">
                        <label for="password-confirm"
                            class="d-block">{{ __('Confirm Password') }}</label>
                        <input id="password-confirm"
                            type="password"
                            class="form-control"
                            tabindex="5"
                            name="password_confirmation"
                            required 
                            autocomplete="new-password"
                        >
                    </div>
                </div>

                <div class="form-group">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox"
                            class="custom-control-input"
                            name="agree"
                            required 
                            tabindex="6"
                            id="agree">
                        <label class="custom-control-label"
                            for="agree">{!! __('I agree to the :terms and :privacy.', ['terms' => mb_strtolower('<a href="'. config('settings.legal_terms_url') .'" class="register-link" target="_blank">'. __('Terms & Conditions').'</a>'), 'privacy' => mb_strtolower('<a href="'. config('settings.legal_privacy_url') .'" class="register-link" target="_blank">'. __('Privacy Policy') .'</a>')]) !!}</label>
                    </div>
                </div>

                @if ($errors->has('g-recaptcha-response'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                    </span>
                @endif

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-block"
                        tabindex="7">
                        {{ __('Register') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <!-- JS Libraies -->
    <script src="{{ asset('vendor/selectric/public/jquery.selectric.min.js') }}"></script>
    <script src="{{ asset('vendor/jquery-pwstrength/jquery.pwstrength.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script src="{{ asset('js/page/auth-register.min.js?v='. config('info.software.version')) }}"></script>
    @if( config('settings.google_recaptcha') == '1' )
    <script src="https://www.google.com/recaptcha/api.js?render={{ env('GOOGLE_RECAPTCHA_KEY') }}"></script>
    <script type="text/javascript">
        $('#register').submit(function(event) {
            event.preventDefault();
        
            grecaptcha.ready(function() {
                grecaptcha.execute("{{ env('GOOGLE_RECAPTCHA_KEY') }}", {action: 'subscribe_newsletter'}).then(function(token) {
                    $('#register').prepend('<input type="hidden" name="g-recaptcha-response" value="' + token + '">');
                    $('#register').unbind('submit').submit();
                });;
            });
        });
    </script>
    @endif
@endpush
