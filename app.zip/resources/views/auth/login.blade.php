@extends('layouts.auth')

@section('title', __('Login'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-social/bootstrap-social.css?v='. config('info.software.version')) }}">
@endpush

@section('main')
    <div class="card card-primary">
        <div class="card-header-login card-header">
            <h1>{{ __('Login') }}</h1>
        </div>
        
        <div class="card-body">
            <div id="output-status">
                @if(session('message'))
                    <div class="alert alert-danger">
                        {{ session('message') }}
                    </div>
                @endif
            </div>

            <form method="POST"
                action="{{ route('login') }}"
                id="login"
                class="needs-validation"
                novalidate="">
                @csrf
                
                <div class="form-group">
                    <label for="email">{{ __('Email Address') }}</label>
                    <input id="email"
                        type="email"
                        class="form-control @error('email') is-invalid @enderror"
                        name="email"
                        tabindex="1"
                        value="{{ old('email') }}"
                        required
                        autocomplete="email"
                        autofocus
                    >

                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <div class="d-block">
                        <label for="password"
                            class="control-label">{{ __('Password') }}</label>
                    </div>
                    <input id="password"
                        type="password"
                        class="form-control @error('password') is-invalid @enderror"
                        name="password"
                        tabindex="2"
                        autocomplete="current-password"
                        required>

                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox"
                            name="remember"
                            class="custom-control-input"
                            tabindex="3"
                            id="remember-me"
                            {{ old('remember') ? 'checked' : '' }}
                        >
                        <label class="custom-control-label"
                            for="remember-me">{{ __('Remember Me') }}</label>
                    </div>
                </div>

                <div class="form-group p-2 mt-2 mb-2">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-icon icon-right"
                        tabindex="4">
                        {{ __('Login') }}
                    </button>

                    @if (Route::has('password.request'))
                    <div class="p-2 mt-2 mb-2">
                        <a class="float-left login-link mt-3" href="{{ route('password.request') }}">
                            {{ __('Forgot Your Password?') }}
                        </a>
                    </div>
                    @endif
                </div>

                @if(config('settings.facebook') == '1' || config('settings.twitter') == '1' || config('settings.linkedin') == '1' || config('settings.google') == '1' || config('settings.github') == '1')
                <div class="mt-5 mb-2 text-center">
                    <div class="text-job text-muted">{{ __('Login With Social') }}</div>
                </div>
                <div class="row sm-gutters text-center">
                   <div class="col-12">
                        @if( config('settings.facebook') == '1' )
                        <a href="{{ url('login/facebook') }}" class="btn btn-social-icon btn-facebook"><i class="fa-brands fa-facebook"></i></a>
                        @endif
                        @if( config('settings.twitter') == '1' )
                        <a href="{{ url('login/twitter') }}" class="btn btn-social-icon btn-x-twitter"><i class="fa-brands fa-x-twitter"></i></a>
                        @endif
                        @if( config('settings.linkedin') == '1' )
                        <a href="{{ url('login/linkedin') }}" class="btn btn-social-icon btn-linkedin"><i class="fa-brands fa-linkedin"></i></a>
                        @endif
                        @if( config('settings.google') == '1' )
                        <a href="{{ url('login/google') }}" class="btn btn-social-icon btn-google"><i class="fa-brands fa-google"></i></a>
                        @endif
                        @if( config('settings.github') == '1' )
                        <a href="{{ url('login/github') }}" class="btn btn-social-icon btn-github"><i class="fa-brands fa-github"></i></a>
                        @endif
                   </div>
                </div>
                @endif

                @if( config('settings.registration') == '1' )
                <div class="text-muted mt-5 text-center">
                    {{ __('Don`t have an account?') }} <a href="/register" class="login-link">{{ __('Create new one') }}</a>
                </div>
                @endif

            </form>
            
        </div>
    </div>
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
    @if( config('settings.google_recaptcha') == '1' )
    <script src="https://www.google.com/recaptcha/api.js?render={{ env('GOOGLE_RECAPTCHA_KEY') }}"></script>
    <script type="text/javascript">
        $('#login').submit(function(event) {
            event.preventDefault();
        
            grecaptcha.ready(function() {
                grecaptcha.execute("{{ env('GOOGLE_RECAPTCHA_KEY') }}", {action: 'subscribe_newsletter'}).then(function(token) {
                    $('#login').prepend('<input type="hidden" name="g-recaptcha-response" value="' + token + '">');
                    $('#login').unbind('submit').submit();
                });;
            });
        });
    </script>
    @endif
@endpush
