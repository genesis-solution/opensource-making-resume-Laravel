@extends('layouts.auth')

@section('title', __('Forgot Password'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="card card-primary">
        <div class="card-header-forgot card-header">
            <h1>{{ __('Forgot Password') }}</h1>
        </div>

        <div class="card-body">
            <p class="text-muted">{{ __('We will send a link to reset your password.') }}</p>

            @if (session('status'))
                <div class="p-2 mb-2 bg-success text-white">
                    {{ session('status') }}
                </div>
            @endif

            <form method="POST" action="{{ route('password.email') }}">
                @csrf

                <div class="form-group">
                    <label for="email">{{ __('Email Address') }}</label>
                    <input id="email"
                        type="email"
                        class="form-control @error('email') is-invalid @enderror"
                        name="email"
                        value="{{ $email ?? old('email') }}"
                        tabindex="1"
                        required
                        autocomplete="email"
                        autofocus
                    >

                     @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-block"
                        tabindex="2">
                        {{ __('Send Password Reset Link') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
