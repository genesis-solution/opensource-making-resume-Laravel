@extends('layouts.auth')

@section('title', __('Two factor Challenge'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <div class="card card-primary">
        <div class="card-header">
            <h4>{{ __('Authentication code') }}</h4>
        </div>

        <div class="card-body">
            @if (session('status'))
                <div class="p-2 mb-2 bg-success text-white">
                    {{ session('status') }}
                </div>
            @endif

            <p>
                {{ __('Please enter your authentication code to login.') }}
            </p>

            <form method="POST" action="{{ route('two-factor.login') }}">
                @csrf

                <div class="form-group">
                    <label for="code">{{ __('Authentication code') }}</label>
                    <input id="code"
                        type="code"
                        class="form-control @error('code') is-invalid @enderror"
                        name="code"
                        value="{{ old('code') }}"
                        required
                        autocomplete="current-code"
                        autofocus
                    >

                     @error('code')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-block"
                        tabindex="2">
                        {{ __('Submit') }}
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card card-primary">
        <div class="card-header">
            <h4>{{ __('Recovery Code') }}</h4>
        </div>

        <div class="card-body">
            @if (session('status'))
                <div class="p-2 mb-2 bg-success text-white">
                    {{ session('status') }}
                </div>
            @endif

            <p>
                {{ __('Please enter your recovery code to login.') }}
            </p>

            <form method="POST" action="{{ route('two-factor.login') }}">
                @csrf

                <div class="form-group">
                    <label for="recovery_code">{{ __('Recovery Code') }}</label>
                    <input id="recovery_code"
                        type="recovery_code"
                        class="form-control @error('recovery_code') is-invalid @enderror"
                        name="recovery_code"
                        value="{{ old('recovery_code') }}"
                        required
                        autocomplete="current-recovery_code"
                    >

                     @error('recovery_code')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary btn-lg btn-block"
                        tabindex="2">
                        {{ __('Submit') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
