<!doctype html>
<html lang="{{ config('settings.language') ?? 'en' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name') }}</title>
    <link rel="shortcut icon" href="{{ config('app.favicon') }}">

     <!-- General CSS Files -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/fontawesome/css/all.min.css?v='. config('info.software.version')) }}">

    @stack('style')

    <!-- Template CSS -->
    <link rel="stylesheet"
        href="{{ asset('css/style.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('css/components.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('css/resumaine.min.css?v='. config('info.software.version')) }}">

    @if( config('settings.site_theme_color') || config('settings.site_bg_primary_color') || config('settings.site_bg_secondary_color') || config('settings.site_button_color') || config('settings.site_button_hover_color') )

    <style>
        @include('theme')
    </style>
    @endif

    @if(config('settings.site_custom_css'))

    <style>
        {!! config('settings.site_custom_css') !!}
    </style>
    @endif

    @if(config('settings.site_custom_head_js'))
    
        {!! config('settings.site_custom_head_js') !!}
    @endif
</head>
<body>
    <div id="app">
        <div class="main-wrapper">
            <!-- Header -->
            @include('components.app-header')

            <!-- Sidebar -->
            @include('components.sidebar')

            <!-- Content -->
            @yield('main')

            <!-- Footer -->
            @include('components.app-footer')
        </div>
    </div>

    <!-- General JS Scripts -->
    <script src="{{ asset('vendor/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('vendor/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('vendor/tooltip.js/dist/umd/tooltip.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendor/jquery.nicescroll/dist/jquery.nicescroll.min.js') }}"></script>
    <script src="{{ asset('vendor/moment/min/moment.min.js') }}"></script>
    <script src="{{ asset('js/resumaine.min.js?v='. config('info.software.version')) }}"></script>

    @stack('scripts')

    <!-- Template JS File -->
    <script src="{{ asset('js/scripts.min.js?v='. config('info.software.version')) }}"></script>

    @if(config('settings.site_custom_body_js'))

        {!! config('settings.site_custom_body_js') !!}
    @endif
</body>
</html>
