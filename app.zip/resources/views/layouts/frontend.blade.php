<!doctype html>
<html lang="{{ config('settings.language') ?? 'en' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, shrink-to-fit=no">
    
    <meta name="description" content="@hasSection('description')@yield('description')@else{{ config('settings.site_meta_description') }}@endif">
    <meta name="keywords" content="@hasSection('keywords')@yield('keywords')@else{{ config('settings.site_meta_keywords') }}@endif">
    <meta name="author" content="{{ config('app.name') }}">

    <meta property="og:title" content="@hasSection('title')@yield('title')@else{{ config('settings.site_meta_title') }}@endif">
    <meta property="og:description" content="@hasSection('description')@yield('description')@else{{ config('settings.site_meta_description') }}@endif">
    <meta property="og:image" content="@hasSection('image')@yield('image')@else{{ config('app.logo') }}@endif">
    <meta property="og:url" content="@hasSection('url')@yield('url')@else{{ config('settings.site_url') }}@endif">

    <meta name="twitter:title" content="@hasSection('title')@yield('title')@else{{ config('settings.site_meta_title') }}@endif">
    <meta name="twitter:description" content="@hasSection('description')@yield('description')@else{{ config('settings.site_meta_description') }}@endif">
    <meta name="twitter:image" content="@hasSection('image')@yield('image')@else{{ config('app.logo') }}@endif">
    <meta name="twitter:card" content="summary_large_image">
    
    <title>@hasSection('title')@yield('title') - {{ config('settings.site_name') }}@else{{ config('settings.site_meta_title') }}@endif</title>
    <link rel="shortcut icon" href="{{ config('app.favicon') }}">

    <!-- General CSS Files -->
    <link rel="stylesheet" href="{{ asset('vendor/prismjs/themes/prism.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/fontawesome/css/all.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet" href="{{ asset('vendor/chocolat/dist/css/chocolat.css') }}">
    @if( config('settings.cookie_consent') == 1 )
    <link rel="stylesheet" href="{{ asset('vendor/vanilla-cookieconsent/dist/cookieconsent.css?v='. config('info.software.version')) }}">
    @endif

    @stack('style')

    <!-- Template CSS -->
    <link rel="stylesheet" href="{{ asset('css/style.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet" href="{{ asset('css/components.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet" href="{{ asset('css/resumaine.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet" href="{{ asset('css/landing.min.css?v='. config('info.software.version')) }}">

    @if( config('settings.site_theme_color') || config('settings.site_bg_primary_color') || config('settings.site_bg_secondary_color') || config('settings.site_button_color') || config('settings.site_button_hover_color') )

    <style>
        @include('theme')
    </style>
    @endif

    @if(config('settings.site_custom_css'))

    <style>
        {!! config('settings.site_custom_css') !!}
    </style>
    @endif

    @if( config('settings.google_analytics') == 1 )

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id={{ config('settings.google_analytics_code') }}"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}

        gtag('js', new Date());
        gtag('config', '{{ config('settings.google_analytics_code') }}');

        // Default ad_storage, analytics_storage to 'denied'.
        gtag('consent', 'default', {
            'ad_storage': 'denied',
            'analytics_storage': 'denied'
        });
    </script>
    @endif

    @if( config('settings.google_adsense') == 1 )
    
    <!-- Google AdSense -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={{ config('settings.google_adsense_code') }}"
        crossorigin="anonymous"></script>

    @endif

    @if(config('settings.site_custom_head_js'))
    
        {!! config('settings.site_custom_head_js') !!}
    @endif
</head>
<body>
    <!-- Content -->
     @yield('main')

     <!-- General JS Scripts -->
    <script src="{{ asset('vendor/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('vendor/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('vendor/tooltip.js/dist/umd/tooltip.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendor/jquery.nicescroll/dist/jquery.nicescroll.min.js') }}"></script>
    <script src="{{ asset('vendor/moment/min/moment.min.js') }}"></script>
    <script src="{{ asset('vendor/prismjs/prism.js') }}"></script>
    <script src="{{ asset('vendor/scrollup/dist/jquery.scrollUp.min.js?v='. config('info.software.version')) }}"></script>
    @if( config('settings.cookie_consent') == 1 )
    <script src="{{ asset('vendor/vanilla-cookieconsent/dist/cookieconsent.js?v='. config('info.software.version')) }}"></script>
    @endif
    <script src="{{ asset('js/resumaine.min.js?v='. config('info.software.version')) }}"></script>
    <script src="{{ asset('js/landing.min.js?v='. config('info.software.version')) }}"></script>

    @stack('scripts')

    <!-- Template JS File -->
    <script src="{{ asset('js/scripts.min.js?v='. config('info.software.version')) }}"></script>

    @if( config('settings.tawk') == 0 )

    <script>
        $(function () {
            // ScrollUp
            $.scrollUp({
                animation: 'fade',
                scrollImg: true
            });
        });
    </script>
    @endif

    @if( config('settings.cookie_consent') == 1 )
    <script>
        var cookieconsent_name = "cc_{{ Str::slug(env('APP_NAME', 'laravel'), '_') }}_cookie";
        var google_analytics_code = "{{ config('settings.google_analytics_code') }}";
        var legal_cookie_url = "{{ config('settings.legal_cookie_url') }}";
        var cookieconsent_lang = "{{ config('settings.language') }}";
        var cookieconsent_modal_layout = "{{ config('settings.cookie_consent_modal_layout') }}";
        var cookieconsent_modal_position = "{{ config('settings.cookie_consent_modal_position') }}";
        var cookieconsent_modal_orientation = " {{ config('settings.cookie_consent_modal_orientation') }}";
        var cookieconsent_modal_title = "{{ __('We use cookies') }}";
        var cookieconsent_modal_description = "{!! __('Our website uses essential cookies to ensure its proper operation and to make your interactions with us, easy and meaningful. By using this website, you agree to our use of cookies. :button', ['button' => '<button type=\"button\" data-cc=\"c-settings\" class=\"cc-link\">'. __('Manage Preferences') .'</button>']) !!}";
        var cookieconsent_modal_accept_all_btn = "{{ __('Accept All') }}";
        var cookieconsent_modal_reject_all_btn = "{{ __('Accept Necessary') }}";
        var cookieconsent_settings_title = "{{ __('Cookie Preferences') }}";
        var cookieconsent_settings_save_btn = "{{ __('Save settings') }}";
        var cookieconsent_settings_close_btn = "{{ __('Close') }}";
        var cookieconsent_settings_table_col1 = "{{ __('Name') }}";
        var cookieconsent_settings_table_col2 = "{{ __('Domain') }}";
        var cookieconsent_settings_table_col3 = "{{ __('Expiration') }}";
        var cookieconsent_settings_table_col4 = "{{ __('Description') }}";
        var cookieconsent_settings_block1_title = "{{ __('Your privacy is important to us') }}";
        var cookieconsent_settings_block1_description = "{!! __('Cookies are tiny text files that get saved on your computer when you visit a website. They serve various purposes and aim to improve your online experience on our website. If you wish, you can modify your preferences and decline specific types of cookies from being stored on your computer while browsing our site. Moreover, you have the option to delete any existing cookies; however, be aware that doing so might limit your ability to access certain parts of our website. For more detailed information about cookies and other sensitive data, please read our :legal', ['legal' => mb_strtolower('<a href=\"'. config('settings.legal_cookie_url') .'\" class=\"cc-link\">'. __('Privacy Policy') .'</a>.')]) !!}";
        var cookieconsent_settings_block2_title = "{{ __('Strictly Necessary Cookies') }}";
        var cookieconsent_settings_block2_description = "{{ __('These cookies are crucial for the smooth functioning of the services provided on our website and for enabling you to access certain features that enhance your interactions with us to be effortless and significant. The website and its services would not function properly or effectively without the presence of these cookies.') }}";
        var cookieconsent_settings_block3_title = "{{ __('Performance and Analytics Cookies') }}";
        var cookieconsent_settings_block3_description = "{{ __('These cookies gather data to analyze website traffic and visitor behavior, but do not disclose personal information about individual users.') }}";
        var cookieconsent_settings_block4_title = "{{ __('Targeting and Advertising Cookies') }}";
        var cookieconsent_settings_block4_description = "{{ __('These cookies are employed to display advertisements that are tailored to your interests, taking into consideration your browsing patterns. Our content and advertising providers utilize these cookies to combine information gathered from our website with other data they have independently collected regarding the online activities of your web browser. If you decide to deactivate these cookies, which are used for targeting or advertising purposes, you will still encounter advertisements, but they may not be as applicable to you.') }}";
        var cookieconsent_settings_block5_title = "{{ __('More information') }}";
        var cookieconsent_settings_block5_description = "{!! __('For any questions regarding our cookie policy and the options available to you, please :contact.', ['contact' => mb_strtolower('<a class=\"cc-link\" href=\"/contact\">'. __('contact us') .'</a>')]) !!}";
        var cookieconsent_settings_block_hours = "{{ __('hours') }}";
        var cookieconsent_settings_block_days = "{{ __('days') }}";
        var cookieconsent_settings_block_weeks = "{{ __('weeks') }}";
        var cookieconsent_settings_block_months = "{{ __('months') }}";
        var cookieconsent_settings_block_years = "{{ __('years') }}";
    </script>
    <script src="{{ asset('js/cookie-consent.min.js?v='. config('info.software.version')) }}"></script>
    @endif

    @if(config('settings.site_custom_body_js'))

        {!! config('settings.site_custom_body_js') !!}
    @endif
    </body>
</html>
