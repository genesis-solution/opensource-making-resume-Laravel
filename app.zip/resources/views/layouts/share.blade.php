<!doctype html>
<html lang="{{ config('settings.language') ?? 'en' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1">

    <title>@yield('title') &mdash; {{ config('app.name') }}</title>

    <link rel="shortcut icon" href="{{ config('app.favicon') }}">

    <!-- General CSS Files -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('vendor/fontawesome/css/all.min.css?v='. config('info.software.version')) }}">

    @stack('style')

    <!-- Template CSS -->
    <link rel="stylesheet"
        href="{{ asset('css/style.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('css/components.min.css?v='. config('info.software.version')) }}">
    <link rel="stylesheet"
        href="{{ asset('css/resumaine.min.css?v='. config('info.software.version')) }}">

    @if(config('settings.site_custom_css'))
    
    <style>
        {!! config('settings.site_custom_css') !!}
    </style>
    @endif

</head>
<body>
    <div id="app">
        <section class="section">
            <div class="mt-5">
                <!-- Header -->
                @include('components.share-header')

                <!-- Content -->
                @yield('main')

                <!-- Footer -->
                @include('components.share-footer')
            </div>
        </section>
    </div>

    <!-- General JS Scripts -->
    <script src="{{ asset('vendor/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('vendor/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('vendor/tooltip.js/dist/umd/tooltip.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendor/jquery.nicescroll/dist/jquery.nicescroll.min.js') }}"></script>
    <script src="{{ asset('vendor/moment/min/moment.min.js') }}"></script>
    <script src="{{ asset('js/resumaine.min.js?v='. config('info.software.version')) }}"></script>

    @stack('scripts')

    <!-- Template JS File -->

</body>
</html>
