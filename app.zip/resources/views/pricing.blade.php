@extends('layouts.frontend')

@section('title', __('Pricing'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    @if( config('settings.subscription') == 1 ) 
    <section id="pricing" class="section-pricing-inside">
        <div class="container">
            <div class="row mb-5 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h1>{!! $frontend::highlightWords(config('frontends.frontend_pricing_headline'), $frontend::stringtoArray(config('frontends.frontend_pricing_highlight_words'))) !!}</h1>
                    <p class="lead">{{ config('frontends.frontend_pricing_description') }}</p>
                </div>
            </div>
            <div>
                @include('components.pricing')
            </div>
        </div>
    </section>
    @endif
    @if( config('frontends.frontend_faqs') == 1 && $faq_count > 0 && config('settings.language') == 'en' ) 
    <section id="faqs" class="section-pricing-faqs-inside">
        <div class="container">
            <div class="row mb-5 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h2>{!! $frontend::highlightWords(config('frontends.frontend_faqs_headline'), $frontend::stringtoArray(config('frontends.frontend_faqs_highlight_words'))) !!}</h2>
                    <p class="lead">{{ config('frontends.frontend_faqs_description') }}</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-faqs">
                        @foreach( collect($faqs)->sortBy('f_order') as $faq )
                            @if($faq->f_status == 1) 
                            <div class="faq">
                                <div class="faq-icon">
                                    <i class="{{ $faq->f_icon }}"></i>
                                </div>
                                <h3>{{ $faq->f_title }}</h3>
                                <p>{{ $faq->f_description }}</p>
                            </div>
                            @endif
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif
    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush