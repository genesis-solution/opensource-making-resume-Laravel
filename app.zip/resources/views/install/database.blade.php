@extends('layouts.install')

@section('title', __('Database Configuration'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                @include('install.steps')
            </div>
            <div class="card-body">
                <form method="POST" 
                action="{{ route('install.database') }}" 
                class="needs-validation"
                novalidate="">
                @csrf
                    <div class="d-block text-center mb-4 mt-2">
                        <h5>{{ __('Database Configuration') }}</h5>
                    </div>

                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif

                    <div class="row mx-n2">
                        <div class="col px-2">
                            <div class="form-group">
                                <label for="database_hostname">{{ __('Hostname') }}</label>
                                <input type="text" 
                                    name="database_hostname" 
                                    id="database_hostname" 
                                    value="{{ old('database_hostname') ?? '127.0.0.1' }}" 
                                    class="form-control @error('database_hostname') is-invalid @enderror"
                                    required>

                                @error('database_hostname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="col px-2">
                            <div class="form-group">
                                <label for="database_port">{{ __('Server Port') }}</label>
                                <input type="text" 
                                    name="database_port" 
                                    id="database_port" 
                                    value="{{ old('database_port') ?? '3306' }}" 
                                    class="form-control @error('database_port') is-invalid @enderror"
                                    required>

                                @error('database_port')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="database_name">{{ __('Database Name') }}</label>
                        <input type="text" 
                            name="database_name" 
                            id="database_name" 
                            value="{{ old('database_name') }}" 
                            class="form-control @error('database_name') is-invalid @enderror"
                            required>

                        @error('database_name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="database_username">{{ __('Username') }}</label>
                        <input type="text" 
                            name="database_username" 
                            id="database_username" 
                            value="{{ old('database_username') }}" 
                            class="form-control @error('database_username') is-invalid @enderror"
                            required>

                        @error('database_username')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="database_password">{{ __('Password') }}</label>
                        <input type="password" 
                            name="database_password" 
                            id="database_password" 
                            value="{{ old('database_password') }}" 
                            class="form-control @error('database_password') is-invalid @enderror">

                        @error('database_password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke text-center">
                    <button type="submit"
                        class="btn btn-primary">
                        {{ __('Next') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
