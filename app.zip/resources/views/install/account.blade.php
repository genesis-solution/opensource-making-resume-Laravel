@extends('layouts.install')

@section('title', __('Admin Credentials'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                @include('install.steps')
            </div>
            <div class="card-body">
                <form method="POST" 
                action="{{ route('install.account') }}" 
                class="needs-validation"
                novalidate="">
                @csrf
                    <div class="d-block text-center mb-4 mt-2">
                        <h5>{{ __('Admin Credentials') }}</h5>
                    </div>

                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif

                    <div class="row mx-n2">
                        <div class="col px-2">
                            <div class="form-group">
                                <label for="firstname">{{ __('First Name') }}</label>
                                <input type="text" 
                                    name="firstname" 
                                    id="firstname" 
                                    value="{{ old('firstname') }}" 
                                    class="form-control @error('firstname') is-invalid @enderror"
                                    required>

                                @error('firstname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col px-2">
                            <div class="form-group">
                                <label for="lastname">{{ __('Last Name') }}</label>
                                <input type="text" 
                                    name="lastname" 
                                    id="lastname" 
                                    value="{{ old('lastname') }}" 
                                    class="form-control @error('lastname') is-invalid @enderror"
                                    required>

                                @error('lastname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">{{ __('Email Address') }}</label>
                        <input type="email" 
                            name="email" 
                            id="email" 
                            value="{{ old('email') }}" 
                            class="form-control @error('email') is-invalid @enderror"
                            required>

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="password">{{ __('Password') }}</label>
                        <input type="password" 
                            name="password" 
                            id="password" 
                            value="{{ old('password') }}" 
                            class="form-control pwstrength @error('password') is-invalid @enderror"
                            required>

                            <div id="pwindicator"
                                class="pwindicator">
                                <div class="bar"></div>
                                <div class="label"></div>
                            </div>

                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="password_confirmation">{{ __('Confirm Password') }}</label>
                        <input type="password" 
                            name="password_confirmation" 
                            id="password_confirmation" 
                            value="{{ old('password_confirmation') }}" 
                            class="form-control @error('password_confirmation') is-invalid @enderror"
                            required>

                        @error('password_confirmation')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>
                <div class="card-footer bg-whitesmoke text-center">
                    <button type="submit"
                        class="btn btn-primary">
                        {{ __('Next') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
    <!-- JS Libraries -->
    <script src="{{ asset('vendor/jquery-pwstrength/jquery.pwstrength.min.js') }}"></script>

    <!-- Page Specific JS File -->
    <script src="{{ asset('js/page/auth-register.min.js?v='. config('info.software.version')) }}"></script>
@endpush