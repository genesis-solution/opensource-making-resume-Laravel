<div class="nav flex-column mx-auto">
    <ul class="nav nav-pills d-flex justify-content-center">
        @foreach (config('install.steps') as $step)
            <li class="nav-item mx-1">
                @if(Route::currentRouteName() == $step['route'])
                    <a href="{{ route($step['route']) }}" class="btn btn-primary btn-lg d-flex text-center">
                        <span><i class="{{ $step['icon'] }}"></i></span>
                    </a>
                @else
                    <a href="#" class="btn d-flex align-items-center disabled">
                        <span><i class="{{ $step['icon'] }}"></i></span>
                    </a>
                @endif
            </li>
        @endforeach
    </ul>
</div>