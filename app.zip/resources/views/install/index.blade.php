@extends('layouts.install')

@section('title', __('Installation'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                @include('install.steps')
            </div>
            <div class="card-body">
                <div class="d-block text-center mb-4 mt-2">
                    <h5>{{ __('Install') }}</h5>
                </div>
                <div>
                    <p class="text-center text-muted mb-0">{!! __(':name installation wizard.', ['name' => '<span class="font-weight-bold">'.config('info.software.name').'</span>']) !!}</p>
                </div>
            </div>
            <div class="card-footer bg-whitesmoke text-center">
                <a href="{{ route('install.requirements') }}"
                    class="btn btn-primary">
                    {{ __('Start') }}
                </a>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
