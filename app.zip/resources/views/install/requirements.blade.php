@extends('layouts.install')

@section('title', __('Requirements'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                @include('install.steps')
            </div>
            <div class="card-body">
                <div class="d-block text-center mb-4 mt-2">
                    <h5>{{ __('Requirements') }}</h5>
                </div>
                    
                @foreach($results['extensions'] as $type => $extension)
                    <div class="list-group list-group-flush {{ $loop->index == 0 ? 'mb-n3 mt-n3' : 'mt-3 mb-n3 pt-3' }}">
                        <div class="list-group-item px-0">
                            <div class="row align-items-center">
                                <div class="col">
                                    <span class="font-weight-bold">{{ mb_strtoupper($type) }}</span>
                                    @if($type == 'php')
                                        {{ config('install.php_version') }}+
                                    @endif
                                </div>

                                <div class="col-auto d-flex align-items-center">
                                    @if($type == 'php')
                                        @if(version_compare(PHP_VERSION, config('installer.php_version')) >= 0)
                                            <i class="fa-solid fa-check text-success"></i>
                                        @else
                                            <i class="fa-solid fa-times text-danger"></i>
                                        @endif
                                    @endif
                                </div>
                            </div>
                        </div>

                        @foreach($extension as $name => $enabled)
                            <div class="list-group-item px-0 text-muted">
                                <div class="row align-items-center">
                                    <div class="col">
                                        {{ $name }}
                                    </div>
                                    <div class="col-auto d-flex align-items-center">
                                        @if($enabled)
                                            <i class="fa-solid fa-check text-success"></i>
                                        @else
                                            <i class="fa-solid fa-times text-danger"></i>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endforeach
            </div>
            @if(isset($results['errors']) == false)
            <div class="card-footer bg-whitesmoke text-center">
                <a href="{{ route('install.permissions') }}"
                    class="btn btn-primary">
                    {{ __('Next') }}
                </a>
            </div>
            @endif
        </div>
    </div>
</div>

@endsection

@push('scripts')
    <!-- JS Libraries -->

    <!-- Page Specific JS File -->
@endpush
