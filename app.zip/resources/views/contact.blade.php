@extends('layouts.frontend')

@section('title', __('Contact'))

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/intl-tel-input/build/css/intlTelInput.min.css') }}">
@endpush

@section('main')
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    <section id="contact-section" class="section-pricing-inside">
        <div class="container">
            @if( config('frontends.frontend_contact') == 1 ) 
            <div class="row mb-5 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h1>{!! $frontend::highlightWords(config('frontends.frontend_contact_headline'), $frontend::stringtoArray(config('frontends.frontend_contact_highlight_words'))) !!}</h1>
                    <p class="lead">{{ config('frontends.frontend_contact_description') }}</p>
                </div>
            </div>
            @endif
            <div class="row">
                <div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" 
                                action="{{ url('/contact') }}" 
                                id="contact"
                                class="needs-validation"
                                novalidate="">
                                @csrf

                                <div id="output-status">
                                    @if(session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                </div>
                                <div class="row">
                                    <div class="form-group floating-addon col-12">
                                        <label for="name">{{ __('Name') }}</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fa-regular fa-user"></i>
                                                </div>
                                            </div>
                                            <input id="name"
                                                type="text"
                                                class="form-control @error('name') is-invalid @enderror"
                                                tabindex="1"
                                                name="name"
                                                placeholder="{{ __('Name') }}"
                                                required 
                                                value="{{ old('name') }}"
                                                autocomplete="name"
                                                autofocus
                                            >

                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group floating-addon col-md-6 col-12">
                                        <label for="email">{{ __('Email Address') }}</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fa-regular fa-envelope"></i>
                                                </div>
                                            </div>
                                            <input id="email"
                                                type="email"
                                                class="form-control @error('email') is-invalid @enderror"
                                                tabindex="2"
                                                name="email"
                                                placeholder="{{ __('Email') }}"
                                                required 
                                                value="{{ old('email') }}" 
                                                autocomplete="email"
                                            >

                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group floating-addon col-md-6 col-12">
                                        <label for="phone">{{ __('Phone') }}</label>
                                        <input id="phone"
                                            type="tel"
                                            class="form-control @error('phone') is-invalid @enderror"
                                            name="phone"
                                            tabindex="3"
                                            value="{{ old('full_phone') }}"
                                            autocomplete="tel">

                                        <span id="phone_output"></span>

                                        @error('phone')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group floating-addon col-12">
                                        <label for="subject">{{ __('Subject') }}</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <i class="fa-regular fa-comment"></i>
                                                </div>
                                            </div>
                                            <input id="subject"
                                                type="text"
                                                class="form-control @error('subject') is-invalid @enderror"
                                                tabindex="4"
                                                name="subject"
                                                placeholder="{{ __('Subject') }}"
                                                required 
                                                value="{{ old('subject') }}"
                                                autocomplete="subject"
                                            >

                                            @error('subject')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label for="message">{{ __('Message') }}</label>
                                        <textarea id="message"
                                            class="form-control @error('message') is-invalid @enderror"
                                            tabindex="5"
                                            name="message"
                                            placeholder="{{ __('Type your message') }}"
                                            required
                                            data-height="150"
                                            style="height:150px;">{{ old('message') }}</textarea>

                                        @error('message')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    @if ($errors->has('g-recaptcha-response'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                        </span>
                                    @endif
                                
                                    <div class="form-group">
                                        <button type="submit"
                                            class="btn btn-primary btn-lg btn-block ml-3"
                                            tabindex="6">
                                            {{ __('Send Message') }}
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')

    <!-- JS Libraies -->
    <script src="{{ asset('vendor/intl-tel-input/build/js/intlTelInput.min.js') }}"></script>

    <!-- Page Specific JS File -->
    @if( config('settings.google_recaptcha') == '1' )
    <script src="https://www.google.com/recaptcha/api.js?render={{ env('GOOGLE_RECAPTCHA_KEY') }}"></script>
    <script type="text/javascript">
        $('#contact').submit(function(event) {
            event.preventDefault();
        
            grecaptcha.ready(function() {
                grecaptcha.execute("{{ env('GOOGLE_RECAPTCHA_KEY') }}", {action: 'subscribe_newsletter'}).then(function(token) {
                    $('#contact').prepend('<input type="hidden" name="g-recaptcha-response" value="' + token + '">');
                    $('#contact').unbind('submit').submit();
                });;
            });
        });
    </script>
    @endif
    
    <script type="text/javascript">
        // International Phone Input
        var intlTelUtilInputSelector = '#phone';
        var intlTelUtilOutputSelector = '#phone_output';
        var intlTelUtilInitialCountry = "{{ config('settings.country') }}";
        var intlTelUtilPath = "{{ asset('vendor/intl-tel-input/build/js/utils.js') }}";

        var intlTelLangValidNumber = "{{ __('Valid number! Full international format:') }}";
        var intlTelLangInvalidNumber = "{{ __('Invalid number - please try again') }}";
        var intlTelLangPleaseEnterValidNumber = "{{ __('Please enter a valid number below') }}";      
    </script>
    <script src="{{ asset('js/page/user-intl-tel.min.js?v='. config('info.software.version')) }}"></script>

@endpush
