<form method="POST" action="{{ route('user-password.update') }}">
    @csrf
    @method('PUT')

     @if (session('status') == "password-updated")
        <div class="alert alert-success">
            {{ __('Password updated successfully.') }}
        </div>
    @endif

    <div class="form-group">
        <label for="current_password">{{ __('Current Password') }}</label>
        <input id="current_password"
            type="password"
            class="form-control @error('current_password', 'updatePassword') is-invalid @enderror"
            name="current_password"
            tabindex="1"
            required
            autocomplete="current_password">

        @error('current_password', 'updatePassword')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-group">
        <label for="password">{{ __('New Password') }}</label>
        <input id="password"
            type="password"
            class="form-control @error('password', 'updatePassword') is-invalid @enderror"
            name="password"
            tabindex="2"
            required
            autocomplete="new-password">

        @error('password', 'updatePassword')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-group">
        <label for="password-confirm">{{ __('Confirm Password') }}</label>
        <input id="password-confirm"
            type="password"
            class="form-control @error('password_confirmation') is-invalid @enderror"
            name="password_confirmation"
            tabindex="3"
            required
            autocomplete="new-password">
    </div>

    <button type="submit"
        class="btn btn-primary btn-lg btn-icon icon-right"
        tabindex="4">
        {{ __('Change Password') }}
    </button>
</form>
