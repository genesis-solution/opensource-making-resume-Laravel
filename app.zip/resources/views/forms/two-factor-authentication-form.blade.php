@if (session('status') == "two-factor-authentication-enabled")
    <div class="alert alert-success">
        {{ __('Two factor authentication enabled.') }}
    </div>
@elseif (session('status') == "two-factor-authentication-confirmed")
    <div class="alert alert-success">
        {{ __('Two factor authentication confirmed.') }}
    </div>
@elseif (session('status') == "two-factor-authentication-disabled")
    <div class="alert alert-success">
        {{ __('Two factor authentication disabled.') }}
    </div>
@elseif (session('status') == "recovery-codes-generated")
    <div class="alert alert-success">
        {{ __('Recovery code generated.') }}
    </div>
@endif

@if(! Auth::user()->two_factor_secret)
    {{-- Enable 2FA --}}

    <div>
        <p>{{ __('Enable your account two factor authentication.') }}</p>
    </div>

    <div class="card-footer p-2 mt-2 mb-2">
        <form method="POST" action="{{ route('two-factor.enable') }}">
            @csrf

            <div class="text-md-left">
                <button type="submit"
                    class="btn btn-primary btn-lg btn-icon icon-right"
                    tabindex="1">
                    {{ __('Enable') }}
                </button>
            </div>
        </form>
    </div>
@else

    @if( session('status') == 'two-factor-authentication-enabled' || Auth::user()->two_factor_secret )
        {{-- Show SVG QR Code, After Enabling 2FA --}}
        <div>
            <p>{{ __('Two factor authentication is now enabled but is not confirmed. Scan the following QR code using your phone`s authenticator application.') }}</p>
        </div>

        <div class="card-footer p-1 mt-2 mb-2">
            {!! Auth::user()->twoFactorQrCodeSvg() !!}
        </div>
        <div class="card-footer p-1 mt-2 mb-2">
            <p>
                {{ __('Setup Key') }}: {{ decrypt(Auth::user()->two_factor_secret) }}
            </p>
        </div>
    @endif

    @if (session('status') == 'two-factor-authentication-confirmed' || Auth::user()->two_factor_confirmed_at )
        <div class="mb-4">
            {{ __('Two factor authentication confirmed and enabled successfully.') }}
        </div>
    @else
    <div class="card-footer p-2 mt-2 mb-2">
        <form method="POST" action="{{ route('two-factor.confirm') }}">
            @csrf

            <div class="form-group">
                <label for="one-time-code">{{ __('Code') }}</label>
                <input id="one-time-code"
                    type="text"
                    class="form-control @error('one-time-code') is-invalid @enderror"
                    tabindex="1"
                    name="code"
                    required 
                    value="{{ old('one-time-code') }}"
                    autocomplete="one-time-code"
                    autofocus
                >

                @error('one-time-code')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="text-md-left">
                <button type="submit"
                    class="btn btn-primary btn-lg btn-icon icon-right"
                    tabindex="2">
                    {{ __('Confirm Code') }}
                </button>
            </div>
        </form>
    </div>
    @endif

    {{-- Show 2FA Recovery Codes --}}
    <div>
        <p>{{ __('Store these recovery codes in a secure password manager. They can be used to recover access to your account if your two factor authentication device is lost.') }}</p>
    </div>

    <div>
        <ul>
            @foreach (json_decode(decrypt(Auth::user()->two_factor_recovery_codes), true) as $code)
                <li>{{ $code }}</li>
            @endforeach
        </ul>
    </div>

    {{-- Regenerate 2FA Recovery Codes --}}
    <div class="card-footer p-2 mt-2 mb-2">
        <form method="POST" action="{{ route('two-factor.recovery-codes') }}">
            @csrf

            <div class="text-md-left">
                <button type="submit"
                    class="btn btn-primary btn-lg btn-icon icon-right"
                    tabindex="3">
                    {{ __('Regenerate Recovery Codes') }}
                </button>
            </div>
        </form>
    </div>

    {{-- Disable 2FA --}}
    <div>
        <p>{{ __('Disable your account two factor authentication.') }}</p>
    </div>

    <div class="card-footer p-2 mt-2 mb-2">
        <form method="POST" action="{{ route('two-factor.disable') }}">
            @csrf
            @method('DELETE')

            <div class="text-md-left">
                <button type="submit"
                    class="btn btn-danger btn-lg btn-icon icon-right"
                    tabindex="4">
                    {{ __('Disable') }}
                </button>
            </div>
        </form>
    </div>

@endif
