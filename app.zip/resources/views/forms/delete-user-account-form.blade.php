<div class="alert alert-danger alert-has-icon">
    <div class="alert-icon"><i class="fa-regular fa-lightbulb"></i></div>
    <div class="alert-body">
        <div class="alert-title">{{ __('Permanently delete your account') }}</div>
        <p>{{ __('You can not reverse this action, and all of your details including user profile, resumes, cover letters, payments, and activity records will be permanently deleted and cannot be recovered.') }}</p>

        <div class="p-2 mt-2 mb-2">
            <div class="text-md-left">
                <button type="submit"
                    class="btn btn-danger btn-lg btn-icon icon-right delete-user-account">
                    {{ __('Delete') }}
                </button>
            </div>
        </div>
    </div>
</div>

