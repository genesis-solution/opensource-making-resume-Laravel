<form method="POST"
    action="{{ route('user-profile-information.update') }}"
    id="profile-form"
    class="needs-validation"
    novalidate="">
    @csrf
    @method('PUT')

    <div class="card" id="profile-card">
        <div class="card-header">
            <h4>{{ __('Edit Profile') }}</h4>
            @if( isset($user->profile_id) && $user->profile_id != '' )
             <div class="card-header-form">
                <div class="dropdown d-inline dropleft text-right">
                    <button class="btn btn-primary dropdown-toggle"
                        type="button"
                        id="share-btn"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false">
                        <i class="fa-solid fa-share-alt"></i> {{ __('Share') }}
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item has-icon"
                            type="button" id="share"
                            href="{{ URL::to('/p/'. $user->profile_id) }}"
                            target="_blank">
                            <i class="fa-solid fa-share-alt"></i> <span>{{ __('Share') }}</span>
                        </a>
                        <a class="dropdown-item has-icon"
                            type="button" id="qrcode"
                            data-toggle="modal" 
                            data-pid="{{ $user->id }}" 
                            data-pname="{{ $user->firstname .' '. $user->lastname }}" 
                            data-target="#profileQrCodeModal">
                            <i class="fa-solid fa-qrcode"></i> <span>{{ __('QR Code') }}</span>
                        </a>
                    </div>
                </div>
            </div>
            @endif
        </div>
        <div class="card-body">
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label for="firstname">{{ __('First Name') }}</label>
                    <input id="firstname"
                        type="text"
                        class="form-control @error('firstname') is-invalid @enderror"
                        name="firstname"
                        required 
                        value="{{ old('firstname') ?? $user->firstname }}"
                        autocomplete="firstname"
                        autofocus
                    >

                    @error('firstname')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-6 col-12">
                    <label for="lastname">{{ __('Last Name') }}</label>
                    <input id="lastname"
                        type="text"
                        class="form-control @error('lastname') is-invalid @enderror"
                        name="lastname"
                        required 
                        value="{{ old('lastname') ?? $user->lastname }}"
                        autocomplete="lastname"
                    >

                    @error('lastname')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label for="email">{{ __('Email Address') }}</label>
                    <input id="email"
                        type="email"
                        class="form-control @error('email') is-invalid @enderror"
                        name="email"
                        value="{{ old('email') ?? $user->email }}"
                        required
                        autocomplete="email"
                    >

                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            
                <div class="form-group col-md-6 col-12">
                    <label for="phone">{{ __('Phone') }}</label>
                    <input id="phone"
                        type="tel"
                        class="form-control @error('phone') is-invalid @enderror"
                        name="phone"
                        value="{{ old('phone') ?? $user->phone }}"
                        autocomplete="tel">

                    <span id="phone_output"></span>

                    @error('phone')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            
            <div class="row">
                <div class="form-group col-12"> 
                    <label for="avatar">{{ __('Avatar') }}</label>
                    <input type="file"
                        name="image"
                        class="file-loading"
                        id="image"
                        multiple="false"
                        data-show-upload="false" 
                        data-show-caption="true">

                    @error('avatar')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="form-group col-12">
                    <label for="timezone">{{ __('Timezone') }}</label>
                    <select id="timezone" 
                        name="timezone" 
                        class="form-control select2"
                    >
                        @foreach(timezone_identifiers_list() as $value)
                            <option value="{{ $value }}" @if ($value == ($user->timezone ?? config('settings.timezone'))) selected @endif>{{ $value }}</option>
                        @endforeach
                    </select>

                    @error('timezone')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label for="resume">{{ __('Resume') }} <span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="{{ __('The resume that will provide the information for your shared profile.') }}"><i class="fa-solid fa-info-circle"></i></span></label>
                    <select id="resume" 
                        name="resume" 
                        class="form-control select2 @error('resume') is-invalid @enderror">
                        @foreach($resumes as $resume)
                           <option value="{{ $resume->r_id ?? null }}" {{ $resume->r_id == $user->resume ? 'selected' : '' }}>{{ $resume->name }}</option>
                        @endforeach 
                    </select>

                    @error('resume')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-6 col-12">
                    <label for="profile_id">{{ __('Profile Id') }}</label>
                    <div class="input-group">
                        <input type="text"
                            name="profile_id"
                            class="form-control @error('profile_id') is-invalid @enderror"
                            id="profile_id"
                            value="{{ old('profile_id') ?? ( $user->profile_id!=null ? $user->profile_id : Str::random(16) ) }}"
                            readonly>
                        <div class="input-group-append">
                            <div class="btn btn-sm btn-primary form-control" data-tooltip-copy="true" title="{{ __('Copy') }}" data-text-copy="{{ __('Copy') }}" data-text-copied="{{ __('Copied') }}" data-clipboard="true" data-clipboard-target="#profile_id">{{ __('Copy') }}</div>
                        </div>
                    </div>

                    @error('profile_id')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="card" id="privacy-card">
        <div class="card-header">
            <h4>{{ __('Privacy') }}</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="privacy">{{ __('Privacy') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Public') }}">
                            <input type="radio"
                                id="privacy-public"
                                name="privacy"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->privacy == '0') checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon"><i
                                    class="fa-solid fa-globe"></i> {{ __('Public') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Private') }}">
                            <input type="radio"
                                id="privacy-private"
                                name="privacy"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->privacy == '1') checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon"><i
                                    class="fa-solid fa-lock"></i> {{ __('Private') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Password') }}">
                            <input type="radio"
                                id="privacy-password"
                                name="privacy"
                                class="selectgroup-input"
                                value="2" @if( $user!=null && $user->privacy == '2') checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon"><i
                                    class="fa-solid fa-fingerprint"></i> {{ __('Password') }}</span>
                        </label>
                    </div>
                </div>
            </div>
            <div id="profile-password" class="row @if($user!=null && $user->profile_password!=null) d-block @else d-none @endif">
                <div class="form-group col-12">
                    <label for="profile_password">{{ __('Password') }}</label>
                    <input type="password"
                        name="profile_password"
                        class="form-control @error('profile_password') is-invalid @enderror"
                        id="profile_password"
                        value="{{ $user!=null ? $user->profile_password : null }}"
                        autocomplete="profile_password">

                    @error('profile_password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="card" id="occupation-card">
        <div class="card-header">
            <h4>{{ __('Occupation') }}</h4>
        </div>
        <div class="card-body"> 
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label for="occupation">{{ __('Occupation') }}</label>
                    <input id="occupation"
                        type="text"
                        class="form-control @error('occupation') is-invalid @enderror"
                        name="occupation"
                        value="{{ old('occupation') ?? $user->occupation }}"
                        autocomplete="occupation"
                    >

                    @error('occupation')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-6 col-12">
                    <label for="yoe">{{ __('Years of Experience') }}</label>
                    <input id="yoe"
                        type="number"
                        class="form-control @error('yoe') is-invalid @enderror"
                        name="yoe"
                        min="0"
                        value="{{ old('yoe') ?? $user->yoe }}"
                        autocomplete="yoe"
                    >

                    @error('yoe')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="card" id="address-card">
        <div class="card-header">
            <h4>{{ __('Address') }}</h4>
        </div>
        <div class="card-body">    
            <div class="row">
                <div class="form-group col-12">
                    <label for="street">{{ __('Street') }}</label>
                    <input id="street"
                        type="text"
                        class="form-control @error('street') is-invalid @enderror"
                        name="street"
                        value="{{ $user->address->street ?? null }}"
                        autocomplete="street"
                    >

                    @error('street')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-5 col-12">
                    <label for="city">{{ __('City') }}</label>
                    <input id="city"
                        type="text"
                        class="form-control @error('city') is-invalid @enderror"
                        name="city"
                        value="{{ $user->address->city ?? null }}"
                        autocomplete="city"
                    >

                    @error('city')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-4 col-12">
                    <label for="state">{{ __('State') }}</label>
                    <input id="state"
                        type="text"
                        class="form-control @error('state') is-invalid @enderror"
                        name="state"
                        value="{{ $user->address->state ?? null }}"
                        autocomplete="state"
                    >

                    @error('state')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-3 col-12">
                    <label for="postal">{{ __('Postal') }}</label>
                    <input id="postal"
                        type="text"
                        class="form-control @error('postal') is-invalid @enderror"
                        name="postal"
                        value="{{ $user->address->postal ?? null }}"
                        maxlength="10"
                        autocomplete="postal"
                    >

                    @error('postal')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="form-group col-12">
                    <label for="country">{{ __('Country') }}</label>
                    <select id="country" 
                        name="country" 
                        class="form-control select2"
                    >
                        @include('dashboard.admin.settings.countries', [ 'provided_country' => ( $user->address->country ?? config('settings.country') ) ])
                    </select>

                    @error('country')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="card" id="bio-card">
        <div class="card-header">
            <h4>{{ __('Bio') }}</h4>
            <div class="card-header-form">
                @if( config('settings.openai') )
                    <button type="button" id="generate-bio-btn" onclick="generateAIUserProfileBio(); return false;" class="btn btn-warning btn-icon icon-left text-md-right" data-toggle="tooltip" data-placement="top" data-original-title="{{ $aiGeneratedContentDescription }}">
                        <i class="fa-solid fa-magic"></i> {{ __('Generate with AI') }} @if($aiGeneratedContentLeft >= 0)<span class="badge badge-transparent">{{ $aiGeneratedContentLeft }}</span>@endif
                    </button>
                @endif
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="form-group col-12">
                    <label for="bio">{{ __('Bio') }}</label>
                    <textarea id="bio" 
                        name="bio"
                        class="form-control summernote-simple"
                    >{{ old('bio') ?? $user->bio }}</textarea>

                </div>
            </div>
        </div>
    </div>

    <div class="card" id="availability-card">
        <div class="card-header">
            <h4 data-toggle="collapse" href="#collapseAvailability" aria-expanded="true" aria-controls="collapseAvailability" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Work Availability') }}</h4>
            <div class="card-header-form">
                <label class="custom-switch p-1 text-md-right">
                    <input type="checkbox"
                        name="availability_status"
                        id="availability_status"
                        class="custom-switch-input"
                        @if( $user!=null && $user->availability!=null && $user->availability_status == '1') checked="checked" @endif>
                    <span class="custom-switch-indicator"></span>
                </label>
            </div>
        </div>
        <div class="card-body collapse" id="collapseAvailability">
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Monday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="monday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->monday) && strpos($user->availability->monday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="monday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->monday) && strpos($user->availability->monday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="monday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->monday) && strpos($user->availability->monday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('monday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Tuesday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="tuesday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->tuesday) && strpos($user->availability->tuesday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="tuesday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->tuesday) && strpos($user->availability->tuesday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="tuesday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->tuesday) && strpos($user->availability->tuesday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('tuesday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Wednesday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="wednesday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->wednesday) && strpos($user->availability->wednesday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="wednesday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->wednesday) && strpos($user->availability->wednesday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="wednesday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->wednesday) && strpos($user->availability->wednesday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('wednesday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Thursday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="thursday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->thursday) && strpos($user->availability->thursday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="thursday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->thursday) && strpos($user->availability->thursday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="thursday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->thursday) && strpos($user->availability->thursday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('thursday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Friday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="friday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->friday) && strpos($user->availability->friday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="friday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->friday) && strpos($user->availability->friday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="friday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->friday) && strpos($user->availability->friday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('friday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group col-md-6 col-12">
                    <label class="form-label">{{ __('Saturday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="saturday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->saturday) && strpos($user->availability->saturday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="saturday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->saturday) && strpos($user->availability->saturday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="saturday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->saturday) && strpos($user->availability->saturday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('saturday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label">{{ __('Sunday') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="sunday[]"
                                value="{{ __('Morning') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->sunday) && strpos($user->availability->sunday, __('Morning')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Morning') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="sunday[]"
                                value="{{ __('Afternoon') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->sunday) && strpos($user->availability->sunday, __('Afternoon')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Afternoon') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="sunday[]"
                                value="{{ __('Evening') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->availability!=null && (isset($user->availability->sunday) && strpos($user->availability->sunday, __('Evening')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Evening') }}</span>
                        </label>
                    </div>

                    @error('sunday')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="card" id="preferences-card">
        <div class="card-header">
            <h4 data-toggle="collapse" href="#collapsePreferences" aria-expanded="true" aria-controls="collapsePreferences" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Work Preferences') }}</h4>
            <div class="card-header-form">
                <label class="custom-switch p-1 text-md-right">
                    <input type="checkbox"
                        name="preferences_status"
                        id="preferences_status"
                        class="custom-switch-input"
                        @if( $user!=null && $user->preferences!=null && $user->preferences_status == '1') checked="checked" @endif>
                    <span class="custom-switch-indicator"></span>
                </label>
            </div>
        </div>
        <div class="card-body collapse" id="collapsePreferences">
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label">{{ __('Work Type') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Full-time') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Full-time')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Full-time') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Part-time') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Part-time')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Part-time') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Seasonal') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Seasonal')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Seasonal') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Temporary') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Temporary')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Temporary') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Contractor') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Contractor')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Contractor') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Internship') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Internship')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Internship') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_type[]"
                                value="{{ __('Volunteer') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_type) && strpos($user->preferences->work_type, __('Volunteer')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Volunteer') }}</span>
                        </label>
                    </div>

                    @error('work_type')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label">{{ __('Work Location') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_location[]"
                                value="{{ __('On-site') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_location) && strpos($user->preferences->work_location, __('On-site')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('On-site') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_location[]"
                                value="{{ __('Remote') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_location) && strpos($user->preferences->work_location, __('Remote')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Remote') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_location[]"
                                value="{{ __('Hybrid') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_location) && strpos($user->preferences->work_location, __('Hybrid')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Hybrid') }}</span>
                        </label>
                    </div>

                    @error('work_location')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label">{{ __('Work Benefits') }}</label>
                    <div class="selectgroup selectgroup-pills">
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('401k') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('401k')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('401k') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Dental insurance') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Dental insurance')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Dental insurance') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Flexible schedule') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Flexible schedule')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Flexible schedule') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Health insurance') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Health insurance')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Health insurance') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Vision insurance') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Vision insurance')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Vision insurance') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Paid time off') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Paid time off')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Paid time off') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Tuition reimbursement') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Tuition reimbursement')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Tuition reimbursement') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Career advancement') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Career advancement')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Career advancement') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Paid sick leave') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Paid sick leave')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Paid sick leave') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Parental leave') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Parental leave')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Parental leave') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Life insurance') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Life insurance')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Life insurance') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Disability insurance') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Disability insurance')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Disability insurance') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Wellness program') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Wellness program')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Wellness program') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Profit sharing') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Profit sharing')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Profit sharing') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Flexible spending account') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Flexible spending account')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Flexible spending account') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Retirement plan') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) && strpos($user->preferences->work_benefits, __('Retirement plan')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Retirement plan') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Employee assistance program') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) &&  strpos($user->preferences->work_benefits, __('Employee assistance program')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Employee assistance program') }}</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="checkbox"
                                name="work_benefits[]"
                                value="{{ __('Work from home') }}"
                                class="selectgroup-input"
                                @if( $user!=null && $user->preferences!=null && (isset($user->preferences->work_benefits) &&  strpos($user->preferences->work_benefits, __('Work from home')) !== false) ) checked="checked" @endif>
                            <span class="selectgroup-button">{{ __('Work from home') }}</span>
                        </label>
                    </div>

                    @error('work_benefits')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>
    
    @if($user->resume!=null)
    <div class="card" id="resume-sections-card">
        <div class="card-header">
            <h4 data-toggle="collapse" href="#collapseResumeSections" aria-expanded="true" aria-controls="collapseResumeSections" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Resume Sections') }}</h4>
        </div>
        <div class="card-body collapse" id="collapseResumeSections">
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="employments">{{ __('Employments') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="employments-on"
                                name="employments"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->employments == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="employments-off"
                                name="employments"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->employments == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('employments')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="volunteer">{{ __('Volunteer') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="volunteer-on"
                                name="volunteer"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->volunteer == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="volunteer-off"
                                name="volunteer"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->volunteer == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('volunteer')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="projects">{{ __('Projects') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="projects-on"
                                name="projects"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->projects == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="projects-off"
                                name="projects"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->projects == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('projects')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="education">{{ __('Education') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="education-on"
                                name="education"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->education == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="education-off"
                                name="education"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->education == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('education')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="certificates">{{ __('Certificates') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="certificates-on"
                                name="certificates"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->certificates == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="certificates-off"
                                name="certificates"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->certificates == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('certificates')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="awards">{{ __('Awards') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="awards-on"
                                name="awards"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->awards == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="awards-off"
                                name="awards"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->awards == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('awards')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="publications">{{ __('Publications') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="publications-on"
                                name="publications"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->publications == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="publications-off"
                                name="publications"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->publications == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('publications')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="languages">{{ __('Languages') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="languages-on"
                                name="languages"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->languages == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="languages-off"
                                name="languages"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->languages == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('languages')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="skills">{{ __('Skills') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="skills-on"
                                name="skills"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->skills == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="skills-off"
                                name="skills"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->skills == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('skills')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="interests">{{ __('Interests') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="interests-on"
                                name="interests"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->interests == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="interests-off"
                                name="interests"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->interests == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('interests')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
            <div class="row">
                <div class="form-group col-12">
                    <label class="form-label" for="references">{{ __('References') }}</label>
                    <div class="selectgroup w-100">
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('On') }}">
                            <input type="radio"
                                id="references-on"
                                name="references"
                                class="selectgroup-input"
                                value="1" @if( $user!=null && $user->sections!=null && $user->sections->references == '1' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('On') }}</span>
                        </label>
                        <label 
                            class="selectgroup-item" 
                            data-toggle="tooltip"
                            data-placement="top"
                            title="{{ __('Off') }}">
                            <input type="radio"
                                id="references-off"
                                name="references"
                                class="selectgroup-input"
                                value="0" @if( $user!=null && $user->sections!=null && $user->sections->references == '0' ) checked="checked" @endif>
                            <span class="selectgroup-button selectgroup-button-icon">{{ __('Off') }}</span>
                        </label>
                    </div>

                    @error('references')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>
    @endif

    <div class="card" id="social-card">
        <div class="card-header">
            <h4 data-toggle="collapse" href="#collapseSocialMedia" aria-expanded="true" aria-controls="collapseSocialMedia" class="collapsed cursor-pointer"><i class="fa"></i> {{ __('Social Media') }}</h4>
        </div>
        <div class="card-body collapse" id="collapseSocialMedia">
            <div class="row">
                <div class="form-group col-md-4 col-12">
                    <label for="facebook">{{ __('Facebook') }}</label>
                    <input id="facebook"
                        type="text"
                        class="form-control @error('facebook') is-invalid @enderror"
                        name="facebook"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->facebook ?? null }}"
                        autocomplete="facebook"
                    >

                    <p class="text-muted"><small>https://facebook.com/<span class="text-primary">username</span></small></p>

                    @error('facebook')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-4 col-12">
                    <label for="twitter">{{ __('Twitter') }}</label>
                    <input id="twitter"
                        type="text"
                        class="form-control @error('twitter') is-invalid @enderror"
                        name="twitter"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->twitter ?? null }}"
                        autocomplete="twitter"
                    >
                    <p class="text-muted"><small>https://twitter.com/<span class="text-primary">username</span></small></p>

                    @error('twitter')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            
                <div class="form-group col-md-4 col-12">
                    <label for="linkedin">{{ __('LinkedIn') }}</label>
                    <input id="linkedin"
                        type="text"
                        class="form-control @error('linkedin') is-invalid @enderror"
                        name="linkedin"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->linkedin ?? null }}"
                        autocomplete="linkedin"
                    >
                    <p class="text-muted"><small>https://www.linkedin.com/in/<span class="text-primary">username</span>/</small></p>

                    @error('linkedin')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-4 col-12">
                    <label for="pinterest">{{ __('Pinterest') }}</label>
                    <input id="pinterest"
                        type="text"
                        class="form-control @error('pinterest') is-invalid @enderror"
                        name="pinterest"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->pinterest ?? null }}"
                        autocomplete="pinterest"
                    >
                    <p class="text-muted"><small>https://www.pinterest.com/<span class="text-primary">username</span>/</small></p>

                    @error('pinterest')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-4 col-12">
                    <label for="youtube">{{ __('YouTube') }}</label>
                    <input id="youtube"
                        type="text"
                        class="form-control @error('youtube') is-invalid @enderror"
                        name="youtube"
                        data-mask="@handle" 
                        data-mask-visible="true" 
                        placeholder="@handle"
                        value="{{ $user->social->youtube ?? null }}"
                        autocomplete="youtube"
                    >
                    <p class="text-muted"><small>https://www.youtube.com/<span class="text-primary">@handle</span></small></p>

                    @error('youtube')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-4 col-12">
                    <label for="github">{{ __('GitHub') }}</label>
                    <input id="github"
                        type="text"
                        class="form-control @error('github') is-invalid @enderror"
                        name="github"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->github ?? null }}"
                        autocomplete="github"
                    >
                    <p class="text-muted"><small>https://github.com/<span class="text-primary">username</span></small></p>

                    @error('github')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-4 col-12">
                    <label for="behance">{{ __('Behance') }}</label>
                    <input id="behance"
                        type="text"
                        class="form-control @error('behance') is-invalid @enderror"
                        name="behance"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->behance ?? null }}"
                        autocomplete="behance"
                    >
                    <p class="text-muted"><small>https://www.behance.net/<span class="text-primary">username</span></small></p>

                    @error('behance')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-4 col-12">
                    <label for="instagram">{{ __('Instagram') }}</label>
                    <input id="instagram"
                        type="text"
                        class="form-control @error('instagram') is-invalid @enderror"
                        name="instagram"
                        data-mask="username" 
                        data-mask-visible="true" 
                        placeholder="username"
                        value="{{ $user->social->instagram ?? null }}"
                        autocomplete="instagram"
                    >
                    <p class="text-muted"><small>https://www.instagram.com/<span class="text-primary">username</span>/</small></p>

                    @error('instagram')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group col-md-4 col-12">
                    <label for="tiktok">{{ __('TikTok') }}</label>
                    <input id="tiktok"
                        type="text"
                        class="form-control @error('tiktok') is-invalid @enderror"
                        name="tiktok"
                        data-mask="@handle" 
                        data-mask-visible="true" 
                        placeholder="@handle"
                        value="{{ $user->social->tiktok ?? null }}"
                        autocomplete="tiktok"
                    >
                    <p class="text-muted"><small>https://www.tiktok.com/<span class="text-primary">@handle</span></small></p>

                    @error('tiktok')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
        </div>
    </div>
    <div class="card"
        id="button-settings-card">
        <div class="card-footer bg-whitesmoke text-md-right">
            <button class="btn btn-primary"
                id="save-btn">{{ __('Save Changes') }}</button>
            <button class="btn btn-secondary"
                type="reset">{{ __('Reset') }}</button>
        </div>
    </div>
</form>
