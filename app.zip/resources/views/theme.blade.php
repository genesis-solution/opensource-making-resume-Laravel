@if( config('settings.site_theme_color') )
    :root {
        --primary: {{ config('settings.site_theme_color') }} !important;
    }
    a.bb {
        border-bottom: 1px solid {{ config('settings.site_theme_color') }} !important;
    }
    .text-primary, .text-primary-all *, .text-primary-all :after, .text-primary-all :before {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .nav-tabs .nav-item .nav-link {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .nav-pills .nav-link.active,.nav-pills .show>.nav-link {
        background-color: {{ config('settings.site_theme_color') }} !important;
    }
    .nav-pills .nav-item .nav-link {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .nav-pills .nav-item .nav-link.active {
        background-color: {{ config('settings.site_theme_color') }} !important;
        color: #fff !important;
    }
    .nav-collapse .navbar-nav .nav-item .nav-link:hover {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .nav-collapse .navbar-nav .nav-item.active>a,.nav-collapse .navbar-nav .nav-item:focus>a {
        background-color: {{ config('settings.site_theme_color') }} !important;
    }
    ul.nav-tabs li.nav-item a.nav-link i {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .section-appeal a, .section-declare a, .section-resources a, .section-blog-main .article-title a, .section-blog-main .article-read a, .section-blog-main .article-tag a, .section-blog-main .article-share a, .section-blog-inside .article-title a, .section-blog-inside .article-read a, .section-blog-inside .article-tag a, .section-blog-inside .article-share a {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .section-blog-main .article-tag a:hover, .section-blog-inside .article-tag a:hover {
        color: #fff !important;
    }
    .section-header-breadcrumb .breadcrumb-item.active a {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .card.card-primary {
        border-top: 2px solid {{ config('settings.site_theme_color') }} !important;
    }
    .card.card-hero .card-header h4 {
        color: #fff !important;
    }
    .card .card-header h4, .card .card-header-login h1, .card .card-header-register h1, .card .card-header-forgot h1 {
        color: {{ config('settings.site_theme_color') }} !important; 
    }
    .card-body .text-small a {
       color: {{ config('settings.site_theme_color') }} !important; 
    }
    .pricing .pricing-title {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .page-item .page-link {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .page-item.active .page-link {
        background-color: {{ config('settings.site_theme_color') }} !important;
        border-color: {{ config('settings.site_theme_color') }} !important;
        color: #fff !important;
    }
    .page-item.disabled .page-link {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .page-link:hover {
        background-color: {{ config('settings.site_theme_color') }} !important;
        color: #fff !important;
    }
    .list-group-item.active {
        background-color: {{ config('settings.site_theme_color') }} !important;
    }
    .list-group-item-primary {
        background-color: {{ config('settings.site_theme_color') }} !important;
    }
    .pricing .pricing-cta a {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .main-sidebar .sidebar-menu li.active a {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .main-sidebar .sidebar-menu li ul.dropdown-menu li.active>a {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .main-sidebar .sidebar-menu li ul.dropdown-menu li a:hover {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .media .media-right {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    .main-footer {
        background-image: none !important;
    }
@endif
@if( config('settings.site_button_color') )
    .btn-primary,.btn-primary.disabled {
        background-color: {{ config('settings.site_button_color') }} !important;
        border-color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-primary.disabled:focus,.btn-primary:focus {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-primary.disabled:focus:active,.btn-primary:focus:active {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-primary.disabled:active,.btn-primary.disabled:hover,.btn-primary:active,.btn-primary:hover {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-outline-primary,.btn-outline-primary.disabled {
        border-color: {{ config('settings.site_button_color') }} !important;
        color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-outline-primary.disabled:active,.btn-outline-primary.disabled:focus,.btn-outline-primary.disabled:hover,.btn-outline-primary:active,.btn-outline-primary:focus,.btn-outline-primary:hover {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-outline-white.disabled:active,.btn-outline-white.disabled:focus,.btn-outline-white.disabled:hover,.btn-outline-white:active,.btn-outline-white:focus,.btn-outline-white:hover {
        color: {{ config('settings.site_button_color') }} !important;
    }
    .btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active, .show>.btn-outline-primary.dropdown-toggle {
        background-color: {{ config('settings.site_button_color') }} !important;
        border-color: {{ config('settings.site_button_color') }} !important;
    }
    .card .card-header h4+.card-header-action .btn.active,.card .card-header h4+.card-header-form .btn.active {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .section-faqs .faq .faq-icon,.section-features .feature .feature-icon {
        color: {{ config('settings.site_button_color') }} !important;
    }
    .stats .h1:after {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .section-tryout a {
        border-bottom: 1px solid {{ config('settings.site_button_color') }} !important;
    }
    .wizard-steps .wizard-step.wizard-step-active {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .wizard-steps .wizard-step.wizard-step-active:before {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .custom-switch-input:checked~.custom-switch-indicator {
        background: {{ config('settings.site_button_color') }} !important;
    }
    .custom-switch-input:focus~.custom-switch-indicator {
        border-color: {{ config('settings.site_button_color') }} !important;
    }
    .selectgroup-input:checked+.selectgroup-button {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .custom-file-input:focus+.custom-file-label {
        border-color: {{ config('settings.site_button_color') }} !important;
    }
    .custom-control-input:checked~.custom-control-label::before,.custom-radio .custom-control-input:checked~.custom-control-label::before {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .bg-primary {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .circle-step .circle.circle-primary {
        border-color: {{ config('settings.site_button_color') }} !important;
        color: {{ config('settings.site_button_color') }} !important;
    }
    .dropdown-flag .dropdown-item.active {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .dropdown-list .dropdown-item:focus {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    a.dropdown-item.active,a.dropdown-item:active,a.dropdown-item:focus {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .pricing.pricing-highlight .pricing-title, .template-frontend.template-frontend-highlight .template-frontend-title {
        background-color: {{ config('settings.site_button_color') }} !important;
        color: #fff !important;
    }
    .pricing.pricing-highlight .pricing-cta a {
        background-color: {{ config('settings.site_button_color') }} !important;
        color: #fff !important;
    }
    .badge.badge-primary {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .section .card-body a.login-link, .section .card-body a.register-link {
        color: {{ config('settings.site_button_color') }} !important;
    }
    .section .card-body a.badge {
        color: unset !important;
    }
    .section .card-body a.badge-success {
        color: #fff !important;
    }
    .card.card-hero .card-header .card-icon {
        color: {{ config('settings.site_button_color') }} !important;
    }
    .card.card-large-icons .card-body a.card-cta {
        color: {{ config('settings.site_theme_color') }} !important;
    }
    #c-bns button:first-child, #s-bns button:first-child {
        background: {{ config('settings.site_button_color') }} !important;
    }
    .cc_div .cc-link {
        border-bottom: 1px solid {{ config('settings.site_button_color') }} !important;
        color: {{ config('settings.site_button_color') }} !important;
    }
    .bootstrap-tagsinput .tag {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .select2-container--default .select2-results__option--highlighted[aria-selected],.select2-container--default .select2-results__option[aria-selected=true],.select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .selectric-items li.highlighted, .selectric-items li.selected {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .swal-button.swal-button--confirm {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .swal-icon--warning__body, .swal-icon--warning__dot {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    .swal-icon--warning {
        border-color: {{ config('settings.site_button_color') }} !important;
    }
    .resumePreviewButton, .resumeSaveButton, .coverLetterPreviewButton, .coverLetterSaveButton {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
    #scrollUp {
        background-color: {{ config('settings.site_button_color') }} !important;
    }
@endif

@if( config('settings.site_button_hover_color') )
    .btn-primary.disabled:active, .btn-primary.disabled:hover, .btn-primary:active, .btn-primary:hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    .btn-outline-primary.disabled:active,.btn-outline-primary.disabled:focus,.btn-outline-primary.disabled:hover,.btn-outline-primary:active,.btn-outline-primary:focus,.btn-outline-primary:hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    .pricing.pricing-highlight .pricing-cta a:hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    .section .card-body a.badge:hover {
        color: #fff !important;
    }
    .select2-container--classic .select2-selection--single:focus, .select2-container--classic.select2-container--open .select2-selection--single, .select2-container--classic .select2-selection--multiple:focus, .select2-container--classic.select2-container--open .select2-selection--multiple {
        border: 1px solid {{ config('settings.site_button_hover_color') }} !important;
    }
    .select2-container--classic.select2-container--open .select2-dropdown {
        border-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    .swal-button--danger:not([disabled]):hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    .resumePreviewButton:hover, .resumeSaveButton:hover, .coverLetterPreviewButton:hover, .coverLetterSaveButton:hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
    #scrollUp:hover {
        background-color: {{ config('settings.site_button_hover_color') }} !important;
    }
@endif
@if( config('settings.site_bg_primary_color') && config('settings.site_bg_secondary_color') )
    .hero-mini {
        background-image: linear-gradient(to right,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    .hero:after {
        background-image: linear-gradient(to bottom,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    @media (min-width: 991.5px) {
        .section-appeal-right:after,.section-appeal:after,.section-declare:after,.section-steps .container:after {
            background-image: linear-gradient(to bottom,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
        }
    }
    .hero-inside:after {
        background-image: linear-gradient(to bottom,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    .bg-gr {
        background-image: linear-gradient(to right,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    .card.card-hero .card-header {
        background-image: linear-gradient(to bottom,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    #template-frontend-card img {
        border-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    #template-frontend-card .template-frontend .template-frontend-title {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
        border-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    #template-frontend-card .button-template {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .section-tryout {
        background-image: linear-gradient(to left,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    body:not(.sidebar-mini) .sidebar-style-1 .sidebar-menu li.active a {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body:not(.sidebar-mini) .sidebar-style-1 .sidebar-menu li.active ul.dropdown-menu li a:hover {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body:not(.sidebar-mini) .sidebar-style-2 .sidebar-menu>li.active>a:before {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body.layout-3 .navbar.navbar-secondary .navbar-nav>.nav-item .dropdown-menu .nav-item .nav-link:focus,body.layout-3 .navbar.navbar-secondary .navbar-nav>.nav-item .dropdown-menu .nav-item.active>.nav-link {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body.layout-3 .navbar.navbar-secondary .navbar-nav>.nav-item>.nav-link:before {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body.sidebar-mini .main-sidebar .sidebar-menu>li ul.dropdown-menu li.active>a,body.sidebar-mini .main-sidebar .sidebar-menu>li ul.dropdown-menu li.active>a:hover,body.sidebar-mini .main-sidebar .sidebar-menu>li ul.dropdown-menu li>a:focus {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    body.sidebar-mini .main-sidebar .sidebar-menu>li.active>a {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .section .section-title:before {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .section .section-header .section-header-back .btn:hover {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .navbar.active {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .navbar-bg {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    .accordion .accordion-header[aria-expanded=true] {
        background-color: {{ config('settings.site_bg_primary_color') }} !important;
    }
    footer {
        background-image: linear-gradient(to right,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
    footer:after {
        background-image: linear-gradient(to right,{{ config('settings.site_bg_primary_color') }},{{ config('settings.site_bg_secondary_color') }});
    }
@endif