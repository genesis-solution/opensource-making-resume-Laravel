<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{{ config('settings.site_url') }}</loc>
        <lastmod>{{ now()->tz('UTC')->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
    @if($pages->isNotEmpty())
    @foreach ($pages as $page)
    <url>
        <loc>{{ config('settings.site_url') }}/pages/{{ $page->slug }}</loc>
        <lastmod>{{ $page->created_at->tz('UTC')->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
    @endforeach
    @endif
    @if($posts->isNotEmpty())
    @foreach ($posts as $post)
    <url>
        <loc>{{ config('settings.site_url') }}/blog/{{ $post->slug }}</loc>
        <lastmod>{{ $page->created_at->tz('UTC')->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
    @endforeach
    @endif
    <url>
        <loc>{{ config('settings.site_url') }}/faqs</loc>
        <lastmod>{{ now()->tz('UTC')->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
    <url>
        <loc>{{ config('settings.site_url') }}/contact</loc>
        <lastmod>{{ now()->tz('UTC')->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
</urlset>