@extends('layouts.frontend')

@section('title', $post->p_title)
@section('description', Str::words(strip_tags( (string) $post->description), 25, '.'))
@section('keywords', $post->keywords)
@section('image', $post->p_image_path)
@section('url', config('settings.site_url') .'/blog/'. $post->slug)

@push('style')
    <!-- CSS Libraries -->
    <link rel="stylesheet"
        href="{{ asset('vendor/bootstrap-social/bootstrap-social.css?v='. config('info.software.version')) }}">
@endpush

@section('main')

<body>
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    <section id="blog" class="section section-blog-inside">
        <div class="container">
            <div class="row">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent text-black-all">
                        <li class="breadcrumb-item"><i class="fas fa-home"></i> <a href="{{ url('/blog') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ config('settings.site_url') .'/blog/category/'. $post->c_slug }}">{{ $post->c_title }}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{ $post->p_title }}</li>
                  </ol>
                </nav>
                <article class="article article-style-c">
                    <div class="article-header article-inside-header">
                        <div class="article-image"
                            data-background="{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : ( $post!=null && $post->p_image !=null ? asset($post->p_image) : null ) ) ?? asset('img/blog/blog-'. rand(1,5) .'.jpg') }}" 
                            style="background-image: url('{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : ( $post!=null && $post->p_image !=null ? asset($post->p_image) : null ) ) ?? asset('img/blog/blog-'. rand(1,5) .'.jpg') }}');">
                        </div>
                    </div>
                    <div class="article-details">
                        <div class="article-category text-center">
                            <a href="{{ config('settings.site_url') .'/blog/category/'. $post->c_slug }}">{{ $post->c_title }}</a>
                            <div class="bullet"></div> 
                            @if($post->name!=null)
                            <a href="{{ config('settings.site_url') .'/blog/author/'. $post->a_slug }}">{{ $post->name }}</a> 
                            <div class="bullet"></div>
                            @endif 
                            <a href="#">{{ $post->p_created_at->diffForHumans() }}</a>
                        </div>
                        <div class="text-center">
                            <h1>{{ $post->p_title }}</h1>
                        </div>
                        <div class="text-left">{!! $post->content !!}</div>
                    </div>
                </article>
            </div>
            @if( $post->privacy == '0' )
            <div class="row">
                <div class="card author profile-widget">
                    <div class="profile-widget-header">
                        <img alt="image"
                            src="{{ ( $post!=null && $post->a_image_path!=null ? $post->a_image_path : ( $post!=null && $post->a_image !=null ? asset($post->a_image) : null ) ) ?? asset('img/author/author-'. rand(1,5) .'.png') }}"
                            class="rounded-circle profile-widget-picture">
                    </div>
                    <div class="profile-widget-description">
                        <div class="profile-widget-name">{{ $post->name }} <div
                                class="text-muted d-inline font-weight-normal">
                                @if($post->occupation!=null)
                                <div class="slash"></div> {{ $post->occupation }}
                                @endif
                            </div>
                        </div>
                        <p>{!! preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', trim(strip_tags($post->bio))) !!}</p>
                    </div>
                    <div class="card-footer text-center">
                        @if ( isset($post->social->facebook) && $post->social->facebook != '' )
                        <a href="https://facebook.com/{{ $post->social->facebook }}"
                            class="btn btn-social-icon btn-facebook mr-1"
                            target="_blank">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->twitter) && $post->social->twitter != '' )
                        <a href="https://twitter.com/{{ $post->social->twitter }}"
                            class="btn btn-social-icon btn-x-twitter mr-1"
                            target="_blank">
                            <i class="fa-brands fa-x-twitter"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->linkedin) && $post->social->linkedin != '' )
                        <a href="https://www.linkedin.com/in/{{ $post->social->linkedin }}/"
                            class="btn btn-social-icon btn-linkedin mr-1"
                            target="_blank">
                            <i class="fa-brands fa-linkedin"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->pinterest) && $post->social->pinterest != '' )
                        <a href="https://www.pinterest.com/{{ $post->social->pinterest }}/"
                            class="btn btn-social-icon btn-pinterest mr-1"
                            target="_blank">
                            <i class="fa-brands fa-pinterest"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->youtube) && $post->social->youtube != '' )
                        <a href="https://www.youtube.com/{{ $post->social->youtube }}"
                            class="btn btn-social-icon btn-youtube mr-1"
                            target="_blank">
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->github) && $post->social->github != '' )
                        <a href="https://github.com/{{ $post->social->github }}"
                            class="btn btn-social-icon btn-github mr-1"
                            target="_blank">
                            <i class="fa-brands fa-github"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->behance) && $post->social->behance != '' )
                        <a href="https://www.behance.net/{{ $post->social->behance }}"
                            class="btn btn-social-icon btn-behance mr-1"
                            target="_blank">
                            <i class="fa-brands fa-behance"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->instagram) && $post->social->instagram != '' )
                        <a href="https://www.instagram.com/{{ $post->social->instagram }}/"
                            class="btn btn-social-icon btn-instagram"
                            target="_blank">
                            <i class="fa-brands fa-instagram"></i>
                        </a>
                        @endif
                        @if ( isset($post->social->tiktok) && $post->social->tiktok != '' )
                        <a href="https://www.tiktok.com/{{ $post->social->tiktok }}"
                            class="btn btn-social-icon btn-tiktok"
                            target="_blank">
                            <i class="fa-brands fa-tiktok"></i>
                        </a>
                        @endif
                        @if ( isset($post->website) && $post->website != '' )
                        <a href="{{ $post->website }}"
                            class="btn btn-social-icon btn-microsoft mr-1"
                            target="_blank">
                            <i class="fa-solid fa-globe"></i>
                        </a>
                        @endif
                    </div>
                </div>
            </div>
            @endif
            <div class="row">
                <div class="col-xs-12 col-md-8 mt-4">
                    <div class="text-md-left">
                        @if($post!=null && $post->tags)
                            <div class="article-tag buttons"> <span class="text-small text-muted text-uppercase">{{ __('Tags') }} </span>
                            @foreach (explode(',', $post->tags) as $tag)
                                <a href="{{ config('settings.site_url') .'/blog/tag/'. $tag }}" class="btn btn-sm btn-outline-primary">{{ $tag }}</a>
                            @endforeach
                            </div>
                        @endif
                    </div>
                </div>
                <div class="col-xs-12 col-md-4 mt-4">
                    <div class="article-share text-md-right"><span class="text-small text-muted text-uppercase">{{ __('Share on') }} </span>
                        <a rel="nofollow" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                            <i class="fa-brands fa-facebook-f fa-1x"></i>
                        </a>
                        <a rel="nofollow" target="_blank" href="https://twitter.com/intent/tweet?text={{ $post->p_title }}&amp;url={{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                            <i class="fa-brands fa-x-twitter fa-1x"></i>
                        </a>
                        <a rel="nofollow" target="_blank" href="https://www.linkedin.com/sharing/share-offsite/?url={{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                            <i class="fa-brands fa-linkedin-in fa-1x"></i>
                        </a>
                        <a rel="nofollow" target="_blank" href="mailto:?subject={{ $post->p_title }}&amp;body={{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                            <i class="fa-regular fa-envelope fa-1x"></i>
                        </a>
                    </div>
                </div>
            </div>
            @if( isset( $latest_posts ) )
                @if(count($latest_posts) > 0)
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title">
                            <h2>{{ __('Latest Posts') }}</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    @foreach($latest_posts as $post)
                        @if($post->status == 1) 
                        <div class="col-12 col-md-4 col-lg-4">
                            <article class="article article-style-c">
                                <div class="article-header">
                                    <a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                                        <div class="article-image"
                                            data-background="{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : asset('img/blog/blog-'. rand(1,5) .'.jpg') ) }}" 
                                            style="background-image: url('{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : asset('img/blog/blog-'. rand(1,5) .'.jpg') ) }}');">
                                        </div>
                                    </a>
                                </div>
                                <div class="article-details">
                                    <div class="article-category"><a href="{{ config('settings.site_url') .'/blog/category/'. $post->c_slug }}">{{ $post->c_title }}</a>
                                        <div class="bullet"></div> <a href="#">{{ $post->p_created_at->diffForHumans() }}</a>
                                    </div>
                                    <div class="article-title">
                                        <h2><a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">{{ $post->p_title }}</a></h2>
                                    </div>
                                    <div class="blog-box-short inside">
                                        <p>{{ Str::limit(trim(strip_tags((string) $post->description)), 255, ' ...') }}</p>
                                        <p class="read-more inside"></p>
                                    </div>
                                    <div class="article-read text-right">
                                        <a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">{{ __('Read More') }} <i class="fa-solid fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </article>
                        </div>
                        @endif
                    @endforeach 
                </div>
                @endif
            @endif
        </div>
    </section>
    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush