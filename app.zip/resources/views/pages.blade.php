@extends('layouts.frontend')

@section('title', $page->title)
@section('description', Str::words(strip_tags( (string) $page->description), 25,'.'))
@section('keywords', $page->keywords)
@section('url', config('settings.site_url') .'/pages/'. $page->slug)

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')

<body>
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    <section id="page" class="section section-page-inside">
        <div class="container">
            <div class="row mb-3 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h1>{{ $page->title }}</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    {!! $page->description !!}
                </div>
            </div>
        </div>
    </section>
    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush