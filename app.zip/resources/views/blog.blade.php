@extends('layouts.frontend')

@section('title', __('Blog'))

@push('style')
    <!-- CSS Libraries -->
@endpush

@section('main')
    <!-- Header -->
    @include('components.header')

    @if( config('frontends.frontend_hero') == 1 ) 
    <div id="top"> 
        <div class="hero-inside">
        </div>
    </div>
    @endif
    @if( config('settings.blog') == 1 ) 
    <section id="blog" class="section section-blog-main">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h1>{!! $frontend::highlightWords(config('frontends.frontend_blog_headline'), $frontend::stringtoArray(config('frontends.frontend_blog_highlight_words'))) !!}</h1>
                    <p class="lead">{{ config('frontends.frontend_blog_description') }}</p>
                </div>
            </div>
            @if( isset( $categories ) )
                @if(count($categories) > 0)
                <div class="row text-center">
                    <div class="card-body">
                        <div class="justify-content-center mt-4">
                            <div class="buttons">
                                @foreach($categories as $category)
                                    <a href="{{ config('settings.site_url') .'/blog/category/'. $category->c_slug }}"><button type="button" class="btn btn-outline-secondary">{{ $category->c_title }} <span class="badge badge-secondary">{{ $category->posts_count }}</span></button></a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            @endif
            <div class="row">
                <div class="card-body">
                    <div class="d-flex flex-column justify-content-center py-3">
                        <form action="{{ route('search') }}" method="get">
                            <input type="text" class="searchBlog" name="q" id="q" value="{{ request()->input('q') ?? null }}" placeholder="{{ __('Search') }}">
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                @if( isset( $posts ) )
                    @if(count($posts) == 0)
                    <div class="card-body">
                        <div class="d-flex flex-column align-items-center justify-content-center py-3">
                            <img src="{{ asset('img/empty.png') }}" class="col-10 col-md-7 col-lg-4 mb-3" alt="{{__('No result found.')}}">
                        </div>
                    </div>
                    @else
                        @foreach($posts as $post)
                            @if($post->status == 1) 
                            <div class="col-12 col-md-4 col-lg-4">
                                <article class="article article-style-c">
                                    <div class="article-header">
                                        <a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">
                                            <div class="article-image"
                                                data-background="{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : asset('img/blog/blog-'. rand(1,5) .'.jpg') ) }}" 
                                                style="background-image: url('{{ ( $post!=null && $post->p_image_path!=null ? $post->p_image_path : asset('img/blog/blog-'. rand(1,5) .'.jpg') ) }}');">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="article-details">
                                        <div class="article-category"><a href="{{ config('settings.site_url') .'/blog/category/'. $post->c_slug }}">{{ $post->c_title }}</a>
                                            <div class="bullet"></div> <a href="#">{{ $post->p_created_at->diffForHumans() }}</a>
                                        </div>
                                        <div class="article-title">
                                            <h2><a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">{{ $post->p_title }}</a></h2>
                                        </div>
                                        <div class="blog-box-short inside">
                                            <p>{{ Str::limit(trim(strip_tags((string) $post->description)), 255, ' ...') }}</p>
                                            <p class="read-more inside"></p>
                                        </div>
                                        <div class="article-read text-right">
                                            <a class="text-decoration-none" href="{{ config('settings.site_url') .'/blog/'. $post->p_slug }}">{{ __('Read More') }} <i class="fa-solid fa-chevron-right"></i></a>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            @endif
                        @endforeach
                    @endif
                @endif
            </div>
            <div class="row">  
                <div class="blog-pagination col-lg-12 pagination">
                {!! $posts->links() !!}
                </div>
            </div>
        </div>
    </section>
    @endif
    @if( config('frontends.frontend_footer') == '1' ) 
    <footer>
        @include('components.footer')
    </footer>
    @endif
    
@endsection

@push('scripts')
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
@endpush