<?php

namespace App\Providers;

use App\Models\Frontend;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;

class FrontendServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(Request $request): void
    {
        try {
            $frontends = Frontend::all()->pluck('value', 'name');

            // Store all the database settings in a config array
            foreach ($frontends as $key => $value) {
                config(['frontends.' . $key => $value]);
            }

        } catch (\Exception $e) {}
    }
}
