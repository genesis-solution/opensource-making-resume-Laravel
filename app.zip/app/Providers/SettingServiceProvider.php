<?php

namespace App\Providers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;

class SettingServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(Request $request): void
    {
        try {
            $settings = Setting::all()->pluck('value', 'name');

            // Set App Name
            config(['app.name' => $settings['site_name']]);

            // Set App Logo
            config(['app.logo' => ( $settings['site_logo'] ? asset($settings['site_logo']) : asset('img/logo.png') )]);

            // Set App Favicon
            config(['app.favicon' => ( $settings['site_favicon'] ? asset($settings['site_favicon']) : asset('img/favicon.png') )]);

            // Set App Timezone
            config(['app.timezone' => $settings['timezone']]);

            // Store all the database settings in a config array
            foreach ($settings as $key => $value) {
                config(['settings.' . $key => $value]);
            }

            // Get the available languages
            $languages = [];
            if($handle = opendir(app()->langPath())) {
                while(false !== ($language = readdir($handle))) {
                    if($language != '.' && $language != '..' && pathinfo($language, PATHINFO_EXTENSION) == 'json') {
                        // Set the default locale
                        if (pathinfo($language, PATHINFO_FILENAME) == config('settings.language')) {
                            config(['app.language' => pathinfo($language, PATHINFO_FILENAME)]);
                        }

                        $languages[] = pathinfo($language, PATHINFO_FILENAME);
                    }
                }
                closedir($handle);
            }

            // Store the languages
            config(['app.languages' => array_intersect_key(config('languages'), array_flip($languages))]);

        } catch (\Exception $e) {}
    }
}
