<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    use HasFactory;
    protected $table = 'activity';

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'a_updated_at' => 'datetime'
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public static function createUserActivity($user_id, $activity_type, $activity_title, $activity_url){
        $activityEntry = new Activity();
        $activityEntry->user_id = $user_id;
        $activityEntry->activity_type = $activity_type;
        $activityEntry->activity_title = $activity_title;
        $activityEntry->activity_url = $activity_url;
        $activityEntry->save();

    }
}
