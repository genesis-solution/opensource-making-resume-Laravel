<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
    use HasFactory;

    protected $table = 'authors';

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'a_created_at' => 'datetime',
        'a_updated_at' => 'datetime',
        'social' => 'object'
    ];

    public function posts()
    {
        return $this->hasMany(Post::class);
    }
}
