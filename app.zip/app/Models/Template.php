<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Template extends Model
{
    use HasFactory;

    protected $table = 'templates';

    public $timestamps = false;

    protected $casts = [
        'top_colors' => 'object',
        'top_default_colors' => 'object',
        'sidebar_colors' => 'object',
        'sidebar_default_colors' => 'object',
        'content_colors' => 'object',
        'content_default_colors' => 'object'
    ];
}
