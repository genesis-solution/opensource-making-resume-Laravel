<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Carbon\Carbon;
use GuzzleHttp\Client as HttpClient;
use GuzzleHttp\Exception\BadResponseException;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;
use Laravel\Fortify\TwoFactorAuthenticatable;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, TwoFactorAuthenticatable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'firstname',
        'lastname',
        'email',
        'phone',
        'street',
        'city',
        'postal',
        'country',
        'occupation',
        'yoe',
        'bio',
        'facebook',
        'twitter',
        'linkedin',
        'pinterest',
        'youtube',
        'github',
        'behance',
        'instagram',
        'tiktok',
        'password'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'profile_password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'two_factor_confirmed_at' => 'datetime',
        'email_verified_at' => 'datetime',
        'plan_created_at' => 'datetime',
        'plan_recurring_at' => 'datetime',
        'plan_trial_ends_at' => 'datetime',
        'plan_ends_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'password' => 'hashed',
        'address' => 'object',
        'profile_password' => 'encrypted',
        'sections' => 'object',
        'availability' => 'object',
        'preferences' => 'object',
        'social' => 'object'
    ];

    // Define the user's subscribed plan.
    public function plan()
    {
        // Check whether the current plan is default, or the plan is not active
        if ($this->planIsDefault() || !$this->planIsActive()) {

            // Switch to the default plan
            $this->plan_id = 1;
        }

        return $this->plan_id;
    }

    // Determine whether the subscription plan is cancelled.
    public function planIsCancelled()
    {
        return !is_null($this->plan_ends_at);
    }

    // Determine whether the subscription plan is on trial.
    public function planOnTrial()
    {
        return $this->plan_trial_ends_at && $this->plan_trial_ends_at->isFuture();
    }

    // Determine whether the subscription plan is active.
    public function planIsActive()
    {
        if ($this->plan_payment_processor == 'paypal') {
            return $this->planOnTrial() || $this->planOnGracePeriod() || $this->plan_subscription_status == 'ACTIVE';
        } elseif ($this->plan_payment_processor == 'stripe') {
            return $this->planOnTrial() || $this->planOnGracePeriod() || $this->plan_subscription_status == 'active';
        } elseif ($this->plan_payment_processor == 'bank') {
            return $this->planOnTrial() || $this->planOnGracePeriod() || $this->plan_subscription_status == 'active';
        } else {
            return !$this->planIsCancelled() || $this->planOnTrial() || $this->planOnGracePeriod();
        }
    }

    // Determine whether the subscription plan is recurring and not on trial.
    public function planIsRecurring()
    {
        return !$this->planOnTrial() && !$this->planIsCancelled();
    }

    // Determine whether the subscription plan is on grace period after cancellation.
    public function planOnGracePeriod()
    {
        return $this->plan_ends_at && $this->plan_ends_at->isFuture();
    }

    // Determine whether the user is subscribed to the default plan.
    public function planIsDefault()
    {
        return $this->plan_id == 1;
    }

    // Cancel the subscribed plan.
    public function planSubscriptionCancel() {

        if ($this->plan_payment_processor == 'paypal') {
            $httpClient = new HttpClient();

            $httpBaseUrl = 'https://'. ( config('settings.paypal_mode') == 'sandbox' ? 'api-m.sandbox' : 'api-m') .'.paypal.com/';

            // Retrieve PayPal Auth Token
            try {

                $payPalAuthRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/oauth2/token', [
                        'auth' => [config('settings.paypal_client_id'), config('settings.paypal_client_secret')],
                        'form_params' => [
                            'grant_type' => 'client_credentials'
                        ]
                    ]
                );

                $payPalAuth = json_decode($payPalAuthRequest->getBody()->getContents());

            } catch (BadResponseException $e) {}

            // Cancel the PayPal Subscription
            try {

                $payPalSubscriptionCancelRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/billing/subscriptions/' . $this->plan_subscription_id . '/cancel', [
                        'headers' => [
                            'Authorization' => 'Bearer ' . $payPalAuth->access_token,
                            'Content-Type' => 'application/json'
                        ],
                        'body' => json_encode([
                            'reason' => __('Cancelled')
                        ])
                    ]
                );

            } catch (BadResponseException $e) {}

        } elseif ($this->plan_payment_processor == 'stripe') {
            
            // Cancel Stripe Current Subscription
            try {

                $stripe = new \Stripe\StripeClient(
                    config('settings.stripe_secret_key')
                );

                $stripe->subscriptions->update(
                    $this->plan_subscription_id,
                    ['cancel_at_period_end' => true]
                );

            } catch (\Exception $e) {}

        } elseif ($this->plan_payment_processor == 'razorpay') {

            // Attempt to cancel the current subscription
            try {

                $razorpay = new \Razorpay\Api\Api(config('settings.razorpay_key_id'), config('settings.razorpay_key_secret'));

                $razorpay->subscription->fetch($this->plan_subscription_id)->cancel();

            } catch (\Exception $e) {}

        } elseif ($this->plan_payment_processor == 'paystack') {
            $httpClient = new HttpClient();

            // Attempt to cancel the current subscription
            try {

                $paystackSubscriptionRequest = $httpClient->request('GET', 'https://api.paystack.co/subscription/' . $this->plan_subscription_id, [
                        'headers' => [
                            'Authorization' => 'Bearer ' . config('settings.paystack_secret_key'),
                            'Content-Type' => 'application/json',
                            'Cache-Control' => 'no-cache'
                        ]
                    ]
                );

                $paystackSubscription = json_decode($paystackSubscriptionRequest->getBody()->getContents());

            } catch (\Exception $e) {}

            if (isset($paystackSubscription->data->email_token)) {

                try {
                    $httpClient->request('POST', 'https://api.paystack.co/subscription/disable', [
                            'headers' => [
                                'Authorization' => 'Bearer ' . config('settings.paystack_secret_key'),
                                'Content-Type' => 'application/json',
                                'Cache-Control' => 'no-cache'
                            ],
                            'body' => json_encode([
                                'code' => $this->plan_subscription_id,
                                'token' => $paystackSubscription->data->email_token
                            ])
                        ]
                    );

                } catch (\Exception $e) {}
            }
        }

        // Update subscription end date and recurring date
        if ( !empty($this->plan_recurring_at) ) {

            $this->plan_ends_at = $this->plan_recurring_at;
            $this->plan_recurring_at = null;
        }

        $this->save();
    }

    // Check whether user email domain is not blacklisted
    public function emailIsNotBlacklisted(string $email) {
        
        if( config('settings.domain_blacklist')!=null ) {

            $userBlacklistedDomains = explode(',', config('settings.domain_blacklist', ''));
            if ($userBlacklistedDomains) {
                $userEmailDomain = explode('@', $email)[1] ?? null;
                if ($userEmailDomain && in_array($userEmailDomain, $userBlacklistedDomains)) {
                    return false;
                }
            }
        }

        return true;
    }

    // Check whether user IP Address is whitelisted
    public function ipIsWhitelisted() {

        if( config('settings.ip_whitelist')!=null ) {
            $whitelistedIpAddresses = explode(',', config('settings.ip_whitelist', ''));

            if ( $whitelistedIpAddresses && !in_array(request()->getClientIp(), $whitelistedIpAddresses, true) ) {
                return false;
            }
        }

        return true;
    }

    // Check whether user can create new resumes
    public function canCreateNewResume() {

        $userPlan = $this->plan();

        $userCreatedResumes = Resume::where('user_id', $this->id)->count();

        $plan = Plan::where('id', $userPlan)->pluck('features')->first();

        $resumePlanNumber = (int) $plan->resumes;

        if( config('settings.subscription') ) {

            if($resumePlanNumber == 1) {
                $resumeNumberLeft = (int) ($resumePlanNumber - $userCreatedResumes);
                $resumeNumberLeftDescription = __('You can create only one resume in your current plan.');
            } else if($resumePlanNumber == -1) {
                $resumeNumberLeft = -1;
                $resumeNumberLeftDescription = __('You can create unlimited resumes.');
            } else if($resumePlanNumber > 0 ) {
                $resumeNumberLeft = (int) ($resumePlanNumber - $userCreatedResumes);
                $resumeNumberLeftDescription = __('You have :number resumes left in your current plan.', ['number' => (int) ($resumePlanNumber - $userCreatedResumes)]);
            } else if ($resumePlanNumber == 0) {
                $resumeNumberLeft = 0;
                $resumeNumberLeftDescription = __('You can not create any more resumes.');
            }
        } else {
            $resumeNumberLeft = -1;
            $resumeNumberLeftDescription = __('You can create unlimited resumes.');
        }

        return array('number' => (int) $resumeNumberLeft, 'description' => (string) $resumeNumberLeftDescription);
    }

    // Display Resume Counts based on user id
    public function resumeCounts() {
        $resume_counts = Resume::where('resumes.user_id', '=', $this->id)->count();

        return (int) $resume_counts;
    }

    // Check whether user can use resume tailoring
    public function canUserResumeTailoring() {
        $userPlan = $this->plan();

        $plan = Plan::where('id', $userPlan)->first();

        // User Resume Tailoring based on their paid plan
        $resumeTailoring = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->resume_tailoring!=null 
                                    && $plan->features->resume_tailoring == '0' ) 
                                      ? '0' : '1' ) : '1' );

        return (int) $resumeTailoring;
    }

    // Check whether user can create new cover letter
    public function canCreateNewCoverLetter() {

        $userPlan = $this->plan();

        $userCreatedCoverLetters = CoverLetter::where('user_id', $this->id)->count();

        $plan = Plan::where('id', $userPlan)->pluck('features')->first();

        $coverLetterPlanNumber = (int) $plan->cover_letters;

        if( config('settings.subscription') ) {

            if($coverLetterPlanNumber == 1) {
                $coverLetterNumberLeft = (int) ($coverLetterPlanNumber - $userCreatedCoverLetters);
                $coverLetterNumberLeftDescription = __('You can create only one cover letter in your current plan.');
            } else if($coverLetterPlanNumber == -1) {
                $coverLetterNumberLeft = -1;
                $coverLetterNumberLeftDescription = __('You can create unlimited cover letters.');
            } else if($coverLetterPlanNumber > 0) {
                $coverLetterNumberLeft = (int) ($coverLetterPlanNumber - $userCreatedCoverLetters);
                $coverLetterNumberLeftDescription = __('You have :number cover letters left in your current plan.', ['number' => (int) ($coverLetterPlanNumber - $userCreatedCoverLetters)]);
            } else if ($coverLetterPlanNumber == 0) {
                $coverLetterNumberLeft = 0;
                $coverLetterNumberLeftDescription = __('You can not create any more cover letters.');
            }
        } else {
            $coverLetterNumberLeft = -1;
            $coverLetterNumberLeftDescription = __('You can create unlimited cover letters.');
        }

        return array('number' => (int) $coverLetterNumberLeft, 'description' => (string) $coverLetterNumberLeftDescription);
    }

    // Display Cover Letter Counts based on user id
    function coverLetterCounts() {
        $cover_letter_counts = CoverLetter::where('cover_letters.user_id', '=', $this->id)->count();

        return (int) $cover_letter_counts;
    }

    // Check whether user can generate AI content
    public function canCreateNewAIGeneratedContent() {

        $userPlan = $this->plan();

        $userCreatedAIGeneratedContent = User::where('id', $this->id)->value('ai_month_count');

        $userPlanInterval = User::where('id', $this->id)->value('plan_interval');

        // Check whether or not the user is on grace period, e.g.: user used a redeemable coupon for x number of days.
        $monthsLeftOnGracePeriod = 0;

        if($this->planOnGracePeriod() == true) {
            $userPlanEndsAt = User::where('id', $this->id)->value('plan_ends_at');

            $monthsLeftOnGracePeriod = round( ( strtotime($userPlanEndsAt) - time() ) / (60 * 60 * 24 * 30) );
        }

        $plan = Plan::where('id', $userPlan)->pluck('features')->first();

        $aiGeneratedContentPlanNumber = (int) $plan->ai_generated_content;

        if( config('settings.subscription') ) {

            if($aiGeneratedContentPlanNumber == 1) {
                $aiGeneratedContentNumberLeft = (int) ($aiGeneratedContentPlanNumber - $userCreatedAIGeneratedContent);
                $aiGeneratedContentNumberLeftDescription = __('You can create only one AI-Generated content in your current plan.');
            } else if($aiGeneratedContentPlanNumber == -1) {
                $aiGeneratedContentNumberLeft = -1;
                $aiGeneratedContentNumberLeftDescription = __('You can create unlimited AI-Generated content.');
            } else if($aiGeneratedContentPlanNumber > 0) {
                // Check whether user plan is set for one year
                if($userPlanInterval == 'year') {
                    $aiGeneratedContentPlanNumber = $aiGeneratedContentPlanNumber * 12; 
                } else if($monthsLeftOnGracePeriod > 0) {
                    $aiGeneratedContentPlanNumber = $aiGeneratedContentPlanNumber * $monthsLeftOnGracePeriod;
                }
                $aiGeneratedContentNumberLeft = (int) ($aiGeneratedContentPlanNumber - $userCreatedAIGeneratedContent);
                $aiGeneratedContentNumberLeftDescription = __('You have :number AI-Generated content left in your current plan.', ['number' => (int) ($aiGeneratedContentPlanNumber - $userCreatedAIGeneratedContent)]);
            } else if ($aiGeneratedContentPlanNumber == 0) {
                $aiGeneratedContentNumberLeft = 0;
                $aiGeneratedContentNumberLeftDescription = __('You can not create any more AI-Generated content.');
            }
        } else {
            $aiGeneratedContentNumberLeft = -1;
            $aiGeneratedContentNumberLeftDescription = __('You can create unlimited AI-Generated content.');
        }

        return array('number' => (int) $aiGeneratedContentNumberLeft, 'description' => (string) $aiGeneratedContentNumberLeftDescription);
    }

    // Display Monthly AI-Generated Content Counts based on user id
    public function aiGeneratedContentMonthCounts() {
        $aigeneratedcontent_counts = User::where('id', $this->id)->value('ai_month_count');

        return (int) $aigeneratedcontent_counts;
    }

    // Display Total AI-Generated Content Counts based on user id
    public function aiGeneratedContentTotalCounts() {
        $aigeneratedcontent_counts = User::where('id', $this->id)->value('ai_total_count');

        return (int) $aigeneratedcontent_counts;
    }

}
