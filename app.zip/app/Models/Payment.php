<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;
    protected $table = 'payments';

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'p_created_at' => 'datetime',
        'product' => 'object',
        'tax_rates' => 'object',
        'p_tax_rates' => 'object',
        'coupon' => 'object',
        'customer' => 'object',
        'seller' => 'object'
    ];

    public function user() {
        return $this->belongsTo('App\Models\User');
    }

    /**
     * Get the plan of the payment.
     */
    public function plan() {
        return $this->belongsTo('App\Models\Plan');
    }

}
