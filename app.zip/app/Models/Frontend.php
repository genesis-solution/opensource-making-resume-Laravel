<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Frontend extends Model
{
    use HasFactory;
    protected  $guarded =  [];

    public $timestamps = false;

    // Highlight Headline Words
    public static function highlightWords($str, $arr_word){
        foreach($arr_word as $vword) {
            $str = preg_replace("/($vword)/Ui", "<span class=\"text-primary\">$1</span>", $str);
        }

        return $str;
    }

    // Convert string comma seperated to array
    public static function stringToArray($stringSeperatedCommas){
        return collect(explode(',', $stringSeperatedCommas))->map(function ($string) {
            return trim($string) != null ? trim($string) : null;
        })->filter(function ($string) {
            return trim($string) != null;
        });
    }
}
