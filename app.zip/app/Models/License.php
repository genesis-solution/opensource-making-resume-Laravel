<?php

namespace App\Models;

use App\Models\Setting;
use Carbon\Carbon;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class License extends Model
{
    use HasFactory;

    protected $table = null;

    // Retrieve product latest version and release date information
    public static function getProductLatestVersion() {
        $licenseSettings = Setting::first();

        try {

            $httpClient = new HttpClient(['timeout' => 10, 'verify' => false]);

            $latestVersionResponse = $httpClient->request('POST', 'https://license.carcani.com/api/latest_version', [
                'headers' => [
                    'LB-API-KEY'   => config('info.software.api.external'),
                    'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                    'LB-IP'        => request()->ip(),
                    'LB-LANG'      => 'english',
                    'Content-Type' => 'application/json'
                ],
                'json' => [
                    'product_id' => config('settings.license_product_id')
                ]
            ]);

            $latestVersionOutput = json_decode($latestVersionResponse->getBody()->getContents());

            if ( $latestVersionOutput->status == true ) {
                // Retrieve product purchase marketplace
                if( config('settings.license_product_market_name') == null && $latestVersionOutput->product_name!=null ) {
                    list($productName, $productMarketplace) = explode('-', preg_replace('/\s+/', '', trim($latestVersionOutput->product_name)));

                    $licenseSettings->where('name','license_product_market_name')->update(['value' => $productMarketplace]);
                }
                // Retrieve Update Information
                $licenseSettings->where('name','license_product_latest_version')->update(['value' => ( $latestVersionOutput->latest_version ?? null )]);
                $licenseSettings->where('name','license_product_release_date')->update(['value' => ( $latestVersionOutput->release_date ?? null )]);

                // Cache Product Latest Version
                Cache::put('product_latest_version', $latestVersionOutput->latest_version, now()->addMinutes(120));
            }

        } catch (\Exception $e) {
            // return back()->with('error', __('Failed to retrieve your product latest version.'));
        }
    }

    // Retrieve product update id
    public static function getProductLatestUpdateId() {
        $licenseSettings = Setting::first();

        $licenseProductUpdateId = '';

        try {

            $httpClient = new HttpClient(['timeout' => 10, 'verify' => false]);

            $latestUpdateIdResponse = $httpClient->request('POST', 'https://license.carcani.com/api/check_update', [
                'headers' => [
                    'LB-API-KEY'   => config('info.software.api.external'),
                    'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                    'LB-IP'        => request()->ip(),
                    'LB-LANG'      => 'english',
                    'Content-Type' => 'application/json'
                ],
                'json' => [
                    'product_id' => config('settings.license_product_id'),
                    'current_version' => 'v'. config('info.software.version')
                ]
            ]);

            $latestUpdateIdOutput = json_decode($latestUpdateIdResponse->getBody()->getContents());

            if ( $latestUpdateIdOutput->status == true ) {
                // Retrieve product purchase marketplace
                if( config('settings.license_product_market_name') == null && $latestUpdateIdOutput->product_name!=null ) {
                    list($productName, $productMarketplace) = explode('-', preg_replace('/\s+/', '', trim($latestUpdateIdOutput->product_name)));

                    $licenseSettings->where('name','license_product_market_name')->update(['value' => $productMarketplace]);
                }
                // Retrieve Update Information
                $licenseSettings->where('name','license_product_latest_version')->update(['value' => ( $latestUpdateIdOutput->latest_version ?? null )]);
                $licenseSettings->where('name','license_product_release_date')->update(['value' => ( $latestUpdateIdOutput->release_date ?? null )]);

                $licenseProductUpdateId = $latestUpdateIdOutput->update_id ?? '';
                
            }

        } catch (\Exception $e) {
            // return back()->with('error', __('Failed to retrieve your product latest update.'));
        }

        return $licenseProductUpdateId;
    }

    // Retrieve Product Support Information
    public static function getProductSupportInformation() {
        $licenseSettings = Setting::first();

        try {

            $httpClient = new HttpClient(['timeout' => 10, 'verify' => false]);

            $getLicenseResponse = $httpClient->request('POST', 'https://license.carcani.com/api/get_license', [
                'headers' => [
                    'LB-API-KEY'   => config('info.software.api.internal'),
                    'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                    'LB-IP'        => request()->ip(),
                    'LB-LANG'      => 'english',
                    'Content-Type' => 'application/json'
                ],
                'json' => [
                    'license_code' => config('settings.license_key')
                ]
            ]);

            $getLicenseOutput = json_decode($getLicenseResponse->getBody()->getContents());

            if ( $getLicenseOutput->status == true ) {

                if( config('settings.license_product_support_expiry') == null || ( $getLicenseOutput->support_expiry != config('settings.license_product_support_expiry') ) ) {
                    $licenseSettings->where('name','license_product_support_expiry')->update(['value' => ( $getLicenseOutput->support_expiry ?? null )]);
                }

                $licenseSettings->where('name','license_type')->update(['value' => $getLicenseOutput->license_type == 'Extended' ? '1' : '0']);
                $licenseSettings->where('name','subscription')->update(['value' => $getLicenseOutput->license_type == 'Extended' ? '1' : '0']);

                // Cache Product Support Information
                Cache::put('product_support_expiry', $getLicenseOutput->support_expiry, now()->addMinutes(120));

            }

        } catch (\Exception $e) {
            // return back()->with('error', __('Failed to retrieve your product information.'));
        }
    }
}
