<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resume extends Model
{
    use HasFactory;
    protected $table = 'resumes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'resume_id',
        'name',
        'template',
        'privacy',
        'password',
        'top_colors',
        'sidebar_colors',
        'content_colors',
        'employments',
        'volunteer',
        'projects',
        'education',
        'certificates',
        'awards',
        'publications',
        'languages',
        'skills',
        'interests',
        'references'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'password' => 'encrypted',
        'top_colors' => 'object',
        'sidebar_colors' => 'object',
        'content_colors' => 'object',
        'employments' => 'object',
        'volunteer' => 'object',
        'projects' => 'object',
        'education' => 'object',
        'certificates' => 'object',
        'awards' => 'object',
        'publications' => 'object',
        'languages' => 'object',
        'skills' => 'object',
        'interests' => 'object',
        'references' => 'object',
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

}
