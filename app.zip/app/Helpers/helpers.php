<?php

use App\Models\Activity;
use App\Models\User;
use App\Models\Plan;
use App\Models\Coupon;
use App\Models\Setting;
use App\Models\Category;
use App\Models\Frontend;
use App\Models\Currency;
use App\Models\Country;
use App\Models\Resume;
use App\Models\CoverLetter;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

// Percentage Change
function percentageChange($old, $new, int $precision = 1) {
    if ($old == 0) {
        $old++;
        $new++;
    }
    $change = round((($new - $old) / $old) * 100, $precision);

    if ($change < 0 ){
        return '<span class="text-danger"><i class="fa-solid fa-caret-down"></i></span> '. $change .'%';
    } else {
        return '<span class="text-primary"><i class="fa-solid fa-caret-up"></i></span> '. $change .'%';
    }

}

// PercentageChangeSign
function percentageChangeSign($old, $new, int $precision = 2) {

    if (percentageChange($old, $new) > 0){
        return 'plus';
    } else {
        return 'minus';
    }

}

// Fix the issue of rounding up a number formatting value
function numberFormatPrecision($number, $precision = 2, $separator = '.') {
    $numberParts = explode($separator, $number);
    $response = $numberParts[0];
    if (count($numberParts)>1 && $precision > 0) {
        $response .= $separator;
        $response .= substr($numberParts[1], 0, $precision);
    }
    return $response;
}

// Format numeric value with decimal based on country currency
function formatMoney($amount, $currency, $separator = true, $translate = true) {
    if (in_array(strtoupper($currency), Currency::select('zero_decimals','code')->where('zero_decimals', '=', 1)->Distinct()->get()->toArray() )) {
        return numberFormatPrecision( $amount, 0, $translate ? __('.') : '.', $separator ? ($translate ? __(',') : ',') : false);
    } else {
        return numberFormatPrecision( $amount, 2, $translate ? __('.') : '.', $separator ? ($translate ? __(',') : ',') : false);
    }
}

// Calculate the amount to be discounted
function calculateDiscount($amount, $discount) {
    return $amount * ($discount / 100);
}

// Calculate the amount after applying a discount
function calculateAfterDiscount($amount, $discount) {
    return $amount - calculateDiscount($amount, $discount);
}

// Calculate Inclusive Tax Rates
function calculateInclusiveTaxRates($amount, $discount, $inclusiveTaxRate) {
    return calculateAfterDiscount($amount, $discount) - (calculateAfterDiscount($amount, $discount) / (1 + ($inclusiveTaxRate / 100)));
}

// Calculate the amount after applying a discount and removing the inclusive tax rates
function calculateAfterDiscountWithoutInclTaxRates($amount, $discount, $inclusiveTaxRates) {
    return calculateAfterDiscount($amount, $discount) - calculateInclusiveTaxRates($amount, $discount, $inclusiveTaxRates);
}

// Calculate the inclusive tax rate
function calculateInclusiveTaxRate($amount, $discount, $inclusiveTaxRate, $inclusiveTaxRates) {
    return calculateAfterDiscountWithoutInclTaxRates($amount, $discount, $inclusiveTaxRates) * ($inclusiveTaxRate / 100);
}

// Return the exclusive Tax Rate
function checkoutExclusiveTaxRate($amount, $discount, $exclusiveTaxRate, $inclusiveTaxRates)
{
    return calculateAfterDiscountWithoutInclTaxRates($amount, $discount, $inclusiveTaxRates) * ($exclusiveTaxRate / 100);
}

// Calculate total amount after discount and tax rate
function checkoutTotalAmount($amount, $discount, $exclusiveTaxRates, $inclusiveTaxRates) {
    return calculateAfterDiscount($amount, $discount) + checkoutExclusiveTaxRate($amount, $discount, $exclusiveTaxRates, $inclusiveTaxRates);
}

// List all available payment processors
function paymentProcessors() {
    $paymentProcessors = [
        'paypal' => [
            'name' => 'PayPal',
            'type' => 'PayPal account'
        ],
        'stripe' => [
            'name' => 'Stripe',
            'type' => 'Credit card'
        ],
        'razorpay' => [
            'name' => 'Razorpay',
            'type' => 'Credit card'
        ],
        'paystack' => [
            'name' => 'Paystack',
            'type' => 'Credit card'
        ],
        'coinbase' => [
            'name' => 'Coinbase',
            'type' => 'Cryptocurrency'
        ],
        'crypto' => [
            'name' => 'Crypto',
            'type' => 'Cryptocurrency'
        ],
        'bank' => [
            'name' => 'Bank',
            'type' => 'Bank transfer'
        ]
    ];

    foreach ($paymentProcessors as $key => $value) {
        // Check if the payment processor is not enabled
        if ( config('settings.'. $key) != 1 ) {
            // Remove the payment processor from the list
            unset($paymentProcessors[$key]);
        }
    }

    return $paymentProcessors;
}

// List all the available date formats
function listOfDateFormats() {

    $dateFormats = [
        'DD/MM/YYYY'  =>  'd/m/Y',
        'DD-MM-YYYY'  =>  'd-m-Y',
        'DD.MM.YYYY'  =>  'd.m.Y',
        'MM/DD/YYYY'  =>  'm/d/Y',
        'MM-DD-YYYY'  =>  'm-d-Y',
        'MM.DD.YYYY'  =>  'm.d.Y',
        'YYYY/MM/DD'  =>  'Y/m/d',
        'YYYY-MM-DD'  =>  'Y-m-d',
        'YYYY.MM.DD'  =>  'Y.m.d',
        'YYYY/DD/MM'  =>  'Y/d/m',
        'YYYY-DD-MM'  =>  'Y-d-m',
        'YYYY.DD.MM'  =>  'Y.d.m'
    ];

    return $dateFormats;

}

// List all the available language levels
function listOfLanguageLevels() {

    $languageLevels = [
        __('Elementary')    =>  __('Elementary'),
        __('Intermediate')  =>  __('Intermediate'),
        __('Proficient')    =>  __('Proficient'),
        __('Advanced')      =>  __('Advanced'),
        __('Fluent')        =>  __('Fluent'),
        __('Native')        =>  __('Native')
    ];

    return $languageLevels;

}

// Format the page titles.
function formatTitle($value = null)
{
    if (is_array($value)) {
        return implode(" - ", $value);
    }

    return $value;
}

// Display category name based on provided category id
function getCategoryName($id) {
    $category = Category::all();

    return $category->where('id', $id)->pluck('title')->first();
}

// Display country name based on provided country code
function getCountryName($code) {
    $country = Country::all();

    return $country->where('code', $code)->pluck('name')->first();
}

// Display user plan name based on provided plan id
function getUserPlan($id) {
    $plans = Plan::all();

    return $plans->where('id', $id)->pluck('name')->first();
}

// // Calculate Resume Percentage Completed
function calculateResumePercentageCompleted($id, $user_id) {
    $user = User::where('id', $user_id)->first();

    $settings = Setting::first();

    $resume = Resume::where('id', $id)->where('user_id', $user_id)->first();

    $resume_percentage = 7;

    if( $user != null && $user->address != null ) {
        $resume_percentage += 3;
    }
    if( $user != null && $user->phone != null ) {
        $resume_percentage += 3;
    }
    if( $resume != null && $resume->professional_title != null ) {
        $resume_percentage += 8;
    }
    if( $resume != null && $resume->professional_yoe != null ) {
        $resume_percentage += 3;
    }
    if( $resume != null && $resume->professional_summary != null ) {
        $resume_percentage += 10;
    }
    if( $resume != null && ( $resume->employments_status != 0 || $resume->volunteer_status != 0 || $resume->projects_status != 0 ) ) {
        $resume_percentage += 18;
    }
    if( $resume != null && $resume->education_status != 0) {
        $resume_percentage += 21;
    }
    if( $resume != null && $resume->certificates_status != 0) {
        $resume_percentage += 10;
    }
    if( $resume != null && $resume->awards_status != 0) {
        $resume_percentage += 2;
    }
    if( $resume != null && $resume->languages_status != 0 ) {
        $resume_percentage += 3;
    }
    if( $resume != null && $resume->skills_status != 0 ) {
        $resume_percentage += 10;
    }
    if( $resume != null && $resume->interests_status != 0 ) {
        $resume_percentage += 2;
    }

    return (int) $resume_percentage;
}

// Calculate Cover Letter Percentage Completed
function calculateCoverLetterPercentageCompleted($id, $user_id) {
    $user = User::where('id', $user_id)->first();

    $settings = Setting::first();

    $coverLetter = CoverLetter::where('id', $id)->where('user_id', $user_id)->first();

    $cover_letter_percentage = 7;

    if( $user != null && $user->address != null ) {
        $cover_letter_percentage += 3;
    }
    if( $user != null && $user->phone != null ) {
        $cover_letter_percentage += 3;
    }
    if( $coverLetter != null && $coverLetter->professional_title != null ) {
        $cover_letter_percentage += 10;
    }
    if( $coverLetter != null && $coverLetter->professional_yoe != null ) {
        $cover_letter_percentage += 5;
    }
    if( $coverLetter != null && $coverLetter->content != null ) {
        $cover_letter_percentage += 40;
    }
    if( $coverLetter != null && $coverLetter->employer != null ) {
        $cover_letter_percentage += 17;
    }
    if( $coverLetter != null && $coverLetter->skills != null ) {
        $cover_letter_percentage += 15;
    }

    return (int) $cover_letter_percentage;
}

// Display background color based on progress value
function displayBgColorProgress($progress) {

    $bgcolor = 'light';

    if ($progress >= 90) {
        // 90 and above
        $bgcolor = 'success';
    } else if ($progress >= 45 && $progress < 90) {
        // From 45 to 89
        $bgcolor = 'info';
    } else if ($progress >= 30 && $progress < 45) {
        // From 30 to 44
        $bgcolor = 'warning';
    } else {
        // 29 and under
        $bgcolor = 'danger';
    }

    return $bgcolor;
}

// Make a string's first character uppercase
if (!function_exists('mb_ucfirst')) {

    // @codingStandardsIgnoreLine
    function mb_ucfirst($string, $encoding = 'utf8')
    {
        $firstChar = mb_substr($string, 0, 1, $encoding);
        $then = mb_substr($string, 1, null, $encoding);

        return mb_strtoupper($firstChar, $encoding) . $then;
    }

}

// Uppercase the first character of each word in a string
if (!function_exists('mb_ucwords')) {

    // @codingStandardsIgnoreLine
    function mb_ucwords($string, $encoding = 'utf8')
    {
        return mb_convert_case($string, MB_CASE_TITLE, $encoding);
    }

}

// Convert String to Array
function stringToArray($stringSeperatedCommas)
{
    return collect(explode(',', $stringSeperatedCommas))->map(function ($string) {
        return trim($string) != null ? (int) trim($string) : null;
    })->filter(function ($string) {
        return trim($string) != null;
    });
}

// Validate base64 images
function validateBase64Image($data) {
    try {

        $img = imagecreatefromstring($data);

        if (!$img) {
            return false;
        }

        $size = getimagesizefromstring($data);

        // Allow only JPG, JPEG, PNG, GIF
        $valid_mime = ['image/jpg', 'image/jpeg', 'image/png', 'image/gif'];

        $valid_extension = ['jpg', 'jpeg', 'png', 'gif'];

        $ext = image_type_to_extension( $size[2], false );

        if ( !$size || $size[0] == 0 || $size[1] == 0 || !$size['mime']  ) {
            return false;
        }

        if ( !in_array($size['mime'], $valid_mime) || !in_array($ext, $valid_extension)  ) {
            return false;
        }

        return true;

     } catch (\Exception $e) {
        //return back()->with('error', $e->getMessage());
        return false;
    }
}
