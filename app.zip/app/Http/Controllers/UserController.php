<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendFooter;
use App\Models\Plan;
use App\Models\Payment;
use App\Models\Resume;
use App\Models\CoverLetter;
use App\Models\User;
use App\Models\Setting;
use App\Models\License;
use App\Traits\OpenAITrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

use SimpleSoftwareIO\QrCode\Facades\QrCode;

class UserController extends Controller
{
    use OpenAITrait;

    public function redirect(){
        $user = Auth::user();

        if ( $user->status == '0' ) {
            Auth::logout();
            Session::flush();
            // Logout user whose account is disabled.
            return redirect()->route('login')->with(['message' => __('Your account has been disabled.')]);
        } else if ( $user->emailIsNotBlacklisted($user->email) == false ) {
            Auth::logout();
            Session::flush();
            // Logout user whose email domain is blacklisted.
            return redirect()->route('login')->with(['message' => __('Your email domain is blacklisted.')]);
        } else if ( $user->role == 'admin' && $user->ipIsWhitelisted() == false ) {
            Auth::logout();
            Session::flush();
            // Logout user whose IP address is not whitelisted.
            return redirect()->route('login')->with(['message' => __('Your admin panel access is denied.')]);
        } else if ( $user->role == 'admin' ) {
            try {
                // Retrieve and Cache Product Latest Version
                License::getProductLatestVersion();
                // Retrieve and Cache Product Support Information
                License::getProductSupportInformation();
            } catch (\Exception $e) {
                // return back()->with('error', $e->getMessage());
            }
            // Redirect to admin dashboard
            return redirect()->route('dashboard.admin.index');
        } else {
            // Redirect to user dashboard
            return redirect()->route('dashboard.user.index');
        }
    }

    public function index(){
        $user = Auth::user();
        $settings = Setting::first();

        // User Payments
        $payments = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->select('payments.id as p_id', 'payments.created_at as p_created_at', 'payments.*', 'plans.*', 'users.*')
                            ->where('payments.user_id', '=', $user->id)
                              ->take(6)->get();

        // User Payment Counts
        $payment_user_counts = Payment::where('payments.user_id', '=', $user->id)->count();
        Cache::put('payment_user_counts', json_encode($payment_user_counts), now()->addMinutes(60));

        // User Total Amount Paid
        $payment_user_paid = Payment::where('payments.user_id', '=', $user->id)->sum('amount');
        Cache::put('payment_user_paid', json_encode($payment_user_paid), now()->addMinutes(60));

        // User Activity
        $activity = Activity::join('users', 'users.id', '=', 'activity.user_id')
                        ->where('users.id', '=', $user->id)
                            ->select('activity.id as a_id', 'activity.updated_at as a_updated_at', 'activity.*', 'users.*')
                                ->orderBy('a_updated_at', 'DESC')
                                    ->take(6)->get();

        // User Resumes
        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.user_id', '=', $user->id)
                            ->select('resumes.id as r_id', 'resumes.*', 'users.*')
                                ->orderBy('resumes.created_at', 'desc')->take(6)->get();

        // User Resume Counts
        $resume_user_counts = Resume::where('resumes.user_id', '=', $user->id)->count();
        Cache::put('resume_user_counts', json_encode($resume_user_counts), now()->addMinutes(60));

        // User Cover Letters
        $coverLetters = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                        ->where('cover_letters.user_id', '=', $user->id)
                            ->select('cover_letters.id as cl_id', 'cover_letters.*', 'users.*')
                                ->orderBy('cover_letters.created_at', 'desc')->take(6)->get();

        // User Cover Letters Counts
        $cover_letter_user_counts = CoverLetter::where('cover_letters.user_id', '=', $user->id)->count();
        Cache::put('cover_letter_user_counts', json_encode($cover_letter_user_counts), now()->addMinutes(60));

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        return view('dashboard.user.index', compact('user', 'settings', 'payments', 'resumes', 'coverLetters', 'activity'));

    }

    // User Settings
    public function userSettings(){
        $user = Auth::user();
        $settings = Setting::first();

        return view('dashboard.user.settings.index', compact('user', 'settings'));
    }

    // User Profile Settings
    public function userProfileSettings(){
        $user = Auth::user();
        $settings = Setting::first();

        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.user_id', '=', $user->id)
                            ->where('resumes.status', '=', '1')
                                ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.*', 'users.*')
                                    ->orderBy('resumes.created_at', 'asc')->get();

        // User Resume Counts
        $resume_counts = Resume::where('resumes.user_id', '=', $user->id)->count();

        // User Cover Letter Counts
        $cover_letter_counts = CoverLetter::where('cover_letters.user_id', '=', $user->id)->count();

        // User AI-Generated Content
        $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];
        $aiGeneratedContentDescription = $user->canCreateNewAIGeneratedContent()['description'];

        return view('dashboard.user.settings.profile', compact('user', 'settings', 'resumes', 'resume_counts', 'cover_letter_counts', 'aiGeneratedContentLeft', 'aiGeneratedContentDescription'));
    }

    public function shareUserProfile($id = null){
        $settings = Setting::first();

        $frontend = Frontend::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get(); 

        $user = User::where('profile_id', '=', $id)
                    ->where('status', '=', '1')->firstOrFail();

        $resume = Resume::where('id', '=', $user->resume)
                        ->where('status', '=', '1')->first();

        // The privacy is not set to public
        if($user->privacy !== '0') {
            $authUser = Auth::user();

            // The privacy is set to private
            if ($user->privacy == '1') {
                // The user is not authenticated, link owner or an admin
                if ( $authUser == null || ( $authUser->id != $user->id && $authUser->role != 'admin' ) ) {
                    abort(403);
                } else if ( ( $authUser != null && $authUser->id == $user->id ) || $authUser->role == 'admin' ) {
                    return view('dashboard.user.profiles.share', compact('user', 'resume', 'frontend', 'navs', 'footer', 'settings'));
                }
            }

            // The privacy is set to password protected
            if ($user->privacy == '2') {
                // No current session password validation
                if (!session(md5($user->profile_id))) {
                    // The user is not authenticated, link owner or an admin
                    if ( $authUser == null || ( $authUser->id != $user->id && $authUser->role != 'admin' ) ) {
                        return view('dashboard.user.profiles.password', compact('user', 'settings'));
                    } else if ( ( $authUser != null && $authUser->id == $user->id ) || $authUser->role == 'admin' ) {
                        return view('dashboard.user.profiles.share', compact('user', 'resume', 'frontend', 'navs', 'footer', 'settings'));
                    }
                } else {
                    return view('dashboard.user.profiles.share', compact('user', 'resume', 'frontend', 'navs', 'footer', 'settings'));
                }
            }
        } else {
            return view('dashboard.user.profiles.share', compact('user', 'resume', 'frontend', 'navs', 'footer', 'settings'));
        }
    }

    public function shareUserQrCodeProfile($id = null){

        $user = User::where('id', '=', $id)->firstOrFail();

        if($user!=null && $user->profile_id!=null) {
            $dataQrCode = QrCode::size(512)
                ->generate(
                    config('settings.site_url') .'/p/'. $user->profile_id,
                );

            return response($dataQrCode)
                ->header('Content-type', 'image/svg+xml');
        } else {
            abort(404);
        }
    }

    public function validateProfilePassword(Request $request) {

        $request->validate([
            'profile_id' => ['required', 'alpha_num'],
            'profile_password' => ['required', 'string'],
        ],[
            'profile_id.required' => __('The Profile Id field is required.'),
            'profile_password.required' => __('The Profile Password field is required.')
        ]);

        // Get the provided password
        $user = User::where('profile_id', '=', $request->profile_id)->firstOrFail();

        // Check whether the password exists
        if ( $user != null ) {
            if ( $request->profile_password === $user->profile_password) {
                //return response()->json(['success' => 'The password is valid.'], 200 );
                // Set Session for this profile id
                session([md5($request->profile_id) => true]);
                // redirect back
                return back()->with(['message' => 'Password Validated Successfully.', 'type' => 'success']);
            } else {
                return response()->json(['errors' => ['message' => 'The password is invalid.']], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => 'The password is not found.']], 419 );
        }
        return false;
    }

    public function generateAIUserProfileBio(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {
                if($request->occupation!=null) {
                    if($request->yoe!=null) {
                        $prompt = config('settings.openai_user_bio_prompt');

                        // Replace prompt theme variables
                        $prompt = str_replace(':occupation', $request->occupation, $prompt);
                        $prompt = str_replace(':yoe', $request->yoe, $prompt);
                        $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                        $response = $this->openAICompletions($request, $prompt);

                        // Check whether the response is returned empty
                        if( $response != null ) {
                            $content = $response['choices'][0]['message']['content'] ?? null;

                            if( $content != null ) {
                                // Increment the AI user usage count
                                $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                $user->save();

                                return response()->json(['success' => ['content' => $content]], 200 );
                                
                            } else {
                                return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                            }
                            
                        } else {
                            return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                        } 
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your years of experience.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your occupation title.')]], 419 );
                }
            } else {
                 return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    // User Account Settings
    public function userAccountSettings(){
        $user = Auth::user();
        $settings = Setting::first();
        
        return view('dashboard.user.settings.account', compact('user', 'settings'));
    }

    // User Activities
    public function activities(){
        $user = Auth::user();
        $settings = Setting::first();

        $activities = Activity::join('users', 'users.id', '=', 'activity.user_id')
                        ->where('users.id', '=', $user->id)
                            ->select('activity.id as a_id', 'activity.updated_at as a_updated_at', 'activity.*', 'users.*')
                                ->orderBy('a_updated_at', 'DESC')
                                    ->paginate(10);

        return view('dashboard.user.activities', compact('settings', 'activities'));
    }

    // Upload User Avatar
    public function uploadUserAvatar(Request $request)
    {

        $user = Auth::user();
        $settings = Setting::first();

        // Upload Image 
        if ($request->hasFile('image')) {

            $request->validate([
                'image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $avatar = $request->file('image');
            $avatar_name = 'avatar-'. time() .'.'. $avatar->getClientOriginalExtension();

            $avatar_dir = 'uploads/';

            $avatar_path = config('settings.site_url') .'/'. $avatar_dir . $avatar_name;

            $avatarTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($avatar->getClientOriginalExtension()), $avatarTypes) ){
                return response()->json(array('status' => __('The file extension must be jpg, jpeg, png, gif, webp or svg.')), 419);
            }

            if(config('settings.storage_method') == 's3') { // AWS S3 Storage

                $aws_avatar_path = $avatar_dir . $avatar_name;

                // Remove any existing s3 stored avatar
                if($user->avatar != '' && Storage::disk('s3')->exists($avatar_dir . $user->avatar) ) {
                    Storage::disk('s3')->delete($avatar_dir . $user->avatar);
                }
         
                Storage::disk('s3')->put($aws_avatar_path, file_get_contents($avatar));
                $avatar_path = Storage::disk('s3')->url($aws_avatar_path);
                
            } else { // Local Storage

                // Remove any existing local stored avatar
                if( $user->avatar != '' && File::exists($avatar_dir . $user->avatar) ) {
                    unlink($avatar_dir . $user->avatar);
                }
                
                $avatar->move($avatar_dir, $avatar_name);
            }

            if( !empty($avatar_dir) && !empty($avatar_name) ) {

                $user->avatar = $avatar_name;
                $user->avatar_path = $avatar_path;

                $user->save();

                Activity::createUserActivity($user->id, __('Updated'), __('Profile Avatar'), null);

                return response()->json(["success" => __('Profile Avatar has been uploaded.')], 200);

                return response()->json(array('status', __('Profile Avatar has been uploaded.')), 200);
                
            }

        }
 
    }

    public function userCancelSubscription(Request $request) {
        $user = $request->user();

        // Cancel the current plan
        $user->planSubscriptionCancel();

        return response()->json(["success" => __('User Subscription Cancelled Succesfully.')], 200);

        return redirect()->route('login')->with('message', __('User Subscription Cancelled Succesfully.'));
    }

    public function userDeleteAccount(){
        $user = Auth::user();

        // Delete user id with exception to first user
        $user = User::where('id', $user->id)->whereNotIn('id', [1])->first();

        // User's resumes, cover letters, activity and payments.
        $resume = Resume::where('user_id', $user->id)->whereNotIn('user_id', [1]);
        $coverLetter = CoverLetter::where('user_id', $user->id)->whereNotIn('user_id', [1]);
        $activity = Activity::where('user_id', $user->id)->whereNotIn('user_id', [1]);
        $payment = Payment::where('user_id', $user->id)->whereNotIn('user_id', [1]);

        if($user !=null) {

            // Check whether the user previously had a subscription and attempt to cancel it
            if ($user->plan_subscription_id) {
                $user->planSubscriptionCancel();
            }

            // Delete user account
            $user->delete();

            // Delete user's resumes, cover letters, activity and payments.
            $resume->delete();
            $coverLetter->delete();
            $activity->delete();
            $payment->delete();
        }

        return response()->json(["success" => __('User Account Deleted Succesfully.')], 200);

        return redirect()->route('login')->with('message', __('User Account Deleted Succesfully.'));
    }

}
