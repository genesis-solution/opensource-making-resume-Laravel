<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendFooter;
use App\Models\Resume;
use App\Models\User;
use App\Models\Plan;
use App\Models\Setting;
use App\Models\Template;
use App\Traits\OpenAITrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;

use SimpleSoftwareIO\QrCode\Facades\QrCode;

class ResumeController extends Controller
{
    use OpenAITrait;

    public function index(){
        $user = Auth::user();
        $settings = Setting::first();

        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.user_id', '=', $user->id)
                            ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.created_at as r_created_at', 'resumes.*', 'users.*')
                                ->orderBy('resumes.created_at', 'desc')->paginate(10);

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $resumeLeft = $user->canCreateNewResume()['number'];
        $resumeLeftDescription = $user->canCreateNewResume()['description'];

        $exportResume = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_resumes!=null 
                                    && $plan->features->export_resumes == '0' ) 
                                      ? '0' : '1' ) : '1' );

        return view('dashboard.user.resumes.index', compact('user', 'settings', 'resumes', 'resumeLeft', 'resumeLeftDescription', 'exportResume'));
    }

    public function shareUserResume($id = null){
        $settings = Setting::first();

        $frontend = Frontend::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get(); 

        $resume = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.resume_id', '=', $id)
                        ->where('resumes.status', '=', '1')
                            ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.*', 'users.*')->firstOrFail();

        $user = User::where('id', '=', $resume->user_id)->where('status', '=', '1')->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $template = Template::where('status', '=', '1')
                        ->where('type', '=', 'R')
                            ->where('resource_id', '=', $resume->template)->firstOrFail();

        $watermark = ( config('settings.watermark') == '1'
                        && $plan->features!=null  
                            && $plan->features->white_label_resumes!=null 
                                && $plan->features->white_label_resumes == '0' ) 
                                    ? '1' : '0';

        // The privacy is not set to public
        if($resume->r_privacy !== '0') {
            $authUser = Auth::user();

            // The privacy is set to private
            if ($resume->r_privacy == '1') {
                // The user is not authenticated, link owner or an admin
                if ( $authUser == null || ( $authUser->id != $resume->user_id && $authUser->role != 'admin' ) ) {
                    abort(403);
                } else if ( ( $authUser != null && $authUser->id == $resume->user_id ) || $authUser->role == 'admin' ) {
                    // Increase the resume view based on provided resume id
                    Resume::where('resumes.resume_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                    return view('dashboard.user.resumes.share', compact('user', 'resume', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                }
            }

            // The privacy is set to password protected
            if ($resume->r_privacy == '2') {
                // No current session password validation
                if (!session(md5($resume->resume_id))) {
                    // The user is not authenticated, link owner or an admin
                    if ( $authUser == null || ( $authUser->id != $resume->user_id && $authUser->role != 'admin' ) ) {
                        return view('dashboard.user.resumes.password', compact('resume', 'settings'));
                    } else if ( ( $authUser != null && $authUser->id == $resume->user_id ) || $authUser->role == 'admin' ) {
                        // Increase the resume view based on provided resume id
                        Resume::where('resumes.resume_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                        return view('dashboard.user.resumes.share', compact('user', 'resume', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                    }
                } else {
                    // Increase the resume view based on provided resume id
                    Resume::where('resumes.resume_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                    return view('dashboard.user.resumes.share', compact('user', 'resume', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                }
            }
        } else {
            // Increase the resume view based on provided resume id
            Resume::where('resumes.resume_id', '=', $id)->update(['views' => DB::raw('views + 1')]);
            
            return view('dashboard.user.resumes.share', compact('user', 'resume', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
        }
    }

    public function shareUserQrCodeResume($id = null){

        $resume = Resume::where('id', '=', $id)->firstOrFail();

        if($resume!=null && $resume->resume_id!=null) {
            $dataQrCode = QrCode::size(512)
                ->generate(
                    config('settings.site_url') .'/r/'. $resume->resume_id,
                );

            return response($dataQrCode)
                ->header('Content-type', 'image/svg+xml');
        } else {
            abort(404);
        }
    }

    public function exportUserJsonResume($id = null, $mode = 'download'){
        $user = Auth::user();
        $settings = Setting::first();

        $resume = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.id', '=', $id)
                        ->where('resumes.user_id', '=', $user->id)
                            ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.*', 'users.*')->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $exportResume = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_resumes!=null 
                                    && $plan->features->export_resumes == '0' ) 
                                      ? '0' : '1' ) : '1' );

        // Create a record array
        $record_arr = array(
            'status'         =>  'success',
            'data'           => array(
                'profile' => array(
                    'firstname' => $user->firstname,
                    'lastname' => $user->lastname,
                    'occupation' => $user->occupation,
                    'yoe' => $user->yoe . ($user->yoe == 1 ? ' year' : ' years'),
                    'avatar' => $user->avatar_path,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'bio' => trim(strip_tags($user->bio)),
                ),
                'resume' => array (
                    'name' => $resume->name,
                    'professional_title' => $resume->professional_title,
                    'professional_yoe' => $resume->professional_yoe . ($resume->professional_yoe == 1 ? ' year' : ' years'),
                    'professional_summary' => trim(strip_tags($resume->professional_summary)),
                ),
            )
        );

        if( $user->address!=null ) {
            $record_arr['data']['profile']['address'] = $user->address;
        }

        if( $user->social!=null ) {
            $record_arr['data']['profile']['social'] = $user->social;
        }

        if( $resume->employments!=null ) {
            $record_arr['data']['resume']['employments'] = $resume->employments;
        }

        if( $resume->volunteer!=null ) {
            $record_arr['data']['resume']['volunteer'] = $resume->volunteer;
        }

        if( $resume->projects!=null ) {
            $record_arr['data']['resume']['projects'] = $resume->projects;
        }

        if( $resume->education!=null ) {
            $record_arr['data']['resume']['education'] = $resume->education;
        }

        if( $resume->certificates!=null ) {
            $record_arr['data']['resume']['certificates'] = $resume->certificates;
        }

        if( $resume->awards!=null ) {
            $record_arr['data']['resume']['awards'] = $resume->awards;
        }

        if( $resume->publications!=null ) {
            $record_arr['data']['resume']['publications'] = $resume->publications;
        }

        if( $resume->languages!=null ) {
            $record_arr['data']['resume']['languages'] = $resume->languages;
        }

        if( $resume->skills!=null ) {
            $record_arr['data']['resume']['skills'] = $resume->skills;
        }

        if( $resume->interests!=null ) {
            $record_arr['data']['resume']['interests'] = $resume->interests;
        }

        if( $resume->references!=null ) {
            $record_arr['data']['resume']['references'] = $resume->references;
        }

        if($exportResume == '1') {

            if( $mode == 'download' ) {

                $jsonFileName = preg_replace('/\s+/', '_', Str::lower($user->firstname. ' '. $user->lastname .' '. $resume->name));

                header('Content-disposition: attachment; filename='. $jsonFileName .'_'. now()->format('mdY') .'.json');
                header('Content-type: application/json; charset=utf-8');
            }

            $json = json_encode($record_arr, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);

            // Strip HTML tags in JSON output
            $json = preg_replace('/<[^>]*>/', '', $json);

            return $json;
        } else {
            abort(404);
        }
    }

    public function exportUserTxtResume($id = null, $mode = 'download'){
        $user = Auth::user();
        $settings = Setting::first();

        $resume = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.id', '=', $id)
                        ->where('resumes.user_id', '=', $user->id)
                            ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.*', 'users.*')->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $exportResume = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_resumes!=null 
                                    && $plan->features->export_resumes == '0' ) 
                                      ? '0' : '1' ) : '1' );

        // Resume Text
        $record_txt = $user->firstname ." ". $user->lastname ."\n" ;
        $record_txt .= $user->address!=null ? ( ( $user->address->street!=null ? $user->address->street : "" ) . ( $user->address->city!=null ? ", ". $user->address->city : "" ) . ( $user->address->state!=null ? ", ". $user->address->state : "" ) . ( $user->address->postal!=null ? ", ". $user->address->postal : "" ) ) ."\n" : null;
        $record_txt .= $user->phone!=null ? $user->phone ."\n" : null;
        $record_txt .= $user->email!=null ? $user->email ."\n" : null;

        if($user->occupation!=null) {
            $record_txt .= "\n". strtoupper(__('Professional Title')) ."\n\n";
            $record_txt .= $user->occupation . ( $user->yoe!=null ? ", ". $user->yoe ." ". __('years') : "" ) ."\n";
        }

        if($user->bio!=null) {
            $record_txt .= "\n". strtoupper(__('Professional Summary')) ."\n\n";
            $record_txt .= trim(strip_tags($user->bio)) ."\n";
        }

        if( $resume->employments!=null && $resume->employments_status == '1' ) {
            $record_txt .= "\n". strtoupper(__('Work Experience')) ."\n\n";
            foreach( collect($resume->employments)->sortBy('job_order') as $employment ) {
                $record_txt .= $employment->job_title . ( $employment->job_employer!=null ? ", ". $employment->job_employer : "" ) . ( isset($employment->job_website) && $employment->job_website!=null ? " (". trim(strip_tags($employment->job_website)) .")" : "" ) . ( $employment->job_location!=null ? ", ". $employment->job_location : "" ) . ( $employment->job_started!=null ? ", ". mb_ucwords(Carbon::parse($employment->job_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ." - ". ( $employment->job_ended!=null ? mb_ucwords(Carbon::parse($employment->job_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') ) ."\n";
                $record_txt .= ( $employment->job_description!=null ? trim(strip_tags($employment->job_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->volunteer!=null && $resume->volunteer_status == '1' ) {
            $record_txt .= strtoupper(__('Volunteer Experience')) ."\n\n";
            foreach( collect($resume->volunteer)->sortBy('volunteer_order') as $volunteer ) {
                $record_txt .= $volunteer->volunteer_title . ( $volunteer->volunteer_employer!=null ? ", ". $volunteer->volunteer_employer : "" ) . ( isset($volunteer->volunteer_website) && $volunteer->volunteer_website!=null ? " (". trim(strip_tags($volunteer->volunteer_website)) .")" : "" ) . ( $volunteer->volunteer_location!=null ? ", ". $volunteer->volunteer_location : "" ) . ( $volunteer->volunteer_started!=null ? ", ". mb_ucwords(Carbon::parse($volunteer->volunteer_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ." - ". ( $volunteer->volunteer_ended!=null ? mb_ucwords(Carbon::parse($volunteer->volunteer_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') ) ."\n";
                $record_txt .= ( $volunteer->volunteer_description!=null ? trim(strip_tags($volunteer->volunteer_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->projects!=null && $resume->projects_status == '1' ) {
            $record_txt .= strtoupper(__('Personal Projects')) ."\n\n";
            foreach( collect($resume->projects)->sortBy('project_order') as $project ) {
                $record_txt .= $project->project_title . ( isset($project->project_website) && $project->project_website!=null ? " (". trim(strip_tags($project->project_website)) .")" : "" ) . ( $project->project_started!=null ? ", ". mb_ucwords(Carbon::parse($project->project_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ." - ". ( $project->project_ended!=null ? mb_ucwords(Carbon::parse($project->project_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') ) ."\n";
                $record_txt .= ( $project->project_description!=null ? trim(strip_tags($project->project_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->education!=null && $resume->education_status == '1' ) {
            $record_txt .= strtoupper(__('Education')) ."\n\n";
            foreach( collect($resume->education)->sortBy('school_order') as $education ) {
                $record_txt .= $education->school_name . ( isset($education->school_website) && $education->school_website!=null ? " (". trim(strip_tags($education->school_website)) .")" : "" ) . ( $education->school_degree!=null ? ", ". $education->school_degree : "" ) . ( isset($education->school_major) && $education->school_major!=null ? ", ". $education->school_major : "" ) . ( isset($education->school_gpa) && $education->school_gpa!=null ? ", ". __('GPA') .": ". $education->school_gpa : "" ) . ( $education->school_started!=null ? ", ". mb_ucwords(Carbon::parse($education->school_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ." - ". ( $education->school_ended!=null ? mb_ucwords(Carbon::parse($education->school_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : __('Present') ) ."\n";
                $record_txt .= ( $education->school_description!=null ? trim(strip_tags($education->school_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->certificates!=null && $resume->certificates_status == '1' ) {
            $record_txt .= strtoupper(__('Certificates')) ."\n\n";
            foreach( collect($resume->certificates)->sortBy('certificate_order') as $certificate ) {
                $record_txt .= $certificate->certificate_title . ( isset($certificate->certificate_institution) && $certificate->certificate_institution!=null ? ", ". $certificate->certificate_institution : "" ) . ( isset($certificate->certificate_website) && $certificate->certificate_website!=null ? " (". trim(strip_tags($certificate->certificate_website)) .")" : "" ) . ( $certificate->certificate_started!=null ? ", ". mb_ucwords(Carbon::parse($certificate->certificate_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) . ( $certificate->certificate_ended!=null ? " - ". mb_ucwords(Carbon::parse($certificate->certificate_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ."\n";
                $record_txt .= ( $certificate->certificate_description!=null ? trim(strip_tags($certificate->certificate_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->awards!=null && $resume->awards_status == '1' ) {
            $record_txt .= strtoupper(__('Awards')) ."\n\n";
            foreach( collect($resume->awards)->sortBy('award_order') as $award ) {
                $record_txt .= $award->award_title . ( $award->award_institution!=null ? ", ". $award->award_institution : "" ) . ( isset($award->award_website) && $award->award_website!=null ? " (". trim(strip_tags($award->award_website)) .")" : "" ) . ( $award->award_started!=null ? ", ". mb_ucwords(Carbon::parse($award->award_started)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) . ( $award->award_ended!=null ? " - ". mb_ucwords(Carbon::parse($award->award_ended)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ."\n";
                $record_txt .= ( $award->award_description!=null ? trim(strip_tags($award->award_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->publications!=null && $resume->publications_status == '1' ) {
            $record_txt .= "\n". strtoupper(__('Publications')) ."\n\n";
            foreach( collect($resume->publications)->sortBy('publication_order') as $publication ) {
                $record_txt .= $publication->publication_name . ( $publication->publication_publisher!=null ? ", ". $publication->publication_publisher : "" ) . ( isset($publication->publication_website) && $publication->publication_website!=null ? " (". trim(strip_tags($publication->publication_website)) .")" : "" ) . ( $publication->publication_date!=null ? ", ". mb_ucwords(Carbon::parse($publication->publication_date)->locale(config('settings.language'))->translatedFormat('M Y')) : "" ) ."\n";
                $record_txt .= ( $publication->publication_description!=null ? trim(strip_tags($publication->publication_description)) ."\n\n" : "\n" );
            }
        }

        if( $resume->languages!=null && $resume->languages_status == '1' ) {
            $record_txt .= strtoupper(__('Languages')) ."\n\n";
            foreach( collect($resume->languages)->sortBy('language_order') as $language ) {
                $record_txt .= "- ". $language->language_name ."\r\n";
            }
        }

        if( $resume->skills!=null && $resume->skills_status == '1' ) {
            $record_txt .= "\n". strtoupper(__('Skills')) ."\n\n";
            foreach( collect($resume->skills)->sortBy('skill_order') as $skill ) {
                $record_txt .= "- ". $skill->skill_name ."\r\n";
                if(isset($skill->skill_keywords) && $skill->skill_keywords!=null) {
                  foreach (explode(',', $skill->skill_keywords) as $skill->skill_keyword) {
                      $record_txt .= "\t" . "- ". $skill->skill_keyword ."\r\n";
                  }
                }
            }
        }

        if( $resume->interests!=null && $resume->interests_status == '1' ) {
            $record_txt .= "\n". strtoupper(__('Interests')) ."\n\n";
            foreach( collect($resume->interests)->sortBy('interest_order') as $interest ) {
                $record_txt .= "- ". $interest->interest_name ."\r\n";
            }
        }

        if( $resume->references!=null && $resume->references_status == '1' ) {
            $record_txt .= "\n". strtoupper(__('References')) ."\n\n";
            foreach( collect($resume->references)->sortBy('reference_order') as $reference ) {
                $record_txt .= $reference->reference_referee . ( $reference->reference_referee_title!=null ? ", ". $reference->reference_referee_title : "" ) . ( $reference->reference_referee_company!=null ? ", ". $reference->reference_referee_company : "" ) . ( isset($reference->reference_referee_website) && $reference->reference_referee_website!=null ? " (". trim(strip_tags($reference->reference_referee_website)) .")" : "" ) . ( $reference->reference_referee_phone!=null ? ", ". $reference->reference_referee_phone : "" ) . ( $reference->reference_referee_email!=null ? ", ". $reference->reference_referee_email : "" ) ."\n";
                $record_txt .= ( isset($reference->reference_referee_description) && $reference->reference_referee_description!=null ? trim(strip_tags($reference->reference_referee_description)) ."\n\n" : "\n" );
            }
        }

        if($exportResume == '1') {

            if( $mode == 'download' ) {

                $txtFileName = preg_replace('/\s+/', '_', Str::lower($user->firstname. ' '. $user->lastname .' '. $resume->name));

                header('Content-disposition: attachment; filename='. $txtFileName .'_'. now()->format('mdY') .'.txt');
                header('Content-type: text/plain; charset=utf-8');
            }

            // Strip HTML tags in JSON output
            $txt = preg_replace('/<[^>]*>/', '', $record_txt);

            return $txt;
        } else {
            abort(404);
        }
    }

    public function validateResumePassword(Request $request) {

        $request->validate([
            'resume_id' => ['required', 'alpha_num'],
            'password' => ['required', 'string'],
        ],[
            'resume_id.required' => __('The Resume Id field is required.'),
            'password.required' => __('The Password field is required.')
        ]);

        // Get the provided password
        $resume = Resume::where('resume_id', '=', $request->resume_id)->firstOrFail();

        // Check whether the password exists
        if ( $resume != null ) {
            if ( $request->password === $resume->password) {
                //return response()->json(['success' => 'The password is valid.'], 200 );
                // Set Session for this resume id
                session([md5($request->resume_id) => true]);
                // redirect back
                return back()->with(['message' => 'Password Validated Successfully.', 'type' => 'success']);
            } else {
                return response()->json(['errors' => ['message' => 'The password is invalid.']], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => 'The password is not found.']], 419 );
        }
        return false;
    }

    public function generateAIResumeProfessionalSummary(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {

                if($request->professional_title!=null) {
                    if($request->professional_yoe!=null) {
                        $prompt = config('settings.openai_resume_summary_prompt');

                        // Replace prompt theme variable
                        $prompt = str_replace(':ptitle', $request->professional_title, $prompt);
                        $prompt = str_replace(':pyoe', $request->professional_yoe, $prompt);
                        $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                        $response = $this->openAICompletions($request, $prompt);

                        // Check whether the response is returned empty
                        if( $response != null ) {
                            $summary = $response['choices'][0]['message']['content'] ?? null;

                            if( $summary != null ) {
                                // Increment the AI user usage count
                                $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                $user->save();

                                return response()->json(['success' => ['summary' => $summary]], 200 );

                            } else {
                                return response()->json(['errors' => ['message' => __('The summary is empty.')]], 419 );
                            }
                            
                        } else {
                            return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                        }
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your years of experience.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your professional title.')]], 419 );
                }
            } else {
                 return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    public function generateAIResumeJobDescription(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {

                if($request->job_title!=null && $request->job_employer!=null) {
                    if($request->job_started!=null && $request->job_ended!=null) {

                        $job_started = mb_ucwords(Carbon::parse($request->job_started)->format('M Y'));
                        $job_ended = mb_ucwords(Carbon::parse($request->job_ended)->format('M Y'));

                        $prompt = config('settings.openai_resume_job_description_prompt');

                        // Replace prompt theme variable
                        $prompt = str_replace(':jtitle', $request->job_title, $prompt);
                        $prompt = str_replace(':jemployer', $request->job_employer, $prompt);
                        $prompt = str_replace(':jstarted', $job_started, $prompt);
                        $prompt = str_replace(':jended', $job_ended, $prompt);
                        $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                        $response = $this->openAICompletions($request, $prompt);

                        // Check whether the response is returned empty
                        if( $response != null ) {
                            $content = $response['choices'][0]['message']['content'] ?? null;

                            $content = str_replace(["\r\n", "\r", "\n"], "<br>", $content); // Replace enter with break

                            if( $content != null ) {
                                // Increment the AI user usage count
                                $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                $user->save();

                                return response()->json(['success' => ['content' => $content]], 200 );

                            } else {
                                return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                            }
                            
                        } else {
                            return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                        }
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your job started and ended date.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your job title and company name.')]], 419 );
                }
            } else {
                 return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    public function generateAIResumeVolunteerDescription(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {

                if($request->volunteer_title!=null && $request->volunteer_employer!=null) {
                    if($request->volunteer_started!=null && $request->volunteer_ended!=null) {

                        $volunteer_started = mb_ucwords(Carbon::parse($request->volunteer_started)->format('M Y'));
                        $volunteer_ended = mb_ucwords(Carbon::parse($request->volunteer_ended)->format('M Y'));

                        $prompt = config('settings.openai_resume_volunteer_description_prompt');

                        // Replace prompt theme variable
                        $prompt = str_replace(':vtitle', $request->volunteer_title, $prompt);
                        $prompt = str_replace(':vemployer', $request->volunteer_employer, $prompt);
                        $prompt = str_replace(':vstarted', $volunteer_started, $prompt);
                        $prompt = str_replace(':vended', $volunteer_ended, $prompt);
                        $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                        $response = $this->openAICompletions($request, $prompt);

                        // Check whether the response is returned empty
                        if( $response != null ) {
                            $content = $response['choices'][0]['message']['content'] ?? null;

                            $content = str_replace(["\r\n", "\r", "\n"], "<br>", $content); // Replace enter with break

                            if( $content != null ) {
                                // Increment the AI user usage count
                                $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                $user->save();

                                return response()->json(['success' => ['content' => $content]], 200 );

                            } else {
                                return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                            }
                            
                        } else {
                            return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                        }
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your volunteer started and ended date.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your volunteer title and company name.')]], 419 );
                }
            } else {
                 return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    public function userResumeTailoring(Request $request){
        $user = Auth::user();

        $settings = Setting::first();

        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.user_id', '=', $user->id)
                            ->where('resumes.status', '=', '1')
                                ->select('resumes.id as r_id', 'resumes.status as r_status', 'resumes.privacy as r_privacy', 'resumes.*', 'users.*')
                                    ->orderBy('resumes.created_at', 'asc')->get();

        // User Resume Counts
        $resume_counts = Resume::where('resumes.user_id', '=', $user->id)->count();

        $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];
        $aiGeneratedContentDescription = $user->canCreateNewAIGeneratedContent()['description'];

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $resumeTailoring = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->resume_tailoring!=null 
                                    && $plan->features->resume_tailoring == '0' ) 
                                      ? '0' : '1' ) : '1' );

        if($resumeTailoring == '1') {

            if( config('settings.openai') && config('settings.openai_key') !=null ) {
                return view('dashboard.user.resumes.tailor', compact('user', 'resumes', 'settings', 'aiGeneratedContentLeft', 'aiGeneratedContentDescription'));
            } else {
                return view('dashboard.user.index');
            }
        } else {
            return back()->with('error', __('Your plan does not allow resume tailoring.'));
        }
        
    }

    public function generateAITailoredResume(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $resumeTailoring = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->resume_tailoring!=null 
                                    && $plan->features->resume_tailoring == '0' ) 
                                      ? '0' : '1' ) : '1' );

        if($resumeTailoring == '1') {

            if( config('settings.openai') && config('settings.openai_key') !=null ) {

                $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

                if( $aiGeneratedContentLeft != 0 ) {

                    $resumeTypeArray = ['internal', 'external'];
                    if( $request->resume_type!=null && in_array($request->resume_type, $resumeTypeArray) ) {

                        if( $request->resume_type == 'internal' && $request->resume_internal!=null && is_numeric($request->resume_internal) ) {
                            $resume_id = $request->resume_internal;
                            $resumeTxtContent = $this->exportUserTxtResume($resume_id, 'view');
                        } else if ( $request->resume_type == 'external' && $request->resume_external!=null ) {
                            $resumeTxtContent = $request->resume_external ?? null;
                            $resumeTxtContent = preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', $resumeTxtContent);
                        } else {
                            $resumeTxtContent = null;
                        }

                        if ( $resumeTxtContent!=null ) {

                            if($request->target_job_description!=null) {

                                $targetJobDescription = $request->target_job_description ?? null;
                                $targetJobDescription = preg_replace('#<(script|style)(.*?)>(.*?)<\/(script|style)>#siU', '', $targetJobDescription);

                                $coverLetter = $request->cover_letter ?? '0';

                                if($coverLetter == '0') {
                                    $prompt = config('settings.openai_resume_tailoring_prompt');
                                } else {
                                    $prompt = config('settings.openai_resume_tailoring_with_cover_letter_prompt');
                                }

                                // Replace prompt variable
                                $prompt = str_replace(':breakline', "\r\n==============\r\n", $prompt);
                                $prompt = str_replace(':resumeTxtContent', "\n". $resumeTxtContent ."\r\n", $prompt);
                                $prompt = str_replace(':targetJobDescription', "\n". $targetJobDescription ."\r\n", $prompt);
                                $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                                $response = $this->openAICompletions($request, $prompt);

                                // Check whether the response is returned empty
                                if( $response != null ) {
                                    $content = $response['choices'][0]['message']['content'] ?? null;

                                    // Remove header and signature of cover letter
                                    $content = str_replace("[Your Name]", "", $content);
                                    $content = str_replace("[Your Address]", "", $content);
                                    $content = str_replace("[Address Line 1]", "", $content);
                                    $content = str_replace("[Address Line 2]", "", $content);
                                    $content = str_replace("[City, State ZIP Code]", "", $content);
                                    $content = str_replace("[City, State, ZIP Code]", "", $content);
                                    $content = str_replace("[Email Address]", "", $content);
                                    $content = str_replace("[Phone Number]", "", $content);
                                    $content = str_replace("[Date]", "", $content);
                                    $content = str_replace("[Today's Date]", "", $content);
                                    $content = str_replace("Dear [Recipient's Name],", "", $content);
                                    $content = str_replace("Dear [Employer's Name],", "", $content);
                                    $content = str_replace("[Recipient's Name]", "", $content);
                                    $content = str_replace("[Employer's Name]", "", $content);
                                    $content = str_replace("[Recipient's Job Title]", "", $content);
                                    $content = str_replace("Dear Hiring Manager,", "", $content);
                                    $content = str_replace("Sincerely,", "", $content);

                                    // Replace enter with break
                                    $content = str_replace(["\r\n", "\r", "\n"], "<br>", $content);

                                    // Remove header company name or company address, without removing it from body part
                                    $content = str_replace("[Company Name]<br>[Company Address]", "", $content);

                                    // Remove accessive empty spaces replaced with break
                                    $content = preg_replace("/(<br\s*\/?><br\s*\/?><br\s*\/?><br\s*\/?>\s*)+/", "<br><br>", $content);
                                    $content = preg_replace("/(<br\s*\/?><br\s*\/?><br\s*\/?>\s*)+/", "<br><br>", $content);

                                    if( $content != null ) {
                                        // Increment the AI user usage count
                                        $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                        $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                        $user->save();

                                        return response()->json(['success' => ['content' => $content]], 200 );

                                    } else {
                                        return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                                    }
                                    
                                } else {
                                    return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                                }

                            } else {
                                return response()->json(['errors' => ['message' => __('Provide the interested target job description.')]], 419 );
                            }

                        } else {
                            return response()->json(['errors' => ['message' => __('Provide the resume to be tailored.')]], 419 );
                        }

                    } else {
                        return response()->json(['errors' => ['message' => __('The resume type is invalid.')]], 419 );
                    }

                } else {
                     return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
                }

            } else {
                return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
            }

        } else {
            return response()->json(['errors' => ['message' => __('Your plan does not allow resume tailoring.')]], 419 );
        }

        return false;
    }

    public function previewUserResumeTemplate(Request $request) {
        $user = Auth::user();
        $settings = Setting::first();

        $request->validate([
            'item_id'   => ['required', 'integer'],
            'template_id'   => ['sometimes', 'nullable'],
        ],[
            'item_id.required' => __('The Item Id is required.'),
            'template_id.required' => __('The Template Id is required.')
        ]);

        if($request->item_id!=null) {

            $resumeId = (int) $request->item_id;
            
            $item = Resume::where('id', $resumeId)->where('user_id', '=', $user->id)->firstOrFail();

            if( $request->template_id!=null && $request->template_id != 'undefined' ) {

                $resumeTemplateId = (int) $request->template_id;

                // Change Resume Template
                $item->template = $resumeTemplateId;

                $item->save();
            }

            $resume = Resume::where('id', $resumeId)->where('user_id', '=', $user->id)->firstOrFail();

            $itemTemplate = $resume->template;

            if($resume!=null && $resume->resume_id!=null) {
                return view('dashboard.user.resumes.templates.template-'. $itemTemplate, compact('user', 'settings', 'resume'));
            } else {
                return '';
            }

        } else {
            return response()->json(['errors' => ['message' => __('Provide the resume id.')]], 419 );
        }
    }

    public function resetResumeTemplateColors(Request $request) {
        $user = Auth::user();
        $settings = Setting::first();

        $request->validate([
            'item_id'   => ['sometimes', 'nullable'],
            'template_id'   => ['required', 'integer'],
        ],[
            'item_id.required' => __('The Item Id is required.'),
            'template_id.required' => __('The Template Id is required.')
        ]);

        if($request->template_id!=null) {

            $resumeTemplateId = (int) $request->template_id;
        
            if( $request->item_id!=null && $request->item_id != 'undefined' ) {
                $resumeId = (int) $request->item_id;

                $item = Resume::where('id', $resumeId)->where('user_id', '=', $user->id)->firstOrFail();

                // Reset Color Palettes
                $item->top_colors = null;
                $item->sidebar_colors = null;
                $item->content_colors = null;

                $item->save();

            } else {
               $item = new Resume(); 
            }

            $template = Template::where('status', '=', '1')
                                ->where('type', '=', 'R')
                                    ->where('resource_id', '=', $resumeTemplateId)->firstOrFail();

            if($template!=null && $template->resource_id!=null) {
                return view('dashboard.user.resumes.template-colors', compact('user', 'settings', 'item', 'template'));
            } else {
                return '';
            }

        } else {
            return response()->json(['errors' => ['message' => __('Provide the template id.')]], 419 );
        }
    }

    public function resetResumeColorPalette(Request $request) {
        $user = Auth::user();

        $request->validate([
            'palette'  => ['required', 'string'],
            'item_id'   => ['required', 'integer'],
        ],[
            'palette.required' => __('The Color Palette is required.'),
            'item_id.required' => __('The Item Id is required.')
        ]);

        if($request->palette!=null && $request->item_id!=null) {

            $colorPalette = (string) $request->palette;
            $resumeId = (int) $request->item_id;

            $colorPaletteArray = ['top-color', 'sidebar-color', 'content-color'];

            if( in_array($colorPalette, $colorPaletteArray) && is_numeric($resumeId) ) {

                $resume = Resume::where('id', $resumeId)->where('user_id', $user->id)->firstOrFail();

                switch($colorPalette) {
                    case 'top-color':
                        $resume->top_colors = null;
                    break;
                    case 'sidebar-color':
                        $resume->sidebar_colors = null;
                    break;
                    case 'content-color':
                        $resume->content_colors = null;
                    break;
                }

                $resume->save();

                return response()->json(["success" => __('Resume Color Palette Reset Successfully.')], 200);

            } else {
                return response()->json(['errors' => ['message' => __('Provide a valid color palette name.')]], 419 );
            } 
        } else {
            return response()->json(['errors' => ['message' => __('Provide the color palette and resume id.')]], 419 );
        }
            
        return false;
    }

    public function resumeCreateUpdate($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        $templates = Template::where('status', '=', '1')->where('type', '=', 'R')->get();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();
                        
        $exportResume = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_resumes!=null 
                                    && $plan->features->export_resumes == '0' ) 
                                      ? '0' : '1' ) : '1' );

        $watermark = ( config('settings.watermark') == '1'
                        && $plan->features!=null  
                            && $plan->features->white_label_resumes!=null 
                                && $plan->features->white_label_resumes == '0' ) 
                                    ? '1' : '0';

        $resumeLeft = $user->canCreateNewResume()['number'];

        $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];
        $aiGeneratedContentDescription = $user->canCreateNewAIGeneratedContent()['description'];

        if ($id == null){
            $item = null;
            $template = Template::where('status', '=', '1')
                            ->where('type', '=', 'R')
                                ->where('resource_id', '=', '1')->firstOrFail();
            if( $resumeLeft == 0 ) {
                return back()->with(['message' => __('Your plan does not allow creation of more resumes.'), 'type' => 'success']);
            }
        } else {
            // Allow only users who created the resume, not even the admins
            $item = Resume::where('id', $id)->where('resumes.user_id', '=', $user->id)->firstOrFail();

            $template = Template::where('status', '=', '1')
                            ->where('type', '=', 'R')
                                ->where('resource_id', '=', $item->template)->firstOrFail();
        }
            
        return view('dashboard.user.resumes.edit', compact('user', 'item', 'template', 'settings', 'templates', 'watermark', 'exportResume', 'aiGeneratedContentLeft', 'aiGeneratedContentDescription'));
        
    }

    public function resumeCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Resume::where('id', $request->item_id)->where('user_id', $user->id)->firstOrFail();
        } else {
            $item = new Resume();
        }

        $template = Template::where('status', '=', '1')
                        ->where('type', '=', 'R')
                            ->where('resource_id', '=', $request->template)->firstOrFail();

        // Save User Profile Information
        $request->validate([
            'firstname'  => ['required', 'string', 'max:20'],
            'lastname'   => ['required', 'string', 'max:35'],
            'phone'      => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'street'     => ['sometimes', 'nullable', 'string', 'max:255'],
            'city'       => ['sometimes', 'nullable', 'string', 'max:100'],
            'state'      => ['sometimes', 'nullable', 'string', 'max:255'],
            'postal'     => ['sometimes', 'nullable', 'string', 'max:10'],
            'country'    => ['sometimes', 'nullable', 'string', 'max:255'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' => __('The Last Name field is required.')
        ]);

        // Update the user's billing information
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->phone = $request->phone;

        $user->address = [
            'street' => $request->street,
            'city' => $request->city, 
            'state' => $request->state,
            'postal' => $request->postal, 
            'country' => $request->country,
        ];

        $user->save();

        // Save Resume Information
        $requiredResumeRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'resume_id' => ['required', 'alpha_num', 'min:16', 'max:16', 'unique:resumes,resume_id,'. $request->item_id],
            'name' => [$requiredResumeRule, 'string', 'max:255'],
            'template' => [$requiredResumeRule, 'integer'],
            'tpl_topbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidebgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'professional_title' => [$requiredResumeRule, 'string', 'max:60'],
            'professional_yoe' => [$requiredResumeRule, 'integer', 'min:0'],
            'professional_summary' => [$requiredResumeRule, 'string', 'max:1000'],
            'privacy' => [$requiredResumeRule, 'integer', Rule::in(['0','1','2'])],
            'password' => [(in_array($request->privacy, [0, 1]) ? 'nullable' : 'required'), 'string', 'min:1', 'max:128'],
        ],[
            'name.required' => __('The Name field is required.'),
            'professional_title.required' => __('The Professional Title field is required.'),
            'professional_yoe.required' => __('The Professional Yoe field is required.'),
            'professional_summary.required' => __('The Professional Summary field is required.'),
            'privacy.required' => __('The Privacy field is required.'),
            'privacy.integer' => __('The Privacy field must be an integer.'),
            'privacy.in' => __('The selected Privacy is invalid.'),
            'password.required' => __('The Password field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->user_id = $user->id;
        $item->resume_id = $request->resume_id;
        $item->name = $request->name;

        // Template
        $item->template = $request->template;

        // Template Top Color
        $top_colors = [
            'background' => $template->top_colors->background == 'Yes' ? $request->tpl_topbgcolor : null,
            'header_background' => $template->top_colors->header_background == 'Yes' ? $request->tpl_tophdbgcolor : null,
            'header_title' => $template->top_colors->header_title == 'Yes' ? $request->tpl_tophdtltxtcolor : null,
            'header_description' => $template->top_colors->header_description == 'Yes' ? $request->tpl_tophddesctxtcolor : null,
            'subheader_background' => $template->top_colors->subheader_background == 'Yes' ? $request->tpl_topsubbgcolor : null,
            'subheader_title' => $template->top_colors->subheader_title == 'Yes' ? $request->tpl_topsubtltxtcolor : null,
            'subheader_byline' => $template->top_colors->subheader_byline == 'Yes' ? $request->tpl_topsubbltxtcolor : null,
            'subheader_description' => $template->top_colors->subheader_description == 'Yes' ? $request->tpl_topsubdesctxtcolor : null
        ];

        $item->top_colors = $top_colors;

        // Template Sidebar Color
        $sidebar_colors = [
            'background' => $template->sidebar_colors->background == 'Yes' ? $request->tpl_sidebgcolor : null,
            'header_background' => $template->sidebar_colors->header_background == 'Yes' ? $request->tpl_sidehdbgcolor : null,
            'header_title' => $template->sidebar_colors->header_title == 'Yes' ? $request->tpl_sidehdtltxtcolor : null,
            'header_description' => $template->sidebar_colors->header_description == 'Yes' ? $request->tpl_sidehddesctxtcolor : null,
            'subheader_background' => $template->sidebar_colors->subheader_background == 'Yes' ? $request->tpl_sidesubbgcolor : null,
            'subheader_title' => $template->sidebar_colors->subheader_title == 'Yes' ? $request->tpl_sidesubtltxtcolor : null,
            'subheader_byline' => $template->sidebar_colors->subheader_byline == 'Yes' ? $request->tpl_sidesubbltxtcolor : null,
            'subheader_description' => $template->sidebar_colors->subheader_description == 'Yes' ? $request->tpl_sidesubdesctxtcolor : null
        ];

        $item->sidebar_colors = $sidebar_colors;

        // Template Content Color
        $content_colors = [
            'background' => $template->content_colors->background == 'Yes' ? $request->tpl_contbgcolor : null,
            'header_background' => $template->content_colors->header_background == 'Yes' ? $request->tpl_conthdbgcolor : null,
            'header_title' => $template->content_colors->header_title == 'Yes' ? $request->tpl_conthdtltxtcolor : null,
            'header_description' => $template->content_colors->header_description == 'Yes' ? $request->tpl_conthddesctxtcolor : null,
            'subheader_background' => $template->content_colors->subheader_background == 'Yes' ? $request->tpl_contsubbgcolor : null,
            'subheader_title' => $template->content_colors->subheader_title == 'Yes' ? $request->tpl_contsubtltxtcolor : null,
            'subheader_byline' => $template->content_colors->subheader_byline == 'Yes' ? $request->tpl_contsubbltxtcolor : null,
            'subheader_description' => $template->content_colors->subheader_description == 'Yes' ? $request->tpl_contsubdesctxtcolor : null
        ];

        $item->content_colors = $content_colors;

        // Professional Summary
        $item->professional_title = $request->professional_title;
        $item->professional_yoe = $request->professional_yoe;
        $item->professional_summary = $request->professional_summary;

        // Privacy
        $item->privacy = $request->privacy;

        // Password protected resume only when privacy is set to 2
        $item->password = $item->privacy == 2 ? $request->password : null;

        // Employements
        $requiredEmploymentsRule = $request->employments_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->employments, true) as $employments) {
            $employmentValidator = Validator::make($employments, [
                'job_title' => [$requiredEmploymentsRule, 'string', 'max:255'],
                'job_employer' => [$requiredEmploymentsRule, 'string', 'max:255'],
                'job_location' => [$requiredEmploymentsRule, 'string', 'max:255'],
                'job_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'job_order' => [$requiredEmploymentsRule, 'integer', 'min:1'],
                'job_started' => [$requiredEmploymentsRule, 'date_format:Y-m'],
                'job_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'job_description' => [$requiredEmploymentsRule, 'string'],
            ],[
                'job_title.required' => __('The Job Title field is required.'),
                'job_employer.required' =>  __('The Job Employer field is required.'),
                'job_location.required' =>  __('The Job Location field is required.'),
                'job_website.required' =>  __('The Job Website field is required.'),
                'job_order.required' =>  __('The Job Order field is required.'),
                'job_started.required' =>  __('The Job Started field is required.'),
                'job_started.date_format' => __('The Job Started field must match the format :format.'),
                'job_ended.required' =>  __('The Job Ended field is required.'),
                'job_ended.date_format' => __('The Job Ended field must match the format :format.'),
                'job_description.required' =>  __('The Job Description field is required.')
            ]);

            if($employmentValidator->fails())
                return response()->json(["errors" => $employmentValidator->errors()], 400);
        }

        $item->employments_status = $request->employments_status ? '1' : '0';
        $item->employments = Str::isJson($request->employments) ? json_decode($request->employments, true) : null;

        // Volunteer
        $requiredVolunteerRule = $request->volunteer_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->volunteer, true) as $volunteer) {
            $volunteerValidator = Validator::make($volunteer, [
                'volunteer_title' => [$requiredVolunteerRule, 'string', 'max:255'],
                'volunteer_employer' => [$requiredVolunteerRule, 'string', 'max:255'],
                'volunteer_location' => [$requiredVolunteerRule, 'string', 'max:255'],
                'volunteer_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'volunteer_order' => [$requiredVolunteerRule, 'integer', 'min:1'],
                'volunteer_started' => [$requiredVolunteerRule, 'date_format:Y-m'],
                'volunteer_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'volunteer_description' => [$requiredVolunteerRule, 'string'],
            ],[
                'volunteer_title.required' => __('The Volunteer Title field is required.'),
                'volunteer_employer.required' =>  __('The Volunteer Employer field is required.'),
                'volunteer_location.required' =>  __('The Volunteer Location field is required.'),
                'volunteer_website.required' =>  __('The Volunteer Website field is required.'),
                'volunteer_order.required' =>  __('The Volunteer Order field is required.'),
                'volunteer_started.required' =>  __('The Volunteer Started field is required.'),
                'volunteer_started.date_format' => __('The Volunteer Started field must match the format :format.'),
                'volunteer_ended.required' =>  __('The Volunteer Ended field is required.'),
                'volunteer_ended.date_format' => __('The Volunteer Ended field must match the format :format.'),
                'volunteer_description.required' =>  __('The Volunteer Description field is required.')
            ]);

            if($volunteerValidator->fails())
                return response()->json(["errors" => $volunteerValidator->errors()], 400);
        }

        $item->volunteer_status = $request->volunteer_status ? '1' : '0';
        $item->volunteer = Str::isJson($request->volunteer) ? json_decode($request->volunteer, true) : null;

        // Projects
        $requiredProjectsRule = $request->projects_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->projects, true) as $project) {
            $projectValidator = Validator::make($project, [
                'project_title' => [$requiredProjectsRule, 'string', 'max:255'],
                'project_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'project_order' => [$requiredProjectsRule, 'integer', 'min:1'],
                'project_started' => [$requiredProjectsRule, 'date_format:Y-m'],
                'project_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'project_description' => [$requiredProjectsRule, 'string'],
            ],[
                'project_title.required' => __('The Project Title field is required.'),
                'project_website.required' => __('The Project Website field is required.'),
                'project_order.required' =>  __('The Project Order field is required.'),
                'project_started.required' =>  __('The Project Started field is required.'),
                'project_started.date_format' => __('The Project Started field must match the format :format.'),
                'project_ended.required' =>  __('The Project Ended field is required.'),
                'project_ended.date_format' => __('The Project Ended field must match the format :format.'),
                'project_description.required' =>  __('The Project Description field is required.')
            ]);

            if($projectValidator->fails())
                return response()->json(["errors" => $projectValidator->errors()], 400);
        }

        $item->projects_status = $request->projects_status ? '1' : '0';
        $item->projects = Str::isJson($request->projects) ? json_decode($request->projects, true) : null;

        // Education
        $requiredEducationRule = $request->education_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->education, true) as $education) {
            $educationValidator = Validator::make($education, [
                'school_name' => [$requiredEducationRule, 'string', 'max:255'],
                'school_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'school_degree' => [$requiredEducationRule, 'string', 'max:255'],
                'school_major' => ['sometimes', 'nullable', 'string', 'max:255'],
                'school_gpa' => ['sometimes', 'nullable', 'string', 'max:255'],
                'school_order' => [$requiredEducationRule, 'integer', 'min:1'],
                'school_started' => [$requiredEducationRule, 'date_format:Y-m'],
                'school_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'school_description' => ['sometimes', 'nullable', 'string'],
            ],[
                'school_name.required' => __('The School Name field is required.'),
                'school_website.required' => __('The School Website field is required.'),
                'school_degree.required' => __('The School Degree field is required.'),
                'school_major.required' => __('The School Major field is required.'),
                'school_gpa.required' => __('The School GPA field is required.'),
                'school_order.required' =>  __('The School Order field is required.'),
                'school_started.required' =>  __('The School Started field is required.'),
                'school_started.date_format' => __('The School Started field must match the format :format.'),
                'school_ended.required' =>  __('The School Ended field is required.'),
                'school_ended.date_format' => __('The School Ended field must match the format :format.'),
                'school_description.required' =>  __('The School Description field is required.')
            ]);

            if($educationValidator->fails())
                return response()->json(["errors" => $educationValidator->errors()], 400);
        }

        $item->education_status = $request->education_status ? '1' : '0';
        $item->education = Str::isJson($request->education) ? json_decode($request->education, true) : null;

        // Certificates
        $requiredCertificatesRule = $request->certificates_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->certificates, true) as $certificate) {
            $certificateValidator = Validator::make($certificate, [
                'certificate_title' => [$requiredCertificatesRule, 'string', 'max:255'],
                'certificate_institution' => [$requiredCertificatesRule, 'string', 'max:255'],
                'certificate_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'certificate_order' => [$requiredCertificatesRule, 'integer', 'min:1'],
                'certificate_started' => [$requiredCertificatesRule, 'date_format:Y-m'],
                'certificate_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'certificate_description' => ['sometimes', 'nullable', 'string'],
            ],[
                'certificate_title.required' => __('The Certificate Title field is required.'),
                'certificate_institution.required' => __('The Certificate Institution field is required.'),
                'certificate_website.required' => __('The Certificate Website field is required.'),
                'certificate_order.required' =>  __('The Certificate Order field is required.'),
                'certificate_started.required' =>  __('The Certificate Started field is required.'),
                'certificate_started.date_format' => __('The Certificate Started field must match the format :format.'),
                'certificate_ended.required' =>  __('The Certificate Ended field is required.'),
                'certificate_ended.date_format' => __('The Certificate Ended field must match the format :format.'),
                'certificate_description.required' =>  __('The Certificate Description field is required.')
            ]);

            if($certificateValidator->fails())
                return response()->json(["errors" => $certificateValidator->errors()], 400);
        }

        $item->certificates_status = $request->certificates_status ? '1' : '0';
        $item->certificates = Str::isJson($request->certificates) ? json_decode($request->certificates, true) : null;

        // Awards
        $requiredAwardsRule = $request->awards_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->awards, true) as $award) {
            $awardValidator = Validator::make($award, [
                'award_title' => [$requiredAwardsRule, 'string', 'max:255'],
                'award_institution' => [$requiredAwardsRule, 'string', 'max:255'],
                'award_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'award_order' => [$requiredAwardsRule, 'integer', 'min:1'],
                'award_started' => [$requiredAwardsRule, 'date_format:Y-m'],
                'award_ended' => ['sometimes', 'nullable', 'date_format:Y-m'],
                'award_description' => ['sometimes', 'nullable', 'string'],
            ],[
                'award_title.required' => __('The Award Title field is required.'),
                'award_institution.required' => __('The Award Institution field is required.'),
                'award_website.required' => __('The Award Website field is required.'),
                'award_order.required' =>  __('The Award Order field is required.'),
                'award_started.required' =>  __('The Award Started field is required.'),
                'award_started.date_format' => __('The Award Started field must match the format :format.'),
                'award_ended.required' =>  __('The Award Ended field is required.'),
                'award_ended.date_format' => __('The Award Ended field must match the format :format.'),
                'award_description.required' =>  __('The Award Description field is required.')
            ]);

            if($awardValidator->fails())
                return response()->json(["errors" => $awardValidator->errors()], 400);
        }

        $item->awards_status = $request->awards_status ? '1' : '0';
        $item->awards = Str::isJson($request->awards) ? json_decode($request->awards, true) : null;

        // Publications
        $requiredPublicationsRule = $request->publications_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->publications, true) as $publication) {
            $publicationValidator = Validator::make($publication, [
                'publication_name' => [$requiredPublicationsRule, 'string', 'max:255'],
                'publication_publisher' => [$requiredPublicationsRule, 'string', 'max:255'],
                'publication_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'publication_order' => [$requiredPublicationsRule, 'integer', 'min:1'],
                'publication_date' => [$requiredPublicationsRule, 'date_format:Y-m'],
                'publication_description' => ['sometimes', 'nullable', 'string'],
            ],[
                'publication_name.required' => __('The Publication Name field is required.'),
                'publication_publisher.required' => __('The Publication Publisher field is required.'),
                'publication_website.required' => __('The Publication Website field is required.'),
                'publication_order.required' =>  __('The Publication Order field is required.'),
                'publication_date.required' =>  __('The Publication Date field is required.'),
                'publication_date.date_format' => __('The Publication Date field must match the format :format.'),
                'publication_description.required' =>  __('The Publication Description field is required.')
            ]);

            if($publicationValidator->fails())
                return response()->json(["errors" => $publicationValidator->errors()], 400);
        }

        $item->publications_status = $request->publications_status ? '1' : '0';
        $item->publications = Str::isJson($request->publications) ? json_decode($request->publications, true) : null;

        // Languages
        $requiredLanguagesRule = $request->languages_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->languages, true) as $language) {
            $languageValidator = Validator::make($language, [
                'language_name' => [$requiredLanguagesRule, 'string', 'max:255'],
                'language_level' => [$requiredLanguagesRule, 'string', 'max:255'],
                'language_order' => [$requiredLanguagesRule, 'integer', 'min:1'],
            ],[
                'language_name.required' => __('The Language Name field is required.'),
                'language_level.required' => __('The Language Level field is required.'),
                'language_order.required' =>  __('The Language Order field is required.')
            ]);

            if($languageValidator->fails())
                return response()->json(["errors" => $languageValidator->errors()], 400);
        }

        $item->languages_status = $request->languages_status ? '1' : '0';
        $item->languages = Str::isJson($request->languages) ? json_decode($request->languages, true) : null;

        // Skills
        $requiredSkillsRule = $request->skills_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->skills, true) as $skill) {
            $skillValidator = Validator::make($skill, [
                'skill_name' => [$requiredSkillsRule, 'string', 'max:255'],
                'skill_rating' => [$requiredSkillsRule, 'string', 'max:255'],
                'skill_keywords' => ['sometimes', 'nullable', 'string'],
                'skill_order' => [$requiredSkillsRule, 'integer', 'min:1'],
            ],[
                'skill_name.required' => __('The Skill Name field is required.'),
                'skill_rating.required' => __('The Skill Rating field is required.'),
                'skill_keywords.required' => __('The Skill Keywords field is required.'),
                'skill_order.required' =>  __('The Skill Order field is required.')
            ]);

            if($skillValidator->fails())
                return response()->json(["errors" => $skillValidator->errors()], 400);
        }
        
        $item->skills_status = $request->skills_status ? '1' : '0';
        $item->skills = Str::isJson($request->skills) ? json_decode($request->skills, true) : null;

        // Interests
        $requiredInterestsRule = $request->interests_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->interests, true) as $interest) {
            $interestValidator = Validator::make($interest, [
                'interest_name' => [$requiredInterestsRule, 'string', 'max:255'],
                'interest_keywords' => ['sometimes', 'nullable', 'string'],
                'interest_order' => [$requiredInterestsRule, 'integer', 'min:1'],
            ],[
                'interest_name.required' => __('The Interest Name field is required.'),
                'interest_keywords.required' => __('The Interest Keywords field is required.'),
                'interest_order.required' =>  __('The Interest Order field is required.')
            ]);

            if($interestValidator->fails())
                return response()->json(["errors" => $interestValidator->errors()], 400);
        }
        
        $item->interests_status = $request->interests_status ? '1' : '0';
        $item->interests = Str::isJson($request->interests) ? json_decode($request->interests, true) : null;

        // References
        $requiredReferencesRule = $request->references_status != 0 ? 'required' : 'nullable';

        foreach(json_decode($request->references, true) as $reference) {
            $referenceValidator = Validator::make($reference, [
                'reference_order' => [$requiredReferencesRule, 'integer', 'min:1'],
                'reference_referee' => [$requiredReferencesRule, 'string', 'max:255'],
                'reference_referee_title' => [$requiredReferencesRule, 'string', 'max:255'],
                'reference_referee_company' => [$requiredReferencesRule, 'string', 'max:255'],
                'reference_referee_website' => ['sometimes', 'nullable', 'string', 'max:255'],
                'reference_referee_phone' => ['sometimes', 'nullable', 'min:8', 'max:15'],
                'reference_referee_email' => ['sometimes', 'nullable', 'string', 'email', 'max:255'],
                'reference_referee_description' => ['sometimes', 'nullable', 'string'],
            ],[
                'reference_order.required' => __('The Reference Order field is required.'),
                'reference_referee.required' =>  __('The Reference Referee field is required.'),
                'reference_referee_title.required' =>  __('The Reference Referee Title field is required.'),
                'reference_referee_company.required' =>  __('The Reference Referee Company field is required.'),
                'reference_referee_website.required' =>  __('The Reference Referee Website field is required.'),
                'reference_referee_phone.required' =>  __('The Reference Referee Phone field is required.'),
                'reference_referee_email.required' =>  __('The Reference Referee Email field is required.'),
                'reference_referee_description.required' =>  __('The Reference Referee Description field is required.')
            ]);

            if($referenceValidator->fails())
                return response()->json(["errors" => $referenceValidator->errors()], 400);
        }

        $item->references_status = $request->references_status ? '1' : '0';
        $item->references = Str::isJson($request->references) ? json_decode($request->references, true) : null;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Resume :name', ['name' => $item->name]), null);

        return response()->json(["success" => __('Resume Saved Succesfully.')], 200);

        return back()->with(['message' => __('Resume Saved Succesfully.'), 'type' => 'success']);
    }

    public function resumeClone($id){
        $user = Auth::user();

        $resumeLeft = $user->canCreateNewResume()['number'];

        if($resumeLeft != 0) {

            // Retrieve the resume, and make sure the user is the owner
            $item = Resume::where('id', $id)->where('user_id', $user->id)->firstOrFail();

            $newItem = $item->replicate();
            $newItem->name = $item->name .' '. __('Cloned');
            $newItem->resume_id = Str::random(16);
            $newItem->created_at = Carbon::now ();
            $newItem->updated_at = Carbon::now ();
            $newItem->save();

            Activity::createUserActivity($user->id, __('Cloned'), __('Resume :name', ['name' => $item->name]), null);

            return back()->with(['message' => __('Resume Cloned Succesfully.'), 'type' => 'success']);
        }
    }

    public function resumeDelete($id){
        $user = Auth::user();

        // Retrieve the resume, and make sure the user is the owner
        $item = Resume::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $item->delete();

        Activity::createUserActivity($user->id, __('Deleted'), __('Resume :name', ['name' => $item->name]), null);

        return response()->json(["success" => __('Resume Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Resume Deleted Succesfully.'), 'type' => 'success']);
    }

}
