<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\Faq;
use App\Models\FrontendFooter;
use App\Models\Activity;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class FaqController extends Controller
{
    // Frequently Asked Questions
    public function index(){
        $items = Faq::join('categories', 'faqs.category_id', '=', 'categories.id')
                        ->select('categories.id as c_id', 'faqs.id as f_id', 'categories.title as c_title', 'faqs.title as f_title', 'categories.status as c_status', 'faqs.status as f_status', 'faqs.created_at as f_created_at', 'faqs.updated_at as f_updated_at', 'faqs.*')
                            ->orderBy('faqs.created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.faqs.index', compact('items', 'settings'));
    }

    // Frontend Faqs
    public function frontendFaqs(){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $faqs = Faq::join('categories', 'faqs.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'faqs.title as f_title', 'faqs.description as f_description', 'faqs.category_id', 'faqs.icon as f_icon', 'categories.faq_order as c_order', 'faqs.order as f_order', 'categories.status as c_status', 'faqs.status as f_status')
                        ->where('faqs.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        $faq_schema = Faq::where('status', '=', '1')->get(); // Faq Schema only for enabled faqs

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        return view('faqs', compact('frontend', 'settings', 'navs', 'faqs', 'faq_schema', 'footer'));
    }

    public function faqCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Faq::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.faqs.edit', compact('item', 'settings'));
    }

    public function faqCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Faq::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Faq();
        }

        $requiredFaqRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredFaqRule, 'integer'],
            'title' => [$requiredFaqRule, 'string', 'max:255'],
            'category_id' => [$requiredFaqRule, 'integer'],
            'description' => [$requiredFaqRule, 'string', 'max:500'],
        ],[
            'order.required' => __('The Order field is required.'),
            'title.required' =>  __('The Title field is required.'),
            'category_id.required' => __('The Category field is required.'),
            'description.required' =>  __('The Description field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->icon = $request->icon;
        $item->title = $request->title;
        $item->category_id = $request->category_id;
        $item->description = $request->description;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Faq Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function faqDelete($id){
        $item = Faq::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }
}
