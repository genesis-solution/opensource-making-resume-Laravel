<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\License;
use App\Models\Migration;
use Carbon\Carbon;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use ZanySoft\Zip\ZipManager;
use Zip;

class UpdateController extends Controller
{   
    const ZIP_REQUIRED_FILES = [
        'config/info.php',
        'public/css/resumaine.min.css',
        'public/css/page/user-cover-letter-preview.min.css',
        'public/css/page/user-resume-preview.min.css',
        'public/js/resumaine.min.js',
        'public/js/page/user-resumes.min.js',
        'public/js/page/user-cover-letters.min.js',
        'resources/views/index.blade.php',
        'resources/views/contact.blade.php',
        'resources/views/pricing.blade.php',
        'resources/views/theme.blade.php',
        'resources/views/dashboard/admin/about.blade.php',
        'resources/views/dashboard/user/resumes/index.blade.php',
        'resources/views/dashboard/user/cover-letters/index.blade.php',
    ];

    // Start Update
    public function index() {
        return view('dashboard.admin.update.index');
    }

    // Start Update
    public function oneClickUpdate() {

        // Check for new information on cache expiration
        if( cache('product_latest_version') == null ) {
            // Retrieve product latest version
            License::getProductLatestVersion();
        }

        // Check for support expiry on cache expiration
        if( cache('product_support_expiry') == null ) {
            // Retrieve Product Support Information
            License::getProductSupportInformation();

            return back()->with('error', 'Failed to retrieve your product information. Try again later.');
        }

        return view('dashboard.admin.update.one-click');
    }

    // File
    public function viewFileStep() {
        $settings = Setting::first();

        // Check for new information on cache expiration
        if( cache('product_latest_version') == null ) {
            // Retrieve product latest version
            License::getProductLatestVersion();
        }

        // Check for support expiry on cache expiration
        if( cache('product_support_expiry') == null ) {
            // Retrieve Product Support Information
            License::getProductSupportInformation();

            return back()->with('error', 'Failed to retrieve your product information. Try again later.');
        }

        return view('dashboard.admin.update.file', compact('settings'));
    }

    public function downloadFile(Request $request) {

        try {

            // Set unlimited execution time
            ini_set('max_execution_time', 0);
            // Set unlimited memory limit
            ini_set('memory_limit', -1);     

            // Check whether the Zip PHP Extension is enabled
            if (!extension_loaded('zip')) {
                return response()->json(['errors' => ['message' => __('The Zip PHP Extension is missing in your host. Please install the extension.')]], 419 );
            }

            // Get Product Latest Update Id
            $productLatestUpdateId = License::getProductLatestUpdateId();

            if($productLatestUpdateId!=null) {

                $file_name = $productLatestUpdateId . '.zip';

                $file_dir = '/storage/';

                $filePathName = base_path($file_dir . $file_name);

                try {

                    $httpClient = new HttpClient(['verify' => false]);

                    $latestUpdateIdResponse = $httpClient->request('POST', 'https://license.carcani.com/api/download_update/main/'. $productLatestUpdateId, [
                        'headers' => [
                            'LB-API-KEY'   => config('info.software.api.external'),
                            'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                            'LB-IP'        => request()->ip(),
                            'LB-LANG'      => 'english',
                            'Content-Type' => 'application/json'
                        ],
                        'json' => [
                            'license_code' => config('settings.license_key'),
                            'client_name' => config('settings.license_user')
                        ],
                        'sink' => storage_path($productLatestUpdateId .'.zip'),
                        'progress' => function ($dl_total_size, $dl_size_so_far, $ul_total_size, $ul_size_so_far) {
                            $fileDownloadPercent = ($dl_total_size > 0) ? (($dl_size_so_far / $dl_total_size) * 100) : 0;
                            File::put(public_path() . '/uploads/file-download-percent.txt', $fileDownloadPercent);
                        }
                    ]);

                } catch (\Exception $e) {
                    // Delete the zip file if it exists
                    if (file_exists($filePathName)) {
                        File::delete($filePathName);
                    }

                    return response()->json(['errors' => ['message' => __('Download failed! Please try again.')]], 419 );
                }

                // Check if file is downloaded
                if (!file_exists($filePathName)) {
                    return response()->json(['errors' => ['message' =>  __('Download failed! Please try again.')]], 419 );
                }

                $isZipValid = Zip::check($filePathName);

                // Check whether the Zip File is Valid
                if( $isZipValid === true ) {

                    $zip = Zip::open($filePathName);

                    // Check whether the Zip file contains the list of required files
                    $filesInside = $zip->listFiles();

                    $intersection = array_intersect(self::ZIP_REQUIRED_FILES, $filesInside);

                    if (count($intersection) !== count(self:: ZIP_REQUIRED_FILES)) {

                        // Delete the zip file if it exists
                        if (file_exists($filePathName)) {
                            File::delete($filePathName);
                        }

                        return response()->json(['errors' => ['message' =>  __('The Zip file content is invalid or corrupted.')]], 419 );
                    }
                    
                    // Extract the zip file to the application base path
                    $zip->extract(base_path('/'));

                    $zip->close();
                    
                    // Delete the zip file if it exists
                    if (file_exists($filePathName)) {
                        File::delete($filePathName);
                    }

                    // Database Update
                    $migrateDatabase = $this->migrateDatabase();
                    if ($migrateDatabase !== true) {
                        return response()->json(['errors' => ['message' => __('Failed to migrate the database.') .' '. $migrateDatabase]], 419 );
                    }

                    // Clear the config
                    Artisan::call('view:clear');
                    Artisan::call('cache:clear');
                    Artisan::call('config:clear');
                    Artisan::call('route:clear');
                    Artisan::call('optimize:clear');

                    cache()->flush();

                } else {
                    return response()->json(['errors' => ['message' => __('The Zip file is invalid or corrupted.')]], 419 );
                }

            } else {
                return response()->json(['errors' => ['message' => __('Product Update Id is Empty.')]], 419 );
            }

            return back()->with('success', __('Application Updated Succesfully.'));

        } catch (\Exception $e) {
            return response()->json(['errors' => ['message' => __('Application Update Failed. Try again or continue with a manual update.')]], 419 );
        }
    
    }

    public function downloadFilePercent() {
        if (!File::exists(public_path() . '/uploads/file-download-percent.txt')) {
            return true;
        }

        return File::get(public_path() . '/uploads/file-download-percent.txt');
    }

    public function uploadFile(Request $request) {

        try {

            // Set unlimited execution time
            ini_set('max_execution_time', 0);
            // Set unlimited memory limit
            ini_set('memory_limit', -1);     

            // Check whether the Zip PHP Extension is enabled
            if (!extension_loaded('zip')) {
                return response()->json(['errors' => ['message' => __('The Zip PHP Extension is missing in your host. Please install the extension.')]], 419 );
            }

            if ($request->hasFile('zip_file')) {

                $fileRequestValidator = Validator::make($request->all(), [
                    'zip_file' => ['required', 'file', 'mimes:zip']
                ]);

                if($fileRequestValidator->fails())
                    return response()->json(['errors' => ['message' => $fileRequestValidator->errors()->first()]], 419 );
            
                $file = $request->file('zip_file');
                $file_name = 'software-'. now()->format('mdY') .'.'. $file->getClientOriginalExtension();

                $file_dir = '/storage/';
                
                $destinationPath = base_path($file_dir);
                $filePath = $destinationPath. "/".  $file_name;
                $file->move($destinationPath, $file_name);

                $filePathName = base_path($file_dir . $file_name);

                $isZipValid = Zip::check($filePathName);

                // Check whether the Zip File is Valid
                if( $isZipValid === true ) {

                    $zip = Zip::open($filePathName);

                    // Check whether the Zip file contains the list of required files
                    $filesInside = $zip->listFiles();

                    $intersection = array_intersect(self::ZIP_REQUIRED_FILES, $filesInside);

                    if (count($intersection) !== count(self:: ZIP_REQUIRED_FILES)) {

                        // Delete the zip file if it exists
                        if (file_exists($filePathName)) {
                            File::delete($filePathName);
                        }

                        return response()->json(['errors' => ['message' =>  __('The Zip file content is invalid or corrupted.')]], 419 );
                    }
                    
                    // Extract the zip file to the application base path
                    $zip->extract(base_path('/'));

                    $zip->close();
                    
                    // Delete the zip file if it exists
                    if (file_exists($filePathName)) {
                        File::delete($filePathName);
                    }

                    // Clear the config
                    Artisan::call('view:clear');
                    Artisan::call('cache:clear');
                    Artisan::call('config:clear');
                    Artisan::call('route:clear');
                    Artisan::call('optimize:clear');

                    cache()->flush();

                } else {
                    return response()->json(['errors' => ['message' => __('The Zip file is invalid or corrupted.')]], 419 );
                }
            } 
        
            return back()->with('success', __('File Updated Successfully.'));

        } catch (\Exception $e) {
            return response()->json(['errors' => ['message' => __('File Update Failed. Try again or continue with a manual update.')]], 419 );
        }
    
    }

    // Database
    public function viewDatabaseStep() {
        $migrations = $this->getMigrations();
        $executedMigrations = $this->getExecutedMigrations();

        $updates = count($migrations) - count($executedMigrations);

        return view('dashboard.admin.update.database', compact('updates'));
    }

    // Complete
    public function complete() {
        return view('dashboard.admin.update.complete');
    }

    // Update Database with new migrations
    public function updateDatabase() {
        $migrateDatabase = $this->migrateDatabase();
        if ($migrateDatabase !== true) {
            return back()->with('error', __('Failed to migrate the database.') .' '. $migrateDatabase);
        }

        return redirect()->route('dashboard.admin.update.complete');
    }

    // Migrate the database
    private function migrateDatabase() {
        try {
            Artisan::call('migrate', ['--force' => true]);
            Artisan::call('view:clear');
            Artisan::call('cache:clear');
            Artisan::call('config:clear');

            return true;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    // Available migrations
    private function getMigrations() {
        $migrations = scandir(database_path().'/migrations');

        $output = [];
        foreach($migrations as $migration) {
            // Select only the .php files
            if($migration != '.' && $migration != '..' && substr($migration, -4, 4) == '.php') {
                $output[] = str_replace('.php', '', $migration);
            }
        }

        return $output;
    }

    // Executed migrations
    private function getExecutedMigrations() {
        return Migration::all()->pluck('migration');
    }
}
