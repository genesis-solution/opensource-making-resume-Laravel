<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Payment;
use App\Models\Setting;
use App\Models\License;
use App\Models\Resume;
use App\Models\CoverLetter;
use App\Models\User;
use Carbon\Carbon;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
    public function index(){
        $settings = Setting::first();

        // Total Users
        Cache::put('total_users', count(User::all()), now()->addMinutes(60));

        // Display Daily Users Statistics Graph
        $week_dates = collect();
        foreach( range( -6, 0 ) AS $i ) {
            $day_date = Carbon::now()->addDays( $i )->format( 'Y-m-d' );
            $week_dates->put( $day_date, 0);
        }

        // Get the day counts
        $daily_users = User::where('created_at', '>=', $week_dates->keys()->first())
             ->groupBy('date')
             ->orderBy('date')
             ->get([
                 DB::raw('DATE(created_at) as date'),
                 DB::raw('COUNT(*) as count')
             ])
             ->pluck('count','date');

        $last_week_dates = $week_dates->merge( $daily_users );
        Cache::put('last_week_dates', json_encode($last_week_dates), now()->addMinutes(60));

        // User Day Change
        $users_this_day = count(User::whereBetween('created_at', [Carbon::now()->startOfDay(), Carbon::now()->endOfDay()])->get());
        Cache::put('users_this_day', $users_this_day, now()->addMinutes(60));
        $users_previous_day = count(User::whereBetween('created_at', [Carbon::now()->subDay()->startOfDay(), Carbon::now()->subDay()->endOfDay()])->get());
        Cache::put('users_previous_day', $users_previous_day, now()->addMinutes(60));

        // User Week Change
        $users_this_week = count(User::whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->get());
        Cache::put('users_this_week', $users_this_week, now()->addMinutes(60));
        $users_previous_week = count(User::whereBetween('created_at', [Carbon::now()->subWeek()->startOfWeek(), Carbon::now()->subWeek()->endOfWeek()])->get());
        Cache::put('users_previous_week', $users_previous_week, now()->addMinutes(60));

        // User Month Change
        $users_this_month = count(User::whereBetween('created_at', [Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth()])->get());
        Cache::put('users_this_month', $users_this_month, now()->addMinutes(60));
        $users_previous_month = count(User::whereBetween('created_at', [Carbon::now()->subMonth()->startOfMonth(), Carbon::now()->subMonth()->endOfMonth()])->get());
        Cache::put('users_previous_month', $users_previous_month, now()->addMinutes(60));

        // User Year Change
        $users_this_year = count(User::whereBetween('created_at', [Carbon::now()->startOfYear(), Carbon::now()->endOfYear()])->get());
        Cache::put('users_this_year', $users_this_year, now()->addMinutes(60));
        $users_previous_year = count(User::whereBetween('created_at', [Carbon::now()->subYear()->startOfYear(), Carbon::now()->subYear()->endOfYear()])->get());
        Cache::put('users_previous_year', $users_previous_year, now()->addMinutes(60));

        // Top Countries
        $top_10_first_countries = User::join('countries', 'countries.code', '=', 'users.address->country')->select('countries.name', 'countries.code', DB::raw('count(*) as total'))
            ->groupBy('countries.name','countries.code')
                ->orderBy('total', 'DESC')
                    ->take(3)->get();
        Cache::put('top_10_first_countries', json_encode($top_10_first_countries), now()->addMinutes(60));

        $top_10_second_countries = User::join('countries', 'countries.code', '=', 'users.address->country')->select('countries.name', 'countries.code', DB::raw('count(*) as total'))
            ->groupBy('countries.name','countries.code')
                ->orderBy('total', 'DESC')
                    ->skip(3)->take(3)->get();
        Cache::put('top_10_second_countries', json_encode($top_10_second_countries), now()->addMinutes(60));

        $payments = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->select('payments.id as p_id', 'payments.created_at as p_created_at', 'payments.*', 'plans.*', 'users.*')
                                ->take(6)->get();

        // User Activity
        $activity = Activity::join('users', 'users.id', '=', 'activity.user_id')
                        ->select('activity.id as a_id', 'activity.updated_at as a_updated_at', 'activity.*', 'users.*')
                            ->orderBy('a_updated_at', 'DESC')
                                ->take(6)->get();

        $users = User::where('status', '=', '1')
                                ->orderBy('updated_at', 'DESC')
                                    ->take(8)->get();

        // User Subscriptions Counts = Payments Counts grouped by user id
        $subscription_counts = Payment::select('payments.user_id')->groupBy('payments.user_id')->get()->count();
        Cache::put('subscription_counts', json_encode($subscription_counts), now()->addMinutes(60));

        // User Payment Counts
        $payment_counts = Payment::all()->count();
        Cache::put('payment_counts', json_encode($payment_counts), now()->addMinutes(60));

        // Total amount of paid subscriptions
        $payment_total_paid = Payment::all()->sum('amount');
        Cache::put('payment_total_paid', json_encode($payment_total_paid), now()->addMinutes(60));

        // User Resumes
        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                            ->select('resumes.id as r_id', 'resumes.*', 'users.*')
                                ->where('resumes.status', '=', '1')
                                ->orderBy('resumes.created_at', 'desc')->take(6)->get();

        // User Resume Counts
        $resume_counts = Resume::all()->count();
        Cache::put('resume_counts', json_encode($resume_counts), now()->addMinutes(60));

        // User Cover Letters
        $coverLetters = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                            ->select('cover_letters.id as cl_id', 'cover_letters.*', 'users.*')
                                ->where('cover_letters.status', '=', '1')
                                ->orderBy('cover_letters.created_at', 'desc')->take(6)->get();

        // User Cover Letter Counts
        $cover_letter_counts = CoverLetter::all()->count();
        Cache::put('cover_letter_counts', json_encode($cover_letter_counts), now()->addMinutes(60));

        return view('dashboard.admin.index', compact('users', 'settings', 'payments', 'resumes', 'resume_counts', 'coverLetters', 'cover_letter_counts', 'activity'));
    }

    // User Activities
    public function activities(){

        $settings = Setting::first();

        $activities = Activity::join('users', 'users.id', '=', 'activity.user_id')
                        ->select('activity.id as a_id', 'activity.updated_at as a_updated_at', 'activity.*', 'users.*')
                            ->orderBy('a_updated_at', 'DESC')
                                ->paginate(10);

        return view('dashboard.admin.activities', compact('settings', 'activities'));
    }

    // About Product
    public function aboutProduct(){
        $settings = Setting::first();

        // Check for new information on cache expiration
        if( cache('product_latest_version') == null ) {
            // Retrieve and Cache Product Latest Version
            License::getProductLatestVersion();
        }

        // Check for support expiry on cache expiration
        if( cache('product_support_expiry') == null ) {
            // Retrieve and Cache Product Support Information
            License::getProductSupportInformation();
        }

        return view('dashboard.admin.about', compact('settings'));
    }

    // Clear App Cache
    public function clearAppCache(){

        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');
        Artisan::call('view:clear');

        Artisan::call('optimize:clear');

        return back()->with('success', __('All cache data has been cleared.'));
    }

    // User Management
    public function users(){
        $users = User::latest()->paginate(10);
        $settings = Setting::first();

        return view('dashboard.admin.users.index', compact('users', 'settings'));
    }

    // All Users Management
    public function listUsers(Request $request){

        $columns = array( 
            0 => 'id', 
            1 => 'avatar',
            2 => 'firstname',
            3 => 'lastname',
            4 => 'email',
            5 => 'email_verified_at',
            6 => 'created_at',
            7 => 'plan_id',
            8 => 'role',
            9 => 'status',
            10 => 'id',
        );
  
        $totalData = User::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {            
            $users = User::offset($start)
                         ->limit($limit)
                         ->orderBy($order,$dir)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $users =  User::where('id','LIKE', "%{$search}%")
                            ->orWhere('firstname', 'LIKE', "%{$search}%")
                            ->orWhere('lastname', 'LIKE', "%{$search}%")
                            ->orWhere('email', 'LIKE', "%{$search}%")
                            ->orWhere('role', 'LIKE', "%{$search}%")
                            ->orWhere('status', 'LIKE', "%{$search}%")
                                ->offset($start)
                                ->limit($limit)
                                ->orderBy($order,$dir)
                                    ->get();

            $totalFiltered = User::where('id','LIKE',"%{$search}%")
                            ->orWhere('firstname', 'LIKE', "%{$search}%")
                            ->orWhere('lastname', 'LIKE', "%{$search}%")
                            ->orWhere('email', 'LIKE', "%{$search}%")
                            ->orWhere('role', 'LIKE', "%{$search}%")
                            ->orWhere('status', 'LIKE', "%{$search}%")
                                ->count();
        }

        $data = array();
        if(!empty($users))
        {
            foreach ($users as $user)
            {
                $show =  route('dashboard.admin.users.index',$user->id);
                $edit =  route('dashboard.admin.users.edit',$user->id);

                // Define status title and badge
                if( $user->status == '1') { 
                    $status_badge = 'class="badge badge-success"';
                    $status_title = __('Active');
                } else { 
                    $status_badge = 'class="badge badge-danger"'; 
                    $status_title = __('Inactive');
                }

                // Define role title and badge
                if( $user->role == 'admin') { 
                    $role_badge = 'class="badge badge-primary"';
                    $role_title = __('Admin');
                } else { 
                    $role_badge = 'class="badge badge-light"'; 
                    $role_title = __('User');
                }

                // Define verified title and badge
                if( $user->email_verified_at == null ) { 
                    $verified_badge = 'class="badge badge-danger"';
                    $verified_title = __('No');
                } else { 
                    $verified_badge = 'class="badge badge-success"'; 
                    $verified_title = __('Yes');
                }

                $avatar = ( $user->avatar_path !=null ? $user->avatar_path : ( $user->avatar !=null ? asset($user->avatar) : null ) ) ?? asset('img/avatar.png');

                $nestedData['id'] = $user->id;
                $nestedData['avatar'] = '<img class="rounded-circle mr-3" width="35" src="'. $avatar .'" alt="avatar">';
                $nestedData['firstname'] = $user->firstname;
                $nestedData['lastname'] = $user->lastname;
                $nestedData['email'] = $user->email;
                $nestedData['email_verified_at'] = '<div '. $verified_badge .'>'. $verified_title .'</div>';
                $nestedData['created_at'] = date(config('settings.date_format'), strtotime($user->created_at));
                $nestedData['plan_id'] = '<a href="'. url('dashboard/admin/plans/item') .'/'. $user->plan_id .'" class="badge badge-light text-truncate">'. getUserPlan($user->plan_id) .'</a>';
                $nestedData['role'] = '<div '. $role_badge .'>'. $role_title .'</div>';
                $nestedData['status'] = '<div '. $status_badge .'>'. $status_title .'</div>';
                $nestedData['options'] = '<div style="white-space:nowrap;">
                                            <a href="'. route('dashboard.admin.users.edit', $user->id) .'" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                            <a type="button" class="btn btn-danger delete-confirm-user" data-user-id="'. $user->id .'"><i class="fa-solid fa-trash-alt"></i></a>
                                            </div>';
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
    }

    public function userEdit($id){
        $user = User::whereId($id)->firstOrFail();
        $settings = Setting::first();

        // User Resumes
        $resumes = Resume::join('users', 'users.id', '=', 'resumes.user_id')
                        ->where('resumes.user_id', '=', $user->id)
                            ->select('resumes.id as r_id', 'resumes.*', 'users.*')
                                ->orderBy('resumes.created_at', 'desc')->take(6)->get();
        // User Resume Counts
        $resume_counts = Resume::where('resumes.user_id', '=', $user->id)->count();

        // User Cover Letter Counts
        $cover_letter_counts = CoverLetter::where('cover_letters.user_id', '=', $user->id)->count();

        return view('dashboard.admin.users.edit', compact('user', 'settings', 'resumes', 'resume_counts', 'cover_letter_counts'));
    }

    public function userSave(Request $request){
        $users = User::all();

        $user = User::whereId($request->user_id)->firstOrFail();

        $request->validate([
            'firstname'     => ['required', 'string', 'max:20'],
            'lastname'      => ['required', 'string', 'max:35'],
            'email'         => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users')->ignore($user->id),
            ],
            'role'          => [
                'required', 
                'string',
                Rule::in(['user','admin']),
            ],
            'phone'         => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'street'        => ['sometimes', 'nullable', 'string', 'max:255'],
            'city'          => ['sometimes', 'nullable', 'string', 'max:100'],
            'state'         => ['sometimes', 'nullable', 'string', 'max:100'],
            'postal'        => ['sometimes', 'nullable', 'string', 'max:10'],
            'country'       => ['sometimes', 'nullable', 'string', 'max:255'],
            'occupation'    => ['sometimes', 'nullable', 'string', 'max:60'],
            'yoe'           => ['sometimes', 'nullable', 'integer', 'min:0'],
            'bio'           => ['sometimes', 'nullable', 'string', 'max:1000'],
            'timezone'      => ['required'],
            'plan_id'       => ['sometimes'],
            'plan_ends_at'  => ['bail', 'sometimes', 'nullable', 'date', 'date_format:Y-m-d'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' => __('The Last Name field is required.')
        ]);

        $user->status = $request->status ? '1' : '0';

        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->email = $request->email;
        $user->phone = $request->phone;

        // Update the user role, except for main admin user
        $user->role = $user->id == '1' ? 'admin' : $request->role;

        $user->address = [
            'street' => $request->street, 
            'city' => $request->city, 
            'state' => $request->state,
            'postal' => $request->postal, 
            'country' => $request->country,
        ];

        $user->occupation = $request->occupation;
        $user->yoe = $request->yoe;
        $user->bio = $request->bio;

        $user->timezone = $request->timezone;

        // Update the plan
        if ($request->plan_id) {

            $actual_plan_ends_at = null;

            // Check whether the plan is not the default one and the plan ends at field is set
            if ($request->plan_ends_at && $request->plan_id != 1) {
                $actual_plan_ends_at = Carbon::createFromFormat('Y-m-d', $request->plan_ends_at, $user->timezone ?? config('app.timezone'))->tz(config('app.timezone'));
            }

            // Check whether the plan has changed, the plan end date is indefinite or the plan has an end date
            if ($user->plan_id != $request->plan_id || ($user->plan_ends_at == null && $user->plan_ends_at != $actual_plan_ends_at) || ($user->plan_ends_at && $actual_plan_ends_at && !$user->plan_ends_at->isSameDay($actual_plan_ends_at))) {
                // Check whether the user previously had a subscription and attempt to cancel it
                if ($user->plan_subscription_id) {
                    $user->planSubscriptionCancel();
                }

                $user->plan_id = $request->plan_id;
                $user->plan_interval = null;
                $user->plan_currency = null;
                $user->plan_amount = null;
                $user->plan_payment_processor = null;
                $user->plan_subscription_id = null;
                $user->plan_subscription_status = null;
                $user->plan_created_at = Carbon::now();
                $user->plan_recurring_at = null;
                $user->plan_trial_ends_at = $user->plan_trial_ends_at ? Carbon::now() : null;
                $user->plan_ends_at = $actual_plan_ends_at;
            }
        }

        $user->save();

       return back()->with(['message' => __('User Saved Succesfully.'), 'type' => 'success']);
    }

    public function userDelete($id){
        // Delete user id with exception to first user
        $user = User::where('id', $id)->whereNotIn('id', [1])->first();

        // Delete user's resumes, cover letters, activity and payments.
        $resume = Resume::where('user_id', $id)->whereNotIn('user_id', [1]);
        $coverLetter = CoverLetter::where('user_id', $id)->whereNotIn('user_id', [1]);
        $activity = Activity::where('user_id', $id)->whereNotIn('user_id', [1]);
        $payment = Payment::where('user_id', $id)->whereNotIn('user_id', [1]);

        if($user !=null) {

            // Check whether the user previously had a subscription and attempt to cancel it
            if ($user->plan_subscription_id) {
                $user->planSubscriptionCancel();
            }

            // Delete user account
            $user->delete();

            // Delete user's resumes, cover letters, activity and payments.
            $resume->delete();
            $coverLetter->delete();
            $activity->delete();
            $payment->delete();
        }

        return response()->json(["success" => __('User Deleted Succesfully.')], 200);

        return back()->with(['message' => __('User Deleted Succesfully.'), 'type' => 'success']);
    }
}
