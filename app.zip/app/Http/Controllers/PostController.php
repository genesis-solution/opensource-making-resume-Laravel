<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\Category;
use App\Models\Post;
use App\Models\FrontendFooter;
use App\Models\Activity;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    // Post
    public function index(){
        $items = Post::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.posts.index', compact('items', 'settings'));
    }

    // All Posts
    public function listPosts(Request $request){

        $columns = array( 
            0  => 'p_id', 
            1  => 'p_title',
            2  => 'category_id',
            3  => 'views',
            4  => 'date',
            5  => 'p_status',
            6  => 'p_id',
        );
  
        $totalData = Post::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {            
            $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                    ->offset($start)
                                        ->limit($limit)
                                            ->orderBy($order, $dir)
                                                ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $posts =  Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                    ->where('posts.title', 'LIKE', "%{$search}%")
                                    ->orWhere('categories.title', 'LIKE', "%{$search}%")
                                    ->offset($start)
                                        ->limit($limit)
                                            ->orderBy($order,$dir)
                                                ->get();

            $totalFiltered = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                                ->join('authors', 'authors.id', '=', 'posts.author_id')
                                    ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                            ->where('posts.title', 'LIKE', "%{$search}%")
                                            ->orWhere('categories.title', 'LIKE', "%{$search}%")
                                                ->count();
        }

        $data = array();
        if(!empty($posts))
        {
            foreach ($posts as $post)
            {
                $show =  route('dashboard.admin.frontend.posts.index', $post->p_id);
                $edit =  route('dashboard.admin.frontend.posts.item', $post->p_id);

                // Define status title and badge
                if( $post->p_status == '1') { 
                    $status_badge = 'class="badge badge-success"';
                    $status_title = __('Published');
                } else { 
                    $status_badge = 'class="badge badge-danger"'; 
                    $status_title = __('Draft');
                }

                $nestedData['p_id'] = $post->p_id;
                $nestedData['p_title'] = $post->p_title;
                $nestedData['category_id'] = '<div class="badge badge-light text-truncate">'. $post->c_title .'</div>';
                $nestedData['views'] = '<div class="badge badge-light">'. $post->views .'</div>';
                $nestedData['date'] = date(config('settings.date_format'), strtotime($post->p_created_at));
                $nestedData['p_status'] = '<div '. $status_badge .'>'. $status_title .'</div>';
                $nestedData['options'] = '<div style="white-space:nowrap;">
                                            <a href="'. route('dashboard.admin.frontend.posts.item', $post->p_id) .'" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                            <a type="button" class="btn btn-danger delete-confirm-post" data-post-id="'. $post->p_id .'"><i class="fa-solid fa-trash-alt"></i></a>
                                            </div>';
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
    }

    // Blog
    public function blog(){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('posts.status', '=', '1')
                                    ->where('categories.status', '=', '1')
                                        ->where('authors.status', '=', '1')
                                            ->orderBy('p_updated_at', 'DESC')
                                                ->paginate(10);

        $categories = Category::join('posts', 'posts.category_id', '=', 'categories.id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('categories.title as c_title', 'categories.slug as c_slug')
                                ->where('categories.status', '=', '1')
                                    ->where('posts.status', '=', '1')
                                        ->where('authors.status', '=', '1')
                                            ->orderBy('categories.blog_order', 'ASC')
                                                ->groupBy('categories.id', 'categories.title', 'categories.slug')
                                                    ->withCount(['posts'])
                                                        ->get();

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        if( config('settings.blog') == 0 ) {
            abort(404);
        }

        return view('blog', compact('frontend', 'settings', 'navs', 'categories', 'posts', 'footer'));
    }

    // Blog Post by Category
    public function blogPostByCategory($slug = null){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('categories.slug', $slug)
                                    ->where('posts.status', '=', '1')
                                        ->where('categories.status', '=', '1')
                                            ->where('authors.status', '=', '1')
                                                ->orderBy('p_updated_at', 'DESC')
                                                    ->paginate(10);

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        if( config('settings.blog') == 0 ) {
            abort(404);
        }

        return view('blog', compact('frontend', 'settings', 'navs', 'posts', 'footer'));
    }

    // Blog Post by Author
    public function blogPostByAuthor($slug = null){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('authors.slug', $slug)
                                    ->where('posts.status', '=', '1')
                                        ->where('categories.status', '=', '1')
                                            ->where('authors.status', '=', '1')
                                                ->orderBy('p_updated_at', 'DESC')
                                                    ->paginate(10);

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        if( config('settings.blog') == 0 ) {
            abort(404);
        }

        return view('blog', compact('frontend', 'settings', 'navs', 'posts', 'footer'));
    }

    // Blog Post by Tag
    public function blogPostByTag($slug = null){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('posts.tags', 'like', '%'.$slug.'%')
                                    ->where('posts.status', '=', '1')
                                        ->where('categories.status', '=', '1')
                                            ->where('authors.status', '=', '1')
                                                ->orderBy('p_updated_at', 'DESC')
                                                    ->paginate(10);

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        if( config('settings.blog') == 0 ) {
            abort(404);
        }

        return view('blog', compact('frontend', 'settings', 'navs', 'posts', 'footer'));
    }

    // Blog Post
    public function blogPost($slug = null){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        $latest_posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('posts.status', '=', '1')
                                    ->where('categories.status', '=', '1')
                                        ->where('authors.status', '=', '1')
                                            ->orderBy('p_updated_at', 'DESC')
                                                ->take(3)->get();

        $post = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                ->where('posts.slug', $slug)
                                    ->where('posts.status', '=', '1')
                                        ->where('categories.status', '=', '1')
                                            ->where('authors.status', '=', '1')
                                                ->first();

        if ($post) {
            // Check post status
            if ( !$post->status ) {
                abort(404);
            } else {

                // Increase the post view based on provided post slug
                Post::where('posts.slug', $slug)->update(['views' => DB::raw('views + 1')]);

                return view('posts', compact('frontend', 'settings', 'navs', 'post', 'latest_posts', 'footer'));
            }

        } else {
            abort(404);
        }
    }

    public function blogPostSearch(Request $request){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order

        $q = $request->input('q');

        $posts = Post::query()
                    ->join('categories', 'categories.id', '=', 'posts.category_id')
                        ->join('authors', 'authors.id', '=', 'posts.author_id')
                            ->select('posts.id as p_id', 'categories.id as c_id', 'authors.id as a_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'authors.slug as a_slug', 'posts.status as p_status', 'categories.status as c_status', 'authors.status as a_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'authors.created_at as a_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'authors.updated_at as a_updated_at', 'posts.image as p_image', 'authors.image as a_image', 'posts.image_path as p_image_path', 'authors.image_path as a_image_path', 'posts.*', 'categories.*', 'authors.*')
                                    ->where('posts.status', '=', '1')
                                        ->where('categories.status', '=', '1')
                                            ->where('authors.status', '=', '1')
                                                ->where(function ($query) use ($q) {
                                                    $query->where('posts.title', 'like', "%$q%")
                                                        ->orWhere('posts.content', 'like', "%$q%");
                                                    })
                                                    ->paginate(10);

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        if( config('settings.blog') == 0 ) {
            abort(404);
        }

        return view('blog', compact('frontend', 'settings', 'navs', 'posts', 'footer'));
    }

    public function postCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Post::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.posts.edit', compact('item', 'settings'));
    }

    public function postCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Post::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Post();
        }

        $requiredPostRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'title' => [$requiredPostRule, 'string', 'max:255'],
            'slug' => [$requiredPostRule, 'string', 'max:255'],
            'category_id' => [$requiredPostRule, 'integer'],
            'author_id' => [$requiredPostRule, 'integer'],
            'description' => [$requiredPostRule, 'string', 'max:500'],
            'keywords' => [$requiredPostRule, 'string'],
            'content' => [$requiredPostRule, 'string'],
            'tags' => ['sometimes', 'nullable', 'string'],
        ],[
            'title.required' =>  __('The Title field is required.'),
            'slug.required' =>  __('The Slug field is required.'),
            'category_id.required' =>  __('The Category field is required.'),
            'author_id.required' =>  __('The Author field is required.'),
            'description.required' =>  __('The Description field is required.'),
            'keywords.required' =>  __('The Keywords field is required.'),
            'content.required' =>  __('The Content field is required.'),
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->title = $request->title;
        $item->slug = Str::slug($request->slug);
        $item->category_id = $request->category_id;
        $item->author_id = $request->author_id;
        $item->description = $request->description;
        $item->keywords = $request->keywords;

        // Check whether content area contain images
        $content = $request->content;

        // Check whether there is content
        if ( $content!=null ) {

            // converts all special characters to utf-8
            $content = mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8');

            // creating new document
            $dom = new \DOMDocument('1.0', 'utf-8');
            $dom->loadHtml($content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NOERROR);

            $image_file = $dom->getElementsByTagName('img');

            try {

                if(isset($image_file) && $image_file!=null) {

                    foreach($image_file as $key => $image) {
                        $data = $image->getAttribute('src');

                        if (strpos($data, 'base64') !== false) {

                            list($type, $data) = explode(';', $data);
                            list(, $data) = explode(',', $data);

                            // Check whether the string entered match base64_decode and is image
                            if ( base64_encode(base64_decode($data, true)) === $data && imagecreatefromstring(base64_decode($data)) && validateBase64Image(base64_decode($data)) ) {

                                $img_data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $data));

                                $image_name = 'post-'. time() .'.png';

                                $image_dir = 'uploads/';

                                $image_path = config('settings.site_url') .'/'. $image_dir . $image_name;

                                // Remove any existing stored image
                                if(config('settings.storage_method') == 's3') { // AWS S3 Storage

                                    $aws_image_path = $image_dir . $image_name;

                                    // Remove any existing s3 stored image
                                    if( Storage::disk('s3')->exists($image_dir . $image_name) ) {
                                        Storage::disk('s3')->delete($image_dir . $image_name);
                                    }
                             
                                    Storage::disk('s3')->put($aws_image_path, $img_data);
                                    $image_path = Storage::disk('s3')->url($aws_image_path);
                                    
                                } else { // Local Storage

                                    // Remove any existing local stored image
                                    if( File::exists($image_dir . $image_name) ) {
                                        unlink($image_dir . $image_name);
                                    }

                                    file_put_contents($image_dir . $image_name, $img_data);
                                }

                                $image->removeAttribute('src');
                                $image->setAttribute('src', $image_path);
                            } else {
                                // Remove base64 string if is not image
                                $image->parentNode->removeChild($image);
                            }
                        }
                    }

                    $content = $dom->saveHTML();

                    $content = html_entity_decode($content, ENT_COMPAT, 'UTF-8');
                }

            } catch (\Exception $e) {
                //return back()->with('error', $e->getMessage());
            }
        }

        // Blog Post Content
        $item->content = $content;

        // Upload Main Post Image 
        if ($request->hasFile('image')) {

            $imageRequestValidator = Validator::make($request->all(), [
                'image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','dimensions:min_width=650,min_height=425','max:1024']
            ]);

            if($imageRequestValidator->fails()) 
                return response()->json(['errors' => ['message' => $imageRequestValidator->errors()->first()]], 419 );

            $image = $request->file('image');
            $image_name = 'blog-'. time() .'.'. $image->getClientOriginalExtension();

            $image_dir = 'uploads/';

            $image_path = config('settings.site_url') .'/'. $image_dir . $image_name;

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return response()->json(['errors' => ['message' => __('The file extension must be jpg, jpeg, png, gif, webp or svg.')]], 419 );
            }

            // Remove any existing stored image
            if(config('settings.storage_method') == 's3') { // AWS S3 Storage

                $aws_image_path = $image_dir . $image_name;

                // Remove any existing s3 stored image
                if($item->image != '' && Storage::disk('s3')->exists($image_dir . $item->image) ) {
                    Storage::disk('s3')->delete($image_dir . $item->image);
                }
         
                Storage::disk('s3')->put($aws_image_path, file_get_contents($image));
                $image_path = Storage::disk('s3')->url($aws_image_path);
                
            } else { // Local Storage

                // Remove any existing local stored image
                if( $item->image != '' && File::exists($image_dir . $item->image) ) {
                    unlink($image_dir . $item->image);
                }
                
                $image->move($image_dir, $image_name);
            }


            if( !empty($image_dir) && !empty($image_name) ) {

                $item->image = $image_name;
                $item->image_path = $image_path;
            }
        }

        // Blog Post Tags
        $item->tags = $request->tags;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Post Section'), null);

        return back()->with(['message' => __('Post Saved Succesfully.'), 'type' => 'success']);
    }

    public function postDelete($id){
        $item = Post::where('id', $id)->firstOrFail();
        $item->delete();

        return response()->json(["success" => __('Post Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Post Deleted Succesfully.'), 'type' => 'success']);
    }
}
