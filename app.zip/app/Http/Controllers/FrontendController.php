<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendStat;
use App\Models\FrontendFeature;
use App\Models\FrontendStep;
use App\Models\FrontendResource;
use App\Models\FrontendFooter;
use App\Models\Category;
use App\Models\Post;
use App\Models\Template;
use App\Models\Activity;
use App\Models\Plan;
use App\Models\User;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class FrontendController extends Controller
{
    public function index(){
        $frontend = Frontend::first(); 
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        $stats = FrontendStat::all()->sortBy('order'); // Ascending Order
        $features = FrontendFeature::all()->sortBy('order'); // Ascending Order
        $steps = FrontendStep::all()->sortBy('order'); // Ascending Order
        $resources = FrontendResource::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        $templates = Template::all()->sortBy('order'); // Ascending Order

        $plans = Plan::all();

        $posts = Post::join('categories', 'categories.id', '=', 'posts.category_id')
                    ->select('posts.id as p_id', 'categories.id as c_id', 'posts.title as p_title', 'categories.title as c_title', 'posts.slug as p_slug', 'categories.slug as c_slug', 'posts.status as p_status', 'categories.status as c_status', 'posts.created_at as p_created_at', 'categories.created_at as c_created_at', 'posts.updated_at as p_updated_at', 'categories.updated_at as c_updated_at', 'posts.*', 'categories.*')
                        ->where('posts.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('p_created_at', 'DESC')
                                    ->take(3)->get();

        $categories = Category::join('posts', 'posts.category_id', '=', 'categories.id')
                        ->select('categories.title as c_title', 'categories.slug as c_slug')
                            ->where('categories.status', '=', '1')
                                ->where('posts.status', '=', '1')
                                    ->orderBy('categories.updated_at', 'ASC')
                                    ->groupBy('categories.id', 'categories.title', 'categories.slug')
                                        ->withCount(['posts'])
                                            ->get();

        return view('newfrontend.index', compact('frontend', 'settings', 'plans', 'templates', 'navs', 'stats', 'features', 'steps', 'resources', 'categories', 'posts', 'footer'));

    }

    public function frontendSettings(){
        $frontend = Frontend::first();
        $settings = Setting::first();

        return view('dashboard.admin.frontend.index', compact('frontend', 'settings'));
    }

    public function saveFrontendSettings(Request $request){

        $user = Auth::user();
        $frontend = Frontend::first();

        $requiredFrontendHeroRule = $request->frontend_hero != '' ? 'required' : 'nullable';
        $requiredFrontendStatsRule = $request->frontend_stats != '' ? 'required' : 'nullable';
        $requiredFrontendFeaturesRule = $request->frontend_features != '' ? 'required' : 'nullable';
        $requiredFrontendDeclareRule = $request->frontend_declare != '' ? 'required' : 'nullable';
        $requiredFrontendPricingRule = $request->frontend_pricing != '' ? 'required' : 'nullable';
        $requiredFrontendAppealRule = $request->frontend_appeal != '' ? 'required' : 'nullable';
        $requiredFrontendTryoutRule = $request->frontend_tryout != '' ? 'required' : 'nullable';
        $requiredFrontendStepsRule = $request->frontend_steps != '' ? 'required' : 'nullable';
        $requiredFrontendCarryoutRule = $request->frontend_carryout != '' ? 'required' : 'nullable';
        $requiredFrontendTemplatesRule = $request->frontend_templates != '' ? 'required' : 'nullable';
        $requiredFrontendFaqsRule = $request->frontend_faqs != '' ? 'required' : 'nullable';
        $requiredFrontendBlogRule = $request->frontend_blog != '' ? 'required' : 'nullable';
        $requiredFrontendContactRule = $request->frontend_contact != '' ? 'required' : 'nullable';
        $requiredFrontendFooterRule = $request->frontend_footer != '' ? 'required' : 'nullable';

        $request->validate([
            'frontend_hero_byline' => [$requiredFrontendHeroRule, 'string', 'max:255'],
            'frontend_hero_headline' => [$requiredFrontendHeroRule, 'string', 'max:255'],
            'frontend_hero_description' => [$requiredFrontendHeroRule, 'string', 'max:255'],
            'frontend_hero_button' => [$requiredFrontendHeroRule, 'string', 'max:255'],
            'frontend_hero_button_url' => [$requiredFrontendHeroRule, 'string', 'max:255'],
            'frontend_stats_headline' => [$requiredFrontendStatsRule, 'string', 'max:255'],
            'frontend_stats_description' => [$requiredFrontendStatsRule, 'string', 'max:255'],
            'frontend_stats_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_features_headline' => [$requiredFrontendFeaturesRule, 'string', 'max:255'],
            'frontend_features_description' => [$requiredFrontendFeaturesRule, 'string', 'max:255'],
            'frontend_features_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_declare_byline' => [$requiredFrontendDeclareRule, 'string', 'max:255'],
            'frontend_declare_headline' => [$requiredFrontendDeclareRule, 'string', 'max:255'],
            'frontend_declare_description' => [$requiredFrontendDeclareRule, 'string', 'max:255'],
            'frontend_declare_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_declare_link_text' => [$requiredFrontendDeclareRule, 'string', 'max:255'],
            'frontend_declare_link_url' => [$requiredFrontendDeclareRule, 'string', 'max:255'],
            'frontend_pricing_headline' => [$requiredFrontendPricingRule, 'string', 'max:255'],
            'frontend_pricing_description' => [$requiredFrontendPricingRule, 'string', 'max:255'],
            'frontend_pricing_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_appeal_byline' => [$requiredFrontendAppealRule, 'string', 'max:255'],
            'frontend_appeal_headline' => [$requiredFrontendAppealRule, 'string', 'max:255'],
            'frontend_appeal_description' => [$requiredFrontendAppealRule, 'string', 'max:255'],
            'frontend_appeal_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_appeal_link_text' => [$requiredFrontendAppealRule, 'string', 'max:255'],
            'frontend_appeal_link_url' => [$requiredFrontendAppealRule, 'string', 'max:255'],
            'frontend_tryout_headline' => [$requiredFrontendTryoutRule, 'string', 'max:255'],
            'frontend_tryout_description' => [$requiredFrontendTryoutRule, 'string', 'max:255'],
            'frontend_tryout_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_tryout_button' => [$requiredFrontendTryoutRule, 'string', 'max:255'],
            'frontend_tryout_button_url' => [$requiredFrontendTryoutRule, 'string', 'max:255'],
            'frontend_steps_headline' => [$requiredFrontendStepsRule, 'string', 'max:255'],
            'frontend_steps_description' => [$requiredFrontendStepsRule, 'string', 'max:255'],
            'frontend_steps_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_carryout_headline' => [$requiredFrontendCarryoutRule, 'string', 'max:255'],
            'frontend_carryout_description' => [$requiredFrontendCarryoutRule, 'string', 'max:255'],
            'frontend_carryout_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_carryout_button' => [$requiredFrontendCarryoutRule, 'string', 'max:255'],
            'frontend_carryout_button_url' => [$requiredFrontendCarryoutRule, 'string', 'max:255'],
            'frontend_templates_headline' => [$requiredFrontendTemplatesRule, 'string', 'max:255'],
            'frontend_templates_description' => [$requiredFrontendTemplatesRule, 'string', 'max:255'],
            'frontend_templates_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_faqs_headline' => [$requiredFrontendFaqsRule, 'string', 'max:255'],
            'frontend_faqs_description' => [$requiredFrontendFaqsRule, 'string', 'max:255'],
            'frontend_faqs_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_blog_headline' => [$requiredFrontendBlogRule, 'string', 'max:255'],
            'frontend_blog_description' => [$requiredFrontendBlogRule, 'string', 'max:255'],
            'frontend_blog_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_contact_headline' => [$requiredFrontendContactRule, 'string', 'max:255'],
            'frontend_contact_description' => [$requiredFrontendContactRule, 'string', 'max:255'],
            'frontend_contact_highlight_words' => ['nullable', 'regex:/^[\p{L}\p{Mn}\p{Pd}\s,-]+$/ui', 'max:255'],
            'frontend_footer_title' => ['sometimes', 'nullable', 'string', 'max:255'],
            'frontend_footer_description' => ['sometimes', 'nullable', 'string', 'max:255'],
            'frontend_footer_copyright' => ['sometimes', 'nullable', 'string', 'max:255'],
        ],[
            'frontend_hero_byline.required' => __('The Hero Byline field is required.'),
            'frontend_hero_headline.required' => __('The Hero Headline field is required.'),
            'frontend_hero_description.required' => __('The Hero Description field is required.'),
            'frontend_hero_button.required' => __('The Hero Button field is required.'),
            'frontend_hero_button_url.required' => __('The Hero Button Url field is required.'),
            'frontend_stats_headline.required' => __('The Stats Headline field is required.'),
            'frontend_stats_description.required' => __('The Stats Description field is required.'),
            'frontend_features_headline.required' => __('The Features Headline field is required.'),
            'frontend_features_description.required' => __('The Features Description field is required.'),
            'frontend_declare_byline.required' => __('The Declare Byline field is required.'),
            'frontend_declare_headline.required' => __('The Declare Headline field is required.'),
            'frontend_declare_description.required' => __('The Declare Description field is required.'),
            'frontend_declare_link_text.required' => __('The Declare Link field is required.'),
            'frontend_declare_link_url.required' => __('The Declare Link Url field is required.'),
            'frontend_pricing_headline.required' => __('The Pricing Headline field is required.'),
            'frontend_pricing_description.required' => __('The Pricing Description field is required.'),
            'frontend_appeal_byline.required' => __('The Appeal Byline field is required.'),
            'frontend_appeal_headline.required' => __('The Appeal Headline field is required.'),
            'frontend_appeal_description.required' => __('The Appeal Description field is required.'),
            'frontend_appeal_link_text.required' => __('The Appeal Link field is required.'),
            'frontend_appeal_link_url.required' => __('The Appeal Link Url field is required.'),
            'frontend_tryout_headline.required' => __('The Tryout Headline field is required.'),
            'frontend_tryout_description.required' => __('The Tryout Description field is required.'),
            'frontend_tryout_button.required' => __('The Tryout Button field is required.'),
            'frontend_tryout_button_url.required' => __('The Tryout Button Url field is required.'),
            'frontend_steps_headline.required' => __('The Steps Headline field is required.'),
            'frontend_steps_description.required' => __('The Steps Description field is required.'),
            'frontend_carryout_headline.required' => __('The Carryout Headline field is required.'),
            'frontend_carryout_description.required' => __('The Carryout Description field is required.'),
            'frontend_carryout_button.required' => __('The Carryout Button field is required.'),
            'frontend_carryout_button_url.required' => __('The Carryout Button Url field is required.'),
            'frontend_templates_headline.required' => __('The Templates Headline field is required.'),
            'frontend_templates_description.required' => __('The Templates Description field is required.'),
            'frontend_faqs_headline.required' => __('The Faqs Headline field is required.'),
            'frontend_faqs_description.required' => __('The Faqs Description field is required.'),
            'frontend_blog_headline.required' => __('The Blog Headline field is required.'),
            'frontend_blog_description.required' => __('The Blog Description field is required.'),
            'frontend_contact_headline.required' => __('The Contact Headline field is required.'),
            'frontend_contact_description.required' => __('The Contact Description field is required.'),
            'frontend_footer_title.required' => __('The Footer Title field is required.'),
            'frontend_footer_description.required' => __('The Footer Description field is required.'),
            'frontend_footer_copyright.required' => __('The Footer Copyright field is required.')
        ]);

        // Frontend Hero
        $frontend->where('name','frontend_hero')->update(['value' => ( $request->frontend_hero ? '1' : '0' )]);
        $frontend->where('name','frontend_hero_byline')->update(['value' => $request->frontend_hero_byline]);
        $frontend->where('name','frontend_hero_headline')->update(['value' => $request->frontend_hero_headline]);
        $frontend->where('name','frontend_hero_description')->update(['value' => $request->frontend_hero_description]);

        // Upload Hero Image 
        if ($request->hasFile('frontend_hero_image')) {

            $request->validate([
                'frontend_hero_image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $image = $request->file('frontend_hero_image');
            $image_name = 'frontend-hero-'. time() .'.'. $image->getClientOriginalExtension();

            $image_path = 'uploads/';

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored image
            if( config('frontends.frontend_hero_image') != '' && File::exists($image_path . config('frontends.frontend_hero_image')) ) {
                unlink($image_path . config('frontends.frontend_hero_image'));
            }
            
            $image->move($image_path, $image_name);

            if( !empty($image_path) && !empty($image_name) ) {

                $frontend->where('name','frontend_hero_image')->update(['value' => ( $image_path . $image_name )]);
            }
        }

        $frontend->where('name','frontend_hero_button')->update(['value' => $request->frontend_hero_button]);
        $frontend->where('name','frontend_hero_button_url')->update(['value' => $request->frontend_hero_button_url]);

        // Frontend Stats
        $frontend->where('name','frontend_stats')->update(['value' => ( $request->frontend_stats ? '1' : '0' )]);
        $frontend->where('name','frontend_stats_headline')->update(['value' => $request->frontend_stats_headline]);
        $frontend->where('name','frontend_stats_description')->update(['value' => $request->frontend_stats_description]);
        $frontend->where('name','frontend_stats_highlight_words')->update(['value' => $request->frontend_stats_highlight_words]);

        // Frontend Features Section
        $frontend->where('name','frontend_features')->update(['value' => ( $request->frontend_features ? '1' : '0' )]);
        $frontend->where('name','frontend_features_headline')->update(['value' => $request->frontend_features_headline]);
        $frontend->where('name','frontend_features_description')->update(['value' => $request->frontend_features_description]);
        $frontend->where('name','frontend_features_highlight_words')->update(['value' => $request->frontend_features_highlight_words]);

        // Frontend Declare Section
        $frontend->where('name','frontend_declare')->update(['value' => ( $request->frontend_declare ? '1' : '0' )]);
        $frontend->where('name','frontend_declare_byline')->update(['value' => $request->frontend_declare_byline]);
        $frontend->where('name','frontend_declare_headline')->update(['value' => $request->frontend_declare_headline]);
        $frontend->where('name','frontend_declare_description')->update(['value' => $request->frontend_declare_description]);
        $frontend->where('name','frontend_declare_highlight_words')->update(['value' => $request->frontend_declare_highlight_words]);

        // Upload Declare Image 
        if ($request->hasFile('frontend_declare_image')) {

            $request->validate([
                'frontend_declare_image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $image = $request->file('frontend_declare_image');
            $image_name = 'frontend-declare-'. time() .'.'. $image->getClientOriginalExtension();

            $image_path = 'uploads/';

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored image
            if( config('frontends.frontend_declare_image') != '' && File::exists(config('frontends.frontend_declare_image')) ) {
                unlink(config('frontends.frontend_declare_image'));
            }
            
            $image->move($image_path, $image_name);

            if( !empty($image_path) && !empty($image_name) ) {

                $frontend->where('name','frontend_declare_image')->update(['value' => ( $image_path . $image_name )]);
            }
        }

        $frontend->where('name','frontend_declare_link_text')->update(['value' => $request->frontend_declare_link_text]);
        $frontend->where('name','frontend_declare_link_url')->update(['value' => $request->frontend_declare_link_url]);

        // Frontend Pricing Section
        $frontend->where('name','frontend_pricing')->update(['value' => ( $request->frontend_pricing ? '1' : '0' )]);
        $frontend->where('name','frontend_pricing_headline')->update(['value' => $request->frontend_pricing_headline]);
        $frontend->where('name','frontend_pricing_description')->update(['value' => $request->frontend_pricing_description]);
        $frontend->where('name','frontend_pricing_highlight_words')->update(['value' => $request->frontend_pricing_highlight_words]);

        // Frontend Appeal Section
        $frontend->where('name','frontend_appeal')->update(['value' => ( $request->frontend_appeal ? '1' : '0' )]);
        $frontend->where('name','frontend_appeal_byline')->update(['value' => $request->frontend_appeal_byline]);
        $frontend->where('name','frontend_appeal_headline')->update(['value' => $request->frontend_appeal_headline]);
        $frontend->where('name','frontend_appeal_description')->update(['value' => $request->frontend_appeal_description]);
        $frontend->where('name','frontend_appeal_highlight_words')->update(['value' => $request->frontend_appeal_highlight_words]);
        
        // Upload Declare Image 
        if ($request->hasFile('frontend_appeal_image')) {

            $request->validate([
                'frontend_appeal_image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $image = $request->file('frontend_appeal_image');
            $image_name = 'frontend-appeal-'. time() .'.'. $image->getClientOriginalExtension();

            $image_path = 'uploads/';

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored image
            if( config('frontends.frontend_appeal_image') != '' && File::exists(config('frontends.frontend_appeal_image')) ) {
                unlink(config('frontends.frontend_appeal_image'));
            }
            
            $image->move($image_path, $image_name);

            if( !empty($image_path) && !empty($image_name) ) {

                $frontend->where('name','frontend_appeal_image')->update(['value' => ( $image_path . $image_name )]);
            }
        }

        $frontend->where('name','frontend_appeal_link_text')->update(['value' => $request->frontend_appeal_link_text]);
        $frontend->where('name','frontend_appeal_link_url')->update(['value' => $request->frontend_appeal_link_url]);

        // Frontend Tryout Section
        $frontend->where('name','frontend_tryout')->update(['value' => ( $request->frontend_tryout ? '1' : '0' )]);
        $frontend->where('name','frontend_tryout_headline')->update(['value' => $request->frontend_tryout_headline]);
        $frontend->where('name','frontend_tryout_description')->update(['value' => $request->frontend_tryout_description]);
        $frontend->where('name','frontend_tryout_highlight_words')->update(['value' => $request->frontend_tryout_highlight_words]);
        $frontend->where('name','frontend_tryout_button')->update(['value' => $request->frontend_tryout_button]);
        $frontend->where('name','frontend_tryout_button_url')->update(['value' => $request->frontend_tryout_button_url]);

        // Frontend Steps Section
        $frontend->where('name','frontend_steps')->update(['value' => ( $request->frontend_steps ? '1' : '0' )]);
        $frontend->where('name','frontend_steps_headline')->update(['value' => $request->frontend_steps_headline]);
        $frontend->where('name','frontend_steps_description')->update(['value' => $request->frontend_steps_description]);
        $frontend->where('name','frontend_steps_highlight_words')->update(['value' => $request->frontend_steps_highlight_words]);
        
        // Upload Steps Image 
        if ($request->hasFile('frontend_steps_image')) {

            $request->validate([
                'frontend_steps_image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $image = $request->file('frontend_steps_image');
            $image_name = 'frontend-steps-'. time() .'.'. $image->getClientOriginalExtension();

            $image_path = 'uploads/';

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored image
            if( config('frontends.frontend_steps_image') != '' && File::exists(config('frontends.frontend_steps_image')) ) {
                unlink(config('frontends.frontend_steps_image'));
            }
            
            $image->move($image_path, $image_name);

            if( !empty($image_path) && !empty($image_name) ) {

                $frontend->where('name','frontend_steps_image')->update(['value' => ( $image_path . $image_name )]);
            }
        }

        // Frontend Carryout Section
        $frontend->where('name','frontend_carryout')->update(['value' => ( $request->frontend_carryout ? '1' : '0' )]);
        $frontend->where('name','frontend_carryout_headline')->update(['value' => $request->frontend_carryout_headline]);
        $frontend->where('name','frontend_carryout_description')->update(['value' => $request->frontend_carryout_description]);
        $frontend->where('name','frontend_carryout_highlight_words')->update(['value' => $request->frontend_carryout_highlight_words]);
        $frontend->where('name','frontend_carryout_button')->update(['value' => $request->frontend_carryout_button]);
        $frontend->where('name','frontend_carryout_button_url')->update(['value' => $request->frontend_carryout_button_url]);

        // Frontend Templates Section
        $frontend->where('name','frontend_templates')->update(['value' => ( $request->frontend_templates ? '1' : '0' )]);
        $frontend->where('name','frontend_templates_headline')->update(['value' => $request->frontend_templates_headline]);
        $frontend->where('name','frontend_templates_description')->update(['value' => $request->frontend_templates_description]);
        $frontend->where('name','frontend_templates_highlight_words')->update(['value' => $request->frontend_templates_highlight_words]);

        // Frontend Resources Section
        $frontend->where('name','frontend_resources')->update(['value' => ( $request->frontend_resources ? '1' : '0' )]);

        // Frontend Faqs Section
        $frontend->where('name','frontend_faqs')->update(['value' => ( $request->frontend_faqs ? '1' : '0' )]);
        $frontend->where('name','frontend_faqs_headline')->update(['value' => $request->frontend_faqs_headline]);
        $frontend->where('name','frontend_faqs_description')->update(['value' => $request->frontend_faqs_description]);
        $frontend->where('name','frontend_faqs_highlight_words')->update(['value' => $request->frontend_faqs_highlight_words]);

        // Frontend Blog Section
        $frontend->where('name','frontend_blog')->update(['value' => ( $request->frontend_blog ? '1' : '0' )]);
        $frontend->where('name','frontend_blog_headline')->update(['value' => $request->frontend_blog_headline]);
        $frontend->where('name','frontend_blog_description')->update(['value' => $request->frontend_blog_description]);
        $frontend->where('name','frontend_blog_highlight_words')->update(['value' => $request->frontend_blog_highlight_words]);

        // Frontend Contact Section
        $frontend->where('name','frontend_contact')->update(['value' => ( $request->frontend_contact ? '1' : '0' )]);
        $frontend->where('name','frontend_contact_headline')->update(['value' => $request->frontend_contact_headline]);
        $frontend->where('name','frontend_contact_description')->update(['value' => $request->frontend_contact_description]);
        $frontend->where('name','frontend_contact_highlight_words')->update(['value' => $request->frontend_contact_highlight_words]);

        // Frontend Footer Section
        $frontend->where('name','frontend_footer')->update(['value' => ( $request->frontend_footer ? '1' : '0' )]);
        $frontend->where('name','frontend_footer_title')->update(['value' => $request->frontend_footer_title]);
        $frontend->where('name','frontend_footer_description')->update(['value' => $request->frontend_footer_description]);
        $frontend->where('name','frontend_footer_copyright')->update(['value' => $request->frontend_footer_copyright]);

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Settings'), null);

        return back()->with('success', __('Frontend Settings Saved.'));
    }

    // Frontend Navs Section
    public function frontendNavs(){
        $items = FrontendNav::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.navs.index', compact('items', 'settings'));
    }


    public function frontendNavCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendNav::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.navs.edit', compact('item', 'settings'));
    }

    public function frontendNavCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendNav::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendNav();
        }

        $requiredNavRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredNavRule, 'integer'],
            'title' => [$requiredNavRule, 'string', 'max:255'],
            'url' => [$requiredNavRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'title.required' => __('The Title field is required.'),
            'url.required' => __('The Url field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->title = $request->title;
        $item->url = $request->url;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Navigation Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendNavDelete($id){
        $item = FrontendNav::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

    // Frontend Stats Section
    public function frontendStats(){
        $items = FrontendStat::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.stats.index', compact('items', 'settings'));
    }


    public function frontendStatCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendStat::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.stats.edit', compact('item', 'settings'));
    }

    public function frontendStatCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendStat::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendStat();
        }

        $requiredStatRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredStatRule, 'integer'],
            'title' => [$requiredStatRule, 'string', 'max:255'],
            'description' => [$requiredStatRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'title.required' => __('The Title field is required.'),
            'description.required' => __('The Description field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->title = $request->title;
        $item->description = $request->description;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Stats Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendStatDelete($id){
        $item = FrontendStat::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

    // Frontend Features Section
    public function frontendFeatures(){
        $items = FrontendFeature::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.features.index', compact('items', 'settings'));
    }


    public function frontendFeatureCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendFeature::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.features.edit', compact('item', 'settings'));
    }

    public function frontendFeatureCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendFeature::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendFeature();
        }

        $requiredFeatureRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredFeatureRule, 'integer'],
            'icon' => [$requiredFeatureRule, 'string', 'max:255'],
            'title' => [$requiredFeatureRule, 'string', 'max:255'],
            'description' => [$requiredFeatureRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'icon.required' => __('The Icon field is required.'),
            'title.required' => __('The Title field is required.'),
            'description.required' => __('The Description field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->icon = $request->icon;
        $item->title = $request->title;
        $item->description = $request->description;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Features Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendFeatureDelete($id){
        $item = FrontendFeature::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

    // Frontend Steps Section
    public function frontendSteps(){
        $items = FrontendStep::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.steps.index', compact('items', 'settings'));
    }


    public function frontendStepCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendStep::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.steps.edit', compact('item', 'settings'));
    }

    public function frontendStepCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendStep::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendStep();
        }

        $requiredStepRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredStepRule, 'integer'],
            'icon' => [$requiredStepRule, 'string', 'max:255'],
            'title' => [$requiredStepRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'icon.required' => __('The Icon field is required.'),
            'title.required' => __('The Title field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->icon = $request->icon;
        $item->title = $request->title;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Steps Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendStepDelete($id){
        $item = FrontendStep::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

    // Frontend Resources Section
    public function frontendResources(){
        $items = FrontendResource::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.resources.index', compact('items', 'settings'));
    }


    public function frontendResourceCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendResource::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.resources.edit', compact('item', 'settings'));
    }

    public function frontendResourceCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendResource::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendResource();
        }

        $requiredResourceRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredResourceRule, 'integer'],
            'icon' => [$requiredResourceRule, 'string', 'max:255'],
            'title' => [$requiredResourceRule, 'string', 'max:255'],
            'description' => [$requiredResourceRule, 'string', 'max:255'],
            'link_title' => [$requiredResourceRule, 'string', 'max:255'],
            'link_url' => [$requiredResourceRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'icon.required' => __('The Icon field is required.'),
            'title.required' => __('The Title field is required.'),
            'description.required' => __('The Description field is required.'),
            'link_title.required' => __('The Link Title field is required.'),
            'link_url.required' => __('The Link Url field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->icon = $request->icon;
        $item->title = $request->title;
        $item->description = $request->description;
        $item->link_title = $request->link_title;
        $item->link_url = $request->link_url;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Resources Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendResourceDelete($id){
        $item = FrontendResource::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

    // Frontend Footer Section
    public function frontendFooter(){
        $items = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                        ->select('categories.id as c_id', 'frontend_footers.id as f_id', 'categories.title as c_title', 'frontend_footers.title as f_title', 'categories.status as c_status', 'frontend_footers.status as f_status', 'frontend_footers.created_at as f_created_at', 'frontend_footers.updated_at as f_updated_at', 'frontend_footers.*')
                            ->orderBy('f_updated_at', 'DESC')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.footer.index', compact('items', 'settings'));
    }


    public function frontendFooterCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = FrontendFooter::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.footer.edit', compact('item', 'settings'));
    }

    public function frontendFooterCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = FrontendFooter::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new FrontendFooter();
        }

        $requiredFooterRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'order' => [$requiredFooterRule, 'integer'],
            'category_id' => [$requiredFooterRule, 'integer'],
            'title' => [$requiredFooterRule, 'string', 'max:255'],
            'url' => [$requiredFooterRule, 'string', 'max:255'],
        ],[
            'order.required' => __('The Order field is required.'),
            'category_id.required' => __('The Category field is required.'),
            'title.required' => __('The Title field is required.'),
            'url.required' => __('The Url field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->order = $request->order;
        $item->category_id = $request->category_id;
        $item->title = $request->title;
        $item->url = $request->url;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Frontend Footer'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function frontendFooterDelete($id){
        $item = FrontendFooter::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }

}
