<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Author;
use App\Models\Activity;
use App\Models\Setting;
use App\Traits\OpenAITrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;

class AuthorController extends Controller
{
    use OpenAITrait;
    
    // Author
    public function index(){
        $items = Author::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.authors.index', compact('items', 'settings'));
    }

    public function generateAIAuthorBio(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {
                if($request->occupation!=null) {
                    if($request->yoe!=null) {
                        $prompt = config('settings.openai_user_bio_prompt');

                        // Replace prompt theme variables
                        $prompt = str_replace(':occupation', $request->occupation, $prompt);
                        $prompt = str_replace(':yoe', $request->yoe, $prompt);
                        $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                        $response = $this->openAICompletions($request, $prompt);

                        // Check whether the response is returned empty
                        if( $response != null ) {
                            $content = $response['choices'][0]['message']['content'] ?? null;

                            if( $content != null ) {
                                // Increment the AI user usage count
                                $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                $user->save();

                                return response()->json(['success' => ['content' => $content]], 200 );
                                
                            } else {
                                return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                            }
                            
                        } else {
                            return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                        } 
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your years of experience.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your occupation title.')]], 419 );
                }
            } else {
                 return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    public function authorCreateUpdate($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        // User AI-Generated Content
        $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];
        $aiGeneratedContentDescription = $user->canCreateNewAIGeneratedContent()['description'];

        if ($id == null){
            $item = null;
        } else {
            $item = Author::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.authors.edit', compact('item', 'settings', 'aiGeneratedContentLeft', 'aiGeneratedContentDescription'));
    }

    public function authorCreateUpdateSave(Request $request){

        $user = Auth::user();
        $settings = Setting::first();

        if ($request->item_id != 'undefined'){
            $item = Author::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Author();
        }

        $requiredAuthorRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'name' => [$requiredAuthorRule, 'string', 'max:70'],
            'slug' => [$requiredAuthorRule, 'string', 'max:100'],
            'occupation' => ['sometimes', 'nullable', 'string', 'max:60'],
            'yoe' => ['sometimes', 'nullable', 'integer', 'min:0'],
            'bio' => ['sometimes', 'nullable', 'string', 'max:1000'],
            'website' => ['sometimes', 'nullable', 'string', 'max:255'],
            'privacy' => [$requiredAuthorRule, 'integer', Rule::in(['0','1'])],
            'facebook' => ['sometimes', 'nullable', 'string', 'max:50'],
            'twitter' => ['sometimes', 'nullable', 'string', 'max:15'],
            'linkedin' => ['sometimes', 'nullable', 'string', 'max:50'],
            'pinterest' => ['sometimes', 'nullable', 'string', 'max:50'],
            'youtube' => ['sometimes', 'nullable', 'string', 'max:30'],
            'github' => ['sometimes', 'nullable', 'string', 'max:39'],
            'behance' => ['sometimes', 'nullable', 'string', 'max:50'],
            'instagram' => ['sometimes', 'nullable', 'string', 'max:30'],
            'tiktok' => ['sometimes', 'nullable', 'string', 'max:39'],
        ],[
            'name.required' =>  __('The Name field is required.'),
            'slug.required' =>  __('The Slug field is required.'),
            'privacy.required' => __('The Privacy field is required.'),
            'privacy.integer' => __('The Privacy field must be an integer.'),
            'privacy.in' => __('The selected Privacy is invalid.'),
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->name = $request->name;
        $item->slug = Str::slug($request->slug);

        $item->occupation = $request->occupation;
        $item->yoe = $request->yoe;

        $item->bio = $request->bio;
        $item->website = $request->website;

        // Privacy
        $item->privacy = $request->privacy;

        // Upload Author Image 
        if ($request->hasFile('image')) {

            $imageRequestValidator = Validator::make($request->all(), [
                'image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            if($imageRequestValidator->fails()) 
                return response()->json(['errors' => ['message' => $imageRequestValidator->errors()->first()]], 419 );

            $image = $request->file('image');
            $image_name = 'author-'. time() .'.'. $image->getClientOriginalExtension();

            $image_dir = 'uploads/';

            $image_path = config('settings.site_url') .'/'. $image_dir . $image_name;

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return response()->json(['errors' => ['message' => __('The file extension must be jpg, jpeg, png, gif, webp or svg.')]], 419 );
            }

            // Remove any existing stored image
            if(config('settings.storage_method') == 's3') { // AWS S3 Storage

                $aws_image_path = $image_dir . $image_name;

                // Remove any existing s3 stored image
                if($item->image != '' && Storage::disk('s3')->exists($image_dir . $item->image) ) {
                    Storage::disk('s3')->delete($image_dir . $item->image);
                }
         
                Storage::disk('s3')->put($aws_image_path, file_get_contents($image));
                $image_path = Storage::disk('s3')->url($aws_image_path);
                
            } else { // Local Storage

                // Remove any existing local stored image
                if( $item->image != '' && File::exists($image_dir . $item->image) ) {
                    unlink($image_dir . $item->image);
                }
                
                $image->move($image_dir, $image_name);
            }


            if( !empty($image_dir) && !empty($image_name) ) {

                $item->image = $image_name;
                $item->image_path = $image_path;
            }
        }

        $item->social = [
            'facebook'  => $request->facebook, 
            'twitter'   => $request->twitter, 
            'linkedin'  => $request->linkedin, 
            'pinterest' => $request->pinterest, 
            'youtube'   => $request->youtube,
            'github'    => $request->github,
            'behance'   => $request->behance,
            'instagram' => $request->instagram,
            'tiktok'    => $request->tiktok
        ];

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Author Section'), null);

        return back()->with(['message' => __('Author Saved Succesfully.'), 'type' => 'success']);
    }

    public function authorDelete($id){
        $item = Author::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Author Deleted Succesfully.'), 'type' => 'success']);
    }
}
