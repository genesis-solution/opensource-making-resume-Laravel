<?php

namespace App\Http\Controllers;

use App\Models\TaxRate;
use App\Models\Plan;
use App\Models\User;
use App\Models\Activity;
use App\Models\Setting;
use App\Rules\ExtendedLicenseRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class TaxRateController extends Controller
{
    public function index(){
        $items = TaxRate::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.tax-rates.index', compact('items', 'settings'));
    }

    public function taxRateCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = TaxRate::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.tax-rates.edit', compact('item', 'settings'));
    }

    public function taxRateCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = TaxRate::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new TaxRate();
        }

        $requiredTaxRateRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'name' => [$requiredTaxRateRule, 'string', 'max:128', new ExtendedLicenseRule()],
            'type' => ['required', 'min:0', 'max:1'],
            'percentage' => [$requiredTaxRateRule, 'numeric', 'min:0', 'max:100'],
        ],[
            'name.required' => __('The Name field is required.'),
            'type.required' => __('The Type field is required.'),
            'percentage.required' => __('The Percentage field is required.'),
            'percentage.numeric' => __('The Percentage field must be a number.')
        ]);

        $item->status = $request->status ? '1' : '0';
        
        $item->name = $request->name;
        $item->type = $request->type;
        $item->percentage = $request->percentage;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Tax Rate'), null);

        return back()->with(['message' => __('Tax Rate Saved Succesfully.'), 'type' => 'success']);
    }

    public function taxRateDelete($id){
        $item = TaxRate::where('id', $id)->firstOrFail();
        $item->delete();

        return response()->json(["success" => __('Tax Rate Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Tax Rate Deleted Succesfully.'), 'type' => 'success']);
    }
}
