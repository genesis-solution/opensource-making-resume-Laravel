<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use App\Models\Plan;
use App\Models\User;
use App\Models\Activity;
use App\Models\Setting;
use App\Rules\ExtendedLicenseRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class CouponController extends Controller
{
    public function index(){
        $items = Coupon::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.coupons.index', compact('items', 'settings'));
    }

    public function checkCouponCode(Request $request) {

        $request->validate([
            'coupon' => ['required', 'alpha_dash', 'max:128'],
        ]);

        // Get the applied Coupon
        $coupon = $request->coupon ? Coupon::where('code', '=', $request->coupon)->first() : null;

        // Check whether the coupon exists
        if ( $coupon != null ) {
            // Check whether the quantity is either unlimited or higher than redeemed number
            if ( ($coupon->quantity == -1 ) || ( $coupon->quantity > $coupon->redeems ) ) {
                
                return response()->json(['success' => 'The coupon code was found.'], 200 );
            } else {
                return response()->json(['errors' => ['message' => 'The coupon code has expired.']], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => 'The coupon code was not found.']], 419 );
        }
        return false;
    }

    public function couponCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Coupon::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.coupons.edit', compact('item', 'settings'));
    }

    public function couponCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Coupon::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Coupon();
        }

        $requiredCouponRule = $request->status != '' ? 'required' : 'nullable';
        $requiredCouponPercentageRule = $request->type == 0 ? 'required' : 'nullable';
        $requiredCouponDayRule = $request->type == 1 ? 'required' : 'nullable';

        $request->validate([
            'name' => [$requiredCouponRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'code' => [$requiredCouponRule, 'alpha_dash', 'max:128', 'unique:coupons,code,'. $request->item_id],
            'percentage' => ['required_if:type,0', 'nullable', 'numeric', 'min:0', 'max:99.99'],
            'quantity' => [$requiredCouponRule, 'integer'],
            'days' => ['required_if:type,1', 'nullable', 'integer', 'min:-1', 'max:3650'],
        ],[
            'name.required' => __('The Name field is required.'),
            'code.required' => __('The Code field is required.'),
            'percentage.required_if' => __('The Percentage field is required when :other is :value.'),
            'quantity.required' => __('The Quantity field is required.'),
            'days.required_if' => __('The Days field is required when :other is :value.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->percentage = ( $request->type == 0 ) ? $request->percentage : '100.00';
        $item->days = ( $request->type == 1 ) ? $request->days : '0';

        $item->name = $request->name;
        $item->code = $request->code;
        $item->type = $request->type;
        $item->quantity = $request->quantity;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Coupon'), null);

        return back()->with(['message' => __('Coupon Saved Succesfully.'), 'type' => 'success']);
    }

    public function couponDelete($id){
        $item = Coupon::where('id', $id)->firstOrFail();
        $item->delete();

        return response()->json(["success" => __('Coupon Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Coupon Deleted Succesfully.'), 'type' => 'success']);
    }
}
