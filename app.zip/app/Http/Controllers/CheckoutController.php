<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Setting;
use App\Models\User;
use App\Models\Currency;
use App\Models\Coupon;
use App\Models\TaxRate;
use App\Models\Plan;
use App\Traits\PaymentTrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;

class CheckoutController extends Controller
{
    use PaymentTrait;

    private $defaultInterval = 'month';
    private $intervals = ['month', 'year'];

    public function index(Request $request, $id){
        $user = $request->user();
        
        $plan = Plan::where('id', '=', $id)
                        ->where('id', '!=', '1')->firstOrFail();

        // If no interval is set
        if (!in_array($request->input('interval'), $this->intervals)) {
            // Redirect to a default interval
            return redirect()->route('dashboard.user.checkout.index', ['id' => $id, 'interval' => $this->defaultInterval]);
        }

        // Check whether the user is already subscribed to the plan
        if ($user->plan_id == $plan->id) {
            return redirect()->route('pricing');
        }

        // Get the coupon
        $coupon = $request->input('coupon') ? Coupon::where('code', '=', $request->input('coupon'))->first() : null;

        // Check whether the coupon was set
        if ($request->old('coupon')) {
            $coupon = Coupon::where('code', '=', $request->old('coupon'))->first() ?? null;

            // If the coupon quantity is smaller or equal with the number of redeems, and it is not unlimited
            if ( !empty($coupon) && ( $coupon->quantity <= $coupon->redeems ) && ( $coupon->quantity != -1 ) ) {
                $coupon = null;
            }
        }

        // Get the tax rates
        $taxRates = TaxRate::whereIn('id', $plan->tax_rates ?? [])->where('status', '=', '1')->orderBy('type')->get();

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = $taxRates->where('type', '=', 0)->where('status', '=', '1')->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = $taxRates->where('type', '=', 1)->where('status', '=', '1')->sum('percentage');

        // Check whether subscription is enabled
        if( config('settings.subscription') ) {
            return view('dashboard.user.checkout.index', compact('plan', 'user', 'coupon', 'taxRates', 'inclTaxRatesPercentage', 'exclTaxRatesPercentage'));
        } else {
            return redirect('/');
        }
    }

    // Start Checkout Process
    public function startCheckoutProcess(Request $request, $id)
    {
        $user = $request->user();

        $plan = Plan::where('id', '=', $id)
                    ->where('id', '!=', '1')->firstOrFail();

        $settings = Setting::first();

        $currencies = Currency::where('code', '=', config('settings.currency'))->first();

        // Check whether the user is already subscribed to the plan
        if ($user->plan_id == $plan->id) {
            return redirect()->route('pricing');
        }

        // Check whether user want to skip trail phase
        if ( $request->input('skip_trial') ) {

            $user->plan_trial_ends_at = Carbon::now();
            $user->save();

            return redirect()->back()->withInput();
        }

        // Check whether a coupon was applied
        if ( $request->has('coupon') && !$request->has('coupon_set') ) {
            return redirect()->back()->withInput();
        }

        $request->validate([
            'firstname'  => ['required', 'string', 'max:20'],
            'lastname'   => ['required', 'string', 'max:35'],
            'phone'      => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'street'     => ['sometimes', 'nullable', 'string', 'max:255'],
            'city'       => ['sometimes', 'nullable', 'string', 'max:100'],
            'state'      => ['sometimes', 'nullable', 'string', 'max:255'],
            'postal'     => ['sometimes', 'nullable', 'string', 'max:10'],
            'country'    => ['sometimes', 'nullable', 'string', 'max:255'],
            'interval'   => ['required', 'in:month,year'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' => __('The Last Name field is required.'),
            'interval.required' => __('The Interval field is required.'),
            'interval.in' => __('The selected Interval is invalid.')
        ]);

        // Update the user's billing information
        $user->firstname = $request->input('firstname');
        $user->lastname = $request->input('lastname');
        $user->phone = $request->input('full_phone');

        $user->address = [
            'street' => $request->input('street'),
            'city' => $request->input('city'), 
            'state' => $request->input('state'),
            'postal' => $request->input('postal'), 
            'country' => $request->input('country'),
        ];

        $user->save();

        // Get the coupon
        $coupon = $request->input('coupon') ? Coupon::where('code', '=', $request->input('coupon'))->firstOrFail() : null;

        // Get the tax rates
        $taxRates = TaxRate::whereIn('id', $plan->tax_rates ?? [])->where('status', '=', '1')->orderBy('type')->get();

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = $taxRates->where('type', '=', 0)->where('status', '=', '1')->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = $taxRates->where('type', '=', 1)->where('status', '=', '1')->sum('percentage');

        // Caculate the otal amount after any applied coupons or tax rates
        $amount = formatMoney(checkoutTotalAmount(($request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month), $coupon->percentage ?? null, $exclTaxRatesPercentage, $inclTaxRatesPercentage), config('settings.currency'), false, false);

        $taxRates = TaxRate::whereIn('id', $plan->tax_rates ?? [])->where('status', '=', '1')->orderBy('type')->get();

        // Check whether a trial is available
        if ( $plan->trial_days > 0 && !$user->plan_trial_ends_at ) {
            return $this->startTrialPlan($request, $plan, $coupon);
        }
        // Check whether a redeemable coupon was applied 
        elseif ( !empty($coupon) && $coupon->type == 1 ) {
            return $this->startDiscountPlan($request, $plan, $coupon);
        } 
        // Check whether the payment process is paypal
        elseif ( $request->input('payment_processor') == 'paypal' ) {
            return $this->startPaypalPaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        } 
        // Check whether the payment process is stripe
        elseif ( $request->input('payment_processor') == 'stripe' ) {
            return $this->startStripePaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
        // Check whether the payment process is razorpay
        elseif ( $request->input('payment_processor') == 'razorpay' ) {
            return $this->startRazorpayPaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
        // Check whether the payment process is paystack
        elseif ( $request->input('payment_processor') == 'paystack' ) {
            return $this->startPaystackPaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
        // Check whether the payment process is coinbase
        elseif ( $request->input('payment_processor') == 'coinbase' ) {
            return $this->startCoinbasePaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
        // Check whether the payment process is crypto.com
        elseif ( $request->input('payment_processor') == 'crypto' ) {
            return $this->startCryptoPaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
        // Check whether the payment process is bank
        elseif ( $request->input('payment_processor') == 'bank' ) {
            return $this->startBankPaymentProcess($request, $plan, $coupon, $taxRates, $amount, $currencies);
        }
    }

    // Start Discounted Plan
    private function startDiscountPlan(Request $request, Plan $plan, Coupon $coupon) {
        $user = $request->user();

        // Cancel the current plan
        $user->planSubscriptionCancel();

        // Store the new plan
        $user->plan_id = $plan->id;
        $user->plan_amount = null;
        $user->plan_currency = null;
        $user->plan_interval = null;
        $user->plan_payment_processor = null;
        $user->plan_subscription_id = null;
        $user->plan_subscription_status = null;
        $user->plan_recurring_at = null;
        $user->plan_ends_at = $coupon->days < 0 ? null : Carbon::now()->addDays($coupon->days);

        $user->save();

        // Increase the coupon usage
        $coupon->increment('redeems', 1);

        Activity::createUserActivity($user->id, 'Started', 'Discount Plan', null);

        return redirect()->route('dashboard.user.checkout.complete');
    }

    // Start Free Trial Plan
    private function startTrialPlan(Request $request, Plan $plan) {
        $user = $request->user();

        // Cancel the current plan
        $user->planSubscriptionCancel();

        // Store the new plan
        $user->plan_id = $plan->id;
        $user->plan_amount = null;
        $user->plan_currency = null;
        $user->plan_interval = null;
        $user->plan_payment_processor = null;
        $user->plan_subscription_id = null;
        $user->plan_subscription_status = null;
        $user->plan_created_at = Carbon::now();
        $user->plan_recurring_at = null;
        $user->plan_trial_ends_at = Carbon::now()->addDays($plan->trial_days);
        $user->plan_ends_at = Carbon::now()->addDays($plan->trial_days);

        $user->save();

        Activity::createUserActivity($user->id, 'Started', 'Trial Plan', null);

        return redirect()->route('dashboard.user.checkout.complete');
    }

    // Start PayPal Payment Process
    public function startPaypalPaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $httpClient = new HttpClient();

        $httpBaseUrl = 'https://'. ( config('settings.paypal_mode') == 'sandbox' ? 'api-m.sandbox' : 'api-m') .'.paypal.com/';

        // Retrieve the Auth Token
        try {
            $payPalAuthRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/oauth2/token', [
                    'auth' => [config('settings.paypal_client_id'), config('settings.paypal_client_secret')],
                    'form_params' => [
                        'grant_type' => 'client_credentials'
                    ]
                ]
            );

            $payPalAuth = json_decode($payPalAuthRequest->getBody()->getContents());

        } catch (BadResponseException $e) {
            return back()->with('error', $e->getResponse()->getBody()->getContents());
        }

        $payPalProduct = 'product_' . $plan->id;

        // Retrieve the Product
        try {
            $payPalProductRequest = $httpClient->request('GET', $httpBaseUrl . 'v1/catalogs/products/' . $payPalProduct, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $payPalAuth->access_token,
                        'Content-Type' => 'application/json'
                    ]
                ]
            );

            $payPalProduct = json_decode($payPalProductRequest->getBody()->getContents());

        } catch (\Exception $e) {
            // Create the Product
            try {
                $payPalProductRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/catalogs/products', [
                        'headers' => [
                            'Authorization' => 'Bearer ' . $payPalAuth->access_token,
                            'Content-Type' => 'application/json'
                        ],
                        'body' => json_encode([
                            'id' => $payPalProduct,
                            'name' => $plan->name,
                            'description' => $plan->description,
                            'type' => 'SERVICE'
                        ])
                    ]
                );

                $payPalProduct = json_decode($payPalProductRequest->getBody()->getContents());

            } catch (BadResponseException $e) {
                return back()->with('error', $e->getResponse()->getBody()->getContents());
            }
        }

        $payPalAmount = $amount;

        $payPalPlan = 'plan_'. $plan->id .'_'. $request->input('interval') .'_'. $payPalAmount .'_'. config('settings.currency');

        // Create the Plan
        try {
            $payPalPlanRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/billing/plans', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $payPalAuth->access_token,
                        'Content-Type' => 'application/json'
                    ],
                    'body' => json_encode([
                        'product_id' => $payPalProduct->id,
                        'name' => $payPalPlan,
                        'status' => 'ACTIVE',
                        'billing_cycles' => [
                            [
                                'frequency' => [
                                    'interval_unit' => strtoupper($request->input('interval')),
                                    'interval_count' => 1,
                                ],
                                'tenure_type' => 'REGULAR',
                                'sequence' => 1,
                                'total_cycles' => 0,
                                'pricing_scheme' => [
                                    'fixed_price' => [
                                        'value' => $payPalAmount,
                                        'currency_code' => config('settings.currency'),
                                    ],
                                ]
                            ]
                        ],
                        'payment_preferences' => [
                            'auto_bill_outstanding' => true,
                            'payment_failure_threshold' => 0,
                        ],
                    ])
                ]
            );

            $payPalPlan = json_decode($payPalPlanRequest->getBody()->getContents());

        } catch (BadResponseException $e) {
            return back()->with('error', $e->getResponse()->getBody()->getContents());
        }

        // Create the Subscription
        try {
            $payPalSubscriptionRequest = $httpClient->request('POST', $httpBaseUrl . 'v1/billing/subscriptions', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $payPalAuth->access_token,
                        'Content-Type' => 'application/json'
                    ],
                    'body' => json_encode([
                        'plan_id' => $payPalPlan->id,
                        'application_context' => [
                            'brand_name' => config('settings.site_name'),
                            'locale' => 'en-US',
                            'shipping_preference' => 'SET_PROVIDED_ADDRESS',
                            'user_action' => 'SUBSCRIBE_NOW',
                            'payment_method' => [
                                'payer_selected' => 'PAYPAL',
                                'payee_preferred' => 'IMMEDIATE_PAYMENT_REQUIRED',
                            ],
                            'return_url' => route('dashboard.user.checkout.complete'),
                            'cancel_url' => route('dashboard.user.checkout.cancelled')
                        ],
                        'custom_id' => http_build_query([
                            'user' => $request->user()->id,
                            'plan' => $plan->id,
                            'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                            'amount' => $amount,
                            'currency' => config('settings.currency'),
                            'interval' => $request->input('interval'),
                            'coupon' => $coupon->id ?? null,
                            'tax_rates' => $taxRates->pluck('id')->implode('_'),
                        ])
                    ])
                ]
            );

            $payPalSubscription = json_decode($payPalSubscriptionRequest->getBody()->getContents());

        } catch (BadResponseException $e) {
            return back()->with('error', $e->getResponse()->getBody()->getContents());
        }

        return redirect($payPalSubscription->links[0]->href);
    }

    // Start Stripe Payment Process
    private function startStripePaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $stripe = new \Stripe\StripeClient(
            config('settings.stripe_secret_key')
        );

        // Retrieve the Product
        try {
            $stripeProduct = $stripe->products->retrieve($plan->id);

            // Check whether the plan's name has changed
            if ($plan->name != $stripeProduct->name) {

                // Update the Product
                try {
                    $stripeProduct = $stripe->products->update($stripeProduct->id, [
                        'name' => $plan->name
                    ]);
                } catch (\Exception $e) {
                    return back()->with('error', $e->getMessage());
                }
            }
        } catch (\Exception $e) {
            // Create the Product
            try {
                $stripeProduct = $stripe->products->create([
                    'id' => $plan->id,
                    'name' => $plan->name,
                    'description' => $plan->description
                ]);
            } catch (\Exception $e) {
                return back()->with('error', $e->getMessage());
            }
        }

        $stripeAmount = $currencies->zero_decimals == '1' ? $amount : ($amount * 100);

        $stripePlan = $plan->id .'_'. $request->input('interval') .'_'. $stripeAmount .'_'. config('settings.currency');

        // Attempt to retrieve the plan
        try {
            $stripePlan = $stripe->plans->retrieve($stripePlan);
        } catch (\Exception $e) {
            // Create the Plan
            try {
                $stripePlan = $stripe->plans->create([
                    'amount' => $stripeAmount,
                    'currency' => config('settings.currency'),
                    'interval' => $request->input('interval'),
                    'product' => $stripeProduct->id,
                    'id' => $stripePlan,
                ]);
            } catch (\Exception $e) {
                return back()->with('error', $e->getMessage());
            }
        }

        // Create the Checkout Session
        try {
            $stripeSession = $stripe->checkout->sessions->create([
                'success_url' => route('dashboard.user.checkout.complete'),
                'cancel_url' => route('dashboard.user.checkout.cancelled'),
                'payment_method_types' => ['card'],
                'line_items' => [
                    [
                        'price' => $stripePlan->id,
                        'quantity' => 1,
                    ],
                ],
                'mode' => 'subscription',
                'subscription_data' => [
                    'metadata' => [
                        'user' => $request->user()->id,
                        'plan' => $plan->id,
                        'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                        'amount' => $amount,
                        'currency' => config('settings.currency'),
                        'interval' => $request->input('interval'),
                        'coupon' => $coupon->id ?? null,
                        'tax_rates' => $taxRates->pluck('id')->implode('_')
                    ],
                ]
            ]);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        return view('dashboard.user.checkout.processors.stripe', ['stripeSession' => $stripeSession]);
    }

    // Start Razorpay Payment Process
    private function startRazorpayPaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $razorpay = new \Razorpay\Api\Api(config('settings.razorpay_key_id'), config('settings.razorpay_key_secret'));

        $razorpayAmount = $currencies->zero_decimals == '1' ? $amount : ($amount * 100);

        $razorpayPlan = $plan->id . '_' .$request->input('interval') . '_' . $razorpayAmount . '_' . config('settings.currency');

        try {
            $razorpayPlanRequest = $razorpay->plan->create([
                'period' => $request->input('interval') == 'month' ? 'monthly' : 'yearly',
                'interval' => 1,
                'item' => [
                    'name' => $razorpayPlan,
                    'description' => $plan->description,
                    'amount' => $razorpayAmount,
                    'currency' => config('settings.currency'),
                ],
            ]);
        } catch (\Exception $e) {
            return back()->with('error', $e->getCode() . ' - ' . $e->getMessage());
        }

        try {
            $razorpaySubscriptionRequest = $razorpay->subscription->create([
                'plan_id' => $razorpayPlanRequest->id,
                'total_count' => $request->input('interval') == 'month' ? 36 : 3,
                'notes' => [
                    'user' => $request->user()->id,
                    'plan' => $plan->id,
                    'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                    'amount' => $amount,
                    'currency' => config('settings.currency'),
                    'interval' => $request->input('interval'),
                    'coupon' => $coupon->id ?? null,
                    'tax_rates' => $taxRates->pluck('id')->implode('_')
                ]
            ]);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        return redirect($razorpaySubscriptionRequest->short_url);
    }

    // Start Paystack Payment Process
    private function startPaystackPaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $httpClient = new HttpClient();

        $paystackAmount = $currencies->zero_decimals == '1' ? $amount : ($amount * 100);

        // Create the plan
        try {
            $paystackPlanRequest = $httpClient->request('POST', 'https://api.paystack.co/plan', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . config('settings.paystack_secret_key'),
                        'Content-Type' => 'application/json',
                        'Cache-Control' => 'no-cache'
                    ],
                    'body' => json_encode([
                        'name' => $plan->name,
                        'interval' => $request->input('interval') == 'year' ? 'annually' : 'monthly',
                        'amount' => $paystackAmount,
                        'currency' => config('settings.currency'),
                        'description' => http_build_query([
                            'currency' => config('settings.currency'),
                            'user' => $request->user()->id,
                            'plan' => $plan->id,
                            'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                            'amount' => $amount,
                            'interval' => $request->input('interval'),
                            'coupon' => $coupon->id ?? null,
                            'tax_rates' => $taxRates->pluck('id')->implode('_'),
                        ])
                    ])
                ]
            );

            $paystackPlan = json_decode($paystackPlanRequest->getBody()->getContents());
        } catch (\Exception $e) {
            return back()->with('error',  $e->getMessage());
        }

        // Create the subscription
        try {
            $paystackSubscriptionRequest = $httpClient->request('POST', 'https://api.paystack.co/transaction/initialize', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . config('settings.paystack_secret_key'),
                        'Content-Type' => 'application/json',
                        'Cache-Control' => 'no-cache'
                    ],
                    'body' => json_encode([
                        'email' => $request->user()->email,
                        'amount' => $paystackAmount,
                        'currency' => config('settings.currency'),
                        'callback_url' => route('dashboard.user.checkout.complete'),
                        'plan' => $paystackPlan->data->plan_code
                    ])
                ]
            );

            $paystackSubscription = json_decode($paystackSubscriptionRequest->getBody()->getContents());
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        return redirect($paystackSubscription->data->authorization_url);
    }

    // Start Coinbase Payment Process
    private function startCoinbasePaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $httpClient = new HttpClient();

        // Attempt to retrieve the auth token
        try {
            $coinbaseCheckoutRequest = $httpClient->request('POST', 'https://api.commerce.coinbase.com/charges', [
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'X-CC-Api-Key' => config('settings.coinbase_api_key'),
                        'X-CC-Version' => '2018-03-22',
                    ],
                    'body' => json_encode(array_merge_recursive([
                        'name' => $plan->name,
                        'description' => $plan->description,
                        'local_price' => [
                            'amount' => $amount,
                            'currency' => config('settings.currency'),
                        ],
                        'pricing_type' => 'fixed_price',
                        'metadata' => [
                            'user' => $request->user()->id,
                            'plan' => $plan->id,
                            'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                            'amount' => $amount,
                            'currency' => config('settings.currency'),
                            'interval' => $request->input('interval'),
                            'coupon' => $coupon->id ?? null,
                            'tax_rates' => $taxRates->pluck('id')->implode('_')
                        ],
                        'redirect_url' => route('dashboard.user.checkout.complete'),
                        'cancel_url' => route('dashboard.user.checkout.cancelled'),
                    ]))
                ]
            );

            $coinbase = json_decode($coinbaseCheckoutRequest->getBody()->getContents());
        } catch (BadResponseException $e) {
            return back()->with('error', $e->getResponse()->getBody()->getContents());
        }

        return redirect($coinbase->data->hosted_url);
    }

    // Start Crypto.com Payment Process
    private function startCryptoPaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {
        $httpClient = new HttpClient();

        $cryptoAmount = $currencies->zero_decimals == '1' ? $amount : ($amount * 100);

        // Attempt to retrieve the auth token
        try {
            $cryptoCheckoutRequest = $httpClient->request('POST', 'https://pay.crypto.com/api/payments', [
                    'auth' => [config('settings.crypto_secret_key'), ''],
                    'form_params' => [
                        'description' => $plan->description,
                        'amount' => $cryptoAmount,
                        'currency' => config('settings.currency'),
                        'metadata' => [
                            'user' => $request->user()->id,
                            'plan' => $plan->id,
                            'plan_amount' => $request->input('interval') == 'year' ? $plan->amount_year : $plan->amount_month,
                            'amount' => $amount,
                            'currency' => config('settings.currency'),
                            'interval' => $request->input('interval'),
                            'coupon' => $coupon->id ?? null,
                            'tax_rates' => $taxRates->pluck('id')->implode('_')
                        ],
                        'return_url' => route('dashboard.user.checkout.complete'),
                        'cancel_url' => route('dashboard.user.checkout.cancelled')
                    ]
                ]
            );

            $crypto = json_decode($cryptoCheckoutRequest->getBody()->getContents());
        } catch (BadResponseException $e) {
            return back()->with('error', $e->getResponse()->getBody()->getContents());
        }

        return redirect($crypto->payment_url);
    }

    // Start Bank Payment Process
    private function startBankPaymentProcess(Request $request, Plan $plan, $coupon, $taxRates, $amount, $currencies) {

        $request->validate([
            'payment_id' => ['required_if:payment_processor,bank', 'alpha_num', 'min:16', 'max:16', 'unique:payments,payment_id']
        ]);
        
        $this->paymentStore([
            'user_id' => $request->user()->id,
            'plan_id' => $plan->id,
            'payment_id' => $request->payment_id,
            'processor' => 'bank',
            'amount' => $amount,
            'currency' => config('settings.currency'),
            'interval' => $request->input('interval'),
            'payment_status' => 'pending',
            'coupon' => $coupon->id ?? null,
            'tax_rates' => $taxRates->pluck('id')->implode('_'),
            'customer' => $request->user()->address,
        ]);

        return redirect()->route('dashboard.user.checkout.pending');
    }

    // Display the Payment complete page.
    public function complete() {
        $user = Auth::user();
        // Reset user AI-Generated Content
        $user->ai_month_count = 0;
        $user->save();

        return view('dashboard.user.checkout.complete');
    }

    // Display the Payment pending page.
    public function pending() {
        return view('dashboard.user.checkout.pending');
    }

    // Display the Payment cancelled page.
    public function cancelled() {
        return view('dashboard.user.checkout.cancelled');
    }
}
