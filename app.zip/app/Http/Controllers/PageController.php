<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\Page;
use App\Models\FrontendFooter;
use App\Models\Activity;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class PageController extends Controller
{
    // Page
    public function index(){
        $items = Page::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.pages.index', compact('items', 'settings'));
    }

    // Frontend Pages
    public function frontendPage($slug = null){
        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        $page = Page::where('slug', $slug)->first();

        if ($page) {
            // Check page status
            if ( !$page->status ) {
                abort(404);
            } else {
                return view('pages', compact('frontend', 'settings', 'navs', 'page', 'footer'));
            }

        } else {
            abort(404);
        }
    }

    public function pageCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Page::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.pages.edit', compact('item', 'settings'));
    }

    public function pageCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Page::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Page();
        }

        $requiredPageRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'title' => [$requiredPageRule, 'string', 'max:255'],
            'slug' => [$requiredPageRule, 'string', 'max:255'],
            'keywords' => [$requiredPageRule, 'string'],
            'description' => [$requiredPageRule, 'string'],
        ],[
            'title.required' =>  __('The Title field is required.'),
            'slug.required' =>  __('The Slug field is required.'),
            'keywords.required' =>  __('The Keywords field is required.'),
            'description.required' =>  __('The Description field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->title = $request->title;
        $item->slug = Str::slug($request->slug);
        $item->keywords = $request->keywords;
        $item->description = $request->description;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Page Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function pageDelete($id){
        $item = Page::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }
}
