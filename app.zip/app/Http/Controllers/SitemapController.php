<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Frontend;
use App\Models\Page;
use App\Models\Post;
use App\Models\Faq;
use App\Models\User;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class SitemapController extends Controller
{
    public function index() {
      $pages = Page::where('status', '=', '1')->get();
    
      $posts = Post::where('status', '=', '1')->get();
     
      return response()->view('sitemap.index', [
          'pages' => $pages, 
          'posts' => $posts
      ])->header('Content-Type', 'text/xml');
    }
}
