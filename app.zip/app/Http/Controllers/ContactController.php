<?php

namespace App\Http\Controllers;

use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendFooter;
use App\Models\Setting;
use Illuminate\Http\Request;
use App\Rules\ReCaptchaRule;
use Carbon\Carbon;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;
  
class ContactController extends Controller
{

    public function index(): View
    {

        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        // Check whether contact is enabled in frontend settings
        if( config('frontends.frontend_contact') == 1 ) {
            return view('newfrontend.contact', compact('frontend', 'settings', 'navs', 'footer'));
        } 
        else {
            abort(404);
        }
    }
  
    public function sendMessage(Request $request) {

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'subject' => ['required', 'string', 'max:255'],
            'message' => ['required'],
            'g-recaptcha-response' => ['required_if:Setting::first()->google_recaptcha, 1', new ReCaptchaRule],
        ],[
            'name.required' => __('The Name field is required.'),
            'email.required' => __('The Email field is required.'),
            'email.email' => __('The Email field must be a valid email address.'),
            'phone.required' => __('The Phone field is required.'),
            'subject.required' => __('The Subject field is required.'),
            'message.required' => __('The Message field is required.'),
            'g-recaptcha-response.required' => __('The ReCaptcha Response field is required.')
        ]);

        $toName = config('settings.site_name');
        $fromName = $request->name;
        $toEmail =  config('settings.site_email');
        $fromEmail =  $request->email; 
        $txtPhone = $request->full_phone;
        $txtSubject = $request->subject;
        $txtMessage = $request->message;

        $emailMessage =  _('Name') .': '. $fromName ."\n";
        $emailMessage .= __('Email') .': '. $fromEmail ."\n";
        if($txtPhone != null) {
            $emailMessage .= __('Phone') .': '. $txtPhone ."\n";
        }
        $emailMessage .= __('Message') .': '.$txtMessage."\n";

        try
        {
            Mail::raw($emailMessage, function ($message) use ($fromEmail, $toEmail, $fromName, $toName, $txtSubject) {
                $message->to($toEmail, $toName)
                    ->replyTo($fromEmail, $fromName)
                    ->subject($txtSubject);
            });
            
            return back()->with(['success' => __('Contact Form Submit Successfully.')]);

        } catch (\Exception $exception){
            return $exception->getMessage();
        }
        
    }
}
