<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
class Resume_builderController extends Controller
{
    public function index()
    {
        return view ('newfrontend.builder.resume_builder');
    }
    
    
      public function choose_template()
    {
        return view ('newfrontend.choose_template');
    }
}