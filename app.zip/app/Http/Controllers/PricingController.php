<?php

namespace App\Http\Controllers;

use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendResource;
use App\Models\Faq;
use App\Models\FrontendFooter;
use App\Models\Plan;
use App\Models\User;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class PricingController extends Controller
{
     public function index()
    {

        $frontend = Frontend::first();
        $settings = Setting::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        $plans = Plan::all();
        $resources = FrontendResource::all()->sortBy('order'); // Ascending Order
        $faqs = Faq::join('categories', 'faqs.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'faqs.title as f_title', 'faqs.description as f_description', 'faqs.category_id', 'faqs.icon as f_icon', 'categories.faq_order as c_order', 'faqs.order as f_order', 'categories.status as c_status', 'faqs.status as f_status')
                        ->where('faqs.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->where('categories.title', '=', 'Pricing')
                                    ->orderBy('faqs.order')->get(); // Ascending Order, only those with Pricing as category

        $faq_count = Faq::join('categories', 'faqs.category_id', '=', 'categories.id')
                        ->where('categories.title', '=', 'Pricing')->count();

        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        // Check whether subscription is enabled
        if( config('settings.subscription') ) {
            return view('pricing', compact('frontend', 'settings', 'plans', 'navs', 'resources', 'faqs', 'faq_count', 'footer'));
        } else {
            return redirect('/');
        }
    }
}
