<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\User;
use App\Models\Setting;
use App\Rules\ExtendedLicenseRule;
use Carbon\Carbon;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;

class SettingController extends Controller
{
    public function index(){

        return view('dashboard.admin.settings.index');
    }

    public function general(){
        $settings = Setting::first();

        return view('dashboard.admin.settings.general', compact('settings'));
    }

    public function saveGeneralSettings(Request $request){

        $user = Auth::user();
        $settings = Setting::first();

        $requiredWatermarkRule = $request->watermark != '' ? 'required' : 'nullable';
        $requiredAnalyticsRule = $request->google_analytics != '' ? 'required' : 'nullable';
        $requiredAdSenseRule = $request->google_adsense != '' ? 'required' : 'nullable';
        $requiredReCaptchaRule = $request->google_recaptcha != '' ? 'required' : 'nullable';
        $requiredCookieConsentRule = $request->cookie_consent != '' ? 'required' : 'nullable';
        $requiredTawkRule = $request->tawk != '' ? 'required' : 'nullable';
        $requiredMaintenanceRule = $request->tawk != '' ? 'required' : 'nullable';

        $request->validate([
            'site_name' => ['required', 'string', 'max:255'],
            'site_url' => ['required', 'string', 'max:255'],
            'site_email' => ['required', 'email', 'max:255'],
            'site_meta_title' => ['required', 'string', 'max:255'],
            'site_meta_description' => ['required', 'string', 'max:255'],
            'site_meta_keywords' => ['required', 'string', 'max:255'],
            'timezone' => ['required', 'string', 'max:255'],
            'country' => ['required', 'string', 'max:255'],
            'date_format' => ['required', 'string', 'max:255'],
            'language' => ['required', 'string', 'max:2'],
            'site_facebook' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_twitter' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_linkedin' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_pinterest' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_youtube' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_github' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_behance' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_instagram' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_tiktok' => ['sometimes', 'nullable', 'string', 'max:255'],
            'site_theme_color' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'site_bg_primary_color' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'site_bg_secondary_color' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'site_button_color' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'site_button_hover_color' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'site_custom_css' => ['sometimes', 'nullable', 'string'],
            'site_custom_head_js' => ['sometimes', 'nullable', 'string'],
            'site_custom_body_js' => ['sometimes', 'nullable', 'string'],
            'legal_cookie_url' => ['sometimes', 'nullable', 'string', 'max:255'],
            'legal_privacy_url' => ['sometimes', 'nullable', 'string', 'max:255'],
            'legal_terms_url' => ['sometimes', 'nullable', 'string', 'max:255'],
            'watermark_position_left' => [$requiredWatermarkRule, 'numeric', 'gt:0'],
            'watermark_position_bottom' => [$requiredWatermarkRule, 'numeric', 'gt:0'],
            'watermark_dimension_width' => [$requiredWatermarkRule, 'numeric', 'gt:0'],
            'watermark_dimension_height' => [$requiredWatermarkRule, 'numeric', 'gt:0', 'max:100'],
            'watermark_background_opacity' => [$requiredWatermarkRule, 'numeric', 'gt:0', 'max:1'],
            'google_analytics_code' => [$requiredAnalyticsRule, 'string', 'max:255'],
            'google_adsense_code' => [$requiredAdSenseRule, 'string', 'max:255'],
            'google_recaptcha_site_key' => [$requiredReCaptchaRule, 'string', 'max:255'],
            'google_recaptcha_secret_key' => [$requiredReCaptchaRule, 'string', 'max:255'],
            'cookie_consent_modal_layout' => [$requiredCookieConsentRule, 'string', 'max:255'],
            'cookie_consent_modal_position' => [$requiredCookieConsentRule, 'string', 'max:255'],
            'cookie_consent_modal_orientation' => ['sometimes', 'nullable', 'string', 'max:255'],
            'tawk_property_id' => [$requiredTawkRule, 'string', 'max:255'],
            'tawk_chat_widget_id' => [$requiredTawkRule, 'string', 'max:255'],
            'domain_blacklist' => ['sometimes', 'nullable', 'string'],
            'ip_blacklist' => ['sometimes', 'nullable', 'string'],
            'ip_whitelist' => ['sometimes', 'nullable', 'string'],
            'maintenance_description' => [$requiredMaintenanceRule, 'string', 'max:255'],
        ],[
            'site_name.required' => __('The Site Name field is required.'),
            'site_url.required' => __('The Site Url field is required.'),
            'site_email.required' => __('The Site Email field is required.'),
            'site_email.email' => __('The Site Email field must be a valid email address.'),
            'site_meta_title.required' => __('The Site Meta Title field is required.'),
            'site_meta_description.required' => __('The Site Meta Description field is required.'),
            'site_meta_keywords.required' => __('The Site Meta Keywords field is required.'),
            'timezone.required' => __('The Default Timezone field is required.'),
            'country.required' => __('The Default Country field is required.'),
            'date_format.required' => __('The Default Date Format field is required.'),
            'language.required' => __('The Default Language field is required.'),
            'watermark_position_left.required' => __('The Watermark Left Position field is required.'),
            'watermark_position_left.numeric' =>  __('The Watermark Left Position field must be a number.'),
            'watermark_position_left.gt' =>  __('The Watermark Left Position field must be greater than :value.'),
            'watermark_position_bottom.required' => __('The Watermark Bottom Position field is required.'),
            'watermark_position_bottom.numeric' =>  __('The Watermark Bottom Position field must be a number.'),
            'watermark_position_bottom.gt' =>  __('The Watermark Bottom Position field must be greater than :value.'),
            'watermark_dimension_width.required' => __('The Watermark Width Dimension field is required.'),
            'watermark_dimension_width.numeric' =>  __('The Watermark Width Dimension field must be a number.'),
            'watermark_dimension_width.gt' =>  __('The Watermark Width Dimension field must be greater than :value.'),
            'watermark_dimension_height.required' => __('The Watermark Height Dimension field is required.'),
            'watermark_dimension_height.numeric' =>  __('The Watermark Height Dimension field must be a number.'),
            'watermark_dimension_height.gt' =>  __('The Watermark Height Dimension field must be greater than :value.'),
            'watermark_background_opacity.required' => __('The Watermark Background Opacity field is required.'),
            'watermark_background_opacity.numeric' =>  __('The Watermark Background Opacity field must be a number.'),
            'watermark_background_opacity.gt' =>  __('The Watermark Background Opacity field must be greater than :value.'),
            'google_analytics_code.required' => __('The Google Analytics Code field is required.'),
            'google_adsense_code.required' => __('The Google AdSense Code field is required.'),
            'google_recaptcha_site_key.required' => __('The Google ReCaptcha Key field is required.'),
            'google_recaptcha_secret_key.required' => __('The Google ReCaptcha Secret field is required.'),
            'cookie_consent_modal_layout.required' => __('The Cookie Consent Layout field is required.'),
            'cookie_consent_modal_position.required' => __('The Cookie Consent Position field is required.'),
            'cookie_consent_modal_orientation.required' => __('The Cookie Consent Orientation field is required.'),
            'tawk_property_id.required' => __('The Tawk Property Id field is required.'),
            'tawk_chat_widget_id.required' => __('The Tawk Chat Widget Id field is required.'),
            'maintenance_description.required' => __('The Maintenance Description field is required.')
        ]);

        // Remove any trailing slash in Site Url
        $siteUrl = rtrim($request->site_url, '/');

        $settings->where('name','site_name')->update(['value' => $request->site_name]);
        $settings->where('name','site_url')->update(['value' => $siteUrl]);
        $settings->where('name','site_email')->update(['value' => $request->site_email]);
        $settings->where('name','site_meta_title')->update(['value' => $request->site_meta_title]);
        $settings->where('name','site_meta_description')->update(['value' => $request->site_meta_description]);
        $settings->where('name','site_meta_keywords')->update(['value' => $request->site_meta_keywords]);
        
        $settings->where('name','timezone')->update(['value' => $request->timezone]);
        $settings->where('name','country')->update(['value' => $request->country]);
        $settings->where('name','date_format')->update(['value' => $request->date_format]);
        $settings->where('name','language')->update(['value' => $request->language]);

        $settings->where('name','site_facebook')->update(['value' => $request->site_facebook]);
        $settings->where('name','site_twitter')->update(['value' => $request->site_twitter]);
        $settings->where('name','site_linkedin')->update(['value' => $request->site_linkedin]);
        $settings->where('name','site_pinterest')->update(['value' => $request->site_pinterest]);
        $settings->where('name','site_youtube')->update(['value' => $request->site_youtube]);
        $settings->where('name','site_github')->update(['value' => $request->site_github]);
        $settings->where('name','site_behance')->update(['value' => $request->site_behance]);
        $settings->where('name','site_tiktok')->update(['value' => $request->site_tiktok]);

        $settings->where('name','site_theme_color')->update(['value' => $request->site_theme_color]);
        $settings->where('name','site_bg_primary_color')->update(['value' => $request->site_bg_primary_color]);
        $settings->where('name','site_bg_secondary_color')->update(['value' => $request->site_bg_secondary_color]);
        $settings->where('name','site_button_color')->update(['value' => $request->site_button_color]);
        $settings->where('name','site_button_hover_color')->update(['value' => $request->site_button_hover_color]);

        $settings->where('name','site_custom_css')->update(['value' => $request->site_custom_css]);
        
        $settings->where('name','site_custom_head_js')->update(['value' => $request->site_custom_head_js]);
        $settings->where('name','site_custom_body_js')->update(['value' => $request->site_custom_body_js]);

        $settings->where('name','registration')->update(['value' => ( $request->registration ? '1' : '0' )]);

        $settings->where('name','subscription')->update(['value' => ( $request->subscription && config('settings.license_type') ? '1' : '0' )]);

        $settings->where('name','blog')->update(['value' => ( $request->blog ? '1' : '0' )]);

        $settings->where('name','legal_cookie_url')->update(['value' => $request->legal_cookie_url]);
        $settings->where('name','legal_privacy_url')->update(['value' => $request->legal_privacy_url]);
        $settings->where('name','legal_terms_url')->update(['value' => $request->legal_terms_url]);

        $settings->where('name','watermark')->update(['value' => ( $request->watermark ? '1' : '0' )]);
        $settings->where('name','watermark_position_left')->update(['value' => $request->watermark_position_left]);
        $settings->where('name','watermark_position_bottom')->update(['value' => $request->watermark_position_bottom]);
        $settings->where('name','watermark_dimension_width')->update(['value' => $request->watermark_dimension_width]);
        $settings->where('name','watermark_dimension_height')->update(['value' => $request->watermark_dimension_height]);
        $settings->where('name','watermark_background_opacity')->update(['value' => $request->watermark_background_opacity]);

        $settings->where('name','google_analytics')->update(['value' => ( $request->google_analytics ? '1' : '0' )]);
        $settings->where('name','google_analytics_code')->update(['value' => $request->google_analytics_code]);

        $settings->where('name','google_adsense')->update(['value' => ( $request->google_adsense ? '1' : '0' )]);
        $settings->where('name','google_adsense_code')->update(['value' => $request->google_adsense_code]);
        
        $settings->where('name','google_recaptcha')->update(['value' => ( $request->google_recaptcha ? '1' : '0' )]);
        $settings->where('name','google_recaptcha_site_key')->update(['value' => $request->google_recaptcha_site_key]);
        $settings->where('name','google_recaptcha_secret_key')->update(['value' => $request->google_recaptcha_secret_key]);

        $settings->where('name','cookie_consent')->update(['value' => ( $request->cookie_consent ? '1' : '0' )]);
        $settings->where('name','cookie_consent_modal_layout')->update(['value' => $request->cookie_consent_modal_layout]);
        $settings->where('name','cookie_consent_modal_position')->update(['value' => $request->cookie_consent_modal_position]);
        $settings->where('name','cookie_consent_modal_orientation')->update(['value' => (($request->cookie_consent_modal_layout && $request->cookie_consent_modal_layout != 'bar') ? $request->cookie_consent_modal_orientation : '')]);

        $settings->where('name','tawk')->update(['value' => ( $request->tawk ? '1' : '0' )]);
        $settings->where('name','tawk_property_id')->update(['value' => $request->tawk_property_id]);
        $settings->where('name','tawk_chat_widget_id')->update(['value' => $request->tawk_chat_widget_id]);

        $settings->where('name','domain_blacklist')->update(['value' => $request->domain_blacklist]);
        $settings->where('name','ip_blacklist')->update(['value' => $request->ip_blacklist]);

        $settings->where('name','ip_whitelist')->update(['value' => $request->ip_whitelist]);

        $settings->where('name','maintenance')->update(['value' => ( $request->maintenance ? '1' : '0' )]);
        $settings->where('name','maintenance_description')->update(['value' => $request->maintenance_description]);

        // Upload Site Logo  
        if ($request->hasFile('site_logo')) {

            $logoRequestValidator = Validator::make($request->all(), [
                'site_logo' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','dimensions:max_height=100','max:1024']
            ]);

            if($logoRequestValidator->fails())
                return back()->with(['error' => $logoRequestValidator->errors()->first(), 'type' => 'error']);

            $logo = $request->file('site_logo');
            $logo_name = 'logo-'. time() .'.'. $logo->getClientOriginalExtension();

            $logo_path = 'uploads/';

            $logoTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($logo->getClientOriginalExtension()), $logoTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored logo image
            if( config('settings.site_logo') != '' && File::exists(config('settings.site_logo')) ) {
                unlink(config('settings.site_logo'));
            }
            
            $logo->move($logo_path, $logo_name);

            if( !empty($logo_path) && !empty($logo_name) ) {

                $settings->where('name','site_logo')->update(['value' => ( $logo_path . $logo_name )]);
            }
        }

        // Upload Site Favicon  
        if ($request->hasFile('site_favicon')) {

            $request->validate([
                'site_favicon' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','max:1024']
            ]);

            $favicon = $request->file('site_favicon');
            $favicon_name = 'favicon-'. time() .'.'. $favicon->getClientOriginalExtension();

            $favicon_path = 'uploads/';

            $faviconTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($favicon->getClientOriginalExtension()), $faviconTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored logo image
            if( config('settings.site_favicon') != '' && File::exists(config('settings.site_favicon')) ) {
                unlink(config('settings.site_favicon'));
            }
            
            $favicon->move($favicon_path, $favicon_name);

            if( !empty($favicon_path) && !empty($favicon_name) ) {

                $settings->where('name','site_favicon')->update(['value' => ( $favicon_path . $favicon_name )]);
            }
        }

        $this->updateEnvSingleValue('APP_NAME', ($request->site_name ?? config('settings.site_name')));
        $this->updateEnvSingleValue('APP_URL', ($siteUrl ?? config('settings.site_url')));
        $this->updateEnvSingleValue('APP_TIMEZONE', ($request->timezone ?? config('settings.timezone')));

        $settingsData = [
            'APP_LANGUAGE' => $request->language ?? config('settings.language'),
            'GOOGLE_RECAPTCHA_KEY' => $request->google_recaptcha_site_key ?? config('settings.google_recaptcha_site_key'),
            'GOOGLE_RECAPTCHA_SECRET' => $request->google_recaptcha_secret_key ?? config('settings.google_recaptcha_secret_key'),
        ];

        $this->updateEnvMultiValues($settingsData);

        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');

        Activity::createUserActivity($user->id, __('Updated'), __('General Settings'), null);

        return back()->with('success', __('General Settings Saved.'));

    }

    public function license(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.license', compact('settings'));
    }

    public function saveLicenseSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $request->validate([
            'license_product_id' => ['required', 'integer'],
            'license_user' => ['required', 'alpha_num', 'max:50'],
            'license_key' => ['required', 'regex:/(?i)^(?:(\w{8})-((\w{4})-){3}(\w{12}))$|(?:((\w{5})-){3}(\w{5}))$|(?:LCN[0-9]{6})$/u'],
        ],[
            'license_product_id.required' => __('The Product Id field is required.'),
            'license_user.required' => __('The Username field is required.'),
            'license_user.alpha_num' => __('The Username field must only contain letters and numbers.'),
            'license_key.required' => __('The License Key field is required.')
        ]);

        // Product License
        if ( ( $request->license_key !=null && config('settings.license_key') == null ) || 
                ( $request->license_key !=null && config('settings.license_key') != $request->license_key ) 
            ) {

            $httpClient = new HttpClient(['timeout' => 10, 'verify' => false]);

            // Check whether product license exists
            try {
                $getLicenseResponse = $httpClient->request('POST', 'https://license.carcani.com/api/get_license', [
                    'headers' => [
                        'LB-API-KEY'   => config('info.software.api.internal'),
                        'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                        'LB-IP'        => request()->ip(),
                        'LB-LANG'      => 'english',
                        'Content-Type' => 'application/json'
                    ],
                    'json' => [
                        'license_code' => $request->input('license_key')
                    ]
                ]);

                $getLicenseOutput = json_decode($getLicenseResponse->getBody()->getContents());

                if ( $getLicenseOutput->status == true ) {
                    // Activate existing license
                    try {
                        $activateResponse = $httpClient->request('POST', 'https://license.carcani.com/api/activate_license', [
                            'headers' => [
                                'LB-API-KEY'   => config('info.software.api.external'),
                                'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                                'LB-IP'        => request()->ip(),
                                'LB-LANG'      => 'english',
                                'Content-Type' => 'application/json'
                            ],
                            'json' => [
                                'verify_type' => 'non_envato',
                                'product_id' => $request->input('license_product_id'),
                                'license_code' => $request->input('license_key'),
                                'client_name' => $request->input('license_user')
                            ]
                        ]);

                        $activateOutput = json_decode($activateResponse->getBody()->getContents());

                        if ( $activateOutput->status == true ) {
                            $settings->where('name','license_product_id')->update(['value' => $getLicenseOutput->product_id ?? $request->input('license_product_id')]);
                            $settings->where('name','license_user')->update(['value' => $getLicenseOutput->client_name ?? $request->input('license_user')]);
                            $settings->where('name','license_key')->update(['value' => $getLicenseOutput->license_code]);
                            
                            $settings->where('name','license_product_support_expiry')->update(['value' => $getLicenseOutput->support_expiry]);

                            $settings->where('name','license_type')->update(['value' => $getLicenseOutput->license_type == 'Extended' ? '1' : '0']);
                            $settings->where('name','subscription')->update(['value' => $getLicenseOutput->license_type == 'Extended' ? '1' : '0']);

                            return back()->with('success', $activateOutput->message);

                        } else {
                            return back()->with('error', $activateOutput->message);
                        }

                    } catch (\Exception $e) {
                        // Failed to activate existing license
                        return back()->with('error', __('Failed to activate existing license.'));
                    }

                } else {
                    // Create a new License
                    try {
                        $getCreateLicenseResponse = $httpClient->request('POST', 'https://license.carcani.com/api/create_license', [
                            'headers' => [
                                'LB-API-KEY'   => config('info.software.api.internal'),
                                'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                                'LB-IP'        => request()->ip(),
                                'LB-LANG'      => 'english',
                                'Content-Type' => 'application/json'
                            ],
                            'json' => [
                                'product_id' => $request->input('license_product_id'),
                                'invoice_number' => null,
                                'license_code' => $request->input('license_key'),
                                'license_type' => $request->input('license_type') == '0' ? 'Regular' : 'Extended',
                                'client_name' => $request->input('license_user'),
                                'client_email' => null,
                                'licensed_ips' => null,
                                'licensed_domains' => null,
                                'support_end_date' => Carbon::now()->addMonths(6)->format('Y-m-d h:i:s'),
                                'updates_end_date' => Carbon::now()->addMonths(6)->format('Y-m-d h:i:s'),
                                'expiry_date' => null,
                                'expiry_days' => null,
                                'license_uses' => null,
                                'license_parallel_uses' => null,
                                'comments' => null
                            ]
                        ]);

                        $getCreateLicenseOutput = json_decode($getCreateLicenseResponse->getBody()->getContents());

                        if ( $getCreateLicenseOutput->status == true ) {
                            // Get the newly created License
                            try {
                                $getNewLicenseResponse = $httpClient->request('POST', 'https://license.carcani.com/api/get_license', [
                                    'headers' => [
                                        'LB-API-KEY'   => config('info.software.api.internal'),
                                        'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                                        'LB-IP'        => request()->ip(),
                                        'LB-LANG'      => 'english',
                                        'Content-Type' => 'application/json'
                                    ],
                                    'json' => [
                                        'license_code' => $getCreateLicenseOutput->license_code 
                                    ]
                                ]);

                                $getNewLicenseOutput = json_decode($getNewLicenseResponse->getBody()->getContents());

                                if ( $getNewLicenseOutput->status == true ) {
                                    // Activate the newly created License
                                    try {
                                        $activateNewResponse = $httpClient->request('POST', 'https://license.carcani.com/api/activate_license', [
                                            'headers' => [
                                                'LB-API-KEY'   => config('info.software.api.external'),
                                                'LB-URL'       => config('settings.site_url') ?? env('APP_URL'),
                                                'LB-IP'        => request()->ip(),
                                                'LB-LANG'      => 'english',
                                                'Content-Type' => 'application/json'
                                            ],
                                            'json' => [
                                                'verify_type' => 'non_envato',
                                                'product_id' => $getNewLicenseOutput->product_id,
                                                'license_code' => $getNewLicenseOutput->license_code,
                                                'client_name' => $getNewLicenseOutput->client_name
                                            ]
                                        ]);

                                        $activateNewOutput = json_decode($activateNewResponse->getBody()->getContents());

                                        if ( $activateNewOutput->status == true ) {
                                            $settings->where('name','license_product_id')->update(['value' => $getNewLicenseOutput->product_id]);
                                            $settings->where('name','license_user')->update(['value' => $getNewLicenseOutput->client_name]);
                                            $settings->where('name','license_key')->update(['value' => $getNewLicenseOutput->license_code]);
                                            
                                            $settings->where('name','license_product_support_expiry')->update(['value' => $getNewLicenseOutput->support_expiry]);

                                            $settings->where('name','license_type')->update(['value' => $getNewLicenseOutput->license_type == 'Extended' ? '1' : '0']);
                                            $settings->where('name','subscription')->update(['value' => $getNewLicenseOutput->license_type == 'Extended' ? '1' : '0']);

                                            return back()->with('success', $activateNewOutput->message);

                                        } else {
                                            return back()->with('error', $activateNewOutput->message);
                                        }

                                    } catch (\Exception $e) {
                                        // Failed to activate the newly created license
                                        return back()->with('error', __('Failed to activate the newly created license.'));
                                    }

                                } else {
                                    return back()->with('error', __('Failed to retrieve new license information.'));
                                }

                            } catch (\Exception $e) {
                                // Failed to get the newly created license
                                return back()->with('error', __('Failed to get the newly created license.'));
                            }

                        } else {
                            return back()->with('error', __('Failed to create new license.'));
                        }

                    } catch (\Exception $e) {
                        // Failed to create new license
                        return back()->with('error', __('Failed to create new license.'));
                    }
                }

            } catch (\Exception $e) {
                // Failed to check whether product license exists
                return back()->with('error', __('Failed to check whether product license exists.'));
            }

            return redirect()->route('dashboard.admin.index');

        } else {
            return back()->with('error', __('License has already been activated.'));
        }

        Activity::createUserActivity($user->id, __('Updated'), __('License Settings'), null);

        return back()->with('success', __('License Settings Saved.'));
    }

    public function resetLicenseSettings(Request $request){

        $authUser = Auth::user();
        $settings = Setting::first();



        // Check whether user is authenticated.
        if ( $authUser != null) {
            // Check whether user has an admin role.
            if( $authUser->role == 'admin' ) {

                if( config('settings.license_key') != null ) {

                    $settings->where('name','license_product_id')->update(['value' => NULL]);
                    $settings->where('name','license_user')->update(['value' => NULL]);
                    $settings->where('name','license_key')->update(['value' => NULL]);
                    $settings->where('name','license_type')->update(['value' => NULL]);

                    return response()->json(["success" => __('License Settings Reset Successfully.')], 200);
                    
                } else {
                    return response()->json(['errors' => ['message' => __('License has already been reset.')]], 419 );
                }
            } else {
                return response()->json(['errors' => ['message' => __('You are not authorized.')]], 403 );
            } 
        } else {
            return response()->json(['errors' => ['message' => __('You are not authenticated.')]], 401 );
        }
            
        return false;
    }

    public function workStyles(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.work-styles', compact('settings'));
    }

    public function saveWorkStyleSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredWorkStyleRule = $request->cover_letter_work_style != '' ? 'required' : 'nullable';

        $request->validate([
            'cover_letter_work_style_artistic' => [$requiredWorkStyleRule, 'string', 'max:2000'],
            'cover_letter_work_style_enterprising' => [$requiredWorkStyleRule, 'string', 'max:2000'],
            'cover_letter_work_style_investigative' => [$requiredWorkStyleRule, 'string', 'max:2000'],
            'cover_letter_work_style_organized' => [$requiredWorkStyleRule, 'string', 'max:2000'],
            'cover_letter_work_style_practical' => [$requiredWorkStyleRule, 'string', 'max:2000'],
            'cover_letter_work_style_service_oriented' => [$requiredWorkStyleRule, 'string', 'max:2000'],
        ],[
            'cover_letter_work_style_artistic.required' => __('The Artistic Work Style field is required.'),
            'cover_letter_work_style_enterprising.required' => __('The Enterprising Work Style field is required.'),
            'cover_letter_work_style_investigative.required' => __('The Investigative Work Style field is required.'),
            'cover_letter_work_style_organized.required' => __('The Organized Work Style field is required.'),
            'cover_letter_work_style_practical.required' => __('The Practical Work Style field is required.'),
            'cover_letter_work_style_service_oriented.required' => __('The Service-Oriented Work Style field is required.')
        ]);

        $settings->where('name','cover_letter_work_style')->update(['value' => ( $request->cover_letter_work_style ? '1' : '0' )]);
        $settings->where('name','cover_letter_work_style_artistic')->update(['value' => $request->cover_letter_work_style_artistic]);
        $settings->where('name','cover_letter_work_style_enterprising')->update(['value' => $request->cover_letter_work_style_enterprising]);
        $settings->where('name','cover_letter_work_style_investigative')->update(['value' => $request->cover_letter_work_style_investigative]);
        $settings->where('name','cover_letter_work_style_organized')->update(['value' => $request->cover_letter_work_style_organized]);
        $settings->where('name','cover_letter_work_style_practical')->update(['value' => $request->cover_letter_work_style_practical]);
        $settings->where('name','cover_letter_work_style_service_oriented')->update(['value' => $request->cover_letter_work_style_service_oriented]);

        Activity::createUserActivity($user->id, __('Updated'), __('Work Style Settings'), null);

        return back()->with('success', __('Work Style Settings Saved.'));
    }

    public function openai(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.openai', compact('settings'));
    }

    public function saveOpenAISettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredOpenAIRule = $request->openai != '' ? 'required' : 'nullable';

        $request->validate([
            'openai_key' => [$requiredOpenAIRule, 'string', 'max:255'],
            'openai_completions_model' => [$requiredOpenAIRule, 'string', 'max:255'],
            'openai_creativity' => [$requiredOpenAIRule, 'numeric', 'between:0,100'],
            'openai_variations' => [$requiredOpenAIRule, 'numeric', 'between:0,100'],
            'openai_request_timeout' => [$requiredOpenAIRule, 'integer'],
            'openai_request_user_agent' => [$requiredOpenAIRule, 'string', 'max:255'],
            'openai_user_bio_prompt' => [$requiredOpenAIRule, 'string', 'max:1000'],
            'openai_resume_summary_prompt' => [$requiredOpenAIRule, 'string', 'max:1000'],
            'openai_resume_job_description_prompt' => [$requiredOpenAIRule, 'string', 'max:1000'],
            'openai_resume_volunteer_description_prompt' => [$requiredOpenAIRule, 'string', 'max:1000'],
            'openai_cover_letter_content_prompt' => [$requiredOpenAIRule, 'string', 'max:1000'],
        ],[
            'openai_key.required' => __('The API Key field is required.'),
            'openai_completions_model.required' => __('The Completions Model field is required.'),
            'openai_creativity.required' => __('The Creativity field is required.'),
            'openai_variations.required' => __('The Variations field is required.'),
            'openai_request_timeout.required' => __('The Request Timemout field is required.'),
            'openai_request_user_agent.required' => __('The Request User Agent field is required.'),
            'openai_user_bio_prompt.required' => __('The User Bio Prompt field is required.'),
            'openai_resume_summary_prompt.required' => __('The Professional Summary Prompt field is required.'),
            'openai_resume_job_description_prompt.required' => __('The Job Description Prompt field is required.'),
            'openai_resume_volunteer_description_prompt.required' => __('The Volunteer Description Prompt field is required.'),
            'openai_cover_letter_content_prompt.required' => __('The Cover Letter Content Prompt field is required.')
        ]);

        $settings->where('name','openai')->update(['value' => ( $request->openai ? '1' : '0' )]);
        $settings->where('name','openai_key')->update(['value' => $request->openai_key]);
        $settings->where('name','openai_completions_model')->update(['value' => $request->openai_completions_model]);
        $settings->where('name','openai_creativity')->update(['value' => $request->openai_creativity]);
        $settings->where('name','openai_variations')->update(['value' => $request->openai_variations]);
        $settings->where('name','openai_request_timeout')->update(['value' => $request->openai_request_timeout]);
        $settings->where('name','openai_request_user_agent')->update(['value' => $request->openai_request_user_agent]);
        $settings->where('name','openai_user_bio_prompt')->update(['value' => $request->openai_user_bio_prompt]);
        $settings->where('name','openai_resume_summary_prompt')->update(['value' => $request->openai_resume_summary_prompt]);
        $settings->where('name','openai_resume_job_description_prompt')->update(['value' => $request->openai_resume_job_description_prompt]);
        $settings->where('name','openai_resume_volunteer_description_prompt')->update(['value' => $request->openai_resume_volunteer_description_prompt]);
        $settings->where('name','openai_cover_letter_content_prompt')->update(['value' => $request->openai_cover_letter_content_prompt]);

        Activity::createUserActivity($user->id, __('Updated'), __('OpenAI Settings'), null);

        return back()->with('success', __('OpenAI Settings Saved.'));
    }

    public function billing(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.billing', compact('settings'));
    }

    public function saveBillingSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredBillingRule = config('settings.subscription') == '1' ? 'required' : 'nullable';

        $request->validate([
            'currency' => ['required', 'string', 'max:255'],
            'billing_vendor' => [$requiredBillingRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'billing_website' => [$requiredBillingRule, 'string', 'max:255'],
            'billing_phone' => [$requiredBillingRule, 'min:8', 'max:15'], // E164 phone numbers
            'billing_street' => [$requiredBillingRule, 'string', 'max:255'],
            'billing_city' => [$requiredBillingRule, 'string', 'max:100'],
            'billing_postal' => [$requiredBillingRule, 'string', 'max:10'],
            'billing_state' => ['sometimes', 'nullable', 'string', 'max:100'],
            'billing_country' => [$requiredBillingRule, 'string', 'max:255'],
            'billing_invoice_prefix' => [$requiredBillingRule, 'string', 'max:255'],
            'billing_vat_number' => ['sometimes', 'nullable', 'string', 'max:255'],
        ],[
            'currency.required' => __('The Default Currency field is required.'),
            'billing_vendor.required' => __('The Billing Vendor field is required.'),
            'billing_website.required' => __('The Billing Website field is required.'),
            'billing_phone.required' => __('The Billing Phone field is required.'),
            'billing_street.required' => __('The Billing Street field is required.'),
            'billing_city.required' => __('The Billing City field is required.'),
            'billing_postal.required' => __('The Billing Postal field is required.'),
            'billing_country.required' => __('The Billing Country field is required.'),
            'billing_invoice_prefix.required' => __('The Billing Invoice Prefix field is required.')
        ]);

        $settings->where('name','currency')->update(['value' => $request->currency]);
        $settings->where('name','billing_vendor')->update(['value' => $request->billing_vendor]);
        $settings->where('name','billing_website')->update(['value' => $request->billing_website]);
        $settings->where('name','billing_street')->update(['value' => $request->billing_street]);
        $settings->where('name','billing_city')->update(['value' => $request->billing_city]);
        $settings->where('name','billing_postal')->update(['value' => $request->billing_postal]);
        $settings->where('name','billing_state')->update(['value' => $request->billing_state]);
        $settings->where('name','billing_country')->update(['value' => $request->billing_country]);
        $settings->where('name','billing_phone')->update(['value' => $request->full_phone]);
        $settings->where('name','billing_invoice_prefix')->update(['value' => $request->billing_invoice_prefix]);
        $settings->where('name','billing_vat_number')->update(['value' => $request->billing_vat_number]);

        Activity::createUserActivity($user->id, __('Updated'), __('Billing Settings'), null);

        return back()->with('success', __('Billing Settings Saved.'));
    }

    public function processor(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.processor', compact('settings'));
    }

    public function saveProcessorSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredStripeRule = $request->stripe != '' ? 'required' : 'nullable';
        $requiredPaypalRule = $request->paypal != '' ? 'required' : 'nullable';
        $requiredRazorpayRule = $request->razorpay != '' ? 'required' : 'nullable';
        $requiredPaystackRule = $request->paystack != '' ? 'required' : 'nullable';
        $requiredCoinbaseRule = $request->coinbase != '' ? 'required' : 'nullable';
        $requiredCryptoRule = $request->crypto != '' ? 'required' : 'nullable';
        $requiredBankRule = $request->bank != '' ? 'required' : 'nullable';

        $request->validate([
            'stripe_publishable_key' => [$requiredStripeRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'stripe_secret_key' => [$requiredStripeRule, 'string', 'max:255'],
            'stripe_webhook_signing_secret' => [$requiredStripeRule, 'string', 'max:255'],
            'paypal_mode' => [$requiredPaypalRule, 'string', 'max:255'],
            'paypal_client_id' => [$requiredPaypalRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'paypal_client_secret' => [$requiredPaypalRule, 'string', 'max:255'],
            'paypal_email' => [$requiredPaypalRule, 'email', 'max:255'],
            'paypal_webhook_id' => [$requiredPaypalRule, 'string', 'max:255'],
            'razorpay_key_id' => [$requiredRazorpayRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'razorpay_key_secret' => [$requiredRazorpayRule, 'string', 'max:255'],
            'razorpay_webhook_secret' => [$requiredRazorpayRule, 'string', 'max:255'],
            'paystack_public_key' => [$requiredPaystackRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'paystack_secret_key' => [$requiredPaystackRule, 'string', 'max:255'],
            'coinbase_api_key' => [$requiredCoinbaseRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'coinbase_webhook_shared_secret' => [$requiredCoinbaseRule, 'string', 'max:255'],
            'crypto_publishable_key' => [$requiredCryptoRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'crypto_secret_key' => [$requiredCryptoRule, 'string', 'max:255'],
            'crypto_webhook_signature_secret' => [$requiredCryptoRule, 'string', 'max:255'],
            'bank_account_owner' => [$requiredBankRule, 'string', 'max:255'],
            'bank_name' => [$requiredBankRule, 'string', 'max:255', new ExtendedLicenseRule()],
            'bank_routing_number' => [$requiredBankRule, 'string', 'max:255'],
            'bank_account_number' => [$requiredBankRule, 'string', 'max:255'],
            'bank_bic_swift' => [$requiredBankRule, 'string', 'max:255'],
            'bank_iban' => [$requiredBankRule, 'string', 'max:255'],
        ],[
            'stripe_publishable_key.required' => __('The Stripe Publishable Key field is required.'),
            'stripe_secret_key.required' => __('The Stripe Secret Key field is required.'),
            'stripe_webhook_signing_secret.required' => __('The Stripe Webhook Signing Secret field is required.'),
            'paypal_mode.required' => __('The PayPal Mode field is required.'),
            'paypal_client_id.required' => __('The PayPal Client Id field is required.'),
            'paypal_client_secret.required' => __('The PayPal Client Secret field is required.'),
            'paypal_email.required' => __('The PayPal Email field is required.'),
            'paypal_email.email' => __('The PayPal Email field must be a valid email address.'),
            'paypal_webhook_id.required' => __('The PayPal Webhook Id field is required.'),
            'razorpay_key_id.required' => __('The Razorpay Key Id field is required.'),
            'razorpay_key_secret.required' => __('The Razorpay Key Secret field is required.'),
            'razorpay_webhook_secret.required' => __('The Razorpay Webhook Secret field is required.'),
            'paystack_public_key.required' => __('The Paystack Public Key field is required.'),
            'paystack_secret_key.required' => __('The Paystack Secret Key field is required.'),
            'coinbase_api_key.required' => __('The Coinbase API Key field is required.'),
            'coinbase_webhook_shared_secret.required' => __('The Coinbase Webhook Shared Secret field is required.'),
            'crypto_publishable_key.required' => __('The Crypto Publishable Key Id field is required.'),
            'crypto_secret_key.required' => __('The Crypto Secret Key field is required.'),
            'crypto_webhook_signature_secret.required' => __('The Crypto Webhook Signature Secret field is required.'),
            'bank_account_owner.required' => __('The Bank Owner field is required.'),
            'bank_name.required' => __('The Bank Name field is required.'),
            'bank_routing_number.required' => __('The Bank Routing number field is required.'),
            'bank_account_number.required' => __('The Bank Accounting Number field is required.'),
            'bank_bic_swift.required' => __('The Bank Swift Code field is required.'),
            'bank_iban.required' => __('The Bank Iban field is required.')
        ]);

        // Stripe
        $settings->where('name','stripe')->update(['value' => ( $request->stripe ? '1' : '0' )]);
        $settings->where('name','stripe_publishable_key')->update(['value' => $request->stripe_publishable_key]);
        $settings->where('name','stripe_secret_key')->update(['value' => $request->stripe_secret_key]);
        $settings->where('name','stripe_webhook_signing_secret')->update(['value' => $request->stripe_webhook_signing_secret]);

        // PayPal
        $settings->where('name','paypal')->update(['value' => ( $request->paypal ? '1' : '0' )]);
        $settings->where('name','paypal_mode')->update(['value' => $request->paypal_mode]);
        $settings->where('name','paypal_client_id')->update(['value' => $request->paypal_client_id]);
        $settings->where('name','paypal_client_secret')->update(['value' => $request->paypal_client_secret]);
        $settings->where('name','paypal_email')->update(['value' => $request->paypal_email]);
        $settings->where('name','paypal_webhook_id')->update(['value' => $request->paypal_webhook_id]);

        // Razorpay
        $settings->where('name','razorpay')->update(['value' => ( $request->razorpay ? '1' : '0' )]);
        $settings->where('name','razorpay_key_id')->update(['value' => $request->razorpay_key_id]);
        $settings->where('name','razorpay_key_secret')->update(['value' => $request->razorpay_key_secret]);
        $settings->where('name','razorpay_webhook_secret')->update(['value' => $request->razorpay_webhook_secret]);

        // Paystack
        $settings->where('name','paystack')->update(['value' => ( $request->paystack ? '1' : '0' )]);
        $settings->where('name','paystack_public_key')->update(['value' => $request->paystack_public_key]);
        $settings->where('name','paystack_secret_key')->update(['value' => $request->paystack_secret_key]);

        // Coinbase
        $settings->where('name','coinbase')->update(['value' => ( $request->coinbase ? '1' : '0' )]);
        $settings->where('name','coinbase_api_key')->update(['value' => $request->coinbase_api_key]);
        $settings->where('name','coinbase_webhook_shared_secret')->update(['value' => $request->coinbase_webhook_shared_secret]);

        // Crypto
        $settings->where('name','crypto')->update(['value' => ( $request->crypto ? '1' : '0' )]);
        $settings->where('name','crypto_publishable_key')->update(['value' => $request->crypto_publishable_key]);
        $settings->where('name','crypto_secret_key')->update(['value' => $request->crypto_secret_key]);
        $settings->where('name','crypto_webhook_signature_secret')->update(['value' => $request->crypto_webhook_signature_secret]);

        // Bank
        $settings->where('name','bank')->update(['value' => ( $request->bank ? '1' : '0' )]);
        $settings->where('name','bank_account_owner')->update(['value' => $request->bank_account_owner]);
        $settings->where('name','bank_name')->update(['value' => $request->bank_name]);
        $settings->where('name','bank_routing_number')->update(['value' => $request->bank_routing_number]);
        $settings->where('name','bank_account_number')->update(['value' => $request->bank_account_number]);
        $settings->where('name','bank_bic_swift')->update(['value' => $request->bank_bic_swift]);
        $settings->where('name','bank_iban')->update(['value' => $request->bank_iban]);


        Activity::createUserActivity($user->id, __('Updated'), __('Payment Processor Settings'), null);

        return back()->with('success', __('Payment Processor Settings Saved.'));
    }

    public function social(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.social', compact('settings'));
    }

    public function saveSocialLoginSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredFacebookRule = $request->facebook != '' ? 'required' : 'nullable';
        $requiredTwitterRule = $request->twitter != '' ? 'required' : 'nullable';
        $requiredLinkedinRule = $request->linkedin != '' ? 'required' : 'nullable';
        $requiredGoogleRule = $request->google != '' ? 'required' : 'nullable';
        $requiredGithubRule = $request->github != '' ? 'required' : 'nullable';

        $request->validate([
            'facebook_app_id' => [$requiredFacebookRule, 'string', 'max:255'],
            'facebook_app_secret' => [$requiredFacebookRule, 'string', 'max:255'],
            'facebook_redirect_url' => [$requiredFacebookRule, 'string', 'max:255'],
            'twitter_consumer_key' => [$requiredTwitterRule, 'string', 'max:255'],
            'twitter_consumer_secret' => [$requiredTwitterRule, 'string', 'max:255'],
            'twitter_redirect_url' => [$requiredTwitterRule, 'string', 'max:255'],
            'google_app_id' => [$requiredGoogleRule, 'string', 'max:255'],
            'google_app_secret' => [$requiredGoogleRule, 'string', 'max:255'],
            'google_redirect_url' => [$requiredGoogleRule, 'string', 'max:255'],
            'linkedin_app_id' => [$requiredLinkedinRule, 'string', 'max:255'],
            'linkedin_app_secret' => [$requiredLinkedinRule, 'string', 'max:255'],
            'linkedin_redirect_url' => [$requiredLinkedinRule, 'string', 'max:255'],
            'github_app_id' => [$requiredGithubRule, 'string', 'max:255'],
            'github_app_secret' => [$requiredGithubRule, 'string', 'max:255'],
            'github_redirect_url' => [$requiredGithubRule, 'string', 'max:255'],
        ],[
            'facebook_app_id.required' => __('The Facebook App Id field is required.'),
            'facebook_app_secret.required' => __('The Facebook App Secret field is required.'),
            'facebook_redirect_url.required' => __('The Facebook Redirect Url field is required.'),
            'twitter_consumer_key.required' => __('The Twitter Consumer Key field is required.'),
            'twitter_consumer_secret.required' => __('The Twitter Consumer Secret field is required.'),
            'twitter_redirect_url.required' => __('The Twitter Redirect Url field is required.'),
            'google_app_id.required' => __('The Google App Id field is required.'),
            'google_app_secret.required' => __('The Google App Secret field is required.'),
            'google_redirect_url.required' => __('The Google Redirect Url field is required.'),
            'linkedin_app_id.required' => __('The LinkedIn App Id field is required.'),
            'linkedin_app_secret.required' => __('The LinkedIn App Secret field is required.'),
            'linkedin_redirect_url.required' => __('The LinkedIn Redirect Url field is required.'),
            'github_app_id.required' => __('The GitHub App Id field is required.'),
            'github_app_secret.required' => __('The GitHub App Secret field is required.'),
            'github_redirect_url.required' => __('The GitHub Redirect Url field is required.')
        ]);

        $settings->where('name','facebook')->update(['value' => ( $request->facebook ? '1' : '0' )]);
        $settings->where('name','facebook_app_id')->update(['value' => $request->facebook_app_id]);
        $settings->where('name','facebook_app_secret')->update(['value' => $request->facebook_app_secret]);
        $settings->where('name','facebook_redirect_url')->update(['value' => $request->facebook_redirect_url]);
        $settings->where('name','twitter')->update(['value' => ( $request->twitter ? '1' : '0' )]);
        $settings->where('name','twitter_consumer_key')->update(['value' => $request->twitter_consumer_key]);
        $settings->where('name','twitter_consumer_secret')->update(['value' => $request->twitter_consumer_secret]);
        $settings->where('name','twitter_redirect_url')->update(['value' => $request->twitter_redirect_url]);
        $settings->where('name','linkedin')->update(['value' => ( $request->linkedin ? '1' : '0' )]);
        $settings->where('name','linkedin_app_id')->update(['value' => $request->linkedin_app_id]);
        $settings->where('name','linkedin_app_secret')->update(['value' => $request->linkedin_app_secret]);
        $settings->where('name','linkedin_redirect_url')->update(['value' => $request->linkedin_redirect_url]);
        $settings->where('name','google')->update(['value' => ( $request->google ? '1' : '0' )]);
        $settings->where('name','google_app_id')->update(['value' => $request->google_app_id]);
        $settings->where('name','google_app_secret')->update(['value' => $request->google_app_secret]);
        $settings->where('name','google_redirect_url')->update(['value' => $request->google_redirect_url]);
        $settings->where('name','github')->update(['value' => ( $request->github ? '1' : '0' )]);
        $settings->where('name','github_app_id')->update(['value' => $request->github_app_id]);
        $settings->where('name','github_app_secret')->update(['value' => $request->github_app_secret]);
        $settings->where('name','github_redirect_url')->update(['value' => $request->github_redirect_url]);

        $settings->save();

        $socialData = [
            'FACEBOOK_CLIENT_ID' => $request->facebook_app_id ?? config('settings.facebook_app_id'),
            'FACEBOOK_CLIENT_SECRET' => $request->facebook_app_secret ?? config('settings.facebook_app_secret'),
            'TWITTER_CLIENT_ID' => $request->twitter_consumer_key ?? config('settings.twitter_consumer_key'),
            'TWITTER_CLIENT_SECRET' => $request->twitter_consumer_secret ?? config('settings.twitter_consumer_secret'),
            'LINKEDIN_CLIENT_ID' => $request->linkedin_app_id ?? config('settings.linkedin_app_id'),
            'LINKEDIN_CLIENT_SECRET' => $request->linkedin_app_secret ?? config('settings.linkedin_app_secret'),
            'GOOGLE_CLIENT_ID' => $request->google_app_id ?? config('settings.google_app_id'),
            'GOOGLE_CLIENT_SECRET' => $request->google_app_secret ?? config('settings.google_app_secret'),
            'GITHUB_CLIENT_ID' => $request->github_app_id ?? config('settings.github_app_id'),
            'GITHUB_CLIENT_SECRET' => $request->github_app_secret ?? config('settings.github_app_secret'),
        ];

        $this->updateEnvMultiValues($socialData);

        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');

        Activity::createUserActivity($user->id, __('Updated'), __('Social Settings'), null);

        return back()->with('success', __('Social Settings Saved.'));
    }

    public function storage(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.storage', compact('settings'));
    }

    public function saveStorageSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredStorageRule = $request->storage_method == 's3' ? 'required' : 'nullable';

        $request->validate([
            'storage_method' => [$requiredStorageRule, 'string', 'max:255'],
            'storage_aws_s3_key' => [$requiredStorageRule, 'string', 'max:255'],
            'storage_aws_s3_secret' => [$requiredStorageRule, 'string', 'max:255'],
            'storage_aws_s3_region' => [$requiredStorageRule, 'string', 'max:255'],
            'storage_aws_s3_bucket' => [$requiredStorageRule, 'string', 'max:255'],
            'storage_aws_s3_endpoint' => [$requiredStorageRule, 'string', 'max:255'],
        ],[
            'storage_method.required' => __('The Storage Method field is required.'),
            'storage_aws_s3_key.required' => __('The Amazon S3 Key field is required.'),
            'storage_aws_s3_secret.required' => __('The Amazon S3 Secret field is required.'),
            'storage_aws_s3_region.required' => __('The Amazon S3 Region field is required.'),
            'storage_aws_s3_bucket.required' => __('The Amazon S3 Bucket field is required.'),
            'storage_aws_s3_endpoint.required' => __('The Amazon S3 Endpoint field is required.')
        ]);

        $settings->where('name','storage_method')->update(['value' => $request->storage_method]);
        $settings->where('name','storage_aws_s3_key')->update(['value' => $request->storage_aws_s3_key]);
        $settings->where('name','storage_aws_s3_secret')->update(['value' => $request->storage_aws_s3_secret]);
        $settings->where('name','storage_aws_s3_region')->update(['value' => $request->storage_aws_s3_region]);
        $settings->where('name','storage_aws_s3_bucket')->update(['value' => $request->storage_aws_s3_bucket]);
        $settings->where('name','storage_aws_s3_endpoint')->update(['value' => $request->storage_aws_s3_endpoint]);

        $storageData = [
            'FILESYSTEM_DISK' => $request->storage_method ?? config('settings.storage_method'),
            'AWS_ACCESS_KEY_ID' => $request->storage_aws_s3_key ?? config('settings.storage_aws_s3_key'),
            'AWS_SECRET_ACCESS_KEY' => $request->storage_aws_s3_secret ?? config('settings.storage_aws_s3_secret'),
            'AWS_DEFAULT_REGION' => $request->storage_aws_s3_region ?? config('settings.storage_aws_s3_region'),
            'AWS_BUCKET' => $request->storage_aws_s3_bucket ?? config('settings.storage_aws_s3_bucket'),
            'AWS_ENDPOINT' => $request->storage_aws_s3_endpoint ?? config('settings.storage_aws_s3_endpoint'),
        ];

        $this->updateEnvMultiValues($storageData);

        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');

        Activity::createUserActivity($user->id, __('Updated'), __('Storage Settings'), null);

        return back()->with('success', __('Storage Settings Saved.'));
    }

    public function smtp(){
        $settings = Setting::first();
        return view('dashboard.admin.settings.smtp', compact('settings'));
    }

    public function saveSmtpSettings(Request $request){
        
        $user = Auth::user();
        $settings = Setting::first();

        $requiredSmtpRule = $request->smtp != '' ? 'required' : 'nullable';

        $request->validate([
            'smtp_host' => [$requiredSmtpRule, 'string', 'max:255'],
            'smtp_port' => [$requiredSmtpRule, 'string', 'max:255'],
            'smtp_username' => ['nullable', 'string', 'max:255'],
            'smtp_password' => ['nullable', 'string', 'max:255'],
            'smtp_sender_email' => [$requiredSmtpRule, 'email', 'max:255'],
            'smtp_encryption' => [$requiredSmtpRule, 'string', 'max:255'],
        ],[
            'smtp_host.required' => __('The SMTP Host field is required.'),
            'smtp_port.required' => __('The SMTP Port field is required.'),
            'smtp_username.required' => __('The SMTP Username field is required.'),
            'smtp_password.required' => __('The SMTP Password field is required.'),
            'smtp_sender_email.required' => __('The SMTP Sender Email field is required.'),
            'smtp_sender_email.email' => __('The SMTP Sender Email field must be a valid email address.'),
            'smtp_encryption.required' => __('The SMTP Encryption field is required.')
        ]);

        $settings->where('name','smtp')->update(['value' => ( $request->smtp ? '1' : '0' )]);
        $settings->where('name','smtp_host')->update(['value' => $request->smtp_host]);
        $settings->where('name','smtp_port')->update(['value' => $request->smtp_port]);
        $settings->where('name','smtp_username')->update(['value' => $request->smtp_username]);
        $settings->where('name','smtp_password')->update(['value' => $request->smtp_password]);
        $settings->where('name','smtp_sender_email')->update(['value' => $request->smtp_sender_email]);
        $settings->where('name','smtp_encryption')->update(['value' => $request->smtp_encryption]);

        $smtpData = [
            'MAIL_MAILER' => 'smtp',
            'MAIL_HOST' => $request->smtp_host ?? config('settings.smtp_host'),
            'MAIL_PORT' => $request->smtp_port ?? config('settings.smtp_port'),
            'MAIL_USERNAME' => $request->smtp_username ?? config('settings.smtp_username'),
            'MAIL_PASSWORD' => $request->smtp_password ?? config('settings.smtp_password'),
            'MAIL_ENCRYPTION' => $request->smtp_encryption ?? config('settings.smtp_encryption'),
            'MAIL_FROM_ADDRESS' => $request->smtp_sender_email ?? config('settings.smtp_sender_email'),
        ];

        $this->updateEnvMultiValues($smtpData);

        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');

        Activity::createUserActivity($user->id, __('Updated'), __('SMTP Settings'), null);

        return back()->with('success', __('SMTP Settings Saved.'));
    }

    public function smtpTest(Request $request) {

        $request->validate([
            'test_email' => ['required', 'email', 'max:255'],
        ]);

        $toEmail =  $request->test_email;
        $toName = 'Test Email';

        try
        {
            Mail::raw('Email test content.', function ($message) use ($toEmail, $toName) {
                $message->to($toEmail, $toName)
                    ->subject('Test Email');
            });
            
            return back()->with('success', __('Test Email Sent.'));

        }catch (\Exception $exception){
            return $exception->getMessage();
        }
    }

    // Update .env array of variable parameters
    private function updateEnvMultiValues( $data = [] ) : void
    {  

        $path = base_path('.env');

        if (file_exists($path)) {
            foreach ($data as $key => $value) {
                file_put_contents($path, str_replace(
                    $key . '=' . env($key), $key . '=' . $value, file_get_contents($path)
                ));
            }
        }

    }

    // Update .env single variable parameter
    private function updateEnvSingleValue($envKey, $envValue) {
        $envFile = app()->environmentFilePath();
        $str = file_get_contents($envFile);

        $str .= "\n"; // In case the searched variable is in the last line without \n
        $keyPosition = strpos($str, "{$envKey}=");
        $endOfLinePosition = strpos($str, PHP_EOL, $keyPosition);
        $oldLine = substr($str, $keyPosition, $endOfLinePosition - $keyPosition);
        $str = str_replace($oldLine, "{$envKey}='{$envValue}'", $str);
        $str = substr($str, 0, -1);

        $fp = fopen($envFile, 'w');
        fwrite($fp, $str);
        fclose($fp);
    }
}
