<?php

namespace App\Http\Controllers;

use App\Mail\InvoiceMail;
use App\Models\Payment;
use App\Models\Coupon;
use App\Models\Plan;
use App\Models\User;
use App\Models\Activity;
use App\Models\Setting;
use App\Rules\ExtendedLicenseRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;

use PDF;

class PaymentController extends Controller
{
    public function index(){
        $items = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                        ->select('payments.id as p_id', 'payments.*', 'users.*', 'plans.*')
                            ->orderBy('payments.created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.payments.index', compact('items', 'settings'));
    }

    public function userPayments(){
        $user = Auth::user();

        $items = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('payments.user_id', '=', $user->id)
                            ->select('payments.id as p_id', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')
                            ->orderBy('payments.created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.user.payments.index', compact('items', 'settings'));
    }

    // All User Payments
    public function listPayments(Request $request){

        $columns = array( 
            0  => 'p_id', 
            1  => 'avatar',
            2  => 'firstname',
            3  => 'lastname',
            4  => 'p_plan_id',
            5  => 'invoice_id',
            6  => 'processor',
            7  => 'amount',
            8  => 'interval',
            9  => 'p_created_at',
            10 => 'payment_status',
            11 => 'p_id',
        );
  
        $totalData = Payment::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {            
            $payments = Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->select('payments.id as p_id', 'payments.plan_id as p_plan_id', 'payments.created_at as p_created_at', 'payments.*', 'users.*')
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order, $dir)
                                ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $payments =  Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->select('payments.id as p_id', 'payments.plan_id as p_plan_id', 'payments.created_at as p_created_at', 'payments.*', 'users.*')
                                    ->where('firstname', 'LIKE', "%{$search}%")
                                    ->orWhere('lastname', 'LIKE', "%{$search}%")
                                    ->orWhere('processor', 'LIKE', "%{$search}%")
                                    ->orWhere('amount', 'LIKE', "%{$search}%")
                                    ->orWhere('interval', 'LIKE', "%{$search}%")
                                    ->orWhere('payment_status', 'LIKE', "%{$search}%")
                                        ->offset($start)
                                        ->limit($limit)
                                        ->orderBy($order,$dir)
                                            ->get();

            $totalFiltered = Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->select('payments.id as p_id', 'payments.plan_id as p_plan_id', 'payments.created_at as p_created_at', 'payments.*', 'users.*')
                                        ->where('firstname', 'LIKE', "%{$search}%")
                                        ->orWhere('lastname', 'LIKE', "%{$search}%")
                                        ->orWhere('processor', 'LIKE', "%{$search}%")
                                        ->orWhere('amount', 'LIKE', "%{$search}%")
                                        ->orWhere('interval', 'LIKE', "%{$search}%")
                                        ->orWhere('payment_status', 'LIKE', "%{$search}%")
                                            ->count();
        }

        $data = array();
        if(!empty($payments))
        {
            foreach ($payments as $payment)
            {
                $show =  route('dashboard.admin.payments.index', $payment->p_id);
                $edit =  route('dashboard.admin.payments.edit', $payment->p_id);

                // Define payment status badge
                if( $payment->payment_status == 'completed') { 
                    $status_badge = 'class="badge badge-success"';
                } else { 
                    $status_badge = 'class="badge badge-warning"'; 
                }

                $avatar = ( $payment->avatar_path !=null ? $payment->avatar_path : ( $payment->avatar !=null ? asset($payment->avatar) : null ) ) ?? asset('img/avatar.png');

                $nestedData['p_id'] = $payment->p_id;
                $nestedData['avatar'] = '<img class="rounded-circle mr-3" width="35" src="'. $avatar .'" alt="avatar">';
                $nestedData['firstname'] = $payment->firstname;
                $nestedData['lastname'] = $payment->lastname;
                $nestedData['p_plan_id'] = '<a href="'. url('dashboard/admin/plans/item') .'/'. $payment->p_plan_id .'" class="badge badge-light text-truncate">'. getUserPlan($payment->p_plan_id) .'</a>';
                $nestedData['invoice_id'] = '<a href="'. url('dashboard/invoices/invoice') .'/'. $payment->invoice_id .'" class="badge badge-light text-truncate">'. ( config('settings.billing_invoice_prefix') ?? 'INV') .'-'. $payment->p_id .'</a>';
                $nestedData['processor'] = '<img class="rounded-circle mr-3" width="35" src="'. asset('img/payment/'. $payment->processor .'.png') .'" alt="'. __($payment->processor) .'">';
                $nestedData['amount'] = $payment->amount .' '. $payment->currency;
                $nestedData['interval'] = '<span class="badge badge-info text-truncate">'. __($payment->interval) .'</span>';
                $nestedData['p_created_at'] = date(config('settings.date_format'), strtotime($payment->p_created_at));
                $nestedData['payment_status'] = '<div '. $status_badge .'>'. __($payment->payment_status) .'</div>';
                $nestedData['options'] = '<div style="white-space:nowrap;">
                                            <a href="'. route('dashboard.admin.payments.edit', $payment->p_id) .'" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                            <a type="button" class="btn btn-danger delete-confirm-payment" data-payment-id="'. $payment->p_id .'"><i class="fa-solid fa-trash-alt"></i></a>
                                            </div>';
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
    }

    public function invoice($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        if($user->role == 'admin') {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('invoice_id', '=', $id)
                            ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->firstOrFail();
        } else {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('invoice_id', '=', $id)
                            ->where('payments.user_id', '=', $user->id)
                                ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->firstOrFail();
        }

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 0)->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 1)->sum('percentage');

        return view('dashboard.invoices.invoice', compact('payment', 'settings', 'inclTaxRatesPercentage', 'exclTaxRatesPercentage'));
    }

    public function invoiceViewPDF($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        if($user->role == 'admin') {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->join('plans', 'plans.id', '=', 'payments.plan_id')
                                ->where('invoice_id', '=', $id)
                                    ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->first();
        } else {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('invoice_id', '=', $id)
                            ->where('payments.user_id', '=', $user->id)
                                ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->firstOrFail();
        }

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 0)->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 1)->sum('percentage');

        $pdf = PDF::loadView('dashboard.invoices.pdf.invoice', ['payment' => $payment, 'settings' => $settings, 'inclTaxRatesPercentage' => $inclTaxRatesPercentage, 'exclTaxRatesPercentage' => $exclTaxRatesPercentage])
        ->setPaper('a4', 'portrait');

        // View PDF file
        return $pdf->stream();
           
    }

    public function invoiceDownloadPDF($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        if($user->role == 'admin') {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->join('plans', 'plans.id', '=', 'payments.plan_id')
                                ->where('invoice_id', '=', $id)
                                ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->first();
        } else {
            $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('invoice_id', '=', $id)
                            ->where('payments.user_id', '=', $user->id)
                            ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->firstOrFail();
        }

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 0)->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 1)->sum('percentage');

        $pdf = PDF::loadView('dashboard.invoices.pdf.invoice', ['payment' => $payment, 'settings' => $settings, 'inclTaxRatesPercentage' => $inclTaxRatesPercentage, 'exclTaxRatesPercentage' => $exclTaxRatesPercentage])
        ->setPaper('a4', 'portrait');

        // download PDF file with download method
        return $pdf->download(( config('settings.billing_invoice_prefix') ?? 'INV' ).'#'.$payment->p_id .'.pdf');
           
    }

    public function invoiceSendPDF($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                            ->join('plans', 'plans.id', '=', 'payments.plan_id')
                                ->where('invoice_id', '=', $id)
                                    ->select('payments.id as p_id', 'payments.tax_rates as p_tax_rates', 'payments.created_at as p_created_at', 'payments.*', 'users.*', 'plans.*')->first();

        // Sum the inclusive tax rates
        $inclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 0)->sum('percentage');

        // Sum the exclusive tax rates
        $exclTaxRatesPercentage = collect($payment->p_tax_rates)->where('type', '=', 1)->sum('percentage');

        $pdf = PDF::loadView('dashboard.invoices.pdf.invoice', ['payment' => $payment, 'settings' => $settings, 'inclTaxRatesPercentage' => $inclTaxRatesPercentage, 'exclTaxRatesPercentage' => $exclTaxRatesPercentage])
        ->setPaper('a4', 'portrait');

        $invoice = [
            'id' => $payment->invoice_id,
            'email' => $payment->email,
            'client' => $payment->firstname,
            'subject' => __('Invoice') .' #'. $payment->p_id .': '. ( $payment->payment_status == 'completed' ? __('Paid') : __('Unpaid') ),
            'payment_id' => $payment->p_id,
            'product_name' => $payment->product->name,
            'interval' => $payment->interval,
            'created_at' => $payment->created_at,
            'amount_month' => $payment->product->amount_month ?? null,
            'amount_year' => $payment->product->amount_year ?? null,
            'currency' => $payment->currency,
            'processor' => $payment->processor,
            'payment_status' => $payment->payment_status,
            'pdf'   => $pdf,
        ];

        // Only Admins can sent invoice out
        if($user->role == 'admin') {

            // Attempt to send the payment confirmation email
            try {
                Mail::to($invoice['email'])->send(new InvoiceMail($invoice));

                $statusType =  'success';
                $statusDesc = __('Email Sent Succesfully.');
            }
            catch (\Exception $e) { 
                $statusType =  'error';
                $statusDesc = __('Error Sending Email.') .' '. $e->getMessage();
            }

            return back()->with($statusType, $statusDesc);
            
        } else {
            abort(404);
        }
           
    }

    public function paymentEdit($id){
        $settings = Setting::first();

        $payment = Payment::join('users', 'users.id', '=', 'payments.user_id')
                        ->join('plans', 'plans.id', '=', 'payments.plan_id')
                            ->where('payments.id', '=', $id)
                                ->select('payments.id as p_id', 'users.id as u_id', 'plans.id as pl_id', 'payments.*', 'plans.*', 'users.*')
                                    ->firstOrFail();

        return view('dashboard.admin.payments.edit', compact('payment', 'settings'));
    }


    public function paymentSave(Request $request){

        $payment = Payment::where('id', $request->p_id)->firstOrFail();

        $request->validate([
            'user_id' => ['required', 'integer', new ExtendedLicenseRule()],
            'plan_id' => ['required', 'integer'],
            'payment_id' => ['required', 'string', 'max:255'],
            'processor' => ['sometimes'],
            'amount' => ['sometimes', 'numeric', 'gt:0', 'max:9999999999'],
            'currency' => ['sometimes'],
            'interval' => ['required', 'string', 'max:255'],
            'payment_status' => ['required', 'string', 'max:255']
        ],[
            'user_id.required' =>  __('The User Id field is required.'),
            'plan_id.required' =>  __('The Plan Id field is required.'),
            'payment_id.required' =>  __('The Payment Id field is required.'),
            'amount.numeric' =>  __('The Amount field must be a number.'),
            'amount.gt' =>  __('The Amount field must be greater than :value.'),
            'interval.required' =>  __('The Interval field is required.'),
            'payment_status.required' =>  __('The Payment Status field is required.')
        ]);

        $payment->user_id = $request->user_id;
        $payment->plan_id = $request->plan_id;
        $payment->payment_id = $request->payment_id;
        $payment->invoice_id = Str::lower( ( config('settings.billing_invoice_prefix') ?? 'INV' ) . str_replace('ch_', '', $request->payment_id) );
        $payment->processor = $request->processor;
        $payment->amount = $request->amount;
        $payment->currency = $request->currency;
        $payment->interval  = $request->interval;
        $payment->payment_status = $request->payment_status;
        $payment->updated_at = Carbon::now();

        $payment->save();

        Activity::createUserActivity(Auth::user()->id, __('Updated'), __('Payment Settings'), null);

        return back()->with(['message' => __('Payment Saved Succesfully.'), 'type' => 'success']);
    }

    public function paymentDelete($id){
        $payment = Payment::where('id', $id)->firstOrFail();
        $payment->delete();

        return response()->json(["success" => __('Payment Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Payment Deleted Succesfully.'), 'type' => 'success']);
    }
}
