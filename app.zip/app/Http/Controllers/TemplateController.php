<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Activity;
use App\Models\Setting;
use App\Models\Resume;
use App\Models\CoverLetter;
use App\Models\Template;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;

class TemplateController extends Controller
{
    public function index(){
        $items = Template::all();

        $settings = Setting::first();

        return view('dashboard.admin.templates.index', compact('items', 'settings'));
    }

    // All Templates
    public function listTemplates(Request $request){

        $columns = array( 
            0  => 'id', 
            1  => 'name',
            2  => 'image',
            3  => 'type',
            4  => 'top',
            4  => 'sidebar',
            4  => 'content',
            4  => 'status',
            5  => 'id',
        );
  
        $totalData = Template::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {            
            $templates = Template::select('*')
                            ->offset($start)
                                ->limit($limit)
                                    ->orderBy($order, $dir)
                                        ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $templates =  Template::where('name', 'LIKE', "%{$search}%")
                                ->offset($start)
                                    ->limit($limit)
                                        ->orderBy($order,$dir)
                                            ->get();

            $totalFiltered = Template::where('name', 'LIKE', "%{$search}%")->count();
        }

        $data = array();
        if(!empty($templates))
        {
            foreach ($templates as $template)
            {
                $show =  route('dashboard.admin.templates.index', $template->id);
                $edit =  route('dashboard.admin.templates.edit', $template->id);

                // Define status title and badge
                if( $template->status == '1') { 
                    $status_badge = 'class="badge badge-success"';
                    $status_title = __('Active');
                } else { 
                    $status_badge = 'class="badge badge-danger"'; 
                    $status_title = __('Inactive');
                }

                // Define top colors status title and badge
                if( $template->top_colors_status == '1') { 
                    $top_colors_status_badge = 'class="badge badge-success"';
                    $top_colors_status_title = __('Active');
                } else { 
                    $top_colors_status_badge = 'class="badge badge-danger"'; 
                    $top_colors_status_title = __('Inactive');
                }

                // Define sidebar colors status title and badge
                if( $template->sidebar_colors_status == '1') { 
                    $sidebar_colors_status_badge = 'class="badge badge-success"';
                    $sidebar_colors_status_title = __('Active');
                } else { 
                    $sidebar_colors_status_badge = 'class="badge badge-danger"'; 
                    $sidebar_colors_status_title = __('Inactive');
                }

                // Define content colors status title and badge
                if( $template->content_colors_status == '1') { 
                    $content_colors_status_badge = 'class="badge badge-success"';
                    $content_colors_status_title = __('Active');
                } else { 
                    $content_colors_status_badge = 'class="badge badge-danger"'; 
                    $content_colors_status_title = __('Inactive');
                }

                // Define type title and badge
                if( $template->type == 'R') { 
                    $type_badge = 'class="badge badge-primary"';
                    $type_title = __('Resume');
                    $type_path = 'resume';
                } else { 
                    $type_badge = 'class="badge badge-info"'; 
                    $type_title = __('Cover Letter');
                    $type_path = 'cover-letter';
                }

                $image = ( $template->image !=null ? asset($template->image) : asset('img/template/'. $type_path .'-template-'. $template->resource_id .'.jpg') );

                $nestedData['id'] = $template->id;
                $nestedData['name'] = $template->name;
                $nestedData['image'] = '<img class="mr-3" width="35" src="'. $image .'" alt="image">';
                $nestedData['type'] = '<div '. $type_badge .'>'. $type_title .'</div>';
                $nestedData['top'] = '<div '. $top_colors_status_badge .'>'. $top_colors_status_title .'</div>';
                $nestedData['sidebar'] = '<div '. $sidebar_colors_status_badge .'>'. $sidebar_colors_status_title .'</div>';
                $nestedData['content'] = '<div '. $content_colors_status_badge .'>'. $content_colors_status_title .'</div>';
                $nestedData['status'] = '<div '. $status_badge .'>'. $status_title .'</div>';
                $nestedData['options'] = '<div style="white-space:nowrap;">
                                            <a href="'. route('dashboard.admin.templates.edit', $template->id) .'" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                            <a type="button" class="btn btn-danger delete-confirm-template" data-template-id="'. $template->id .'"><i class="fa-solid fa-trash-alt"></i></a>
                                            </div>';
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
    }

    public function templateEdit($id){
        $settings = Setting::first();

        $template = Template::where('templates.id', '=', $id)
                        ->select('*')
                            ->firstOrFail();

        return view('dashboard.admin.templates.edit', compact('template', 'settings'));
    }

    public function templateSave(Request $request){

        $user = Auth::user();

        $template = Template::where('id', $request->template_id)->firstOrFail();

        $requiredTopColorsRule = $request->top_colors_status != '' ? 'required' : 'nullable';
        $requiredSidebarColorsRule = $request->sidebar_colors_status != '' ? 'required' : 'nullable';
        $requiredContentColorsRule = $request->content_colors_status != '' ? 'required' : 'nullable';

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'order' => ['required', 'integer'],
            'type' => ['required', 'string', Rule::in(['R','C'])],
            'top_position' => [$requiredTopColorsRule, 'string', Rule::in(['top','left', 'right'])],
            'top_background' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_header_background' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_header_title' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_header_description' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_subheader_background' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_subheader_title' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_subheader_byline' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'top_subheader_description' => [$requiredTopColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_position' => [$requiredSidebarColorsRule, 'string', Rule::in(['top','left', 'right'])],
            'sidebar_background' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_header_background' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_header_title' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_header_description' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_subheader_background' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_subheader_title' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_subheader_byline' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'sidebar_subheader_description' => [$requiredSidebarColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_position' => [$requiredContentColorsRule, 'string', Rule::in(['top','left', 'right'])],
            'content_background' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_header_background' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_header_title' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_header_description' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_subheader_background' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_subheader_title' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_subheader_byline' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'content_subheader_description' => [$requiredContentColorsRule, 'string', Rule::in(['Yes','No'])],
            'tpl_topbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidebgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidehddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_sidesubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_conthddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_contsubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
        ],[
            'name.required' =>  __('The Name field is required.'),
            'order.required' =>  __('The Order field is required.'),
            'type.required' =>  __('The Type field is required.'),
            'type.in' =>  __('The selected Type is invalid.'),
            'top_position.required' =>  __('The Top Position field is required.'),
            'top_position.in' =>  __('The selected Top Position is invalid.'),
            'top_background.required' =>  __('The Top Background field is required.'),
            'top_background.in' =>  __('The selected Top Background is invalid.'),
            'top_header_background.required' =>  __('The Top Header Background field is required.'),
            'top_header_background.in' =>  __('The selected Top Header Background is invalid.'),
            'top_header_title.required' =>  __('The Header Top Title field is required.'),
            'top_header_title.in' =>  __('The selected Top Header Title is invalid.'),
            'top_header_description.required' =>  __('The Top Header Description field is required.'),
            'top_header_description.in' =>  __('The selected Top Header Description is invalid.'),
            'top_subheader_background.required' =>  __('The Top Subheader Background field is required.'),
            'top_subheader_background.in' =>  __('The selected Top Subheader Background is invalid.'),
            'top_subheader_title.required' =>  __('The Top Subheader Title field is required.'),
            'top_subheader_title.in' =>  __('The selected Top Subheader Title is invalid.'),
            'top_subheader_byline.required' =>  __('The Top Subheader ByLine field is required.'),
            'top_subheader_byline.in' =>  __('The selected Top Subheader ByLine is invalid.'),
            'top_subheader_description.required' =>  __('The Top Subheader Description field is required.'),
            'top_subheader_description.in' =>  __('The selected Top Subheader Description is invalid.'),
            'sidebar_position.required' =>  __('The Sidebar Position field is required.'),
            'sidebar_position.in' =>  __('The selected Sidebar Position is invalid.'),
            'sidebar_background.required' =>  __('The Sidebar Background field is required.'),
            'sidebar_background.in' =>  __('The selected Sidebar Background is invalid.'),
            'sidebar_header_background.required' =>  __('The Sidebar Header Background field is required.'),
            'sidebar_header_background.in' =>  __('The selected Sidebar Header Background is invalid.'),
            'sidebar_header_title.required' =>  __('The Sidebar Header Title field is required.'),
            'sidebar_header_title.in' =>  __('The selected Sidebar Header Title is invalid.'),
            'sidebar_header_description.required' =>  __('The Sidebar Header Description field is required.'),
            'sidebar_header_description.in' =>  __('The selected Sidebar Header Description is invalid.'),
            'sidebar_subheader_background.required' =>  __('The Sidebar Subheader Background field is required.'),
            'sidebar_subheader_background.in' =>  __('The selected Sidebar Subheader Background is invalid.'),
            'sidebar_subheader_title.required' =>  __('The Sidebar Subheader Title field is required.'),
            'sidebar_subheader_title.in' =>  __('The selected Sidebar Subheader Title is invalid.'),
            'sidebar_subheader_byline.required' =>  __('The Sidebar Subheader ByLine field is required.'),
            'sidebar_subheader_byline.in' =>  __('The selected Sidebar Subheader ByLine is invalid.'),
            'sidebar_subheader_description.required' =>  __('The Sidebar Subheader Description field is required.'),
            'sidebar_subheader_description.in' =>  __('The selected Sidebar Subheader Description is invalid.'),
            'content_position.required' =>  __('The Content Position field is required.'),
            'content_position.in' =>  __('The selected Content Position is invalid.'),
            'content_background.required' =>  __('The Content Background field is required.'),
            'content_background.in' =>  __('The selected Content Background is invalid.'),
            'content_header_background.required' =>  __('The Content Header Background field is required.'),
            'content_header_background.in' =>  __('The selected Content Header Background is invalid.'),
            'content_header_title.required' =>  __('The Header Content Title field is required.'),
            'content_header_title.in' =>  __('The selected Content Header Title is invalid.'),
            'content_header_description.required' =>  __('The Content Header Description field is required.'),
            'content_header_description.in' =>  __('The selected Content Header Description is invalid.'),
            'content_subheader_background.required' =>  __('The Content Subheader Background field is required.'),
            'content_subheader_background.in' =>  __('The selected Content Subheader Background is invalid.'),
            'content_subheader_title.required' =>  __('The Content Subheader Title field is required.'),
            'content_subheader_title.in' =>  __('The selected Content Subheader Title is invalid.'),
            'content_subheader_byline.required' =>  __('The Content Subheader ByLine field is required.'),
            'content_subheader_byline.in' =>  __('The selected Content Subheader ByLine is invalid.'),
            'content_subheader_description.required' =>  __('The Content Subheader Description field is required.'),
            'content_subheader_description.in' =>  __('The selected Content Subheader Description is invalid.'),
        ]);
        
        $template->status = $request->status ? '1' : '0';

        $template->name = $request->name;
        $template->order = $request->order;
        $template->type = $request->type;

        // Upload Template Image 
        if ($request->hasFile('image')) {

            $imageRequestValidator = Validator::make($request->all(), [
                'image' => ['required','image','mimes:jpg,jpeg,png,gif,webp,svg','dimensions:min_width=300,min_height=450,ratio=2/3','max:1024']
            ]);

            if($imageRequestValidator->fails())
                return back()->with(['error' => $imageRequestValidator->errors()->first(), 'type' => 'error']);

            $image = $request->file('image');
            $image_name = 'template-'. ( $request->type == 'R' ? 'resume' : 'cover-letter' ) .'-'. time() .'.'. $image->getClientOriginalExtension();

            $image_path = 'uploads/';

            $imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            if ( !in_array(Str::lower($image->getClientOriginalExtension()), $imageTypes) ){
                return back()->with('error', __('The file extension must be jpg, jpeg, png, gif, webp or svg.'));
            }

            // Remove any existing stored image
            if( $template->image != '' && File::exists($image_path . $template->image) ) {
                unlink($image_path . $template->image);
            }
            
            $image->move($image_path, $image_name);

            if( !empty($image_path) && !empty($image_name) ) {

                $template->image = $image_path . $image_name;
            }
        }

        // Top Colors
        $top_colors = [
            'position' => $request->top_position,
            'background' => $request->top_background,
            'header_background' => $request->top_header_background,
            'header_title' => $request->top_header_title,
            'header_description' => $request->top_header_description,
            'subheader_background' => $request->top_subheader_background,
            'subheader_title' => $request->top_subheader_title,
            'subheader_byline' => $request->top_subheader_byline,
            'subheader_description' => $request->top_subheader_description
        ];

        $template->top_colors_status = $request->top_colors_status ? '1' : '0';
        $template->top_colors = $top_colors;

        // Top Default Colors
        $top_default_colors = [
            'background' => $request->tpl_topbgcolor ?? null,
            'header_background' => $request->tpl_tophdbgcolor ?? null,
            'header_title' => $request->tpl_tophdtltxtcolor ?? null,
            'header_description' => $request->tpl_tophddesctxtcolor ?? null,
            'subheader_background' => $request->tpl_topsubbgcolor ?? null,
            'subheader_title' => $request->tpl_topsubtltxtcolor ?? null,
            'subheader_byline' => $request->tpl_topsubbltxtcolor ?? null,
            'subheader_description' => $request->tpl_topsubdesctxtcolor ?? null
        ];

        $template->top_default_colors = $top_default_colors!=null && ( $request->type == 'R' || $request->type == 'C' ) ? $top_default_colors : null;

        // Sidebar Colors
        $sidebar_colors = [
            'position' => $request->sidebar_position,
            'background' => $request->sidebar_background,
            'header_background' => $request->sidebar_header_background,
            'header_title' => $request->sidebar_header_title,
            'header_description' => $request->sidebar_header_description,
            'subheader_background' => $request->sidebar_subheader_background,
            'subheader_title' => $request->sidebar_subheader_title,
            'subheader_byline' => $request->sidebar_subheader_byline,
            'subheader_description' => $request->sidebar_subheader_description
        ];

        $template->sidebar_colors_status = $request->sidebar_colors_status ? '1' : '0';
        $template->sidebar_colors = $sidebar_colors!=null && $request->type == 'R' ? $sidebar_colors : null;

        // Sidebar Default Colors
        $sidebar_default_colors = [
            'background' => $request->tpl_sidebgcolor ?? null,
            'header_background' => $request->tpl_sidehdbgcolor ?? null,
            'header_title' => $request->tpl_sidehdtltxtcolor ?? null,
            'header_description' => $request->tpl_sidehddesctxtcolor ?? null,
            'subheader_background' => $request->tpl_sidesubbgcolor ?? null,
            'subheader_title' => $request->tpl_sidesubtltxtcolor ?? null,
            'subheader_byline' => $request->tpl_sidesubbltxtcolor ?? null,
            'subheader_description' => $request->tpl_sidesubdesctxtcolor ?? null
        ];

        $template->sidebar_default_colors = $sidebar_default_colors!=null && $request->type == 'R' ? $sidebar_default_colors : null;

        // Content Colors
        $content_colors = [
            'position' => $request->content_position,
            'background' => $request->content_background,
            'header_background' => $request->content_header_background,
            'header_title' => $request->content_header_title,
            'header_description' => $request->content_header_description,
            'subheader_background' => $request->content_subheader_background,
            'subheader_title' => $request->content_subheader_title,
            'subheader_byline' => $request->content_subheader_byline,
            'subheader_description' => $request->content_subheader_description
        ];

        $template->content_colors_status = $request->content_colors_status ? '1' : '0';
        $template->content_colors = $content_colors!=null && $request->type == 'R' ? $content_colors : null;

        // Content Default Colors
        $content_default_colors = [
            'background' => $request->tpl_contbgcolor ?? null,
            'header_background' => $request->tpl_conthdbgcolor ?? null,
            'header_title' => $request->tpl_conthdtltxtcolor ?? null,
            'header_description' => $request->tpl_conthddesctxtcolor ?? null,
            'subheader_background' => $request->tpl_contsubbgcolor ?? null,
            'subheader_title' => $request->tpl_contsubtltxtcolor ?? null,
            'subheader_byline' => $request->tpl_contsubbltxtcolor ?? null,
            'subheader_description' => $request->tpl_contsubdesctxtcolor ?? null
        ];

        $template->content_default_colors = $content_default_colors!=null && $request->type == 'R' ? $content_default_colors : null;

        $template->save();

        Activity::createUserActivity(Auth::user()->id, __('Updated'), __('Template Settings'), null);

        return back()->with(['message' => __('Template Saved Succesfully.'), 'type' => 'success']);
    }

    public function templateDelete($id){
        $template = Template::where('id', $id)->firstOrFail();

        // Update appropriate resume and cover letter entries
        $templateType = $template->type;

        if($templateType!=null && $templateType == 'R') {
            Resume::where('template', $template->resource_id)->update(['template' => 1]);
        } else if($templateType!=null && $templateType == 'C') {
            CoverLetter::where('template', $template->resource_id)->update(['template' => 1]);
        }

        $template->delete();

        return response()->json(["success" => __('Template Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Template Deleted Succesfully.'), 'type' => 'success']);
    }
}
