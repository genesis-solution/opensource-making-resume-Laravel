<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Activity;
use App\Models\Setting;
use App\Models\SoftSkill;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;

class SoftSkillController extends Controller
{
    public function index(){
        $items = SoftSkill::all();

        $settings = Setting::first();

        return view('dashboard.admin.soft-skills.index', compact('items', 'settings'));
    }

    // All Soft Skills
    public function listSoftSkills(Request $request){

        $columns = array( 
            0  => 'id', 
            1  => 'keyword',
            2  => 'date',
            3  => 'status',
            4  => 'id',
        );
  
        $totalData = SoftSkill::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {            
            $softSkills = SoftSkill::select('*')
                            ->offset($start)
                                ->limit($limit)
                                    ->orderBy($order, $dir)
                                        ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $softSkills =  SoftSkill::where('keyword', 'LIKE', "%{$search}%")
                                ->offset($start)
                                    ->limit($limit)
                                        ->orderBy($order,$dir)
                                            ->get();

            $totalFiltered = SoftSkill::where('keyword', 'LIKE', "%{$search}%")->count();
        }

        $data = array();
        if(!empty($softSkills))
        {
            foreach ($softSkills as $softSkill)
            {
                $show =  route('dashboard.admin.soft-skills.index', $softSkill->id);
                $edit =  route('dashboard.admin.soft-skills.item', $softSkill->id);

                // Define status title and badge
                if( $softSkill->status == '1') { 
                    $status_badge = 'class="badge badge-success"';
                    $status_title = __('Active');
                } else { 
                    $status_badge = 'class="badge badge-danger"'; 
                    $status_title = __('Inactive');
                }

                $nestedData['id'] = $softSkill->id;
                $nestedData['keyword'] = $softSkill->keyword;
                $nestedData['date'] = date(config('settings.date_format'), strtotime($softSkill->created_at));
                $nestedData['status'] = '<div '. $status_badge .'>'. $status_title .'</div>';
                $nestedData['options'] = '<div style="white-space:nowrap;">
                                            <a href="'. route('dashboard.admin.soft-skills.item', $softSkill->id) .'" class="btn btn-warning"><i class="fa-solid fa-pencil-alt"></i></a>
                                            <a type="button" class="btn btn-danger delete-confirm-item" data-item-id="'. $softSkill->id .'"><i class="fa-solid fa-trash-alt"></i></a>
                                            </div>';
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
    }

    public function softSkillCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = SoftSkill::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.soft-skills.edit', compact('item', 'settings'));
    }

    public function softSkillCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = SoftSkill::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new SoftSkill();
        }

        $requiredSoftSkillRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'keyword' => [$requiredSoftSkillRule, 'string', 'max:255'],
        ],[
            'keyword.required' => __('The Keyword field is required.'),
        ]);

        $item->status = $request->status ? '1' : '0';
        
        $keyword = trim(strip_tags($request->keyword));

        // Remove non-word and non-space characters, except dashes and spaces from your unicode string.
        $keyword = preg_replace('/[^\p{L}\p{N}\s-]+/u', '', $keyword); 

        $item->keyword = $keyword;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Soft Skill'), null);

        return back()->with(['message' => __('Soft Skill Saved Succesfully.'), 'type' => 'success']);
    }

    public function softSkillDelete($id){
        $item = SoftSkill::where('id', $id)->firstOrFail();
        $item->delete();

        return response()->json(["success" => __('Soft Skill Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Soft Skill Deleted Succesfully.'), 'type' => 'success']);
    }
}
