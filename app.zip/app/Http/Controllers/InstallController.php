<?php

namespace App\Http\Controllers;

use App\Models\User;
use GuzzleHttp\Client as HttpClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;

class InstallController extends Controller
{
    // Start Installation
    public function index()
    {
        return view('install.index');
    }

    // Requirements
    public function requirements()
    {
        $requirements = config('install.extensions');

        $results = [];
        // Check the requirements
        foreach ($requirements as $type => $extensions) {
            if (strtolower($type) == 'php') {
                foreach ($requirements[$type] as $extensions) {
                    $results['extensions'][$type][$extensions] = true;

                    if (!extension_loaded($extensions)) {
                        $results['extensions'][$type][$extensions] = false;

                        $results['errors'] = true;
                    }
                }
            } elseif (strtolower($type) == 'apache') {
                foreach ($requirements[$type] as $extensions) {
                    // Check whether the function exists and prevent from returning false errors
                    if (function_exists('apache_get_modules')) {
                        $results['extensions'][$type][$extensions] = true;

                        if (!in_array($extensions, apache_get_modules())) {
                            $results['extensions'][$type][$extensions] = false;

                            $results['errors'] = true;
                        }
                    }
                }
            }
        }

        // Current php version doesn't meet requirements
        if (version_compare(PHP_VERSION, config('install.php_version')) == -1) {
            $results['errors'] = true;
        }

        return view('install.requirements', compact('results'));
    }

    // Permissions
    public function permissions()
    {
        $permissions = config('install.permissions');

        $results = [];
        foreach ($permissions as $type => $files) {
            if($type == 'Files') {
                $fileMode = '674';
            } elseif($type == 'Folders') {
                $fileMode = '775';
            } 
            foreach ($files as $file) {
                if( ( PHP_OS_FAMILY === 'Linux' && $fileMode === decoct(fileperms(base_path($file)) & 0777) && is_writable(base_path($file)) ) 
                        || ( PHP_OS_FAMILY === 'Windows' && is_writable(base_path($file)) ) 
                ) {
                    $results['permissions'][$type][$file] = true;
                } else {
                    $results['permissions'][$type][$file] = false;
                    $results['errors'] = true;
                }
            }
        }

        return view('install.permissions', compact('results'));
    }

    // Database configuration
    public function database()
    {
        return view('install.database');
    }

    // Admin credentials
    public function account()
    {
        return view('install.account');
    }

    // Complete
    public function complete()
    {
        return view('install.complete');
    }

    // Save Database Credentials in the .env config file
    public function saveDatabaseCredentials(Request $request)
    {

        $request->validate([
            'database_hostname' => ['required', 'string', 'max:50'],
            'database_port' => ['required', 'numeric'],
            'database_name' => ['required', 'string', 'max:50'],
            'database_username' => ['required', 'string', 'max:50'],
            'database_password' => ['nullable', 'string', 'max:50'],
        ],[
            'database_hostname.required' => __('The Database Hostname field is required.'),
            'database_port.required' => __('The Database Port field is required.'),
            'database_name.required' => __('The Database Name field is required.'),
            'database_username.required' => __('The Database Username field is required.')
        ]);

        $validateDatabase = $this->validateDatabaseCredentials($request);
        if ($validateDatabase !== true) {
            return back()->with('error', __('Invalid database credentials.') .' '. $validateDatabase)->withInput();
        }

        $validateConfigFile = $this->writeEnvFile($request);
        if ($validateConfigFile !== true) {
            return back()->with('error', __('Unable to save .env file, check file permissions.') .' '. $validateConfigFile)->withInput();
        }

        return redirect()->route('install.account');
    }

    // Migrate the database, add the admin user
    public function migrateDatabase(Request $request)
    {
        $request->validate([
            'firstname' => ['required', 'string', 'max:255'],
            'lastname'  => ['required', 'string', 'max:255'],
            'email'     => ['required', 'string', 'email', 'max:255'],
            'password'  => ['required', 'string', 'min:6', 'max:128', 'confirmed'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' => __('The Last Name field is required.'),
            'email.required' => __('The Email field is required.'),
            'email.email' => __('The Email field must be a valid email address.'),
            'password.required' => __('The Password field is required.')
        ]);

        $migrateDatabase = $this->forceMigrateDatabase();
        if ($migrateDatabase !== true) {
            return back()->with('error', __('Failed to migrate the database.') .' '. $migrateDatabase)->withInput();
        }

        $createAdminUser = $this->createAdminUser($request);
        if ($createAdminUser !== true) {
            return back()->with('error', __('Failed to create the admin user.') .' '. $createAdminUser)->withInput();
        }

        $saveInstalledFile = $this->writeEnvInstalledStatus();
        if ($saveInstalledFile !== true) {
            return back()->with('error', __('Failed to finalize the installation.') .' '. $saveInstalledFile)->withInput();
        }

        return redirect()->route('install.complete');
    }

    // Validate Database Credentials
    private function validateDatabaseCredentials(Request $request)
    {
        $settings = config("database.connections.mysql");

        config([
            'database' => [
                'default' => 'mysql',
                'connections' => [
                    'mysql' => array_merge($settings, [
                        'driver' => 'mysql',
                        'host'      => $request->input('database_hostname'),
                        'port'      => $request->input('database_port'),
                        'database'  => $request->input('database_name'),
                        'username'  => $request->input('database_username'),
                        'password'  => $request->input('database_password'),
                    ]),
                ],
            ],
        ]);

        DB::purge();

        try {

            DB::connection()->getPdo();

            return true;

        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    // Force Migrate the database using artisan command line
    private function forceMigrateDatabase()
    {
        try {

            Artisan::call('migrate', ['--force' => true]);

            return true;

        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    // Create the admin user.
    private function createAdminUser(Request $request)
    {
        try {

            $user = new User;

            $user->firstname = $request->input('firstname');
            $user->lastname = $request->input('lastname');
            $user->email = $request->input('email');
            $user->password = Hash::make($request->input('password'));
            $user->role = 'admin';
            $user->timezone = 'America/Chicago';
            $user->address = [
                'street' => '', 
                'city' => '', 
                'state' => '', 
                'postal' => '', 
                'country' => '',
            ];
            $user->social = [
                'facebook' => '', 
                'twitter' => '', 
                'linkedin' => '', 
                'pinterest' => '', 
                'youtube' => '',
                'github' => '',
                'behance' => '',
                'instagram' => '',
                'tiktok' => '',
            ];
            $user->plan_id = '1';
            $user->status = '1';
            $user->created_at = Carbon::now();
            $user->updated_at = Carbon::now();

            $user->save();

            $user->markEmailAsVerified();

        } catch (\Exception $e) {
            return $e->getMessage();
        }

        return true;
    }

    // Write the .env config file.
    private function writeEnvFile(Request $request)
    {
        $config =
            "APP_NAME='".config('info.software.name')."'\n".
            "APP_ENV=production\n".
            "APP_KEY=base64:'".base64_encode(Str::random(32))."'\n".
            "APP_DEBUG=false\n".
            "APP_URL='". route('landing') ."'\n".
            "\n".
            "LOG_CHANNEL=stack\n".
            "LOG_DEPRECATIONS_CHANNEL=null\n".
            "LOG_LEVEL=debug\n".
            "\n".
            "DB_CONNECTION=mysql\n".
            "DB_HOST='".$request->input('database_hostname')."'\n".
            "DB_PORT=".$request->input('database_port')."\n".
            "DB_DATABASE='".$request->input('database_name')."'\n".
            "DB_USERNAME='".$request->input('database_username')."'\n".
            "DB_PASSWORD='".$request->input('database_password')."'\n".
            "\n".
            "BROADCAST_DRIVER=log\n".
            "CACHE_DRIVER=file\n".
            "FILESYSTEM_DISK=local\n".
            "QUEUE_CONNECTION=sync\n".
            "SESSION_DRIVER=file\n".
            "SESSION_LIFETIME=120\n".
            "\n".
            "MEMCACHED_HOST=127.0.0.1\n".
            "\n".
            "REDIS_HOST=127.0.0.1\n".
            "REDIS_PASSWORD=null\n".
            "REDIS_PORT=6379\n".
            "\n".
            "MAIL_MAILER=smtp\n".
            "MAIL_HOST=smtp.mailtrap.io\n".
            "MAIL_PORT=2525\n".
            "MAIL_USERNAME=null\n".
            "MAIL_PASSWORD=null\n".
            "MAIL_ENCRYPTION=null\n".
            "MAIL_FROM_ADDRESS=null\n".
            "MAIL_FROM_NAME=\"\${APP_NAME}\"\n".
            "\n".
            "AWS_ACCESS_KEY_ID=\n".
            "AWS_SECRET_ACCESS_KEY=\n".
            "AWS_DEFAULT_REGION=us-east-1\n".
            "AWS_BUCKET=\n".
            "AWS_ENDPOINT=\n".
            "AWS_USE_PATH_STYLE_ENDPOINT=false\n".
            "\n".
            "FACEBOOK_CLIENT_ID=\n".
            "FACEBOOK_CLIENT_SECRET=\n".
            "\n".
            "TWITTER_CLIENT_ID=\n".
            "TWITTER_CLIENT_SECRET=\n".
            "\n".
            "LINKEDIN_CLIENT_ID=\n".
            "LINKEDIN_CLIENT_SECRET=\n".
            "\n".
            "GOOGLE_CLIENT_ID=\n".
            "GOOGLE_CLIENT_SECRET=\n".
            "\n".
            "GITHUB_CLIENT_ID=\n".
            "GITHUB_CLIENT_SECRET=\n".
            "\n".
            "GOOGLE_RECAPTCHA_KEY=\n".
            "GOOGLE_RECAPTCHA_SECRET=\n".
            "\n".
            "APP_TIMEZONE=America/Chicago\n".
            "\n".
            "APP_LANGUAGE=en\n".
            "\n".
            "PUSHER_APP_ID=\n".
            "PUSHER_APP_KEY=\n".
            "PUSHER_APP_SECRET=\n".
            "PUSHER_HOST=\n".
            "PUSHER_PORT=443\n".
            "PUSHER_SCHEME=https\n".
            "PUSHER_APP_CLUSTER=mt1\n".
            "\n".
            "VITE_PUSHER_APP_KEY=\"\${PUSHER_APP_KEY}\"\n".
            "VITE_PUSHER_HOST=\"\${PUSHER_HOST}\"\n".
            "VITE_PUSHER_PORT=\"\${PUSHER_PORT}\"\n".
            "VITE_PUSHER_SCHEME=\"\${PUSHER_SCHEME}\"\n".
            "VITE_PUSHER_APP_CLUSTER=\"\${PUSHER_APP_CLUSTER}\"";

        try {

            file_put_contents(base_path('.env'), $config);

        } catch (\Exception $e) {
            return $e->getMessage();
        }

        return true;
    }

    // Write Installed Status to the .env config file.
    private function writeEnvInstalledStatus()
    {
        try {

            file_put_contents(base_path('.env'), "\n\nAPP_INSTALLED=true", FILE_APPEND);

        } catch (\Exception $e) {
            return $e->getMessage();
        }

        return true;
    }

}
