<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Frontend;
use App\Models\FrontendNav;
use App\Models\FrontendFooter;
use App\Models\CoverLetter;
use App\Models\User;
use App\Models\Plan;
use App\Models\Setting;
use App\Models\Template;
use App\Traits\OpenAITrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Validator;

use SimpleSoftwareIO\QrCode\Facades\QrCode;
use PDF;

class CoverLetterController extends Controller
{
    use OpenAITrait;

    public function index(){
        $user = Auth::user();
        $settings = Setting::first();

        $coverLetters = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                        ->where('cover_letters.user_id', '=', $user->id)
                            ->select('cover_letters.id as cl_id', 'cover_letters.status as cl_status', 'cover_letters.privacy as cl_privacy', 'cover_letters.created_at as cl_created_at', 'cover_letters.*', 'users.*')
                                ->orderBy('cover_letters.created_at', 'desc')->paginate(10);

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $cover_letter_left = $user->canCreateNewCoverLetter()['number'];
        $cover_letter_left_description = $user->canCreateNewCoverLetter()['description'];

        $exportCoverLetter = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_cover_letters!=null 
                                    && $plan->features->export_cover_letters == '0' ) 
                                      ? '0' : '1' ) : '1' );

        return view('dashboard.user.cover-letters.index', compact('user', 'settings', 'coverLetters', 'cover_letter_left', 'cover_letter_left_description', 'exportCoverLetter'));
    }

    public function shareUserCoverLetter($id = null){
        $settings = Setting::first();

        $frontend = Frontend::first();
        $navs = FrontendNav::all()->sortBy('order'); // Ascending Order
        
        $footer = FrontendFooter::join('categories', 'frontend_footers.category_id', '=', 'categories.id')
                    ->select('categories.title as c_title', 'frontend_footers.title as f_title', 'frontend_footers.url as f_url', 'frontend_footers.category_id', 'categories.footer_order as c_order', 'frontend_footers.order as f_order', 'categories.status as c_status', 'frontend_footers.status as f_status')
                        ->where('frontend_footers.status', '=', '1')
                            ->where('categories.status', '=', '1')
                                ->orderBy('c_order', 'ASC')->get();

        $coverLetter = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                        ->where('cover_letters.cover_letter_id', '=', $id)
                        ->where('cover_letters.status', '=', '1')
                            ->select('cover_letters.id as cl_id', 'cover_letters.status as cl_status', 'cover_letters.privacy as cl_privacy', 'cover_letters.*', 'users.*')->firstOrFail();

        $user = User::where('id', '=', $coverLetter->user_id)->where('status', '=', '1')->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $template = Template::where('status', '=', '1')
                        ->where('type', '=', 'C')
                            ->where('resource_id', '=', $coverLetter->template)->firstOrFail();

        $watermark = ( config('settings.watermark') == '1'
                        && $plan->features!=null 
                            && $plan->features->white_label_cover_letters!=null 
                                && $plan->features->white_label_cover_letters == '0' ) 
                                    ? '1' : '0';

        // The privacy is not set to public
        if($coverLetter->cl_privacy !== '0') {
            $authUser = Auth::user();

            // The privacy is set to private
            if ($coverLetter->cl_privacy == '1') {
                // The user is not authenticated, link owner or an admin
                if ( $authUser == null || ( $authUser->id != $coverLetter->user_id && $authUser->role != 'admin' ) ) {
                    abort(403);
                } else if ( ( $authUser != null && $authUser->id == $coverLetter->user_id ) || $authUser->role == 'admin' ) {
                    // Increase the cover letter view based on provided cover letter id
                    CoverLetter::where('cover_letters.cover_letter_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                    return view('dashboard.user.cover-letters.share', compact('user', 'coverLetter', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                }
            }

            // The privacy is set to password protected
            if ($coverLetter->cl_privacy == '2') {
                // No current session password validation
                if (!session(md5($coverLetter->cover_letter_id))) {
                    // The user is not authenticated, link owner or an admin
                    if ( $authUser == null || ( $authUser->id != $coverLetter->user_id && $authUser->role != 'admin' ) ) {
                        return view('dashboard.user.cover-letters.password', compact('coverLetter', 'settings'));
                    } else if ( ( $authUser != null && $authUser->id == $coverLetter->user_id ) || $authUser->role == 'admin' ) {
                        // Increase the cover letter view based on provided cover letter id
                        CoverLetter::where('cover_letters.cover_letter_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                        return view('dashboard.user.cover-letters.share', compact('user', 'coverLetter', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                    }
                } else {
                    // Increase the cover letter view based on provided cover letter id
                    CoverLetter::where('cover_letters.cover_letter_id', '=', $id)->update(['views' => DB::raw('views + 1')]);

                    return view('dashboard.user.cover-letters.share', compact('user', 'coverLetter', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
                }
            }
        } else {
            // Increase the cover letter view based on provided cover letter id
            CoverLetter::where('cover_letters.cover_letter_id', '=', $id)->update(['views' => DB::raw('views + 1')]);
            
            return view('dashboard.user.cover-letters.share', compact('user', 'coverLetter', 'template', 'watermark', 'frontend', 'navs', 'footer', 'settings'));
        }
    }

    public function shareUserQrCodeCoverLetter($id = null){

        $coverLetter = CoverLetter::where('id', '=', $id)->firstOrFail();

        if($coverLetter!=null && $coverLetter->cover_letter_id!=null) {
            $dataQrCode = QrCode::size(512)
                ->generate(
                    config('settings.site_url') .'/c/'. $coverLetter->cover_letter_id,
                );

            return response($dataQrCode)
                ->header('Content-type', 'image/svg+xml');
        } else {
            abort(404);
        }
    }

    public function validateCoverLetterPassword(Request $request) {

        $request->validate([
            'cover_letter_id' => ['required', 'alpha_num'],
            'password' => ['required', 'string'],
        ],[
            'cover_letter_id.required' => __('The Cover Letter Id field is required.'),
            'password.required' => __('The Password field is required.')
        ]);

        // Get the provided password
        $coverLetter = CoverLetter::where('cover_letter_id', '=', $request->cover_letter_id)->firstOrFail();

        // Check whether the password exists
        if ( $coverLetter != null ) {
            if ( $request->password === $coverLetter->password) {
                //return response()->json(['success' => 'The password is valid.'], 200 );
                // Set Session for this cover letter id
                session([md5($request->cover_letter_id) => true]);
                // redirect back
                return back()->with(['message' => __('Password Validated Successfully.'), 'type' => 'success']);
            } else {
                return response()->json(['errors' => ['message' => __('The password is invalid.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('The password is not found.')]], 419 );
        }
        return false;
    }

    public function generateWorkStyleBasedContent(Request $request, string $style = null)
    {
        $user = Auth::user();

        if( config('settings.cover_letter_work_style') ) {

            if($request->professional_title!=null) {
                if($request->job_title!=null && $request->company_name!=null) {
                    if($request->skills!=null) {

                        $skillArray = preg_split("/\s*,\s*/", $request->skills, -1, PREG_SPLIT_NO_EMPTY);

                        $skill1 = $skillArray[0] ?? '[Skill1]';
                        $skill2 = $skillArray[1] ?? '[Skill2]';
                        $skill3 = $skillArray[2] ?? '[Skill3]';

                        if($style!=null) {

                            switch($style) {
                                case 'artistic':
                                    $content = config('settings.cover_letter_work_style_artistic');
                                break;
                                case 'enterprising':
                                    $content = config('settings.cover_letter_work_style_enterprising');
                                break;
                                case 'investigative':
                                    $content = config('settings.cover_letter_work_style_investigative');
                                break;
                                case 'organized':
                                    $content = config('settings.cover_letter_work_style_organized');
                                break;
                                case 'practical':
                                    $content = config('settings.cover_letter_work_style_practical');
                                break;
                                case 'service-oriented':
                                    $content = config('settings.cover_letter_work_style_service_oriented');
                                break;
                                default:
                                    $content = config('settings.cover_letter_work_style_artistic');
                                break;
                            }

                            // Replace content theme variables
                            $content = str_replace(':tJobTitle', $request->job_title, $content);
                            $content = str_replace(':cJobTitle', $request->professional_title, $content);
                            $content = str_replace(':company', $request->company_name, $content);

                            $content = str_replace(':skill1', $skill1, $content);
                            $content = str_replace(':skill2', $skill2, $content);
                            $content = str_replace(':skill3', $skill3, $content);

                            if( $content != null ) {

                                return response()->json(['success' => ['content' => $content]], 200 );

                            } else {
                                return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                            }

                        } else {
                            return response()->json(['errors' => ['message' => __('Provide a valid work style name.')]], 419 );
                        } 
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide three skills in order of importance.')]], 419 );
                    } 
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your target job title and company name.')]], 419 );
                }
            } else {
                return response()->json(['errors' => ['message' => __('Provide your professional title.')]], 419 );
            }
            
        } else {
            return response()->json(['errors' => ['message' => __('Work Styles are not enabled.')]], 419 );
        }
        return false;
    }

    public function generateAICoverLetterContent(Request $request, string $prompt = null)
    {
        $user = Auth::user();

        if( config('settings.openai') && config('settings.openai_key') !=null ) {

            $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];

            if( $aiGeneratedContentLeft != 0 ) {
                if($request->professional_title!=null) {
                    if($request->professional_yoe!=null) {
                        if($request->job_title!=null && $request->company_name!=null) {
                            if($request->skills!=null) {
                                $prompt = config('settings.openai_cover_letter_content_prompt');

                                // Replace prompt theme variables
                                $prompt = str_replace(':ptitle', $request->professional_title, $prompt);
                                $prompt = str_replace(':pyoe', $request->professional_yoe, $prompt);
                                $prompt = str_replace(':jtitle', $request->job_title, $prompt);
                                $prompt = str_replace(':company', $request->company_name, $prompt);
                                $prompt = str_replace(':skills', $request->skills, $prompt);
                                $prompt = str_replace(':lang', config('languages')[config('settings.language')]['iso'], $prompt);

                                $response = $this->openAICompletions($request, $prompt);

                                // Check whether the response is returned empty
                                if( $response != null ) {
                                    $content = $response['choices'][0]['message']['content'] ?? null;

                                    // Remove header and signature of cover letter
                                    $content = str_replace("[Your Name]", "", $content);
                                    $content = str_replace("[Your Address]", "", $content);
                                    $content = str_replace("[City, State ZIP Code]", "", $content);
                                    $content = str_replace("[City, State, ZIP Code]", "", $content);
                                    $content = str_replace("[Email Address]", "", $content);
                                    $content = str_replace("[Phone Number]", "", $content);
                                    $content = str_replace("[Date]", "", $content);
                                    $content = str_replace("[Today's Date]", "", $content);
                                    $content = str_replace("Dear [Recipient's Name],", "", $content);
                                    $content = str_replace("[Recipient's Name]", "", $content);
                                    $content = str_replace("[Recipient's Job Title]", "", $content);
                                    $content = str_replace("Dear Hiring Manager,", "", $content);
                                    $content = str_replace("Sincerely,", "", $content);

                                    // Replace enter with break
                                    $content = str_replace(["\r\n", "\r", "\n"], "<br>", $content);

                                    // Remove header company name or company address, without removing it from body part
                                    $content = str_replace("[Company Name]<br>[Company Address]", "", $content);

                                    // Remove accessive empty spaces replaced with break
                                    $content = preg_replace("/(<br\s*\/?><br\s*\/?><br\s*\/?><br\s*\/?>\s*)+/", "<br><br>", $content);
                                    $content = preg_replace("/(<br\s*\/?><br\s*\/?><br\s*\/?>\s*)+/", "<br><br>", $content); 

                                    if( $content != null ) {
                                        // Increment the AI user usage count
                                        $user->ai_month_count = $user->aiGeneratedContentMonthCounts() + 1;
                                        $user->ai_total_count = $user->aiGeneratedContentTotalCounts() + 1;
                                        $user->save();

                                        return response()->json(['success' => ['content' => $content]], 200 );

                                    } else {
                                        return response()->json(['errors' => ['message' => __('The content is empty.')]], 419 );
                                    }
                                    
                                } else {
                                    return response()->json(['errors' => ['message' => __('The response is empty.')]], 419 );
                                }
                            } else {
                                return response()->json(['errors' => ['message' => __('Provide three skills in order of importance.')]], 419 );
                            } 
                        } else {
                            return response()->json(['errors' => ['message' => __('Provide your target job title and company name.')]], 419 );
                        }
                    } else {
                        return response()->json(['errors' => ['message' => __('Provide your years of experience.')]], 419 );
                    }
                } else {
                    return response()->json(['errors' => ['message' => __('Provide your professional title.')]], 419 );
                }
            } else {
                return response()->json(['errors' => ['message' => __('Your plan does not allow creation of more AI-Generated content.')]], 419 );
            }
        } else {
            return response()->json(['errors' => ['message' => __('OpenAI Integration not enabled or the api key is invalid.')]], 419 );
        }
        return false;
    }

    public function previewUserCoverLetterTemplate(Request $request) {
        $user = Auth::user();
        $settings = Setting::first();

        $request->validate([
            'item_id'   => ['required', 'integer'],
            'template_id'   => ['sometimes', 'nullable'],
        ],[
            'item_id.required' => __('The Item Id is required.'),
            'template_id.required' => __('The Template Id is required.')
        ]);

        if($request->item_id!=null) {

            $coverLetterId = (int) $request->item_id;
            
            $item = CoverLetter::where('id', $coverLetterId)->where('user_id', '=', $user->id)->firstOrFail();

            if( $request->template_id!=null && $request->template_id != 'undefined' ) {

                $coverLetterTemplateId = (int) $request->template_id;

                // Change Cover Letter Template
                $item->template = $coverLetterTemplateId;

                $item->save();
            }

            $coverLetter = CoverLetter::where('id', $coverLetterId)->where('user_id', '=', $user->id)->firstOrFail();

            $itemTemplate = $coverLetter->template;

            if($coverLetter!=null && $coverLetter->cover_letter_id!=null) {
                return view('dashboard.user.cover-letters.templates.template-'. $itemTemplate, compact('user', 'settings', 'coverLetter'));
            } else {
                return '';
            }

        } else {
            return response()->json(['errors' => ['message' => __('Provide the cover letter id.')]], 419 );
        }
    }

    public function resetCoverLetterTemplateColors(Request $request) {
        $user = Auth::user();
        $settings = Setting::first();

        $request->validate([
            'item_id'   => ['sometimes', 'nullable'],
            'template_id'   => ['required', 'integer'],
        ],[
            'item_id.required' => __('The Item Id is required.'),
            'template_id.required' => __('The Template Id is required.')
        ]);

        if($request->template_id!=null) {

            $coverLetterTemplateId = (int) $request->template_id;
        
            if( $request->item_id!=null && $request->item_id != 'undefined' ) {
                $coverLetterId = (int) $request->item_id;

                $item = CoverLetter::where('id', $coverLetterId)->where('user_id', '=', $user->id)->firstOrFail();

                // Reset Color Palettes
                $item->top_colors = null;

                $item->save();

            } else {
               $item = new CoverLetter(); 
            }

            $template = Template::where('status', '=', '1')
                                ->where('type', '=', 'C')
                                    ->where('resource_id', '=', $coverLetterTemplateId)->firstOrFail();

            if($template!=null && $template->resource_id!=null) {
                return view('dashboard.user.cover-letters.template-colors', compact('user', 'settings', 'item', 'template'));
            } else {
                return '';
            }

        } else {
            return response()->json(['errors' => ['message' => __('Provide the template id.')]], 419 );
        }
    }

    public function resetCoverLetterColorPalette(Request $request) {
        $user = Auth::user();

        $request->validate([
            'palette'  => ['required', 'string'],
            'item_id'   => ['required', 'integer'],
        ],[
            'palette.required' => __('The Color Palette is required.'),
            'item_id.required' => __('The Item Id is required.')
        ]);

        if($request->palette!=null && $request->item_id!=null) {

            $colorPalette = (string) $request->palette;
            $coverLetterId = (int) $request->item_id;

            $colorPaletteArray = ['top-color', 'sidebar-color', 'content-color'];

            if( in_array($colorPalette, $colorPaletteArray) && is_numeric($coverLetterId) ) {

                $coverLetter = CoverLetter::where('id', '=', $coverLetterId)->where('user_id', $user->id)->firstOrFail();

                switch($colorPalette) {
                    case 'top-color':
                        $coverLetter->top_colors = null;
                    break;
                    case 'sidebar-color':
                    break;
                    case 'content-color':
                    break;
                }

                $coverLetter->save();

                return response()->json(["success" => __('Cover Letter Color Palette Reset Successfully.')], 200);

            } else {
                return response()->json(['errors' => ['message' => __('Provide a valid color palette name.')]], 419 );
            } 
        } else {
            return response()->json(['errors' => ['message' => __('Provide the color palette and cover letter id.')]], 419 );
        }
            
        return false;
    }

    public function exportUserPdfCoverLetter($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        $coverLetter = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                            ->where('cover_letters.id', '=', $id)
                                ->where('cover_letters.user_id', '=', $user->id)
                                    ->where('cover_letters.status', '=', '1')
                                        ->select('cover_letters.id as cl_id', 'cover_letters.status as cl_status', 'cover_letters.privacy as cl_privacy', 'cover_letters.*', 'users.*')
                                            ->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $template = Template::where('status', '=', '1')
                        ->where('type', '=', 'C')
                            ->where('resource_id', '=', $coverLetter->template)->firstOrFail();

        $watermark = ( config('settings.watermark') == '1'
                        && $plan->features!=null 
                            && $plan->features->white_label_cover_letters!=null 
                                && $plan->features->white_label_cover_letters == '0' ) 
                                    ? '1' : '0';

        $exportCoverLetter = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_cover_letters!=null 
                                    && $plan->features->export_cover_letters == '0' ) 
                                      ? '0' : '1' ) : '1' );

        $pdf = PDF::loadView('dashboard.user.cover-letters.pdf', ['user' => $user, 'settings' => $settings, 'coverLetter' => $coverLetter, 'template' => $template, 'watermark' => $watermark])->setPaper('a4', 'portrait');

        // Watermark
        if($watermark == true) {
            // Instantiate canvas instance 
            $pdf->setPaper('A4');
            $pdf->output();
            $canvas = $pdf->getDomPDF()->getCanvas();
             
            // Get height and width of page 
            $w = $canvas->get_width(); 
            $h = $canvas->get_height(); 
             
            // Specify watermark image 
            $imageURL = config('app.logo');

            // Set image width
            $imgWidth = config('settings.watermark_dimension_width')!=null ? (int) config('settings.watermark_dimension_width') : 50;

            // Set image height
            $imgHeight = config('settings.watermark_dimension_height')!=null ? (int) config('settings.watermark_dimension_height') : 50;
             
            // Set image opacity 
            $imgBackgroundOpacity = config('settings.watermark_background_opacity')!=null ? (float) config('settings.watermark_background_opacity') : 0.2;

            $canvas->set_opacity((float) $imgBackgroundOpacity, "Multiply");

            $canvas->set_opacity((float) $imgBackgroundOpacity);
             
            // Specify horizontal and vertical position
            $imgLeftPosition = config('settings.watermark_position_left')!=null ? (int) config('settings.watermark_position_left') : 15;
            $imgBottomPosition = config('settings.watermark_position_bottom')!=null ? (int) config('settings.watermark_position_bottom') : 15;
            
            $x = (int) $imgLeftPosition; 
            $y = (($h-$imgHeight) - (int) $imgLeftPosition); 
             
            // Add an image to the pdf 
            $canvas->image($imageURL, $x, $y, $imgWidth, $imgHeight); 

            //$canvas->page_text($w/3, $h/2, config('app.name'), null, 55, array(0,0,0),2,2,-30); // Text Watermark
        }

        $pdfFileName = preg_replace('/\s+/', '_', Str::lower($user->firstname. ' '. $user->lastname .' '. $coverLetter->name));

        if($exportCoverLetter == '1') {

            // View PDF file
            // return $pdf->stream();

            // Export User PDF file with download method
            return $pdf->download($pdfFileName .'_'. now()->format('mdY') .'.pdf');

        } else {
            abort(404);
        }
           
    }

    public function exportUserTxtCoverLetter($id = null, $mode = 'download'){
        $user = Auth::user();
        $settings = Setting::first();

        $coverLetter = CoverLetter::join('users', 'users.id', '=', 'cover_letters.user_id')
                            ->where('cover_letters.id', '=', $id)
                                ->where('cover_letters.user_id', '=', $user->id)
                                    ->where('cover_letters.status', '=', '1')
                                        ->select('cover_letters.id as cl_id', 'cover_letters.status as cl_status', 'cover_letters.privacy as cl_privacy', 'cover_letters.*', 'users.*')
                                            ->firstOrFail();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $exportCoverLetter = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_cover_letters!=null 
                                    && $plan->features->export_cover_letters == '0' ) 
                                      ? '0' : '1' ) : '1' );

        // Cover Letter Text
        $record_txt = $user->firstname ." ". $user->lastname ."\n";

        // Professional Title
        if($user->occupation!=null) {
            $record_txt .= $user->occupation ."\n\n";
        }

        // Contact Area
        $record_txt .= $user->address!=null ? ( ( $user->address->street!=null ? $user->address->street ."\n" : "" ) . ( $user->address->city!=null ? $user->address->city : "" ) . ( $user->address->state!=null ? ", ". $user->address->state : "" ) . ( $user->address->postal!=null ? ", ". $user->address->postal : "" ) ) ."\n" : null;
        $record_txt .= $user->phone!=null ? $user->phone ."\n" : null;
        $record_txt .= $user->email!=null ? $user->email ."\n" : null;

        // Datetime local format
        $record_txt .= "\n\n". mb_ucwords(Carbon::now()->locale(config('settings.language'))->translatedFormat('M d, Y')) ."\n\n";

        // Hiring Employer Area
        if($coverLetter->employer!=null) {
            $record_txt .= ( $coverLetter->employer->employer_name!=null ? trim($coverLetter->employer->employer_name) ."\n" : "" );
            $record_txt .= ( $coverLetter->employer->company_name!=null ? trim($coverLetter->employer->company_name) ."\n" : "" );
            $record_txt .= ( $coverLetter->employer->company_location!=null ? trim($coverLetter->employer->company_location) ."\n" : "" );
            $record_txt .= ( $coverLetter->employer->company_phone!=null ? trim($coverLetter->employer->company_phone) ."\n" : "" );
            $record_txt .= ( $coverLetter->employer->company_email!=null ? trim($coverLetter->employer->company_email) ."\n\n" : "\n" );
        
            // Reference section
            $record_txt .= ( ( $coverLetter->employer->job_title!=null ? __('RE') .": ". $coverLetter->employer->job_title ."," : "" ) . ( $coverLetter->employer->job_reference!=null ? "Ref#". $coverLetter->employer->job_reference ."," : "" ) . ( $coverLetter->employer->job_reference_date!=null ? mb_ucwords(Carbon::parse($coverLetter->employer->job_reference_date)->locale(config('settings.language'))->translatedFormat('M Y')) ."\n\n" : "\n" ) );

            // Greeting section
            $record_txt .= "\n". __('Dear') ." ". $coverLetter->employer->employer_name .",\n\n";
        }

        // Body Content Area
        if($coverLetter->content!=null) {

            $content = preg_replace("/<br\W*?\/?>/", "\n", $coverLetter->content);

            $record_txt .= trim(strip_tags($content)) ."\n\n";
        }

        // Closing Section
        $record_txt .= "\n". __('Sincerely') .",\n";

        // Signature Section
        $record_txt .= $user->firstname .' '. $user->lastname ."\n\n";

        if($exportCoverLetter == '1') {

            if( $mode == 'download' ) {

                $txtFileName = preg_replace('/\s+/', '_', Str::lower($user->firstname. ' '. $user->lastname .' '. $coverLetter->name));

                header('Content-disposition: attachment; filename='. $txtFileName .'_'. now()->format('mdY') .'.txt');
                header('Content-type: text/plain; charset=utf-8');
            }

            // Strip HTML tags in JSON output
            $txt = preg_replace('/<[^>]*>/', '', $record_txt);

            return $txt;
        } else {
            abort(404);
        }
    }

    public function coverLetterCreateUpdate($id = null){
        $user = Auth::user();

        $settings = Setting::first();

        $templates = Template::where('status', '=', '1')->where('type', '=', 'C')->get();

        $plan = Plan::join('users', 'users.plan_id', '=', 'plans.id')
                        ->where('users.id', '=', $user->id )->firstOrFail();

        $exportCoverLetter = ( ( config('settings.subscription') == '1' ) ? ( ( $plan->features!=null 
                                && $plan->features->export_cover_letters!=null 
                                    && $plan->features->export_cover_letters == '0' ) 
                                      ? '0' : '1' ) : '1' );

        $watermark = ( config('settings.watermark') == '1'
                        && $plan->features!=null 
                            && $plan->features->white_label_cover_letters!=null 
                                && $plan->features->white_label_cover_letters == '0' ) 
                                    ? '1' : '0';

        $cover_letter_left = $user->canCreateNewCoverLetter()['number'];

        $aiGeneratedContentLeft = $user->canCreateNewAIGeneratedContent()['number'];
        $aiGeneratedContentDescription = $user->canCreateNewAIGeneratedContent()['description'];

        if ($id == null){
            $item = null;
            $template = Template::where('status', '=', '1')
                            ->where('type', '=', 'C')
                                ->where('resource_id', '=', '1')->firstOrFail();
            if( $cover_letter_left == 0 ) {
                return back()->with(['message' => __('Your plan does not allow creation of more cover letters.'), 'type' => 'success']);
            }
        } else {
            // Allow only users who created the cover letter, not even the admins
            $item = CoverLetter::where('id', $id)->where('cover_letters.user_id', '=', $user->id)->firstOrFail();
            $template = Template::where('status', '=', '1')
                            ->where('type', '=', 'C')
                                ->where('resource_id', '=', $item->template)->firstOrFail();
        }
            
        return view('dashboard.user.cover-letters.edit', compact('user', 'item', 'template', 'settings', 'templates', 'watermark', 'exportCoverLetter', 'aiGeneratedContentLeft', 'aiGeneratedContentDescription'));
        
    }

    public function coverLetterCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = CoverLetter::where('id', $request->item_id)->where('user_id', $user->id)->firstOrFail();
        } else {
            $item = new CoverLetter();
        }

        $template = Template::where('status', '=', '1')
                        ->where('type', '=', 'C')
                            ->where('resource_id', '=', $request->template)->firstOrFail();

        // Save User Profile Information
        $request->validate([
            'firstname'  => ['required', 'string', 'max:20'],
            'lastname'   => ['required', 'string', 'max:35'],
            'phone'      => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'street'     => ['sometimes', 'nullable', 'string', 'max:255'],
            'city'       => ['sometimes', 'nullable', 'string', 'max:100'],
            'state'      => ['sometimes', 'nullable', 'string', 'max:255'],
            'postal'     => ['sometimes', 'nullable', 'string', 'max:10'],
            'country'    => ['sometimes', 'nullable', 'string', 'max:255'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' => __('The Last Name field is required.')
        ]);

        // Update the user's billing information
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->phone = $request->phone;

        $user->address = [
            'street' => $request->street,
            'city' => $request->city, 
            'state' => $request->state,
            'postal' => $request->postal, 
            'country' => $request->country,
        ];

        $user->save();

        // Save Cover Letter Information
        $requiredCoverLetterRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'cover_letter_id' => ['required', 'alpha_num', 'min:16', 'max:16', 'unique:cover_letters,cover_letter_id,'. $request->item_id],
            'name' => [$requiredCoverLetterRule, 'string', 'max:255'],
            'content' => [$requiredCoverLetterRule, 'string'],
            'template' => [$requiredCoverLetterRule, 'integer'],
            'tpl_topbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophdtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_tophddesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbgcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubtltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubbltxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'tpl_topsubdesctxtcolor' => ['sometimes', 'nullable', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
            'professional_title' => [$requiredCoverLetterRule, 'string', 'max:60'],
            'professional_yoe' => [$requiredCoverLetterRule, 'integer', 'min:0'],
            'privacy' => [$requiredCoverLetterRule, 'integer', Rule::in(['0','1','2'])],
            'password' => [(in_array($request->privacy, [0, 1]) ? 'nullable' : 'required'), 'string', 'min:1', 'max:128'],
            'job_title' => ['required', 'string', 'max:255'],
            'employer_name' => ['required', 'string', 'max:255'],
            'company_name' => ['required', 'string', 'max:255'],
            'company_location' => ['required', 'string', 'max:255'],
            'company_phone' => ['sometimes', 'nullable', 'regex:/^\+[1-9]\d{10,14}$/', 'min:8', 'max:15'], // E164 phone numbers
            'company_email' => ['sometimes', 'nullable', 'string', 'email', 'max:255'],
            'job_reference' => ['sometimes', 'nullable', 'string', 'max:255'],
            'job_reference_date' => ['sometimes', 'nullable', 'date_format:Y-m'],
            'skills' => ['sometimes', 'nullable'],
        ],[
            'name.required' => __('The Name field is required.'),
            'content.required' => __('The Content field is required.'),
            'professional_title.required' => __('The Professional Title field is required.'),
            'professional_yoe.required' => __('The Professional Yoe field is required.'),
            'privacy.required' => __('The Privacy field is required.'),
            'privacy.integer' => __('The Privacy field must be an integer.'),
            'privacy.in' => __('The selected Privacy is invalid.'),
            'password.required' => __('The Password field is required.'),
            'job_title.required' => __('The Job Title field is required.'),
            'employer_name.required' => __('The Employer Name field is required.'),
            'company_name.required' => __('The Company Name field is required.'),
            'company_location.required' => __('The Company Location field is required.')
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->user_id = $user->id;
        $item->cover_letter_id = $request->cover_letter_id;
        $item->name = $request->name;
        $item->content = $request->content;

        // Template
        $item->template = $request->template;

        // Template Top Color
        $top_colors = [
            'background' => $template->top_colors->background == 'Yes' ? $request->tpl_topbgcolor : null,
            'header_background' => $template->top_colors->header_background == 'Yes' ? $request->tpl_tophdbgcolor : null,
            'header_title' => $template->top_colors->header_title == 'Yes' ? $request->tpl_tophdtltxtcolor : null,
            'header_description' => $template->top_colors->header_description == 'Yes' ? $request->tpl_tophddesctxtcolor : null,
            'subheader_background' => $template->top_colors->subheader_background == 'Yes' ? $request->tpl_topsubbgcolor : null,
            'subheader_title' => $template->top_colors->subheader_title == 'Yes' ? $request->tpl_topsubtltxtcolor : null,
            'subheader_byline' => $template->top_colors->subheader_byline == 'Yes' ? $request->tpl_topsubbltxtcolor : null,
            'subheader_description' => $template->top_colors->subheader_description == 'Yes' ? $request->tpl_topsubdesctxtcolor : null
        ];

        $item->top_colors = $top_colors;

        // Professional Title
        $item->professional_title = $request->professional_title;
        $item->professional_yoe = $request->professional_yoe;

        // Privacy
        $item->privacy = $request->privacy;

        // Password protected cover letter only when privacy is set to 2
        $item->password = $item->privacy == 2 ? $request->password : null;

        // Employer information
        $item->employer = [
            'job_title' => $request->job_title,
            'employer_name' => $request->employer_name, 
            'company_name' => $request->company_name,
            'company_location' => $request->company_location, 
            'company_phone' => $request->company_phone,
            'company_email' => $request->company_email,
            'job_reference' => $request->job_reference,
            'job_reference_date' => $request->job_reference_date,
        ];

        $item->skills = $request->skills;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Cover Letter :name', ['name' => $item->name]), null);

        return response()->json(["success" => __('Cover Letter Saved Succesfully.')], 200);

        return back()->with(['message' => __('Cover Letter Saved Succesfully.'), 'type' => 'success']);
    }

    public function coverLetterClone($id){
        $user = Auth::user();

        $cover_letter_left = $user->canCreateNewCoverLetter()['number'];

        if($cover_letter_left != 0) {

            // Retrieve the cover letter, and make sure the user is the owner
            $item = CoverLetter::where('id', $id)->where('user_id', $user->id)->firstOrFail();

            $newItem = $item->replicate();
            $newItem->name = $item->name .' '. __('Cloned');
            $newItem->cover_letter_id = Str::random(16);
            $newItem->created_at = Carbon::now ();
            $newItem->updated_at = Carbon::now ();
            $newItem->save();

            Activity::createUserActivity($user->id, __('Cloned'), __('Cover Letter :name', ['name' => $item->name]), null);

            return back()->with(['message' => __('Cover Letter Cloned Succesfully.'), 'type' => 'success']);
        }
    }

    public function coverLetterDelete($id){
        $user = Auth::user();

        // Retrieve the cover letter, and make sure the user is the owner
        $item = CoverLetter::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $item->delete();

        Activity::createUserActivity($user->id, __('Deleted'), __('Cover Letter :name', ['name' => $item->name]), null);

        return response()->json(["success" => __('Cover Letter Deleted Succesfully.')], 200);

        return back()->with(['message' => __('Cover Letter Deleted Succesfully.'), 'type' => 'success']);
    }
}
