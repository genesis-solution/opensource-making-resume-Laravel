<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Laravel\Socialite\Facades\Socialite;

class SocialController extends Controller
{
    /**
    * Handle Social login request
    *
    * @return response
    */

    public function socialLogin($social)
    {
        return Socialite::driver($social)->redirect();
    }

    /**
    * Obtain the user information from Social Logged in.
    * @param $social
    * @return Response
    */

    public function handleProviderCallback($social)
    {

        // Stateless oAuth does not work with Twitter
        if($social == 'twitter') {
            $userSocial = Socialite::driver($social)->user();
        } else {
            $userSocial = Socialite::driver($social)->stateless()->user();
        }

        $finduser = User::where(['email' => $userSocial->getEmail()])->first();
       
        if($finduser){

            Auth::login($finduser);
            return redirect()->route('dashboard.index');

        } else {

           return view('auth.register',['name' => $userSocial->getName(), 'email' => $userSocial->getEmail()]);

       }
    }
}
