<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BuilderController extends Controller
{
    // public function index(){
    //     return view('newfrontend.index');
    // }


    public function job_description(){
        return view('newfrontend.builder.job_description');
    }
    public function job_review(){
        return view('newfrontend.builder.job_review');
    }
    public function education_review(){
        return view('newfrontend.builder.education_review');
    }
    public function how_its_work(){
        return view('newfrontend.builder.how_its_work');
    }
    public function AI_module(){
        return view('newfrontend.builder.AI_module');
    }
    public function languages(){
        return view('newfrontend.builder.languages');
    }
    public function additional_sections(){
        return view('newfrontend.builder.additional_sections');
    }
    public function other(){
        return view('newfrontend.builder.other');
    }
    public function finalize(){
        return view('newfrontend.builder.finalize');
    }
    public function upgrade(){
        return view('newfrontend.builder.upgrade');
    }
    public function payout(){
        return view('newfrontend.builder.payout');
    }

function generateResumeContent($profession)
{
    // Define your OpenAI API key
    $apiKey = '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';

    // Prepare prompt based on the selected profession
    $prompt = "As a $profession, ";

    // Set up data to send to the API
    $data = [
        'prompt' => $prompt,
        'max_tokens' => 200, // Maximum length of generated content
        'temperature' => 0.7, // Controls randomness of generated text (optional)
        'top_p' => 1, // Controls diversity of generated text (optional)
        'n' => 1, // Number of completions to generate (optional)
        'model' => 'gpt-3.5-turbo' // Use the new model `text-davinci`
    ];

    // Set up cURL request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);

    // Execute the cURL request
    $response = curl_exec($ch);
  dd($response);
    // Check for errors
    if (curl_errno($ch)) {
        // Handle error
        $error = curl_error($ch);
        curl_close($ch);
        return "Error: $error";
    }

    // Close cURL session
    curl_close($ch);

    // Parse and return the generated content from the API response
    $responseData = json_decode($response, true);
    if (isset($responseData['choices'][0]['text'])) {
        return $responseData['choices'][0]['text'];
    } else {
        // Log the response for debugging
        error_log(print_r($responseData, true));
        return "Error: Failed to fetch content from the AI API.";
    }
}


 public function generate(Request $request)
{
    $profession = $request->input('profession');
    $resumeContent = $this->generateResumeContent($profession); // Corrected syntax
    dd($resumeContent);
    return $resumeContent;
}


}