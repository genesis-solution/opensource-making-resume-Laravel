<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Resume_templateController extends Controller
{
    public function index(){
        return view('newfrontend.template.resume_template');
    }


    public function Resume_template_3(){
        return view('newfrontend.template.3_Resume_template');
    }

    public function Resume_template_4(){
        return view('newfrontend.template.4_Resume_template');
    }

    public function Resume_template_5(){
        return view('newfrontend.template.5_Resume_template');
    }
}