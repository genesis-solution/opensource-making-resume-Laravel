<?php

namespace App\Http\Controllers\frontend\Resume_template;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Resume_template1Controller extends Controller
{
    public function index(){
        return view('newfrontend.template.1_Resume_template');
    }

    public function updateContactInfo(Request $request)
    {
        // Process form data
        $name = $request->input('name');
        $address = $request->input('address');
        $city = $request->input('city');
        $state = $request->input('state');
        $country = $request->input('country');
        $email = $request->input('email');
        $phone = $request->input('phone');
    
        // You can customize the resume template here using the form data
    
        // Return the updated resume template with the data
        return view('newfrontend.template.1_Resume_template', [
            'name' => $name,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'country' => $country,
            'email' => $email,
            'phone' => $phone,
        ]);
    }
    
    
    
}
