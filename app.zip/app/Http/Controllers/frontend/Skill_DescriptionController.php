<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Skill_DescriptionController extends Controller
{
    public function index(){
        return view('newfrontend.builder.skill_description');
    }
}
