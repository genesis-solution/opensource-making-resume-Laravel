<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Summary_DetailsController extends Controller
{
    public function index(){
        return view('newfrontend.builder.summary_details');
    }
}
