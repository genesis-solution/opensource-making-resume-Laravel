<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Activity;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class CategoryController extends Controller
{
    // Category
    public function index(){
        $items = Category::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.frontend.categories.index', compact('items', 'settings'));
    }

    public function categoryCreateUpdate($id = null){

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Category::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.frontend.categories.edit', compact('item', 'settings'));
    }

    public function categoryCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Category::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Category();
        }

        $requiredCategoryRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'title' => [$requiredCategoryRule, 'string', 'max:255'],
            'slug' => [$requiredCategoryRule, 'string', 'max:255'],
            'blog_order' => [$requiredCategoryRule, 'integer'],
            'faq_order' => [$requiredCategoryRule, 'integer'],
            'footer_order' => [$requiredCategoryRule, 'integer'],
        ],[
            'title.required' =>  __('The Title field is required.'),
            'slug.required' =>  __('The Slug field is required.'),
            'blog_order.required' =>  __('The Blog Order field is required.'),
            'faq_order.required' =>  __('The FAQ Order field is required.'),
            'footer_order.required' =>  __('The Footer Order field is required.'),
        ]);

        $item->status = $request->status ? '1' : '0';
        $item->title = $request->title;
        $item->slug = Str::slug($request->slug);

        $item->blog_order = $request->blog_order;
        $item->faq_order = $request->faq_order;
        $item->footer_order = $request->footer_order;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Category Section'), null);

        return back()->with(['message' => __('Item Saved Succesfully.'), 'type' => 'success']);
    }

    public function categoryDelete($id){
        $item = Category::where('id', $id)->firstOrFail();
        $item->delete();

        return back()->with(['message' => __('Item Deleted Succesfully.'), 'type' => 'success']);
    }
}
