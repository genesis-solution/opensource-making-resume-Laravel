<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Setting;
use App\Models\User;
use App\Models\Plan;
use App\Models\TaxRate;
use App\Rules\ExtendedLicenseRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;

class PlanController extends Controller
{

    public function index()
    {
        $items = Plan::orderBy('created_at', 'desc')->paginate(10);

        $settings = Setting::first();

        return view('dashboard.admin.plans.index', compact('items', 'settings'));
    }

    public function planCreateUpdate($id = null){
        $taxRates = TaxRate::all()->where('status', '=', '1');

        $settings = Setting::first();

        if ($id == null){
            $item = null;
        } else {
            $item = Plan::where('id', $id)->firstOrFail();
        }

        return view('dashboard.admin.plans.edit', compact('item', 'settings', 'taxRates'));
    }

    public function planCreateUpdateSave(Request $request){

        $user = Auth::user();

        if ($request->item_id != 'undefined'){
            $item = Plan::where('id', $request->item_id)->firstOrFail();
        } else {
            $item = new Plan();
        }

        $requiredPlanRule = $request->status != '' ? 'required' : 'nullable';

        $request->validate([
            'name' => [$requiredPlanRule, 'string', 'max:64', new ExtendedLicenseRule()],
            'description' => [$requiredPlanRule, 'string', 'max:255'],
            'trial_days' => ['sometimes', 'integer', 'min:0', 'max:3650'],
            'tax_rates' => ['sometimes', 'nullable'],
            'amount_month' => [$requiredPlanRule, 'numeric', 'gte:0', 'max:9999999999'],
            'amount_year' => [$requiredPlanRule, 'numeric', 'gte:0', 'max:9999999999'],
            'order' => [$requiredPlanRule, 'integer', 'min:0'],
            'resumes' => [$requiredPlanRule, 'integer'],
            'cover_letters' => [$requiredPlanRule, 'integer'],
            'ai_generated_content' => [$requiredPlanRule, 'integer'],
            'offerings' => ['sometimes', 'nullable', 'string'],
        ],[
            'name.required' =>  __('The Name field is required.'),
            'description.required' =>  __('The Description field is required.'),
            'trial_days.required' =>  __('The Trial Days field is required.'),
            'trial_days.integer' =>  __('The Trial Days field must be an integer.'),
            'amount_month.required' =>  __('The Monthly field is required.'),
            'amount_month.numeric' =>  __('The Monthly field must be a number.'),
            'amount_month.gte' =>  __('The Monthly field must be greater than or equal to :value.'),
            'amount_year.required' =>  __('The Yearly field is required.'),
            'amount_year.numeric' =>  __('The Yearly field must be a number.'),
            'amount_year.gte' =>  __('The Yearly field must be greater than or equal to :value.'),
            'order.required' =>  __('The Order field is required.'),
            'resumes.required' =>  __('The Resumes field is required.'),
            'cover_letters.required' =>  __('The Cover Letters field is required.'),
            'ai_generated_content.required' =>  __('The AI Generated Content field is required.')
        ]);

        $plan_features = [
            'resumes' => $request->resumes, 
            'cover_letters' => $request->cover_letters, 
            'ai_generated_content' => $request->ai_generated_content, 
            'white_label_resumes' => $request->white_label_resumes ? '1' : '0', 
            'white_label_cover_letters' => $request->white_label_cover_letters ? '1' : '0',
            'resume_tailoring' => $request->resume_tailoring ? '1' : '0',
            'export_resumes' => $request->export_resumes ? '1' : '0',
            'export_cover_letters' => $request->export_cover_letters ? '1' : '0',
        ];

        $item->status = $request->status ? '1' : '0';
        $item->highlight = $request->highlight ? '1' : '0';
        $item->name = $request->name;
        $item->description = $request->description;
        $item->trial_days = $request->trial_days;
        $item->tax_rates = stringToArray($request->tax_rates);
        $item->amount_month = $request->amount_month;
        $item->amount_year = $request->amount_year;
        $item->order = $request->order;
        $item->features = $plan_features;
        $item->offerings = $request->offerings;

        $item->save();

        Activity::createUserActivity($user->id, __('Updated'), __('Plan :name', ['name' => $item->name]), null);

        return back()->with(['message' => __('Plan Saved Succesfully.'), 'type' => 'success']);
    }

    public function planDelete($id){
        // Delete plan id with exception to default plan
        $item = Plan::where('id', $id)->whereNotIn('id', [1])->first();

        if($item !=null) {
            $item->delete();
        }

        return response()->json(["success" => __('Plan Deleted Succesfully.')], 200);
        
        return back()->with(['message' => __('Plan Deleted Succesfully.'), 'type' => 'success']);
    }
}
