<?php

namespace App\Http\Middleware;

use App\Models\Setting;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class RestrictIpAddressMiddleware
{
	/**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): mixed
    {
    	// List of Blacklisted IP Addresses
    	$blacklistedIpAddresses = explode(',', config('settings.ip_blacklist', ''));
    	// List of Whitelisted IP Addresses
    	$whitelistedIpAddresses = explode(',', config('settings.ip_whitelist', ''));

    	// Priority whitelisted, allow  whitelisted, allow whitelisted that is blacklisted, deny blacklisted.
        if ( $whitelistedIpAddresses && !in_array($request->getClientIp(), $whitelistedIpAddresses, true) 
        		&& $blacklistedIpAddresses && in_array($request->getClientIp(), $blacklistedIpAddresses, true) ) {
            throw new AccessDeniedHttpException('Access Denied');
        }

        return $next($request);
    }
}
