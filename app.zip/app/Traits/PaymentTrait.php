<?php

namespace App\Traits;

use App\Models\Coupon;
use App\Models\Payment;
use App\Models\Plan;
use App\Models\TaxRate;
use Illuminate\Support\Str;

trait PaymentTrait
{

    private function paymentStore($params)
    {
        $payment = new Payment();
        $payment->user_id = $params['user_id'];
        $payment->plan_id = $params['plan_id'];
        $payment->payment_id = $params['payment_id'];
        $payment->processor = $params['processor'];
        $payment->amount = $params['amount'];
        $payment->currency = $params['currency'];
        $payment->interval = $params['interval'];
        $payment->payment_status = $params['payment_status'];
        $payment->product = Plan::select('id', 'name', 'amount_' . $params['interval'])->where('id', '=', $params['plan_id'])->first();
        $payment->coupon = $params['coupon'] ? Coupon::select('id', 'name', 'code', 'type', 'percentage')->where('id', '=', $params['coupon'])->first() : null;
        $payment->tax_rates = $params['tax_rates'] ? TaxRate::select('id', 'name', 'type', 'percentage')->whereIn('id', explode('_', $params['tax_rates']))->get() : null;
        $payment->customer = $params['customer'];
        $payment->seller = collect([
            'title' => config('settings.site_name'),
            'vendor' => config('settings.billing_vendor'),
            'street' => config('settings.billing_street'),
            'city' => config('settings.billing_city'),
            'state' => config('settings.billing_state'),
            'postal' => config('settings.billing_postal'),
            'country' => config('settings.billing_country'),
            'phone' => config('settings.billing_phone'),
            'vat_number' => config('settings.billing_vat_number')
        ]);

        // Store the invoice ID
        $payment->invoice_id = Str::lower( ( config('settings.billing_invoice_prefix') ?? 'INV' ) . str_replace(['ch_', 'in_', 'order_', 'pay_', 'pi_', 'sub_'], '', $params['payment_id']) );

        $payment->save();

        return $payment;
    }
}