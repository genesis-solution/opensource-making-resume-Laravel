<?php

namespace App\Traits;

use App\Models\User;
use App\Models\Resume;
use App\Models\CoverLetter;
use GuzzleHttp\Client as HttpClient;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Request;

trait OpenAITrait
{

    private function openAICompletions(Request $request, $prompt)
    {
        $httpClient = new HttpClient();

        $response = $httpClient->request('POST', 'https://api.openai.com/v1/chat/completions',
            [
                'timeout' => (int) config('settings.openai_request_timeout') * 60,
                'headers' => [
                    'User-Agent' => config('settings.openai_request_user_agent'),
                    'Authorization' => 'Bearer ' . config('settings.openai_key'),
                ],
                'json' => [
                    'model' => config('settings.openai_completions_model'),
                    'messages' => [
                        [
                            'role' => 'user',
                            'content' => trim(preg_replace('/(?:\s{2,}+|[^\S ])/ui', ' ', $prompt))
                        ]
                    ],
                    'temperature' => (int) config('settings.openai_creativity'),
                    'n' => (int) config('settings.openai_variations'),
                    'frequency_penalty' => 0.52,
                    'presence_penalty' => 0.5,
                    'user' => 'user' . $request->user()->id
                ]
            ]
        );

        return json_decode($response->getBody()->getContents(), true);
    }
}