<?php

namespace App\Actions\Fortify;

use App\Models\User;
use App\Models\Setting;
use Closure;
use App\Rules\ReCaptchaRule;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    public function create(array $input): User
    {
        Validator::make($input, [
            'firstname'  => ['required', 'string', 'max:255'],
            'lastname'   => ['required', 'string', 'max:255'],
            'email'      => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique(User::class),
                function (string $attribute, mixed $value, Closure $fail) {
                    if (!self::emailIsValid($value)) {
                        $fail(__('The email domain is blacklisted.'));
                    }
                },
            ],
            'password'   => $this->passwordRules(),
            'g-recaptcha-response' => ['required_if:Setting::first()->google_recaptcha, 1', new ReCaptchaRule],
        ])->validate();

        return User::create([
            'firstname'  => $input['firstname'],
            'lastname'   => $input['lastname'],
            'role'       => 'user',
            'email'      => $input['email'],
            'password'   => Hash::make($input['password']),
        ]);
    }

    // Check whether email domain is not blacklisted
    public static function emailIsValid(string $email): bool
    {
        $blacklistedDomains = explode(',', config('settings.domain_blacklist', ''));
        if ($blacklistedDomains) {
            $domain = explode('@', $email)[1] ?? null;
            if ($domain && in_array($domain, $blacklistedDomains)) {
                return false;
            }
        }

        return true;
    }
}
