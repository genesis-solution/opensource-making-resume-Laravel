<?php

namespace App\Actions\Fortify;

use App\Models\User;
use App\Models\Activity;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;

class UpdateUserProfileInformation implements UpdatesUserProfileInformation
{
    /**
     * Validate and update the given user's profile information.
     *
     * @param  array<string, string>  $input
     */
    public function update(User $user, array $input)
    {
        Validator::make($input, [
            'firstname'         => ['required', 'string', 'max:20'],
            'lastname'          => ['required', 'string', 'max:35'],
            'email'             => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users')->ignore($user->id),
            ],
            'phone'             => ['sometimes', 'nullable', 'min:8', 'max:15'], // E164 phone numbers
            'street'            => ['sometimes', 'nullable', 'string', 'max:255'],
            'city'              => ['sometimes', 'nullable', 'string', 'max:100'],
            'state'             => ['sometimes',' nullable', 'string', 'max:255'],
            'postal'            => ['sometimes', 'nullable', 'string', 'max:10'],
            'country'           => ['sometimes', 'nullable', 'string', 'max:255'],
            'occupation'        => ['sometimes', 'nullable', 'string', 'max:60'],
            'yoe'               => ['sometimes', 'nullable', 'integer', 'min:0'],
            'bio'               => ['sometimes', 'nullable', 'string', 'max:1000'],
            'timezone'          => ['required'],
            'profile_id'        => ['required', 'alpha_num', 'min:16', 'max:16', Rule::unique('users')->ignore($user->id)],
            'profile_password'  => [(in_array($input['privacy'], [0, 1]) ? 'nullable' : 'required'), 'string', 'min:1', 'max:128'],
            'privacy'           => ['required', 'integer', Rule::in(['0','1','2'])],
            'resume'            => ['sometimes', 'nullable', 'integer'],
            'facebook'          => ['sometimes', 'nullable', 'string', 'max:50'],
            'twitter'           => ['sometimes', 'nullable', 'string', 'max:15'],
            'linkedin'          => ['sometimes', 'nullable', 'string', 'max:50'],
            'pinterest'         => ['sometimes', 'nullable', 'string', 'max:50'],
            'youtube'           => ['sometimes', 'nullable', 'string', 'max:30'],
            'github'            => ['sometimes', 'nullable', 'string', 'max:39'],
            'behance'           => ['sometimes', 'nullable', 'string', 'max:50'],
            'instagram'         => ['sometimes', 'nullable', 'string', 'max:30'],
            'tiktok'            => ['sometimes', 'nullable', 'string', 'max:39'],
        ],[
            'firstname.required' => __('The First Name field is required.'),
            'lastname.required' =>  __('The Last Name field is required.'),
            'email.required' =>  __('The Email Address field is required.'),
            'email.email' =>  __('The Email Address field must be a valid email address.'),
            'timezone.required' =>  __('The Timezone field is required.'),
            'privacy.required' => __('The Privacy field is required.'),
            'privacy.integer' => __('The Privacy field must be an integer.'),
            'privacy.in' => __('The selected Privacy is invalid.'),
            'profile_password.required' => __('The Profile Password field is required.'),
        ])->validateWithBag('updateProfileInformation');

        if ($input['email'] !== $user->email &&
            $user instanceof MustVerifyEmail) {
            $this->updateVerifiedUser($user, $input);
        } else {

            $user->forceFill([
                'firstname'         => $input['firstname'],
                'lastname'          => $input['lastname'],
                'email'             => $input['email'],
                'phone'             => $input['full_phone'],
                'address'           => [
                    'street'    => $input['street'], 
                    'city'      => $input['city'], 
                    'state'     => $input['state'],
                    'postal'    => $input['postal'], 
                    'country'   => $input['country'],
                ],
                'occupation'        => $input['occupation'],
                'yoe'               => $input['yoe'],
                'bio'               => $input['bio'],
                'timezone'          => $input['timezone'],
                'profile_id'        => $input['profile_id'],
                'profile_password'  => isset($input['privacy']) && $input['privacy'] == '2' ? $input['profile_password'] : null,
                'privacy'           => $input['privacy'],
                'resume'            => isset($input['resume']) && $input['resume']!=null ? $input['resume'] : null,
                'sections'      => [
                    'employments'   => isset($input['employments']) && $input['employments']!=0 ? '1' : '0',
                    'volunteer'     => isset($input['volunteer']) && $input['volunteer']!=0 ? '1' : '0',
                    'projects'      => isset($input['projects']) && $input['projects']!=0 ? '1' : '0',
                    'education'     => isset($input['education']) && $input['education']!=0 ? '1' : '0',
                    'certificates'  => isset($input['certificates']) && $input['certificates']!=0 ? '1' : '0',
                    'awards'        => isset($input['awards']) && $input['awards']!=0 ? '1' : '0',
                    'publications'  => isset($input['publications']) && $input['publications']!=0 ? '1' : '0',
                    'languages'     => isset($input['languages']) && $input['languages']!=0 ? '1' : '0',
                    'skills'        => isset($input['skills']) && $input['skills']!=0 ? '1' : '0',
                    'interests'     => isset($input['interests']) && $input['interests']!=0 ? '1' : '0',
                    'references'    => isset($input['references']) && $input['references']!=0 ? '1' : '0',
                ],
                'availability'      => [
                    'monday'    => isset($input['monday']) && $input['monday']!=null ? join(', ', $input['monday']) : null,
                    'tuesday'   => isset($input['tuesday']) && $input['tuesday']!=null ? join(', ', $input['tuesday']) : null, 
                    'wednesday' => isset($input['wednesday']) && $input['wednesday']!=null ? join(', ', $input['wednesday']) : null,
                    'thursday'  => isset($input['thursday']) && $input['thursday']!=null ? join(', ', $input['thursday']) : null, 
                    'friday'    => isset($input['friday']) && $input['friday']!=null ? join(', ', $input['friday']) : null,
                    'saturday'  => isset($input['saturday']) && $input['saturday']!=null ? join(', ', $input['saturday']) : null,
                    'sunday'    => isset($input['sunday']) && $input['sunday']!=null ? join(', ', $input['sunday']) : null,
                ],
                'availability_status' => isset($input['availability_status']) && $input['availability_status']!=null ? '1' : '0',
                'preferences'      => [
                    'work_type'      => isset($input['work_type']) && $input['work_type']!=null ? join(', ', $input['work_type']) : null,
                    'work_location'  => isset($input['work_location']) && $input['work_location']!=null ? join(', ', $input['work_location']) : null,
                    'work_benefits'  => isset($input['work_benefits']) && $input['work_benefits']!=null ? join(', ', $input['work_benefits']) : null,
                ],
                'preferences_status' => isset($input['preferences_status']) && $input['preferences_status']!=null ? '1' : '0',
                'social'            => [
                    'facebook'  => $input['facebook'], 
                    'twitter'   => $input['twitter'], 
                    'linkedin'  => $input['linkedin'], 
                    'pinterest' => $input['pinterest'], 
                    'youtube'   => $input['youtube'],
                    'github'    => $input['github'],
                    'behance'   => $input['behance'],
                    'instagram' => $input['instagram'],
                    'tiktok'    => $input['tiktok'],
                ],
            ])->save();

            Activity::createUserActivity($user->id, __('Updated'), __('User Profile'), null);

            return back()->with('success', __('User Profile Saved Succesfully.'));
        }
    }

    /**
     * Update the given verified user's profile information.
     *
     * @param  array<string, string>  $input
     */
    protected function updateVerifiedUser(User $user, array $input): void
    {
        $user->forceFill([
            'firstname'         => $input['firstname'],
            'lastname'          => $input['lastname'],
            'email'             => $input['email'],
            'email_verified_at' => null,
        ])->save();

        Activity::createUserActivity($user->id, __('Updated'), __('User Profile'), null);

        $user->sendEmailVerificationNotification();
    }
}
