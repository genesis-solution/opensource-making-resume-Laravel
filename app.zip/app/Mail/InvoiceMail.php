<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class InvoiceMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var
     */
    public $invoice;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($invoice)
    {
        $this->invoice = (object) $invoice;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        $title = $this->invoice->subject;

        $data = [
            'level' => 'success',
            'introLines' => [( $this->invoice->payment_status == 'completed' ? __('The invoice is paid successfully.') : __('You have an unpaid invoice.') )],
            'outroLines' => null,
            'actionText' => __('Invoice'),
            'actionUrl' => route('dashboard.invoices.invoice', $this->invoice->id),
            'displayableActionUrl' => route('dashboard.invoices.invoice', $this->invoice->id),
        ];

        return $this->subject(formatTitle([$title, config('app.name')]))
                    ->attachData($this->invoice->pdf->output(), ( config('settings.billing_invoice_prefix') ?? 'INV' ). '#' . $this->invoice->payment_id .'.pdf')
                        ->markdown('vendor.notifications.email', $data);
    }
}
