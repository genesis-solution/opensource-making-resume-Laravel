<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class PaymentMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var
     */
    public $payment;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($payment)
    {
        $this->payment = $payment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        if ($this->payment->payment_status == 'completed') {
            $title = __('Payment completed');

            $data = [
                'level' => 'success',
                'introLines' => [__('The payment was successful.')],
                'outroLines' => null,
                'actionText' => __('Invoice'),
                'actionUrl' => route('dashboard.invoices.invoice', $this->payment->invoice_id),
                'displayableActionUrl' => route('dashboard.invoices.invoice', $this->payment->invoice_id),
            ];

        } else {
            $title = __('Payment cancelled');

            $data = [
                'level' => 'error',
                'introLines' => [__('The payment was cancelled.')],
                'outroLines' => null,
            ];
        }

        return $this->subject(formatTitle([$title, config('app.name')]))
                        ->markdown('vendor.notifications.email', $data);
    }
}
